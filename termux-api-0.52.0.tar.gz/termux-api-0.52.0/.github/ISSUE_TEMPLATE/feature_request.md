---
name: Feature request
about: Suggest a new feature for Termux:API application

---

<!--
IMPORTANT:

1. Support of Android 5.x - 6.x is finished.
2. Fill the template AFTER comments.
-->

**Feature description**
<!--
Describe the feature and why you want it.
-->

**Reference implementation**

Have you checked if the feature is accessible through the Android API?
Do you know of other open-source apps that has a similar feature as the one you want? (Provide links)
