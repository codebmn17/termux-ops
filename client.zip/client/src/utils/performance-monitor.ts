// Performance monitoring utilities for Quick-Load Startup Accelerator
export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: Map<string, number> = new Map();
  private startTime: number;

  private constructor() {
    this.startTime = performance.now();
  }

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  mark(name: string): void {
    this.metrics.set(name, performance.now() - this.startTime);
  }

  measure(name: string, startMark: string, endMark: string): number {
    const start = this.metrics.get(startMark) || 0;
    const end = this.metrics.get(endMark) || performance.now() - this.startTime;
    const duration = end - start;
    this.metrics.set(name, duration);
    return duration;
  }

  getMetric(name: string): number | undefined {
    return this.metrics.get(name);
  }

  getAllMetrics(): Record<string, number> {
    const result: Record<string, number> = {};
    this.metrics.forEach((value, key) => {
      result[key] = value;
    });
    return result;
  }

  reset(): void {
    this.metrics.clear();
    this.startTime = performance.now();
  }
}

// Preload critical resources
export function preloadResources(): void {
  // Preload fonts
  const fonts = [
    { name: 'Orbitron', weight: '400' },
    { name: 'Orbitron', weight: '700' },
    { name: 'Orbitron', weight: '900' }
  ];

  fonts.forEach(({ name, weight }) => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'font';
    link.href = `https://fonts.googleapis.com/css2?family=${name}:wght@${weight}&display=swap`;
    document.head.appendChild(link);
  });

  // Preload critical images
  const criticalImages = [
    '/assets/storm-echo-logo.svg',
    '/assets/galaxy-bg.webp'
  ];

  criticalImages.forEach(src => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = src;
    document.head.appendChild(link);
  });
}

// Optimize render performance
export function optimizeRenderPerformance(): void {
  // Enable CSS containment for better paint performance
  document.documentElement.style.contain = 'layout style paint';

  // Request idle callback for non-critical tasks
  if ('requestIdleCallback' in window) {
    requestIdleCallback(() => {
      // Load non-critical components
      import('@/components/holographic-display');
    });
  }
}

// Cache management
export class CacheManager {
  private static readonly CACHE_VERSION = 'v1';
  private static readonly CACHE_NAME = `storm-echo-${CacheManager.CACHE_VERSION}`;

  static async cacheResources(resources: string[]): Promise<void> {
    if ('caches' in window) {
      try {
        const cache = await caches.open(CacheManager.CACHE_NAME);
        await cache.addAll(resources);
      } catch (error) {
        console.warn('Failed to cache resources:', error);
      }
    }
  }

  static async getCached(request: string): Promise<Response | undefined> {
    if ('caches' in window) {
      try {
        const cache = await caches.open(CacheManager.CACHE_NAME);
        return await cache.match(request);
      } catch (error) {
        console.warn('Failed to get cached resource:', error);
      }
    }
    return undefined;
  }

  static async clearOldCaches(): Promise<void> {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      const oldCaches = cacheNames.filter(name => 
        name.startsWith('storm-echo-') && name !== CacheManager.CACHE_NAME
      );
      
      await Promise.all(oldCaches.map(name => caches.delete(name)));
    }
  }
}

// Resource hint utilities
export function addResourceHints(): void {
  // DNS prefetch for external domains
  const domains = [
    'https://fonts.googleapis.com',
    'https://fonts.gstatic.com'
  ];

  domains.forEach(domain => {
    const link = document.createElement('link');
    link.rel = 'dns-prefetch';
    link.href = domain;
    document.head.appendChild(link);
  });

  // Preconnect to critical domains
  const preconnectDomains = [
    'https://fonts.googleapis.com'
  ];

  preconnectDomains.forEach(domain => {
    const link = document.createElement('link');
    link.rel = 'preconnect';
    link.href = domain;
    link.crossOrigin = 'anonymous';
    document.head.appendChild(link);
  });
}

// Lazy load images with intersection observer
export function setupLazyLoading(): void {
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          const src = img.dataset.src;
          if (src) {
            img.src = src;
            img.removeAttribute('data-src');
            observer.unobserve(img);
          }
        }
      });
    });

    // Observe all images with data-src attribute
    document.querySelectorAll('img[data-src]').forEach(img => {
      imageObserver.observe(img);
    });
  }
}