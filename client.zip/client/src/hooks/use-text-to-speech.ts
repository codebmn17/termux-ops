import { useState, useEffect, useRef } from 'react';

interface VoiceSettings {
  pitch: number;
  rate: number;
  volume: number;
  voice: string;
}

export function useTextToSpeech() {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    pitch: 1,
    rate: 1,
    volume: 1,
    voice: ''
  });
  
  const speechSynthRef = useRef<SpeechSynthesis | null>(null);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    // Check if speech synthesis is supported
    if (typeof window === 'undefined') {
      return;
    }

    // Force detection - some browsers hide speechSynthesis until user interaction
    const checkSpeechSupport = () => {
      let synth = null;
      
      if ('speechSynthesis' in window) {
        synth = window.speechSynthesis;
      } else if ((window as any).webkitSpeechSynthesis) {
        synth = (window as any).webkitSpeechSynthesis;
      }
      
      if (synth) {
        speechSynthRef.current = synth;
        setIsSupported(true);
        console.log('Speech synthesis detected');
        
        const loadVoices = () => {
          try {
            const availableVoices = synth.getVoices();
            console.log('Available voices:', availableVoices.length, availableVoices.map((v: SpeechSynthesisVoice) => v.name));
            
            if (availableVoices.length > 0) {
              setVoices(availableVoices);
              
              // Auto-select best voice if none selected
              if (!voiceSettings.voice) {
                const englishVoices = availableVoices.filter((v: SpeechSynthesisVoice) => v.lang.startsWith('en'));
                const bestVoice = englishVoices.find((v: SpeechSynthesisVoice) => !v.name.includes('eSpeak')) || 
                                englishVoices[0] || 
                                availableVoices[0];
                
                if (bestVoice) {
                  setVoiceSettings(prev => ({ ...prev, voice: bestVoice.name }));
                  console.log('Auto-selected voice:', bestVoice.name);
                }
              }
            } else {
              console.log('No voices loaded yet, retrying...');
              setTimeout(loadVoices, 200);
            }
          } catch (error) {
            console.error('Error loading voices:', error);
          }
        };

        // Initial load
        loadVoices();
        
        // Listen for voice changes
        if (synth.onvoiceschanged !== undefined) {
          synth.onvoiceschanged = loadVoices;
        }
        
        // Aggressive retry strategy for different browsers
        const retryIntervals = [50, 100, 200, 500, 1000, 2000];
        retryIntervals.forEach(ms => setTimeout(loadVoices, ms));
        
        // Add user interaction event to trigger voice loading
        const handleUserInteraction = () => {
          try {
            synth.cancel();
            synth.resume();
            loadVoices();
            document.removeEventListener('click', handleUserInteraction);
            document.removeEventListener('touchstart', handleUserInteraction);
          } catch (e) {
            console.log('User interaction trigger failed');
          }
        };
        
        document.addEventListener('click', handleUserInteraction, { once: true });
        document.addEventListener('touchstart', handleUserInteraction, { once: true });
        
        // Force wake-up with silent utterance after a delay
        setTimeout(() => {
          try {
            const wakeUtterance = new SpeechSynthesisUtterance('');
            wakeUtterance.volume = 0;
            synth.speak(wakeUtterance);
            setTimeout(loadVoices, 100);
          } catch (e) {
            console.log('Wake utterance failed, but continuing...');
          }
        }, 500);
        
      } else {
        console.log('Speech synthesis not detected on initial load');
        setIsSupported(false);
        
        // Retry detection after user interaction
        const retryDetection = () => {
          if ('speechSynthesis' in window) {
            console.log('Speech synthesis found after user interaction');
            checkSpeechSupport();
            document.removeEventListener('click', retryDetection);
            document.removeEventListener('touchstart', retryDetection);
          }
        };
        
        document.addEventListener('click', retryDetection, { once: true });
        document.addEventListener('touchstart', retryDetection, { once: true });
      }
    };

    checkSpeechSupport();

    return () => {
      if (speechSynthRef.current) {
        speechSynthRef.current.cancel();
      }
    };
  }, []);

  const speak = (text: string) => {
    if (!text || !speechSynthRef.current || !isSupported) return;
    
    // Cancel any ongoing speech
    speechSynthRef.current.cancel();
    
    // Create utterance
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.pitch = voiceSettings.pitch;
    utterance.rate = voiceSettings.rate;
    utterance.volume = voiceSettings.volume;
    
    // Set voice
    if (voices.length > 0 && voiceSettings.voice) {
      const selectedVoice = voices.find(v => v.name === voiceSettings.voice);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
    }
    
    // Event handlers
    utterance.onstart = () => {
      setIsSpeaking(true);
      console.log('Speech started');
    };
    
    utterance.onend = () => {
      setIsSpeaking(false);
      console.log('Speech ended');
    };
    
    utterance.onerror = (event) => {
      setIsSpeaking(false);
      console.error('Speech error:', event.error);
    };
    
    currentUtteranceRef.current = utterance;
    
    // Speak
    try {
      speechSynthRef.current.speak(utterance);
    } catch (error) {
      console.error('Failed to speak:', error);
      setIsSpeaking(false);
    }
  };

  const stop = () => {
    if (speechSynthRef.current) {
      speechSynthRef.current.cancel();
      setIsSpeaking(false);
    }
  };

  const updateVoiceSettings = (settings: Partial<VoiceSettings>) => {
    setVoiceSettings(prev => ({ ...prev, ...settings }));
  };

  const forceLoadVoices = () => {
    if (speechSynthRef.current) {
      speechSynthRef.current.cancel();
      speechSynthRef.current.resume();
      
      // Create silent utterance to wake up system
      const wakeUtterance = new SpeechSynthesisUtterance('');
      wakeUtterance.volume = 0;
      speechSynthRef.current.speak(wakeUtterance);
      
      setTimeout(() => {
        const availableVoices = speechSynthRef.current?.getVoices() || [];
        console.log('Force loaded voices:', availableVoices.length);
        
        if (availableVoices.length > 0) {
          setVoices(availableVoices);
          
          // Auto-select first English voice if none selected
          if (!voiceSettings.voice) {
            const englishVoices = availableVoices.filter((v: SpeechSynthesisVoice) => v.lang.startsWith('en'));
            const bestVoice = englishVoices.find((v: SpeechSynthesisVoice) => !v.name.includes('eSpeak')) || 
                            englishVoices[0] || 
                            availableVoices[0];
            
            if (bestVoice) {
              setVoiceSettings(prev => ({ ...prev, voice: bestVoice.name }));
            }
          }
        }
      }, 200);
    }
  };

  return {
    speak,
    stop,
    isSpeaking,
    isSupported,
    voices,
    voiceSettings,
    updateVoiceSettings,
    forceLoadVoices
  };
}