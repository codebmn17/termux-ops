import { useState, useCallback } from 'react';

interface BluetoothDevice {
  id: string;
  name: string;
  connected: boolean;
}

export function useBluetoothSync() {
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectedDevice, setConnectedDevice] = useState<BluetoothDevice | null>(null);
  const [bleSupported, setBleSupported] = useState(() => 'bluetooth' in navigator);

  const checkBLESupport = useCallback(() => {
    return bleSupported;
  }, [bleSupported]);

  const broadcastBLESignal = useCallback(async (message: string = "Echo Sync Signal") => {
    if (!bleSupported) {
      console.log("📡 BLE not available on this system.");
      return false;
    }

    try {
      setIsConnecting(true);
      console.log(`📡 Broadcasting BLE Message: ${message}`);

      // Request Bluetooth device
      const device = await (navigator as any).bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['generic_access']
      });

      console.log("🔗 Waiting for connection...");
      
      // Connect to GATT server
      const server = await device.gatt.connect();
      
      console.log(`🔌 Connected to ${device.name || 'Unknown Device'}`);
      
      // Store connected device info
      setConnectedDevice({
        id: device.id,
        name: device.name || 'Unknown Device',
        connected: true
      });

      // Simulate message broadcast (actual implementation would depend on service characteristics)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log("✅ BLE Broadcast Complete");
      
      // Disconnect
      device.gatt.disconnect();
      setConnectedDevice(prev => prev ? { ...prev, connected: false } : null);
      setIsConnecting(false);
      
      return true;
    } catch (error) {
      console.error("BLE connection failed:", error);
      setIsConnecting(false);
      setConnectedDevice(null);
      return false;
    }
  }, [bleSupported]);

  const disconnectDevice = useCallback(() => {
    if (connectedDevice) {
      setConnectedDevice(null);
      console.log("🔌 Device disconnected");
    }
  }, [connectedDevice]);

  return {
    isConnecting,
    connectedDevice,
    bleSupported,
    broadcastBLESignal,
    disconnectDevice
  };
}