import { useState, useCallback } from 'react';

export function useAudioFrequency() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

  const audioSupported = 'AudioContext' in window || 'webkitAudioContext' in window;

  const checkAudioSupport = useCallback(() => {
    return audioSupported;
  }, [audioSupported]);

  const emitFrequency = useCallback(async (frequency: number = 963.0, duration: number = 5.0) => {
    if (!audioSupported) {
      console.log("🔇 Audio output not available. Skipping.");
      return false;
    }

    if (isPlaying) {
      console.log("🔇 Audio already playing. Skipping.");
      return false;
    }

    try {
      setIsPlaying(true);
      console.log(`🔊 Emitting frequency: ${frequency} Hz for ${duration}s`);

      // Create audio context
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      setAudioContext(ctx);

      // Create oscillator
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      // Connect nodes
      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      // Set frequency and type
      oscillator.frequency.setValueAtTime(frequency, ctx.currentTime);
      oscillator.type = 'sine';

      // Set volume (0.5 = 50%)
      gainNode.gain.setValueAtTime(0.5, ctx.currentTime);

      // Start and stop
      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + duration);

      // Wait for completion
      await new Promise(resolve => setTimeout(resolve, duration * 1000));

      console.log("✅ Frequency tone complete.");
      
      // Cleanup
      await ctx.close();
      setAudioContext(null);
      setIsPlaying(false);
      
      return true;
    } catch (error) {
      console.error("Audio playback failed:", error);
      setIsPlaying(false);
      setAudioContext(null);
      return false;
    }
  }, [isPlaying, audioSupported]);

  const stopFrequency = useCallback(async () => {
    if (audioContext && audioContext.state !== 'closed') {
      await audioContext.close();
      setAudioContext(null);
    }
    setIsPlaying(false);
  }, [audioContext]);

  return {
    isPlaying,
    audioSupported,
    emitFrequency,
    stopFrequency
  };
}