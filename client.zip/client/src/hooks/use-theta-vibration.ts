import { useState, useCallback, useRef } from 'react';

interface ThetaPattern {
  frequency: number;
  pattern: number[];
  intensity: number;
}

export function useThetaVibration() {
  const [isVibrating, setIsVibrating] = useState(false);
  const vibrateInterval = useRef<NodeJS.Timeout | null>(null);
  
  const thetaPatterns: Record<string, ThetaPattern> = {
    deep: {
      frequency: 4,
      pattern: [250, 250], // 4Hz = 250ms on, 250ms off
      intensity: 200
    },
    rem: {
      frequency: 6,
      pattern: [167, 167], // 6Hz = ~167ms on, ~167ms off
      intensity: 150
    },
    earth: {
      frequency: 7.83,
      pattern: [128, 128], // 7.83Hz = ~128ms on, ~128ms off
      intensity: 100
    },
    meditation: {
      frequency: 5,
      pattern: [200, 200], // 5Hz = 200ms on, 200ms off
      intensity: 175
    }
  };

  const startThetaVibration = useCallback((patternName: keyof typeof thetaPatterns = 'deep', duration: number = 10000) => {
    if (!('vibrate' in navigator)) {
      console.warn("Vibration API not supported on this device");
      return false;
    }

    if (isVibrating) {
      stopVibration();
    }

    const pattern = thetaPatterns[patternName];
    setIsVibrating(true);
    
    console.log(`🌊 Starting theta vibration: ${patternName} at ${pattern.frequency}Hz`);
    
    // Skip test vibration - we know it works from the test button
    console.log(`📳 Vibration API available, starting pattern...`);
    
    // Create continuous vibration pattern
    const vibratePattern = () => {
      if (navigator.vibrate) {
        const success = navigator.vibrate(pattern.pattern);
        console.log(`📳 Vibration cycle: ${success ? 'success' : 'failed'}`);
        return success;
      }
      return false;
    };
    
    // Start first vibration immediately
    const firstVibration = navigator.vibrate(pattern.pattern);
    console.log(`📳 First vibration: ${firstVibration ? 'success' : 'failed'}`);
    
    if (firstVibration) {
      // Continue vibration pattern
      const totalDuration = pattern.pattern[0] + pattern.pattern[1];
      vibrateInterval.current = setInterval(() => {
        if (!vibratePattern()) {
          // If vibration fails, stop the interval
          stopVibration();
        }
      }, totalDuration);
    } else {
      setIsVibrating(false);
      return false;
    }
    
    // Auto-stop after duration
    setTimeout(() => {
      stopVibration();
    }, duration);
    
    return true;
  }, []);

  const stopVibration = useCallback(() => {
    setIsVibrating(false);
    
    if (vibrateInterval.current) {
      clearInterval(vibrateInterval.current);
      vibrateInterval.current = null;
    }
    
    if (navigator.vibrate) {
      navigator.vibrate(0);
    }
    
    console.log("✅ Theta vibration stopped");
  }, []);

  const pulseTheta = useCallback((frequency: number = 4) => {
    if (!('vibrate' in navigator)) {
      console.warn("Vibration API not available");
      return false;
    }
    
    // Calculate pulse duration based on frequency
    const pulseDuration = Math.round(1000 / (frequency * 2));
    
    // Create a theta wave pulse pattern
    const pulsePattern = [];
    const cycles = Math.min(10, frequency * 2); // 2 seconds worth
    
    for (let i = 0; i < cycles; i++) {
      pulsePattern.push(pulseDuration, pulseDuration);
    }
    
    const success = navigator.vibrate(pulsePattern);
    console.log(`🌊 Theta pulse at ${frequency}Hz - ${success ? 'success' : 'failed'}`);
    
    return success;
  }, []);

  return {
    isVibrating,
    startThetaVibration,
    stopVibration,
    pulseTheta,
    thetaPatterns
  };
}