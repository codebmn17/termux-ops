import { useState, useCallback } from 'react';
import { useAudioFrequency } from './use-audio-frequency';
import { useBluetoothSync } from './use-bluetooth-sync';

type SyncMode = 'auto' | 'audio' | 'ble';

export function useEchoSync() {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMode, setSyncMode] = useState<SyncMode>('auto');
  const [syncStatus, setSyncStatus] = useState<string>('');
  
  const { isPlaying, audioSupported, emitFrequency } = useAudioFrequency();
  const { isConnecting, connectedDevice, bleSupported, broadcastBLESignal } = useBluetoothSync();

  const echoSync = useCallback(async (mode: SyncMode = 'auto') => {
    if (isSyncing || isPlaying || isConnecting) {
      console.log("🌐 Echo Sync already in progress...");
      return false;
    }

    setIsSyncing(true);
    setSyncMode(mode);
    setSyncStatus('Starting Echo Sync Companion...');
    console.log("🌐 Starting Echo Sync Companion...");

    try {
      let success = false;

      if (mode === "audio") {
        setSyncStatus('Emitting audio frequency...');
        success = await emitFrequency(963.0, 3.0); // Shorter duration for web
      } else if (mode === "ble") {
        setSyncStatus('Broadcasting BLE signal...');
        success = await broadcastBLESignal("Echo Sync Signal");
      } else if (mode === "auto") {
        if (bleSupported) {
          setSyncStatus('Auto mode: Attempting BLE first...');
          success = await broadcastBLESignal("Echo Sync Signal");
          
          if (!success && audioSupported) {
            setSyncStatus('BLE failed, falling back to audio...');
            success = await emitFrequency(963.0, 3.0);
          }
        } else if (audioSupported) {
          setSyncStatus('Auto mode: Using audio frequency...');
          success = await emitFrequency(963.0, 3.0);
        } else {
          setSyncStatus('No sync methods available');
          console.log("🔇 No sync methods available on this system.");
        }
      }

      if (success) {
        setSyncStatus('Echo Sync Complete');
        console.log("✅ Echo Sync Complete");
      } else {
        setSyncStatus('Echo Sync Failed');
        console.log("❌ Echo Sync Failed");
      }

      // Clear status after delay
      setTimeout(() => {
        setSyncStatus('');
        setIsSyncing(false);
      }, 2000);

      return success;
    } catch (error) {
      console.error("Echo Sync error:", error);
      setSyncStatus('Echo Sync Error');
      setTimeout(() => {
        setSyncStatus('');
        setIsSyncing(false);
      }, 2000);
      return false;
    }
  }, [isSyncing, isPlaying, isConnecting, bleSupported, audioSupported, emitFrequency, broadcastBLESignal]);

  const capabilities = {
    audio: audioSupported,
    ble: bleSupported,
    auto: audioSupported || bleSupported
  };

  return {
    isSyncing,
    syncMode,
    syncStatus,
    connectedDevice,
    capabilities,
    echoSync
  };
}