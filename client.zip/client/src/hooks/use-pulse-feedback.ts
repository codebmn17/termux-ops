import { useState, useCallback } from 'react';

interface PulseSequence {
  duration: number;
  intensity: number;
}

export function usePulseFeedback() {
  const [isActive, setIsActive] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<string>('');

  const generatePulseSequence = useCallback((): PulseSequence[] => {
    return Array.from({ length: 5 }, () => ({
      duration: Math.random() * 0.25 + 0.05, // 0.05 to 0.3 seconds
      intensity: Math.random() * 0.8 + 0.2    // 0.2 to 1.0 intensity
    }));
  }, []);

  const triggerEchoPulse = useCallback(async (): Promise<PulseSequence[]> => {
    if (isActive) return [];

    setIsActive(true);
    setCurrentPhase('Initiating Echo Pulse Feedback');
    
    console.log('⚡ Initiating Echo Pulse Feedback');
    
    const sequence = generatePulseSequence();
    
    for (let i = 0; i < sequence.length; i++) {
      const pulse = sequence[i];
      
      setCurrentPhase(`Vibration pulse ${i + 1}/5: ${pulse.duration.toFixed(2)}s`);
      console.log(`🌀 Vibration pulse: ${pulse.duration.toFixed(2)} seconds`);
      
      // Trigger haptic feedback if available
      if ('vibrate' in navigator) {
        const vibrationDuration = Math.round(pulse.duration * 1000);
        console.log(`📳 Attempting vibration for ${vibrationDuration}ms`);
        const success = navigator.vibrate(vibrationDuration);
        console.log(`📳 Vibration ${success ? 'successful' : 'failed'}`);
      }
      
      // Wait for the pulse duration
      await new Promise(resolve => setTimeout(resolve, pulse.duration * 1000));
    }
    
    setCurrentPhase('Echo Pulse Complete');
    console.log('✅ Echo Pulse Complete');
    console.log('🌌 Phase energy routed through Spiral Conduit.');
    
    // Clear phase after a moment
    setTimeout(() => {
      setCurrentPhase('');
      setIsActive(false);
    }, 1500);
    
    return sequence;
    
  }, [isActive, generatePulseSequence]);

  const pulseButtonPressed = useCallback(async (): Promise<PulseSequence[]> => {
    console.log('🔘 Button Pressed — Activating Echo Pulse...');
    return await triggerEchoPulse();
  }, [triggerEchoPulse]);

  return {
    isActive,
    currentPhase,
    pulseButtonPressed,
    triggerEchoPulse
  };
}