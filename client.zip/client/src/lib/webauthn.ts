import { apiRequest } from './queryClient';

export interface WebAuthnCredential {
  id: string;
  publicKey: ArrayBuffer;
  counter: number;
  createdAt: Date;
}

export interface BiometricAuthResult {
  success: boolean;
  credential?: WebAuthnCredential;
  error?: string;
  fallbackToPasscode?: boolean;
}

export class BiometricAuth {
  private static instance: BiometricAuth;
  private lockoutEndTime: number | null = null;
  private failedAttempts: number = 0;
  private readonly MAX_ATTEMPTS = 3;
  private readonly LOCKOUT_DURATION = 10 * 60 * 1000; // 10 minutes

  static getInstance(): BiometricAuth {
    if (!BiometricAuth.instance) {
      BiometricAuth.instance = new BiometricAuth();
    }
    return BiometricAuth.instance;
  }

  // Check if WebAuthn is supported
  isWebAuthnSupported(): boolean {
    return !!(
      window.PublicKeyCredential &&
      navigator.credentials &&
      navigator.credentials.create &&
      navigator.credentials.get
    );
  }

  // Check if platform authenticator (fingerprint/face) is available
  async isPlatformAuthenticatorAvailable(): Promise<boolean> {
    if (!this.isWebAuthnSupported()) return false;
    
    try {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch (error) {
      console.error('Error checking platform authenticator:', error);
      return false;
    }
  }

  // Check if currently locked out
  isLockedOut(): boolean {
    if (!this.lockoutEndTime) return false;
    
    if (Date.now() >= this.lockoutEndTime) {
      this.lockoutEndTime = null;
      this.failedAttempts = 0;
      return false;
    }
    
    return true;
  }

  // Get remaining lockout time in minutes
  getRemainingLockoutTime(): number {
    if (!this.lockoutEndTime) return 0;
    const remaining = Math.max(0, this.lockoutEndTime - Date.now());
    return Math.ceil(remaining / (60 * 1000));
  }

  // Register new biometric credential
  async registerBiometric(userId: string): Promise<BiometricAuthResult> {
    if (!this.isWebAuthnSupported()) {
      return { success: false, error: 'WebAuthn not supported', fallbackToPasscode: true };
    }

    if (!(await this.isPlatformAuthenticatorAvailable())) {
      return { success: false, error: 'No biometric authenticator available', fallbackToPasscode: true };
    }

    try {
      // Get registration options from server
      const optionsResponse = await apiRequest('POST', '/api/webauthn/register/begin', { userId });
      const options = optionsResponse.options;

      // Convert challenge and user ID to ArrayBuffer
      const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
        challenge: this.base64ToArrayBuffer(options.challenge),
        rp: options.rp,
        user: {
          id: this.stringToArrayBuffer(options.user.id),
          name: options.user.name,
          displayName: options.user.displayName,
        },
        pubKeyCredParams: options.pubKeyCredParams,
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
          requireResidentKey: false
        },
        timeout: 60000,
        attestation: 'direct'
      };

      // Create credential
      const credential = await navigator.credentials.create({
        publicKey: publicKeyCredentialCreationOptions
      }) as PublicKeyCredential;

      if (!credential) {
        return { success: false, error: 'Failed to create credential' };
      }

      // Send credential to server for verification
      const attestationResponse = credential.response as AuthenticatorAttestationResponse;
      const registrationData = {
        id: credential.id,
        rawId: this.arrayBufferToBase64(credential.rawId),
        response: {
          attestationObject: this.arrayBufferToBase64(attestationResponse.attestationObject),
          clientDataJSON: this.arrayBufferToBase64(attestationResponse.clientDataJSON),
        },
        type: credential.type,
      };

      const verificationResponse = await apiRequest('POST', '/api/webauthn/register/complete', {
        userId,
        credential: registrationData
      });

      if (verificationResponse.verified) {
        return { success: true, credential: verificationResponse.credential };
      } else {
        return { success: false, error: 'Failed to verify registration' };
      }
    } catch (error) {
      console.error('Biometric registration error:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Registration failed',
        fallbackToPasscode: true 
      };
    }
  }

  // Authenticate with biometric
  async authenticateBiometric(userId: string, purpose: 'admin' | 'killswitch' | 'settings'): Promise<BiometricAuthResult> {
    if (this.isLockedOut()) {
      return { 
        success: false, 
        error: `Locked out for ${this.getRemainingLockoutTime()} more minutes`,
        fallbackToPasscode: false 
      };
    }

    if (!this.isWebAuthnSupported()) {
      return { success: false, error: 'WebAuthn not supported', fallbackToPasscode: true };
    }

    if (!(await this.isPlatformAuthenticatorAvailable())) {
      return { success: false, error: 'No biometric authenticator available', fallbackToPasscode: true };
    }

    try {
      // Get authentication options from server
      const optionsResponse = await apiRequest('POST', '/api/webauthn/authenticate/begin', { 
        userId, 
        purpose 
      });
      const options = optionsResponse.options;

      // Convert challenge to ArrayBuffer
      const publicKeyCredentialRequestOptions: PublicKeyCredentialRequestOptions = {
        challenge: this.base64ToArrayBuffer(options.challenge),
        allowCredentials: options.allowCredentials?.map((cred: any) => ({
          id: this.base64ToArrayBuffer(cred.id),
          type: cred.type,
          transports: cred.transports
        })),
        userVerification: 'required',
        timeout: 60000,
      };

      // Get credential
      const credential = await navigator.credentials.get({
        publicKey: publicKeyCredentialRequestOptions
      }) as PublicKeyCredential;

      if (!credential) {
        this.handleFailedAttempt();
        return { success: false, error: 'Authentication cancelled or failed' };
      }

      // Send credential to server for verification
      const assertionResponse = credential.response as AuthenticatorAssertionResponse;
      const authenticationData = {
        id: credential.id,
        rawId: this.arrayBufferToBase64(credential.rawId),
        response: {
          authenticatorData: this.arrayBufferToBase64(assertionResponse.authenticatorData),
          clientDataJSON: this.arrayBufferToBase64(assertionResponse.clientDataJSON),
          signature: this.arrayBufferToBase64(assertionResponse.signature),
          userHandle: assertionResponse.userHandle ? 
            this.arrayBufferToBase64(assertionResponse.userHandle) : null,
        },
        type: credential.type,
      };

      const verificationResponse = await apiRequest('POST', '/api/webauthn/authenticate/complete', {
        userId,
        purpose,
        credential: authenticationData
      });

      if (verificationResponse.verified) {
        this.resetFailedAttempts();
        return { success: true, credential: verificationResponse.credential };
      } else {
        this.handleFailedAttempt();
        return { success: false, error: 'Authentication failed' };
      }
    } catch (error) {
      console.error('Biometric authentication error:', error);
      this.handleFailedAttempt();
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Authentication failed',
        fallbackToPasscode: !this.isLockedOut()
      };
    }
  }

  // Check if user has registered biometric credentials
  async hasRegisteredCredentials(userId: string): Promise<boolean> {
    try {
      const response = await apiRequest('GET', `/api/webauthn/credentials/${userId}`);
      return response.hasCredentials;
    } catch (error) {
      console.error('Error checking credentials:', error);
      return false;
    }
  }

  // Handle failed authentication attempt
  private handleFailedAttempt(): void {
    this.failedAttempts++;
    
    if (this.failedAttempts >= this.MAX_ATTEMPTS) {
      this.lockoutEndTime = Date.now() + this.LOCKOUT_DURATION;
      console.warn('Too many failed biometric attempts. Portal locked for 10 minutes.');
    }
  }

  // Reset failed attempts counter
  private resetFailedAttempts(): void {
    this.failedAttempts = 0;
    this.lockoutEndTime = null;
  }

  // Utility functions for ArrayBuffer conversion
  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  private stringToArrayBuffer(str: string): ArrayBuffer {
    const encoder = new TextEncoder();
    return encoder.encode(str);
  }
}

export const biometricAuth = BiometricAuth.getInstance();