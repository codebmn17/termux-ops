// Max Terminal Upgrade - AI Hook & Monitoring Integration for StormEcho
// Seamlessly integrates with existing terminal sessions

export interface TerminalSession {
  id: string;
  name: string;
  status: 'active' | 'idle' | 'disconnected';
  lastActivity: Date;
  aiLinked: boolean;
}

export class MasterLoop {
  private static instance: MasterLoop;
  private sessions: Map<string, TerminalSession> = new Map();
  private monitorInterval: number | null = null;
  private readonly AI_HOOK_URL = '/api/terminal-modules/ai-hook';
  private readonly MONITOR_INTERVAL = 30000; // 30 seconds

  // Terminal session mappings
  private readonly TERMINAL_MAPPINGS = {
    'dev': 'Terminal1',
    'network': 'Terminal2', 
    'mining': 'Terminal3',
    'security': 'Terminal4',
    'logs': 'Terminal5',
    'personal': 'Terminal6',
    'wildcard': 'Terminal7'
  };

  private constructor() {
    console.log('🔻 StormEcho MasterLoop initializing...');
  }

  static getInstance(): MasterLoop {
    if (!MasterLoop.instance) {
      MasterLoop.instance = new MasterLoop();
    }
    return MasterLoop.instance;
  }

  // Initialize the master loop system
  async initialize() {
    console.log('🚀 Initializing Max Terminal AI Integration...');
    
    // Set up sessions
    Object.entries(this.TERMINAL_MAPPINGS).forEach(([sessionId, terminalName]) => {
      this.sessions.set(sessionId, {
        id: sessionId,
        name: terminalName,
        status: 'idle',
        lastActivity: new Date(),
        aiLinked: false
      });
    });

    // Attach AI hooks to all terminals
    await this.attachAllAIHooks();
    
    // Start monitoring
    this.startMonitoring();
    
    console.log('🔥 Max Terminal Upgrade complete. All systems linked.');
  }

  // Attach AI hook to a specific terminal
  async attachAIHook(sessionId: string): Promise<boolean> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      console.error(`❌ Session ${sessionId} not found`);
      return false;
    }

    console.log(`⚡ Attaching AI hook to ${session.name}...`);
    
    try {
      const response = await fetch(this.AI_HOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          terminal: session.name,
          sessionId: sessionId,
          status: 'linked',
          timestamp: Date.now(),
          capabilities: this.getSessionCapabilities(sessionId)
        })
      });

      if (response.ok) {
        session.aiLinked = true;
        console.log(`✅ AI Hook ready for ${session.name}`);
        return true;
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error(`❌ AI Hook failed for ${session.name}:`, error);
      return false;
    }
  }

  // Attach AI hooks to all terminals
  async attachAllAIHooks() {
    const promises = Array.from(this.sessions.keys()).map(sessionId => 
      this.attachAIHook(sessionId)
    );
    await Promise.all(promises);
  }

  // Get capabilities based on session type
  private getSessionCapabilities(sessionId: string): string[] {
    const capabilities: Record<string, string[]> = {
      'dev': ['code-execution', 'git-operations', 'package-management', 'ai-assistance'],
      'network': ['network-scanning', 'connection-monitoring', 'traffic-analysis'],
      'mining': ['crypto-mining', 'wallet-sync', 'performance-monitoring'],
      'security': ['threat-detection', 'process-monitoring', 'auto-kill'],
      'logs': ['log-analysis', 'error-tracking', 'performance-metrics'],
      'personal': ['custom-scripts', 'automation', 'ai-chat'],
      'wildcard': ['experimental-features', 'all-capabilities']
    };
    
    return capabilities[sessionId] || [];
  }

  // Start monitoring all terminals
  startMonitoring() {
    if (this.monitorInterval) {
      clearInterval(this.monitorInterval);
    }

    this.monitorInterval = window.setInterval(() => {
      this.monitorAllTerminals();
    }, this.MONITOR_INTERVAL);

    // Initial monitor run
    this.monitorAllTerminals();
  }

  // Monitor all terminals
  private async monitorAllTerminals() {
    console.log('📡 Monitoring all terminals...');
    
    const sessionsArray = Array.from(this.sessions.entries());
    for (const [sessionId, session] of sessionsArray) {
      await this.monitorTerminal(sessionId);
    }
  }

  // Monitor a specific terminal
  private async monitorTerminal(sessionId: string) {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    try {
      // Check terminal health
      const response = await fetch(`/api/terminal/status/${sessionId}`);
      
      if (response.ok) {
        const data = await response.json();
        session.status = data.isActive ? 'active' : 'idle';
        session.lastActivity = new Date();
        
        // Log performance metrics
        if (data.metrics) {
          console.log(`📊 ${session.name} - CPU: ${data.metrics.cpu}%, Memory: ${data.metrics.memory}MB`);
        }
      } else {
        session.status = 'disconnected';
      }

      // Re-attach AI hook if disconnected
      if (!session.aiLinked && session.status === 'active') {
        await this.attachAIHook(sessionId);
      }
    } catch (error) {
      console.error(`❌ Monitor failed for ${session.name}:`, error);
      session.status = 'disconnected';
    }
  }

  // Update session activity
  updateSessionActivity(sessionId: string) {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.lastActivity = new Date();
      session.status = 'active';
    }
  }

  // Get session status
  getSessionStatus(sessionId: string): TerminalSession | undefined {
    return this.sessions.get(sessionId);
  }

  // Get all sessions status
  getAllSessionsStatus(): TerminalSession[] {
    return Array.from(this.sessions.values());
  }

  // Stop monitoring
  stopMonitoring() {
    if (this.monitorInterval) {
      clearInterval(this.monitorInterval);
      this.monitorInterval = null;
    }
  }

  // Cleanup
  destroy() {
    this.stopMonitoring();
    this.sessions.clear();
    console.log('🔻 MasterLoop shutdown complete');
  }
}

// Export singleton instance
export const masterLoop = MasterLoop.getInstance();