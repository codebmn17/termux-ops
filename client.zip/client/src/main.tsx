import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { 
  PerformanceMonitor, 
  preloadResources, 
  optimizeRenderPerformance,
  addResourceHints,
  CacheManager
} from './utils/performance-monitor';

// Initialize performance monitoring
const perfMonitor = PerformanceMonitor.getInstance();
perfMonitor.mark('app-start');

// Add resource hints for faster loading
addResourceHints();

// Preload critical resources
preloadResources();

// Optimize render performance
optimizeRenderPerformance();

// Cache critical resources
CacheManager.cacheResources([
  '/',
  '/assets/storm-echo-logo.svg',
  '/assets/galaxy-bg.webp'
]);

// Clear old caches
CacheManager.clearOldCaches();

// Mark before React render
perfMonitor.mark('react-render-start');

createRoot(document.getElementById("root")!).render(<App />);

// Mark after React render
perfMonitor.mark('react-render-end');

// Mobile keyboard and viewport optimization
window.addEventListener('resize', () => {
  // Adjust body height for mobile keyboard
  document.body.style.height = window.innerHeight + 'px';
  
  // Handle orientation changes
  const orientation = window.orientation;
  if (orientation !== undefined) {
    document.documentElement.setAttribute('data-orientation', 
      Math.abs(orientation) === 90 ? 'landscape' : 'portrait'
    );
  }
});

// Prevent zoom on double tap for iOS
let lastTouchEnd = 0;
document.addEventListener('touchend', (event) => {
  const now = new Date().getTime();
  if (now - lastTouchEnd <= 300) {
    event.preventDefault();
  }
  lastTouchEnd = now;
}, false);

// Handle viewport changes for mobile keyboards
const viewportMetaTag = document.querySelector('meta[name=viewport]');
function handleViewportChange() {
  if (viewportMetaTag) {
    const isKeyboardOpen = window.innerHeight < window.screen.height * 0.75;
    if (isKeyboardOpen) {
      viewportMetaTag.setAttribute('content', 
        'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover'
      );
    }
  }
}

window.addEventListener('resize', handleViewportChange);

// Log performance metrics in development
if (import.meta.env.DEV) {
  setTimeout(() => {
    const metrics = perfMonitor.getAllMetrics();
    console.log('Performance Metrics:', metrics);
  }, 1000);
}
