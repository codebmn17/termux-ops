import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, ArrowLeft, Home } from "lucide-react";
import { GalaxyBackground } from '@/components/galaxy-background';

export default function NotFound() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-md"
        >
          <Card className="bg-gray-900/90 border-cyan-400/30 backdrop-blur-sm">
            <CardContent className="pt-6 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="flex flex-col items-center mb-4"
              >
                <AlertCircle className="h-16 w-16 text-cyan-400 mb-4" />
                <h1 className="text-3xl font-bold text-cyan-300 font-['Orbitron']">404</h1>
                <h2 className="text-xl font-semibold text-white mt-2">Page Not Found</h2>
              </motion.div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="mt-4 text-gray-300 mb-6"
              >
                The page you're looking for doesn't exist in the Storm Echo RI system.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="flex flex-col space-y-3"
              >
                <Link href="/">
                  <motion.button
                    className="w-full px-4 py-3 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-medium hover:from-cyan-700 hover:to-blue-700 transition-all duration-300 flex items-center justify-center space-x-2"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Home size={18} />
                    <span>Return to Storm Echo</span>
                  </motion.button>
                </Link>
                
                <button
                  onClick={() => window.history.back()}
                  className="w-full px-4 py-3 rounded-lg bg-gray-700/50 text-gray-300 font-medium hover:bg-gray-600/50 transition-all duration-300 flex items-center justify-center space-x-2"
                >
                  <ArrowLeft size={18} />
                  <span>Go Back</span>
                </button>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
