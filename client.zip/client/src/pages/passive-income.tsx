import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import { IncomeTracker } from '@/components/income-tracker';
import { PlatformIntegrations } from '@/components/platform-integrations';
import { 
  ArrowLeft, 
  DollarSign, 
  BookOpen, 
  ShoppingBag, 
  Smartphone, 
  Terminal,
  Github,
  Zap,
  TrendingUp,
  Globe
} from 'lucide-react';

export default function PassiveIncome() {
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  const incomeStreams = [
    {
      id: 'ebooks',
      name: 'Digital eBooks',
      icon: BookOpen,
      description: 'Storm Echo AI guides and technical documentation',
      platforms: ['Amazon KDP', 'Gumroad', 'Direct Sales'],
      revenue: '$200-2000/month',
      difficulty: 'Medium',
      color: 'from-purple-600 to-indigo-600'
    },
    {
      id: 'marketplace',
      name: 'Marketplace Sales',
      icon: ShoppingBag,
      description: 'Physical products and digital assets',
      platforms: ['eBay', 'Etsy', 'Amazon FBA'],
      revenue: '$500-5000/month',
      difficulty: 'High',
      color: 'from-green-600 to-emerald-600'
    },
    {
      id: 'mobile',
      name: 'Mobile Apps',
      icon: Smartphone,
      description: 'Flutter Storm Echo mobile applications',
      platforms: ['Google Play', 'App Store', 'Direct APK'],
      revenue: '$100-1000/month',
      difficulty: 'High',
      color: 'from-blue-600 to-cyan-600'
    },
    {
      id: 'tools',
      name: 'Dev Tools & Scripts',
      icon: Terminal,
      description: 'Termux scripts and Linux automation tools',
      platforms: ['GitHub Sponsors', 'Custom Scripts', 'Consulting'],
      revenue: '$300-3000/month',
      difficulty: 'Medium',
      color: 'from-orange-600 to-red-600'
    },
    {
      id: 'opensource',
      name: 'Open Source Projects',
      icon: Github,
      description: 'Storm OS and related repositories',
      platforms: ['GitHub Sponsors', 'Patreon', 'Ko-fi'],
      revenue: '$50-500/month',
      difficulty: 'Low',
      color: 'from-gray-600 to-slate-600'
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Low': return 'text-green-400 bg-green-400/20';
      case 'Medium': return 'text-yellow-400 bg-yellow-400/20';
      case 'High': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <DollarSign className="text-cyan-400" size={24} />
            <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 glow-text">
              Passive Income Streams
            </h1>
          </motion.div>
        </motion.div>

        {/* Income Streams Grid */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {incomeStreams.map((stream, index) => {
            const IconComponent = stream.icon;
            return (
              <motion.div
                key={stream.id}
                className={`bg-black/40 backdrop-blur-sm border rounded-lg p-6 cursor-pointer transition-all duration-300 ${
                  selectedCategory === stream.id 
                    ? 'border-cyan-400 bg-cyan-400/10' 
                    : 'border-cyan-400/20 hover:border-cyan-400/40'
                }`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                onClick={() => setSelectedCategory(selectedCategory === stream.id ? '' : stream.id)}
              >
                <div className="mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${stream.color} flex items-center justify-center mb-3`}>
                    <IconComponent size={24} className="text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-cyan-400 mb-2">{stream.name}</h3>
                  <p className="text-gray-300 text-sm mb-3">{stream.description}</p>
                  
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-green-400 font-semibold">{stream.revenue}</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${getDifficultyColor(stream.difficulty)}`}>
                      {stream.difficulty}
                    </span>
                  </div>
                </div>
                
                {selectedCategory === stream.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="border-t border-cyan-400/20 pt-4"
                  >
                    <h4 className="text-cyan-400 font-semibold mb-2 flex items-center">
                      <Globe size={16} className="mr-2" />
                      Platforms
                    </h4>
                    <ul className="space-y-1 mb-4">
                      {stream.platforms.map((platform, idx) => (
                        <li key={idx} className="flex items-center text-sm text-gray-300">
                          <Zap size={12} className="text-cyan-400 mr-2" />
                          {platform}
                        </li>
                      ))}
                    </ul>
                    
                    <motion.button
                      className="w-full bg-gradient-to-r from-cyan-600 to-teal-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:from-cyan-700 hover:to-teal-700 transition-all duration-300"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      Get Started with {stream.name}
                    </motion.button>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* GitHub Integration */}
        <motion.div
          className="max-w-4xl mx-auto bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="flex items-center mb-4">
            <Github className="text-cyan-400 mr-3" size={24} />
            <h3 className="text-xl font-bold text-cyan-400">Storm OS Repository</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-gray-300 text-sm mb-3">
                Your GitHub repository: <span className="text-cyan-400">codebmn17/stormos.git</span>
              </p>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Termux integration scripts</li>
                <li>• Linux automation tools</li>
                <li>• Flutter mobile applications</li>
                <li>• Storm Echo AI components</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <motion.button
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:from-purple-700 hover:to-indigo-700 transition-all duration-300"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <TrendingUp size={16} className="inline mr-2" />
                Enable GitHub Sponsors
              </motion.button>
              
              <motion.button
                className="w-full bg-gradient-to-r from-gray-600 to-slate-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:from-gray-700 hover:to-slate-700 transition-all duration-300"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Github size={16} className="inline mr-2" />
                View Repository
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Income Analytics Dashboard */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <IncomeTracker />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
          >
            <PlatformIntegrations />
          </motion.div>
        </div>

        {/* Revenue Projection */}
        <motion.div
          className="max-w-2xl mx-auto text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-cyan-400 mb-4">Total Revenue Potential</h3>
            <div className="text-3xl font-bold text-green-400 mb-2">$1,150 - $11,500</div>
            <p className="text-gray-300 text-sm mb-4">Monthly passive income range across all streams</p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-400">
              <span>📊 Data-driven projections</span>
              <span>⚡ Storm Echo powered</span>
              <span>🚀 Scalable systems</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}