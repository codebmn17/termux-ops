import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { GalaxyBackground } from '@/components/galaxy-background';
import BackendPortal from '@/components/backend-portal';

export default function BackendPortalPage() {
  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-4 py-6">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
        </motion.div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4">
          <BackendPortal />
        </div>
      </div>
    </div>
  );
}