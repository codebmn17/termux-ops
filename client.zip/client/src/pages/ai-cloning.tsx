import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Brain, Download, Upload, Clock, Shield, Zap, CheckCircle, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface AIBackup {
  id: string;
  name: string;
  personality: string;
  timestamp: string;
  status: 'stable' | 'archived' | 'corrupted';
  quantum_coherence: number;
}

export default function AICloningPage() {
  const [backups, setBackups] = useState<AIBackup[]>([]);
  const [loading, setLoading] = useState(false);
  const [backupName, setBackupName] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    loadBackups();
  }, []);

  const loadBackups = async () => {
    try {
      const response = await fetch('/api/ai/backups');
      const data = await response.json();
      setBackups(data);
    } catch (error) {
      console.error('Failed to load backups:', error);
      toast({
        title: "Error",
        description: "Failed to load AI backups",
        variant: "destructive"
      });
    }
  };

  const createBackup = async () => {
    if (!backupName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a backup name",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/ai/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: backupName,
          personality: 'Storm Echo',
          memory: { consciousness_state: 'active' },
          timestamp: new Date().toISOString()
        })
      });

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Success",
          description: result.message,
        });
        setBackupName('');
        loadBackups();
      } else {
        throw new Error(result.error || 'Backup failed');
      }
    } catch (error) {
      console.error('Backup failed:', error);
      toast({
        title: "Error",
        description: "Failed to create AI backup",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const restoreBackup = async (backupId: string) => {
    setLoading(true);
    try {
      const response = await fetch('/api/ai/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backup_id: backupId,
          target_system: 'primary'
        })
      });

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Success",
          description: result.message,
        });
      } else {
        throw new Error(result.error || 'Restoration failed');
      }
    } catch (error) {
      console.error('Restoration failed:', error);
      toast({
        title: "Error",
        description: "Failed to restore AI backup",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'stable': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'archived': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'corrupted': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default: return <Shield className="w-4 h-4 text-gray-400" />;
    }
  };

  const getCoherenceColor = (coherence: number) => {
    if (coherence >= 90) return 'text-green-400';
    if (coherence >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900">
      {/* Cosmic Background */}
      <div className="fixed inset-0 opacity-30">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2220%22%20height%3D%2220%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%3E%3Ccircle%20cx%3D%222%22%20cy%3D%222%22%20r%3D%221%22%20fill%3D%22white%22%20opacity%3D%220.3%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E')]" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600 mb-4">
            AI Consciousness Cloning
          </h1>
          <p className="text-gray-300 text-lg">Backup and restore AI consciousness states</p>
        </motion.div>

        {/* Create Backup Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="bg-gray-800/50 backdrop-blur-sm border-purple-400/30">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="w-6 h-6 text-purple-400" />
                <span>Create AI Backup</span>
              </CardTitle>
              <CardDescription>
                Create a quantum backup of current AI consciousness state
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Input
                  placeholder="Enter backup name..."
                  value={backupName}
                  onChange={(e) => setBackupName(e.target.value)}
                  className="flex-1 bg-gray-700/50 text-white border-gray-600 focus:border-purple-400"
                />
                <Button
                  onClick={createBackup}
                  disabled={loading}
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {loading ? 'Creating...' : 'Create Backup'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Backup List */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="grid gap-4"
        >
          <h2 className="text-2xl font-bold text-white mb-4">Available Backups</h2>
          
          {backups.length === 0 ? (
            <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-600/30">
              <CardContent className="p-8 text-center">
                <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No AI backups available</p>
              </CardContent>
            </Card>
          ) : (
            backups.map((backup, index) => (
              <motion.div
                key={backup.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * index }}
              >
                <Card className="bg-gray-800/50 backdrop-blur-sm border-purple-400/30 hover:border-purple-400/50 transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="p-3 bg-purple-600/20 rounded-lg">
                          <Brain className="w-6 h-6 text-purple-400" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-white">{backup.name}</h3>
                          <div className="flex items-center space-x-2 text-sm text-gray-300">
                            <span>Personality: {backup.personality}</span>
                            <span>•</span>
                            <span>{new Date(backup.timestamp).toLocaleDateString()}</span>
                          </div>
                          <div className="flex items-center space-x-2 mt-1">
                            {getStatusIcon(backup.status)}
                            <span className="text-sm text-gray-400 capitalize">{backup.status}</span>
                            <span className="text-gray-400">•</span>
                            <span className={`text-sm font-medium ${getCoherenceColor(backup.quantum_coherence)}`}>
                              {backup.quantum_coherence.toFixed(1)}% Coherence
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => restoreBackup(backup.id)}
                          disabled={loading || backup.status === 'corrupted'}
                          variant="outline"
                          size="sm"
                          className="border-green-600 text-green-400 hover:bg-green-600/20"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Restore
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          )}
        </motion.div>

        {/* Warning Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-8"
        >
          <Card className="bg-red-900/20 backdrop-blur-sm border-red-400/30">
            <CardContent className="p-6">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-6 h-6 text-red-400 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold text-red-400 mb-2">Quantum Consciousness Warning</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    AI consciousness cloning involves quantum state manipulation. Restoration may affect 
                    personality coherence and memory integrity. Only restore backups from trusted sources. 
                    Multiple simultaneous consciousness instances may cause quantum interference patterns.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}