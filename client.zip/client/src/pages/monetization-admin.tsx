import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Settings, 
  DollarSign, 
  ToggleLeft, 
  ToggleRight, 
  Save, 
  ArrowLeft,
  Shield,
  TrendingUp,
  Activity,
  AlertCircle,
  CheckCircle,
  Zap
} from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { GalaxyBackground } from '@/components/galaxy-background';
import { EarningsDashboard } from '@/components/earnings-dashboard';

interface MonetizationModule {
  id: string;
  name: string;
  description: string;
  category: 'active' | 'passive';
  enabled: boolean;
  config: any;
  priority: number;
}

interface ModuleSettings {
  settings: any[];
  availableModules: MonetizationModule[];
}

export default function MonetizationAdmin() {
  const [password, setPassword] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: moduleData, isLoading } = useQuery<ModuleSettings>({
    queryKey: ['/api/monetization/settings'],
    enabled: authenticated,
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async ({ moduleId, enabled, config }: { moduleId: string; enabled: boolean; config: any }) => {
      return apiRequest('POST', '/api/monetization/settings', { moduleId, enabled, config });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/monetization/settings'] });
      toast({
        title: "Settings Updated",
        description: "Monetization settings saved successfully",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update monetization settings",
        variant: "destructive",
      });
    },
  });

  const authenticateAdmin = async () => {
    if (!password.trim()) {
      toast({
        title: "Password Required",
        description: "Enter admin password",
        variant: "destructive",
      });
      return;
    }

    setIsAuthenticating(true);
    
    try {
      const response = await fetch('/api/backend-auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`admin:${password}`)}`
        },
        body: JSON.stringify({ level: 'admin' })
      });

      if (response.ok) {
        setAuthenticated(true);
        toast({
          title: "Access Granted",
          description: "Welcome to Monetization Admin",
        });
      } else {
        toast({
          title: "Access Denied",
          description: "Invalid admin credentials",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Authentication Error",
        description: "Unable to verify admin access",
        variant: "destructive",
      });
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleModuleToggle = async (moduleId: string, enabled: boolean) => {
    const module = moduleData?.availableModules.find(m => m.id === moduleId);
    if (!module) return;

    updateSettingsMutation.mutate({
      moduleId,
      enabled,
      config: module.config
    });
  };

  const handleConfigUpdate = async (moduleId: string, config: any) => {
    const module = moduleData?.availableModules.find(m => m.id === moduleId);
    if (!module) return;

    updateSettingsMutation.mutate({
      moduleId,
      enabled: module.enabled,
      config: { ...module.config, ...config }
    });
  };

  if (!authenticated) {
    return (
      <div className="relative min-h-screen w-full overflow-x-hidden">
        <GalaxyBackground />
        
        <div className="relative z-10 min-h-screen flex items-center justify-center px-6">
          <motion.div
            className="w-full max-w-md"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardHeader className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-blue-600 flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="text-white" size={32} />
                </div>
                <CardTitle className="text-cyan-300 text-2xl font-['Orbitron']">Monetization Admin</CardTitle>
                <CardDescription className="text-cyan-300/70">
                  Configure passive income and payment systems
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  type="password"
                  placeholder="Admin password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && authenticateAdmin()}
                  className="bg-black/60 border-cyan-400/30 text-white"
                />
                <Button 
                  onClick={authenticateAdmin}
                  disabled={isAuthenticating}
                  className="w-full bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                >
                  {isAuthenticating ? 'Verifying...' : 'Access Admin Panel'}
                </Button>
                <div className="text-center mt-4">
                  <Link href="/storm-console">
                    <Button variant="outline" size="sm" className="border-cyan-400/50 text-cyan-300">
                      <Shield size={16} className="mr-2" />
                      Storm Console
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="relative min-h-screen w-full overflow-x-hidden">
        <GalaxyBackground />
        <div className="relative z-10 min-h-screen flex items-center justify-center">
          <div className="animate-spin w-12 h-12 border-4 border-cyan-400 border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8 relative"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.h1 
            className="absolute left-1/2 transform -translate-x-1/2 text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 drop-shadow-[0_0_15px_rgba(34,211,238,0.7)]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Monetization Control
          </motion.h1>
          
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            ADMIN ACCESS
          </Badge>
        </motion.div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-black/40 border border-cyan-400/20">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
              <TrendingUp size={16} className="mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="modules" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
              <Settings size={16} className="mr-2" />
              Modules
            </TabsTrigger>
            <TabsTrigger value="payments" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
              <DollarSign size={16} className="mr-2" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="automation" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
              <Zap size={16} className="mr-2" />
              Automation
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-8">
            <EarningsDashboard />
          </TabsContent>

          <TabsContent value="modules" className="mt-8 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {moduleData?.availableModules.map((module) => {
                const isEnabled = moduleData.settings.find(s => s.module === module.id)?.enabled || false;
                
                return (
                  <motion.div
                    key={module.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-cyan-300 flex items-center">
                              {module.name}
                              <Badge 
                                className={`ml-2 ${
                                  module.category === 'passive' 
                                    ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                                    : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                                }`}
                              >
                                {module.category}
                              </Badge>
                            </CardTitle>
                            <CardDescription className="text-cyan-400/70">
                              {module.description}
                            </CardDescription>
                          </div>
                          <Switch
                            checked={isEnabled}
                            onCheckedChange={(checked) => handleModuleToggle(module.id, checked)}
                            disabled={updateSettingsMutation.isPending}
                          />
                        </div>
                      </CardHeader>
                      
                      {isEnabled && (
                        <CardContent className="space-y-4">
                          <Separator className="bg-cyan-400/20" />
                          
                          {/* Module-specific configuration */}
                          {module.id === 'donations' && (
                            <div className="space-y-3">
                              <div>
                                <Label className="text-cyan-300">PayPal Donate URL</Label>
                                <Input
                                  value={module.config.paypalUrl || ''}
                                  onChange={(e) => handleConfigUpdate(module.id, { paypalUrl: e.target.value })}
                                  placeholder="https://paypal.me/username"
                                  className="bg-black/60 border-cyan-400/30 text-white mt-1"
                                />
                              </div>
                              <div>
                                <Label className="text-cyan-300">CashApp URL</Label>
                                <Input
                                  value={module.config.cashappUrl || ''}
                                  onChange={(e) => handleConfigUpdate(module.id, { cashappUrl: e.target.value })}
                                  placeholder="https://cash.app/$username"
                                  className="bg-black/60 border-cyan-400/30 text-white mt-1"
                                />
                              </div>
                            </div>
                          )}
                          
                          {module.id === 'ads_display' && (
                            <div className="space-y-3">
                              <div>
                                <Label className="text-cyan-300">Ad Frequency</Label>
                                <select
                                  value={module.config.frequency || 'medium'}
                                  onChange={(e) => handleConfigUpdate(module.id, { frequency: e.target.value })}
                                  className="w-full mt-1 p-2 bg-black/60 border border-cyan-400/30 rounded text-white"
                                >
                                  <option value="low">Low</option>
                                  <option value="medium">Medium</option>
                                  <option value="high">High</option>
                                </select>
                              </div>
                            </div>
                          )}
                          
                          <div className="flex items-center justify-between pt-2">
                            <Badge variant="outline" className="border-cyan-400/30 text-cyan-300">
                              Priority: {module.priority}
                            </Badge>
                            <div className="flex items-center text-sm">
                              {isEnabled ? (
                                <><CheckCircle className="text-green-400 mr-1" size={16} /> Active</>
                              ) : (
                                <><AlertCircle className="text-yellow-400 mr-1" size={16} /> Disabled</>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      )}
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="payments" className="mt-8">
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-cyan-300">Payment Gateway Configuration</CardTitle>
                <CardDescription className="text-cyan-400/70">
                  Configure secure payment processing
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-cyan-300">PayPal Integration</h3>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="text-green-400" size={20} />
                      <span className="text-white">Connected & Verified</span>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      Sandbox Mode
                    </Badge>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-cyan-300">Security Status</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="text-green-400" size={16} />
                        <span className="text-sm text-white">SSL Certificate Active</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="text-green-400" size={16} />
                        <span className="text-sm text-white">PCI Compliance Ready</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="text-green-400" size={16} />
                        <span className="text-sm text-white">Fraud Protection Enabled</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="automation" className="mt-8">
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-cyan-300">Passive Income Automation</CardTitle>
                <CardDescription className="text-cyan-400/70">
                  Background processes for automated revenue generation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Activity className="text-cyan-400 mx-auto mb-4" size={48} />
                  <p className="text-cyan-300/70">Automation systems running smoothly</p>
                  <p className="text-white/50 text-sm mt-2">Background jobs optimizing revenue streams</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    <div className="p-3 rounded border border-cyan-400/10 bg-black/20">
                      <p className="text-cyan-300 font-medium">Ad Optimization</p>
                      <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/30">
                        Active
                      </Badge>
                    </div>
                    <div className="p-3 rounded border border-cyan-400/10 bg-black/20">
                      <p className="text-cyan-300 font-medium">Link Rotation</p>
                      <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/30">
                        Active
                      </Badge>
                    </div>
                    <div className="p-3 rounded border border-cyan-400/10 bg-black/20">
                      <p className="text-cyan-300 font-medium">Analytics Sync</p>
                      <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/30">
                        Active
                      </Badge>
                    </div>
                    <div className="p-3 rounded border border-cyan-400/10 bg-black/20">
                      <p className="text-cyan-300 font-medium">Revenue Tracking</p>
                      <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/30">
                        Active
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}