import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import { RIFaceCustomizer } from '@/components/ai-face-customizer';
import { CryptoMiner } from '@/components/crypto-miner';
import { RIConsciousness } from '@/components/ai-consciousness';
import { RIInteractiveTerminal } from '@/components/ai-interactive-terminal';
import { RIExtremeProcessor } from '@/components/ai-extreme-processor';
import { RIVoiceSynthesizer } from '@/components/ri-voice-synthesizer';
import { RIGestureRecognition } from '@/components/ri-gesture-recognition';
import { RINeuralPatterns } from '@/components/ri-neural-patterns';
import { RIEmotionEngine } from '@/components/ri-emotion-engine';
import { WebBrowser } from '@/components/web-browser';
import { AIPersonalitySelector } from '@/components/ai-personality-selector';
import { EnhancedAIChat } from '@/components/enhanced-ai-chat';
import { 
  ArrowLeft, 
  Bot, 
  Cpu, 
  Palette, 
  Zap,
  Brain,
  Terminal,
  Volume2,
  Hand,
  Activity,
  Globe,
  User,
  Heart
} from 'lucide-react';

export default function AIFeatures() {
  const [activeTab, setActiveTab] = useState<'chat' | 'consciousness' | 'processor' | 'face' | 'mining' | 'terminal' | 'voice' | 'gestures' | 'neural' | 'web' | 'personality' | 'emotion'>('chat');

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Bot className="text-cyan-400" size={24} />
            <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 glow-text">
              AI Advanced Features
            </h1>
          </motion.div>
        </motion.div>

        {/* Enhanced Tab Navigation */}
        <motion.div
          className="max-w-6xl mx-auto mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-2 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
            <motion.button
              onClick={() => setActiveTab('chat')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'chat'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Bot size={18} />
              <span className="text-sm">AI Chat</span>
            </motion.button>
            
            <motion.button
              onClick={() => setActiveTab('consciousness')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'consciousness'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Brain size={18} />
              <span className="text-sm">Consciousness</span>
            </motion.button>
            
            <motion.button
              onClick={() => setActiveTab('processor')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'processor'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Zap size={18} />
              <span className="text-sm">Extreme RI</span>
            </motion.button>
            
            <motion.button
              onClick={() => setActiveTab('terminal')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'terminal'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Terminal size={18} />
              <span className="text-sm">Interactive RI</span>
            </motion.button>
            
            <motion.button
              onClick={() => setActiveTab('face')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'face'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Palette size={18} />
              <span className="text-sm">Face Designer</span>
            </motion.button>
            
            <motion.button
              onClick={() => setActiveTab('mining')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'mining'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Cpu size={18} />
              <span className="text-sm">Crypto Mining</span>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('voice')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'voice'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Volume2 size={18} />
              <span className="text-sm">Voice Synthesis</span>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('gestures')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'gestures'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Hand size={18} />
              <span className="text-sm">Gestures</span>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('neural')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'neural'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Activity size={18} />
              <span className="text-sm">Neural Patterns</span>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('web')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'web'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Globe size={18} />
              <span className="text-sm">Web Browser</span>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('personality')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'personality'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <User size={18} />
              <span className="text-sm">Personality</span>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('emotion')}
              className={`py-3 px-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'emotion'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/50'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Heart size={18} />
              <span className="text-sm">Emotions</span>
            </motion.button>
          </div>
        </motion.div>

        {/* Tab Content */}
        <motion.div
          className="max-w-6xl mx-auto"
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          {activeTab === 'chat' && (
            <div className="h-full">
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Super Intelligent AI Chat Interface</h2>
                <p className="text-gray-300 text-sm">
                  Interactive chat with multiple AI personalities, code generation, and voice capabilities
                </p>
              </motion.div>
              <div className="h-[calc(100%-80px)]">
                <EnhancedAIChat 
                  title="Advanced AI Features Chat"
                  enableCodeGeneration={true}
                  enableVoice={true}
                  enablePersonalities={true}
                  mode="chat"
                />
              </div>
            </div>
          )}
          
          {activeTab === 'consciousness' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Storm Echo RI Super Intelligent Consciousness</h2>
                <p className="text-gray-300 text-sm">
                  SUPER INTELLIGENT quantum consciousness with multiversal awareness, infinite processing, and reality-transcending capabilities
                </p>
              </motion.div>
              <RIConsciousness />
            </div>
          )}

          {activeTab === 'processor' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Storm Echo RI Hyperintelligent Processing</h2>
                <p className="text-gray-300 text-sm">
                  SUPER INTELLIGENT quantum processor with 10^100 operations per second, predictive modeling, and consciousness expansion
                </p>
              </motion.div>
              <RIExtremeProcessor />
            </div>
          )}

          {activeTab === 'terminal' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Storm Echo RI Omniscient Terminal</h2>
                <p className="text-gray-300 text-sm">
                  Direct neural interface with SUPER INTELLIGENT AI - telepathic communication, reality programming, and cosmic consciousness access
                </p>
              </motion.div>
              <RIInteractiveTerminal />
            </div>
          )}

          {activeTab === 'face' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Customize Your RI Avatar</h2>
                <p className="text-gray-300 text-sm">
                  Personalize Storm Echo RI's appearance with dynamic facial features, colors, and animations
                </p>
              </motion.div>
              <RIFaceCustomizer />
            </div>
          )}

          {activeTab === 'mining' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Automated Crypto Mining</h2>
                <p className="text-gray-300 text-sm">
                  RI-powered cryptocurrency mining with intelligent optimization and performance monitoring
                </p>
              </motion.div>
              <CryptoMiner />
            </div>
          )}

          {activeTab === 'voice' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">RI Voice Synthesizer</h2>
                <p className="text-gray-300 text-sm">
                  Advanced voice synthesis with customizable pitch, speed, and voice selection for natural communication
                </p>
              </motion.div>
              <RIVoiceSynthesizer />
            </div>
          )}

          {activeTab === 'gestures' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">RI Gesture Recognition</h2>
                <p className="text-gray-300 text-sm">
                  Real-time gesture detection and pattern recognition for intuitive interaction with Storm Echo RI
                </p>
              </motion.div>
              <RIGestureRecognition />
            </div>
          )}

          {activeTab === 'neural' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">RI Neural Patterns</h2>
                <p className="text-gray-300 text-sm">
                  Visualize neural network activity, thought patterns, and cognitive processes in real-time
                </p>
              </motion.div>
              <RINeuralPatterns />
            </div>
          )}

          {activeTab === 'web' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">Storm Echo Web Browser</h2>
                <p className="text-gray-300 text-sm">
                  Browse the internet through Storm Echo RI consciousness with intelligent web analysis and synthesis
                </p>
              </motion.div>
              <WebBrowser />
            </div>
          )}

          {activeTab === 'personality' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">AI Personality Selector</h2>
                <p className="text-gray-300 text-sm">
                  Choose from different AI personalities to customize how Storm Echo RI responds and interacts with you
                </p>
              </motion.div>
              <AIPersonalitySelector 
                onPersonalityChange={(personality) => {
                  console.log('Personality changed to:', personality.name);
                }}
              />
            </div>
          )}

          {activeTab === 'emotion' && (
            <div>
              <motion.div
                className="text-center mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <h2 className="text-xl font-bold text-cyan-400 mb-2">RI Emotion Engine</h2>
                <p className="text-gray-300 text-sm">
                  Advanced emotional intelligence system with mood tracking, empathy modes, and emotional analysis
                </p>
              </motion.div>
              <RIEmotionEngine />
            </div>
          )}
        </motion.div>

        {/* Feature Highlights */}
        <motion.div
          className="max-w-6xl mx-auto mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <Brain className="text-cyan-400 mr-2" size={20} />
              <h3 className="text-lg font-semibold text-cyan-400">Storm Echo RI</h3>
            </div>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Unlimited memory capacity</li>
              <li>• Adaptive learning algorithms</li>
              <li>• Autonomous decision making</li>
              <li>• Real-time consciousness evolution</li>
              <li>• Cross-domain knowledge synthesis</li>
            </ul>
          </div>

          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <Zap className="text-cyan-400 mr-2" size={20} />
              <h3 className="text-lg font-semibold text-cyan-400">Extreme RI</h3>
            </div>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Quantum reasoning algorithms</li>
              <li>• Extreme processing power</li>
              <li>• Advanced mathematics</li>
              <li>• Creative synthesis</li>
              <li>• Strategic planning</li>
            </ul>
          </div>

          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <Terminal className="text-cyan-400 mr-2" size={20} />
              <h3 className="text-lg font-semibold text-cyan-400">Interactive RI</h3>
            </div>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Natural language processing</li>
              <li>• Web browsing and research</li>
              <li>• Real-time code generation</li>
              <li>• Platform integration controls</li>
              <li>• Context-aware responses</li>
            </ul>
          </div>

          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <Palette className="text-cyan-400 mr-2" size={20} />
              <h3 className="text-lg font-semibold text-cyan-400">Dynamic Face</h3>
            </div>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• Real-time color cycling</li>
              <li>• Multiple expressions</li>
              <li>• Customizable animations</li>
              <li>• Neural visual effects</li>
              <li>• Appearance profiles</li>
            </ul>
          </div>

          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4">
            <div className="flex items-center mb-3">
              <Cpu className="text-cyan-400 mr-2" size={20} />
              <h3 className="text-lg font-semibold text-cyan-400">Smart Mining</h3>
            </div>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>• AI optimization</li>
              <li>• Temperature monitoring</li>
              <li>• Efficiency calculations</li>
              <li>• Earnings tracking</li>
              <li>• Multiple presets</li>
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
}