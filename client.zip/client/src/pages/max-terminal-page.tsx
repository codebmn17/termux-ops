import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft, Terminal, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { MaxTerminal } from '@/components/max-terminal';
import { AICodingAssistant } from '@/components/ai-coding-assistant';
import { KeyboardDebugPanel } from '@/components/keyboard-debug-panel';
import { AutonomyControlPanel } from '@/components/autonomy-control-panel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function MaxTerminalPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black" />
        <motion.div
          className="absolute inset-0 opacity-30"
          animate={{
            backgroundImage: [
              'radial-gradient(circle at 20% 50%, #00ffea 0%, transparent 50%)',
              'radial-gradient(circle at 80% 50%, #0088ff 0%, transparent 50%)',
              'radial-gradient(circle at 20% 50%, #00ffea 0%, transparent 50%)',
            ],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-4 sm:py-6 lg:py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 sm:mb-6 lg:mb-8 gap-4 sm:gap-0">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm" className="border-cyan-500/30 hover:bg-cyan-500/10">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Terminal className="w-8 h-8 text-cyan-400" />
                <h1 className="text-3xl font-bold text-cyan-400">Max Terminal System</h1>
              </div>
            </div>
          </div>

          {/* Terminal, AI Assistant, and Debug Panel */}
          <Tabs defaultValue="terminal" className="w-full">
            <TabsList className="grid grid-cols-4 bg-black/50 border border-cyan-500/30 mb-4">
              <TabsTrigger value="terminal" className="flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                Terminal Sessions
              </TabsTrigger>
              <TabsTrigger value="ai-assistant" className="flex items-center gap-2">
                <Brain className="w-4 h-4" />
                AI Coding Assistant
              </TabsTrigger>
              <TabsTrigger value="debug" className="flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                Keyboard Debug
              </TabsTrigger>
              <TabsTrigger value="autonomy" className="flex items-center gap-2">
                <Brain className="w-4 h-4" />
                Autonomy Control
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="terminal" className="mt-0">
              <MaxTerminal />
            </TabsContent>
            
            <TabsContent value="ai-assistant" className="mt-0">
              <AICodingAssistant />
            </TabsContent>
            
            <TabsContent value="debug" className="mt-0">
              <KeyboardDebugPanel />
            </TabsContent>
            
            <TabsContent value="autonomy" className="mt-0">
              <AutonomyControlPanel />
            </TabsContent>
          </Tabs>

          {/* Features Info */}
          <div className="mt-6 sm:mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-black/50 backdrop-blur-lg border border-cyan-500/30 rounded-lg p-4"
            >
              <h3 className="text-cyan-400 font-semibold mb-2">🚀 Multi-Session Support</h3>
              <p className="text-gray-400 text-sm">
                7 dedicated terminal sessions for different tasks: Dev, Network, Mining, Security, Logs, Personal, and Wildcard.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-black/50 backdrop-blur-lg border border-cyan-500/30 rounded-lg p-4"
            >
              <h3 className="text-cyan-400 font-semibold mb-2">⚡ Hot Commands</h3>
              <p className="text-gray-400 text-sm">
                Quick access to frequently used commands: Launch Miner, Auto Fund, System Update, Network Scan, and more.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-black/50 backdrop-blur-lg border border-cyan-500/30 rounded-lg p-4"
            >
              <h3 className="text-cyan-400 font-semibold mb-2">💾 Persistent History</h3>
              <p className="text-gray-400 text-sm">
                All commands and sessions are saved locally and in backend history files with 5000 command retention.
              </p>
            </motion.div>
          </div>

          {/* System Requirements */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-6 bg-black/30 backdrop-blur-lg border border-cyan-500/20 rounded-lg p-4"
          >
            <h3 className="text-cyan-400 font-semibold mb-2">System Tools Available:</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-gray-400">
              <span>✓ Git</span>
              <span>✓ Python 3</span>
              <span>✓ Node.js & npm</span>
              <span>✓ Tmux</span>
              <span>✓ Curl & Wget</span>
              <span>✓ Nano & Vim</span>
              <span>✓ Nmap</span>
              <span>✓ OpenSSL</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}