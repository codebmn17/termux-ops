import { motion } from 'framer-motion';
import { ArrowLeft, Heart, Coffee, Gift, ExternalLink } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { GalaxyBackground } from '@/components/galaxy-background';

export default function DonatePage() {
  const donationOptions = [
    {
      platform: 'PayPal',
      icon: '💳',
      description: 'Secure payments worldwide',
      url: process.env.VITE_PAYPAL_DONATE_URL || '#',
      color: 'from-blue-500 to-blue-600'
    },
    {
      platform: 'CashApp',
      icon: '💰',
      description: 'Quick mobile payments',
      url: process.env.VITE_CASHAPP_URL || '#',
      color: 'from-green-500 to-green-600'
    },
    {
      platform: 'Venmo',
      icon: '📱',
      description: 'Social payments made easy',
      url: process.env.VITE_VENMO_URL || '#',
      color: 'from-purple-500 to-purple-600'
    }
  ];

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8 relative"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.h1 
            className="absolute left-1/2 transform -translate-x-1/2 text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 drop-shadow-[0_0_15px_rgba(34,211,238,0.7)]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Support Storm Echo
          </motion.h1>
          
          <div className="w-[120px]"></div>
        </motion.div>

        {/* Welcome Message */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Heart className="text-red-500 mr-2" size={24} />
            <p className="text-lg text-blue-400">Thank you for supporting our cosmic journey</p>
          </div>
          <p className="text-white opacity-70 max-w-2xl mx-auto">
            Your support helps us continue developing advanced AI technologies, 
            maintaining our servers, and expanding the Storm Echo ecosystem.
          </p>
        </motion.div>

        {/* Donation Options */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          {donationOptions.map((option, index) => (
            <motion.div
              key={option.platform}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
            >
              <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm hover:border-cyan-400/50 hover:bg-cyan-400/5 transition-all duration-300">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${option.color} flex items-center justify-center mx-auto mb-4`}>
                    <span className="text-2xl">{option.icon}</span>
                  </div>
                  <CardTitle className="text-white">{option.platform}</CardTitle>
                  <CardDescription className="text-cyan-300/70">{option.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white border-none"
                    onClick={() => window.open(option.url, '_blank')}
                    disabled={option.url === '#'}
                  >
                    <ExternalLink size={16} className="mr-2" />
                    Donate via {option.platform}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Additional Support Options */}
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
        >
          <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm max-w-2xl mx-auto">
            <CardHeader>
              <div className="flex items-center justify-center mb-4">
                <Coffee className="text-yellow-500 mr-2" size={24} />
                <CardTitle className="text-white">Other Ways to Support</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-cyan-300/70 mb-4">
                You can also support us by sharing Storm Echo with others, 
                providing feedback, or contributing to our open-source development.
              </p>
              <div className="flex justify-center space-x-4">
                <Button variant="outline" className="border-cyan-400/50 text-cyan-300 hover:bg-cyan-400/10">
                  <Gift size={16} className="mr-2" />
                  Share with Friends
                </Button>
                <Button variant="outline" className="border-cyan-400/50 text-cyan-300 hover:bg-cyan-400/10">
                  <ExternalLink size={16} className="mr-2" />
                  GitHub Repository
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}