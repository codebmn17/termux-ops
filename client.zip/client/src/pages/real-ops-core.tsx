import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  DollarSign, Shield, TrendingUp, Activity, 
  Search, Zap, BarChart3, Settings, Key,
  Wallet, Users, Globe, Brain, Lock
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { GalaxyBackground } from '@/components/galaxy-background';

interface RealOpsSession {
  authenticated: boolean;
  username?: string;
  permissions?: string[];
}

export default function RealOpsCore() {
  const [session, setSession] = useState<RealOpsSession>({ authenticated: false });
  const [password, setPassword] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check session status
  const { data: sessionData } = useQuery({
    queryKey: ['/api/realops/auth/session'],
    enabled: true,
    retry: false
  });

  useEffect(() => {
    if (sessionData?.valid) {
      setSession({
        authenticated: true,
        username: sessionData.user.username,
        permissions: sessionData.user.permissions
      });
    }
  }, [sessionData]);

  // Authentication mutation
  const loginMutation = useMutation({
    mutationFn: async (password: string) => {
      return apiRequest('POST', '/api/realops/auth/login', { password });
    },
    onSuccess: (data) => {
      if (data.success) {
        setSession({
          authenticated: true,
          username: data.session.username,
          permissions: data.session.permissions
        });
        toast({
          title: "Access Granted",
          description: "Welcome to Real-Ops Core",
          className: "bg-green-900/90 border-green-500"
        });
        queryClient.invalidateQueries({ queryKey: ['/api/realops'] });
      }
    },
    onError: () => {
      toast({
        title: "Access Denied",
        description: "Invalid password",
        variant: "destructive"
      });
    }
  });

  // Dashboard data
  const { data: dashboardData } = useQuery({
    queryKey: ['/api/realops/dashboard'],
    enabled: session.authenticated,
    refetchInterval: 30000
  });

  const { data: monetizationStats } = useQuery({
    queryKey: ['/api/realops/monetization/analytics'],
    enabled: session.authenticated,
    refetchInterval: 60000
  });

  const { data: automationStatus } = useQuery({
    queryKey: ['/api/realops/automation/dashboard'],
    enabled: session.authenticated,
    refetchInterval: 30000
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.trim()) {
      loginMutation.mutate(password);
    }
  };

  if (!session.authenticated) {
    return (
      <div className="relative min-h-screen">
        <GalaxyBackground />
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <Card className="w-full max-w-md bg-black/60 backdrop-blur-md border-amber-500/30">
            <CardHeader>
              <CardTitle className="text-2xl font-['Orbitron'] text-amber-400 text-center">
                Storm/Echo Real-Ops Core
              </CardTitle>
              <CardDescription className="text-gray-400 text-center">
                Advanced Operations Management System
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin}>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-300 mb-2 block">
                      Secure Access Password
                    </label>
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-black/40 border-amber-500/30 text-white"
                      placeholder="Enter Real-Ops password"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <Lock className="animate-pulse" size={20} />
                    ) : (
                      <>
                        <Shield size={20} className="mr-2" />
                        Access Real-Ops Core
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen">
      <GalaxyBackground />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <Card className="mb-6 bg-black/60 backdrop-blur-md border-amber-500/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-full bg-amber-500/20 border border-amber-500/30">
                  <Shield className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <CardTitle className="text-2xl font-['Orbitron'] text-amber-300">
                    Real-Ops Core Dashboard
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Advanced monetization, automation, and intelligence operations
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                  <Activity className="w-3 h-3 mr-1" />
                  System Active
                </Badge>
                <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30">
                  User: {session.username}
                </Badge>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* System Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/40 backdrop-blur-md border-green-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Monetization Status</p>
                  <p className="text-2xl font-bold text-green-400">
                    ${monetizationStats?.totalRevenue?.toLocaleString() || '0'}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 backdrop-blur-md border-blue-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Automation Scripts</p>
                  <p className="text-2xl font-bold text-blue-400">
                    {automationStatus?.overview?.activeScripts || 0}
                  </p>
                </div>
                <Zap className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 backdrop-blur-md border-purple-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">OSINT Queries</p>
                  <p className="text-2xl font-bold text-purple-400">
                    {dashboardData?.modules?.truthOps?.activeQueries || 0}
                  </p>
                </div>
                <Search className="w-8 h-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/40 backdrop-blur-md border-cyan-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Passive Streams</p>
                  <p className="text-2xl font-bold text-cyan-400">
                    {dashboardData?.modules?.passiveIncome?.streams || 0}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-cyan-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="monetization" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-black/40 backdrop-blur-md">
            <TabsTrigger value="monetization" className="data-[state=active]:bg-green-500/20">
              <DollarSign className="w-4 h-4 mr-2" />
              Monetization
            </TabsTrigger>
            <TabsTrigger value="passive" className="data-[state=active]:bg-blue-500/20">
              <TrendingUp className="w-4 h-4 mr-2" />
              Passive Income
            </TabsTrigger>
            <TabsTrigger value="truthops" className="data-[state=active]:bg-purple-500/20">
              <Search className="w-4 h-4 mr-2" />
              Truth-Ops
            </TabsTrigger>
            <TabsTrigger value="automation" className="data-[state=active]:bg-cyan-500/20">
              <Zap className="w-4 h-4 mr-2" />
              Automation
            </TabsTrigger>
            <TabsTrigger value="api" className="data-[state=active]:bg-orange-500/20">
              <Globe className="w-4 h-4 mr-2" />
              API Gateway
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-red-500/20">
              <Shield className="w-4 h-4 mr-2" />
              Security
            </TabsTrigger>
          </TabsList>

          {/* Monetization Tab */}
          <TabsContent value="monetization">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 backdrop-blur-md border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400">Revenue Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Revenue:</span>
                      <span className="text-green-400 font-bold">
                        ${monetizationStats?.totalRevenue?.toLocaleString() || '0'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Monthly Recurring:</span>
                      <span className="text-green-400 font-bold">
                        ${monetizationStats?.monthlyRecurring?.toLocaleString() || '0'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Affiliate Earnings:</span>
                      <span className="text-green-400 font-bold">
                        ${monetizationStats?.affiliateEarnings?.toLocaleString() || '0'}
                      </span>
                    </div>
                    <div className="pt-4">
                      <Button className="w-full bg-green-500/20 hover:bg-green-500/30 text-green-300 border border-green-500/30">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        View Detailed Analytics
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 backdrop-blur-md border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400">Crypto Wallets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex items-center space-x-2">
                        <Wallet className="w-4 h-4 text-orange-400" />
                        <span className="text-gray-300">Bitcoin</span>
                      </div>
                      <span className="text-orange-400 font-mono">0.00124 BTC</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex items-center space-x-2">
                        <Wallet className="w-4 h-4 text-blue-400" />
                        <span className="text-gray-300">Ethereum</span>
                      </div>
                      <span className="text-blue-400 font-mono">0.234 ETH</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex items-center space-x-2">
                        <Wallet className="w-4 h-4 text-green-400" />
                        <span className="text-gray-300">USDC</span>
                      </div>
                      <span className="text-green-400 font-mono">1,250.00 USDC</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Passive Income Tab */}
          <TabsContent value="passive">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 backdrop-blur-md border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Affiliate Programs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Tech Affiliate Program</span>
                        <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Commission: 15% | Conversion: 8.5% | Earnings: $2,450
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Finance Tools</span>
                        <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Commission: 25% | Conversion: 12.1% | Earnings: $1,890
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 backdrop-blur-md border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Lead Funnels</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Email Capture Funnel</span>
                        <Badge className="bg-blue-500/20 text-blue-300">Optimizing</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Leads: 1,245 | Conversion: 18.5% | Revenue: $3,200
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Social Media Funnel</span>
                        <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Leads: 890 | Conversion: 14.2% | Revenue: $1,850
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Truth-Ops Tab */}
          <TabsContent value="truthops">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 backdrop-blur-md border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-purple-400">OSINT Sources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div>
                        <span className="text-gray-300">SEC EDGAR Database</span>
                        <div className="text-sm text-gray-500">Financial records</div>
                      </div>
                      <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div>
                        <span className="text-gray-300">USPTO Patent API</span>
                        <div className="text-sm text-gray-500">Tech intelligence</div>
                      </div>
                      <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div>
                        <span className="text-gray-300">Census API</span>
                        <div className="text-sm text-gray-500">Public records</div>
                      </div>
                      <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 backdrop-blur-md border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-purple-400">Research Queries</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Input
                      placeholder="Enter research query..."
                      className="bg-black/40 border-purple-500/30 text-white"
                    />
                    <Button className="w-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30">
                      <Search className="w-4 h-4 mr-2" />
                      Start Research
                    </Button>
                    <div className="text-sm text-gray-400">
                      Recent queries: Company analysis, Market research, Competitor intelligence
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Automation Tab */}
          <TabsContent value="automation">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 backdrop-blur-md border-cyan-500/30">
                <CardHeader>
                  <CardTitle className="text-cyan-400">Active Scripts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Crypto Analysis Bot</span>
                        <Badge className="bg-green-500/20 text-green-300">Running</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Schedule: Every 5 minutes | Success Rate: 98.2%
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Affiliate Processor</span>
                        <Badge className="bg-green-500/20 text-green-300">Running</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Schedule: Hourly | Success Rate: 95.7%
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium text-gray-300">Data Scraper</span>
                        <Badge className="bg-blue-500/20 text-blue-300">Scheduled</Badge>
                      </div>
                      <div className="text-sm text-gray-400">
                        Schedule: Daily at 2 AM | Success Rate: 92.1%
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 backdrop-blur-md border-cyan-500/30">
                <CardHeader>
                  <CardTitle className="text-cyan-400">System Health</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Uptime:</span>
                      <span className="text-green-400 font-bold">99.8%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">CPU Usage:</span>
                      <span className="text-cyan-400 font-bold">24%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Memory Usage:</span>
                      <span className="text-cyan-400 font-bold">45%</span>
                    </div>
                    <div className="pt-4">
                      <Button className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30">
                        <Settings className="w-4 h-4 mr-2" />
                        Manage Scripts
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* API Gateway Tab */}
          <TabsContent value="api">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 backdrop-blur-md border-orange-500/30">
                <CardHeader>
                  <CardTitle className="text-orange-400">API Endpoints</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="font-medium text-gray-300 mb-1">
                        GET /v1/monetization/stats
                      </div>
                      <div className="text-sm text-gray-400">
                        Real-time monetization statistics
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="font-medium text-gray-300 mb-1">
                        POST /v1/affiliate/create
                      </div>
                      <div className="text-sm text-gray-400">
                        Create tracked affiliate links
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-black/20 border border-gray-600/30">
                      <div className="font-medium text-gray-300 mb-1">
                        POST /v1/crypto/analyze
                      </div>
                      <div className="text-sm text-gray-400">
                        Cryptocurrency trend analysis
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 backdrop-blur-md border-orange-500/30">
                <CardHeader>
                  <CardTitle className="text-orange-400">API Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button className="w-full bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/30">
                      <Key className="w-4 h-4 mr-2" />
                      Generate API Key
                    </Button>
                    <Button className="w-full bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/30">
                      <Globe className="w-4 h-4 mr-2" />
                      View Documentation
                    </Button>
                    <div className="text-sm text-gray-400 pt-2">
                      Total requests today: 1,247<br />
                      Active API keys: 3<br />
                      Success rate: 99.1%
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/40 backdrop-blur-md border-red-500/30">
                <CardHeader>
                  <CardTitle className="text-red-400">Security Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Authentication:</span>
                      <Badge className="bg-green-500/20 text-green-300">Secure</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Encryption:</span>
                      <Badge className="bg-green-500/20 text-green-300">AES-256</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Biometric Auth:</span>
                      <Badge className="bg-blue-500/20 text-blue-300">Available</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400">Rate Limiting:</span>
                      <Badge className="bg-green-500/20 text-green-300">Active</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/40 backdrop-blur-md border-red-500/30">
                <CardHeader>
                  <CardTitle className="text-red-400">Access Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-gray-400">
                      <span>2025-01-05 13:15:42</span>
                      <span className="text-green-400">Login Success</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>2025-01-05 12:45:18</span>
                      <span className="text-blue-400">API Access</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>2025-01-05 11:30:22</span>
                      <span className="text-yellow-400">Rate Limit Hit</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>2025-01-05 10:15:45</span>
                      <span className="text-green-400">Biometric Auth</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-xs text-gray-500">
            Storm/Echo Real-Ops Core v1.0 - Advanced Operations Management
          </p>
          <div className="flex justify-center space-x-4 mt-2">
            <span className="text-xs text-green-400">🟢 All Systems Operational</span>
            <span className="text-xs text-amber-400">🔒 Secure Connection</span>
            <span className="text-xs text-blue-400">🚀 Performance Optimized</span>
          </div>
        </div>
      </div>
    </div>
  );
}