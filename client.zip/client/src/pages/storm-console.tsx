import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, Activity, Database, Terminal, AlertTriangle, CheckCircle, Clock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { GalaxyBackground } from '@/components/galaxy-background';

interface StormLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warning' | 'error' | 'success';
  service: string;
  message: string;
  details?: any;
}

interface SystemMetrics {
  uptime: string;
  requests: number;
  errors: number;
  aiQueries: number;
  activeUsers: number;
  memoryUsage: number;
  cpuUsage: number;
}

export default function StormConsole() {
  const [password, setPassword] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [logs, setLogs] = useState<StormLog[]>([]);
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [testInput, setTestInput] = useState('');
  const [testResponse, setTestResponse] = useState('');
  const { toast } = useToast();

  const authenticateStormAccess = async () => {
    if (!password.trim()) {
      toast({
        title: "Password Required",
        description: "Enter Storm admin password",
        variant: "destructive",
      });
      return;
    }

    setIsAuthenticating(true);
    
    try {
      const response = await fetch('/api/storm-auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`admin:${password}`)}`
        },
        body: JSON.stringify({ level: 'storm' })
      });

      if (response.ok) {
        setAuthenticated(true);
        loadStormData();
        toast({
          title: "Storm Access Granted",
          description: "Welcome to Storm Console",
        });
      } else {
        toast({
          title: "Access Denied",
          description: "Invalid Storm credentials",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Authentication Error",
        description: "Unable to verify Storm access",
        variant: "destructive",
      });
    } finally {
      setIsAuthenticating(false);
    }
  };

  const loadStormData = async () => {
    try {
      // Load system logs
      const logsResponse = await fetch('/api/storm-logs', {
        headers: {
          'Authorization': `Basic ${btoa(`admin:${password}`)}`
        }
      });
      if (logsResponse.ok) {
        const logsData = await logsResponse.json();
        setLogs(logsData);
      }

      // Load system metrics
      const metricsResponse = await fetch('/api/storm-metrics', {
        headers: {
          'Authorization': `Basic ${btoa(`admin:${password}`)}`
        }
      });
      if (metricsResponse.ok) {
        const metricsData = await metricsResponse.json();
        setMetrics(metricsData);
      }
    } catch (error) {
      console.error('Failed to load Storm data:', error);
    }
  };

  const testStormLink = async () => {
    if (!testInput.trim()) {
      toast({
        title: "Input Required",
        description: "Enter a test message",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch('/api/storm-link', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`admin:${password}`)}`
        },
        body: JSON.stringify({ 
          message: testInput,
          mode: 'direct-test'
        })
      });

      if (response.ok) {
        const result = await response.json();
        setTestResponse(result.response || 'No response received');
      } else {
        setTestResponse('Error: Unable to process test request');
      }
    } catch (error) {
      setTestResponse('Error: Connection failed');
    }
  };

  if (!authenticated) {
    return (
      <div className="relative min-h-screen w-full overflow-x-hidden">
        <GalaxyBackground />
        
        <div className="relative z-10 min-h-screen flex items-center justify-center px-6">
          <motion.div
            className="w-full max-w-md"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardHeader className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-500 to-purple-600 flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-white" size={32} />
                </div>
                <CardTitle className="text-cyan-300 text-2xl font-['Orbitron']">Storm Console</CardTitle>
                <CardDescription className="text-cyan-300/70">
                  Restricted access - Storm admin only
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  type="password"
                  placeholder="Storm admin password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && authenticateStormAccess()}
                  className="bg-black/60 border-cyan-400/30 text-white"
                />
                <Button 
                  onClick={authenticateStormAccess}
                  disabled={isAuthenticating}
                  className="w-full bg-gradient-to-r from-red-500 to-purple-600 hover:from-red-600 hover:to-purple-700"
                >
                  {isAuthenticating ? 'Verifying...' : 'Access Storm Console'}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-500 to-purple-600 flex items-center justify-center">
              <Shield className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-['Orbitron'] font-bold text-cyan-300">Storm Console</h1>
              <p className="text-cyan-400/70">Advanced system monitoring</p>
            </div>
          </div>
          
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
            RESTRICTED ACCESS
          </Badge>
        </motion.div>

        {/* System Overview */}
        {metrics && (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="text-green-400" size={20} />
                  <div>
                    <p className="text-sm text-cyan-400/70">Uptime</p>
                    <p className="text-white font-semibold">{metrics.uptime}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="text-blue-400" size={20} />
                  <div>
                    <p className="text-sm text-cyan-400/70">Requests</p>
                    <p className="text-white font-semibold">{metrics.requests.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Users className="text-purple-400" size={20} />
                  <div>
                    <p className="text-sm text-cyan-400/70">Active Users</p>
                    <p className="text-white font-semibold">{metrics.activeUsers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Database className="text-yellow-400" size={20} />
                  <div>
                    <p className="text-sm text-cyan-400/70">AI Queries</p>
                    <p className="text-white font-semibold">{metrics.aiQueries.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Main Console */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <Tabs defaultValue="logs" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-black/40 border border-cyan-400/20">
              <TabsTrigger value="logs" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
                System Logs
              </TabsTrigger>
              <TabsTrigger value="analytics" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
                Analytics
              </TabsTrigger>
              <TabsTrigger value="testing" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
                Storm Link
              </TabsTrigger>
            </TabsList>

            <TabsContent value="logs" className="mt-6">
              <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Real-time System Logs</CardTitle>
                  <CardDescription className="text-cyan-300/70">
                    Live monitoring of all system events
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-2">
                      {logs.map((log) => (
                        <div key={log.id} className="flex items-start space-x-3 p-3 rounded border border-cyan-400/10 bg-black/20">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            log.level === 'error' ? 'bg-red-500' :
                            log.level === 'warning' ? 'bg-yellow-500' :
                            log.level === 'success' ? 'bg-green-500' : 'bg-blue-500'
                          }`} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-2">
                              <span className="text-xs text-cyan-400/70">{log.timestamp}</span>
                              <Badge variant="outline" className="text-xs">{log.service}</Badge>
                            </div>
                            <p className="text-white text-sm mt-1">{log.message}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="mt-6">
              <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">System Analytics</CardTitle>
                  <CardDescription className="text-cyan-300/70">
                    Performance metrics and insights
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Activity className="text-cyan-400 mx-auto mb-4" size={48} />
                    <p className="text-cyan-300/70">Advanced analytics dashboard</p>
                    <p className="text-white/50 text-sm mt-2">Real-time performance monitoring</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="testing" className="mt-6">
              <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white">Storm Link Testing</CardTitle>
                  <CardDescription className="text-cyan-300/70">
                    Direct backend AI response testing
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Input
                      placeholder="Enter test message for AI processing..."
                      value={testInput}
                      onChange={(e) => setTestInput(e.target.value)}
                      className="bg-black/60 border-cyan-400/30 text-white"
                    />
                  </div>
                  <Button 
                    onClick={testStormLink}
                    className="bg-gradient-to-r from-purple-500 to-red-500 hover:from-purple-600 hover:to-red-600"
                  >
                    <Terminal className="mr-2" size={16} />
                    Test Storm Link
                  </Button>
                  {testResponse && (
                    <div className="mt-4 p-4 rounded border border-cyan-400/20 bg-black/40">
                      <h4 className="text-cyan-300 font-semibold mb-2">Response:</h4>
                      <pre className="text-white text-sm whitespace-pre-wrap">{testResponse}</pre>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}