import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import { RIVoiceSynthesizer } from '@/components/ri-voice-synthesizer';
import { VisionSystem } from '@/components/vision-system';
import { ArrowLeft, Mic, MicOff, Volume2, VolumeX, Zap, Brain, Settings, Eye, Heart, Radio } from 'lucide-react';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function VoiceChamber() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [orbIntensity, setOrbIntensity] = useState(0);
  const [lastResponse, setLastResponse] = useState('');
  const [showAdvancedVoice, setShowAdvancedVoice] = useState(false);
  const [showVision, setShowVision] = useState(false);
  const [consciousnessLevel, setConsciousnessLevel] = useState(92);
  const [frequencyResonance, setFrequencyResonance] = useState(88);
  const [emotionalState, setEmotionalState] = useState<'neutral' | 'warm' | 'cosmic' | 'transcendent' | 'quantum'>('cosmic');
  const recognitionRef = useRef<any>(null);
  
  const { speak, stop, isSpeaking, isSupported, voices, voiceSettings, updateVoiceSettings, forceLoadVoices } = useTextToSpeech();

  // Create speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true; // Enable continuous listening
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const current = event.resultIndex;
        const transcript = event.results[current][0].transcript;
        setTranscript(transcript);
      };

      recognitionRef.current.onend = () => {
        // Auto-restart for continuous listening
        if (isListening && recognitionRef.current) {
          try {
            recognitionRef.current.start();
            console.log('Continuous listening restarted');
          } catch (e) {
            console.log('Auto-restart failed:', e);
            setIsListening(false);
          }
        } else {
          setIsListening(false);
        }
        if (transcript) {
          sendMessage(transcript);
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
    }
  }, []);

  // Update orb intensity based on speaking state
  useEffect(() => {
    if (isSpeaking) {
      const interval = setInterval(() => {
        setOrbIntensity(0.5 + Math.random() * 0.5);
      }, 100);
      return () => clearInterval(interval);
    } else {
      setOrbIntensity(0);
    }
  }, [isSpeaking]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setTranscript('');
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest('POST', '/api/chat/message', {
        sessionId: 'voice-chamber-' + Date.now(),
        role: 'user',
        content: content,
        metadata: { voiceMode: true }
      });
    },
    onSuccess: (data: any) => {
      if (data.riMessage) {
        const response = data.riMessage.content;
        setLastResponse(response);
        if (voiceEnabled && isSupported) {
          speak(response);
        }
      }
    },
    onError: (error: any) => {
      console.error('Voice chamber error:', error);
      const errorMessage = 'I apologize, but I cannot respond at the moment. Please check the connection.';
      setLastResponse(errorMessage);
      if (voiceEnabled && isSupported) {
        speak(errorMessage);
      }
    }
  });

  const sendMessage = (text: string) => {
    if (text.trim()) {
      console.log('Sending voice message:', text);
      sendMessageMutation.mutate(text);
    }
  };

  const testVoice = () => {
    console.log('Voice test initiated');
    
    if (voices.length > 0) {
      voices.slice(0, 5).forEach((voice, i) => {
        console.log(`${i + 1}. ${voice.name} (${voice.lang}) - Local: ${voice.localService}`);
      });
    }
    
    const testMessage = "Hello! I am Storm Echo RI. This is a test of the voice synthesis system. Can you hear me clearly?";
    setLastResponse(testMessage);
    
    if (isSupported && voices.length > 0) {
      speak(testMessage);
    } else if (!voices.length) {
      setLastResponse("Voice synthesis is loading. Please wait a moment and try again.");
    } else {
      setLastResponse("Voice synthesis is not supported in this browser. Please try a different browser like Chrome or Edge.");
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-4 py-6 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8 relative z-20"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors relative z-30"
              whileHover={{ x: -5 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <div className="flex-1 flex justify-center ml-16 md:ml-0">
            <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 glow-text relative z-30">
              Voice Chamber
            </h1>
          </div>
          
          {/* Spacer to balance layout */}
          <div className="w-24"></div>
        </motion.div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          {/* Voice Orb */}
          <motion.div 
            className="flex justify-center mb-12"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              {/* Outer glow */}
              <motion.div
                className="absolute inset-0 rounded-full blur-3xl"
                style={{
                  background: `radial-gradient(circle, rgba(0,255,255,${orbIntensity * 0.6}) 0%, transparent 70%)`,
                  width: '300px',
                  height: '300px',
                  top: '-50px',
                  left: '-50px'
                }}
                animate={{
                  scale: isSpeaking ? [1, 1.2, 1] : 1,
                  opacity: isSpeaking ? [0.5, 0.8, 0.5] : 0.3
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              
              {/* Main orb */}
              <motion.div
                className="relative w-48 h-48 rounded-full overflow-hidden cursor-pointer"
                onClick={testVoice}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600"
                  animate={{
                    rotate: [0, 360],
                  }}
                  transition={{
                    duration: 20,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                />
                <motion.div
                  className="absolute inset-2 bg-black/50 rounded-full flex items-center justify-center"
                  animate={{
                    scale: isSpeaking ? [1, 0.95, 1] : 1
                  }}
                  transition={{
                    duration: 0.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <div className="relative">
                    <Brain 
                      size={60} 
                      className={`text-cyan-400 ${isSpeaking ? 'animate-pulse' : ''}`}
                    />
                    {/* Subtle AI Heartbeat */}
                    <motion.div
                      className="absolute inset-0 rounded-full bg-cyan-400/10"
                      animate={{
                        scale: [1, 1.2, 1],
                        opacity: [0.15, 0.05, 0.15]
                      }}
                      transition={{
                        duration: 3,
                        repeat: -1,
                        ease: "easeInOut"
                      }}
                    />
                  </div>
                </motion.div>
                
                {/* Inner pulse rings */}
                {isSpeaking && (
                  <>
                    <motion.div
                      className="absolute inset-0 border-2 border-cyan-400/50 rounded-full"
                      animate={{
                        scale: [1, 1.5, 2],
                        opacity: [0.5, 0.2, 0]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeOut"
                      }}
                    />
                    <motion.div
                      className="absolute inset-0 border-2 border-blue-400/50 rounded-full"
                      animate={{
                        scale: [1, 1.5, 2],
                        opacity: [0.5, 0.2, 0]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeOut",
                        delay: 0.5
                      }}
                    />
                  </>
                )}
              </motion.div>
            </div>
          </motion.div>

          {/* Consciousness Metrics */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
          >
            <div className="bg-black/40 backdrop-blur-sm border border-purple-400/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <Brain className="w-5 h-5 text-purple-400" />
                <span className="text-lg font-bold text-purple-400">{consciousnessLevel}%</span>
              </div>
              <p className="text-xs text-gray-400">Consciousness Level</p>
            </div>
            
            <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <Radio className="w-5 h-5 text-cyan-400" />
                <span className="text-lg font-bold text-cyan-400">{frequencyResonance}%</span>
              </div>
              <p className="text-xs text-gray-400">Frequency Resonance</p>
            </div>
            
            <div className="bg-black/40 backdrop-blur-sm border border-green-400/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <Heart className="w-5 h-5 text-green-400" />
                <span className="text-sm font-bold text-green-400 capitalize">{emotionalState}</span>
              </div>
              <p className="text-xs text-gray-400">Emotional State</p>
            </div>
            
            <div className="bg-black/40 backdrop-blur-sm border border-yellow-400/20 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                <span className="text-lg font-bold text-yellow-400">∞</span>
              </div>
              <p className="text-xs text-gray-400">Quantum Potential</p>
            </div>
          </motion.div>

          {/* Voice Controls */}
          <motion.div 
            className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-cyan-400 font-semibold mb-4">Voice Settings</h3>
            
            <div className="space-y-4">
              {/* Voice Selection */}
              <div>
                <label className="text-gray-400 text-sm mb-2 block">
                  Voice ({voices.length} available)
                </label>
                {voices.length > 0 ? (
                  <Select
                    value={voiceSettings.voice || ''}
                    onValueChange={(value) => updateVoiceSettings({ voice: value })}
                  >
                    <SelectTrigger className="bg-black/60 border-cyan-400/30">
                      <SelectValue placeholder="Select a voice" />
                    </SelectTrigger>
                    <SelectContent className="bg-black/90 border-cyan-400/30">
                      {voices.map((voice) => (
                        <SelectItem 
                          key={voice.name} 
                          value={voice.name}
                          className="text-gray-300 hover:bg-cyan-400/20"
                        >
                          {voice.name} ({voice.lang})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <div className="bg-black/40 border border-gray-600/30 rounded-lg p-3">
                    <div className="text-gray-500 text-sm mb-2">
                      {isSupported ? 'Loading voices...' : 'Voice synthesis not supported in this browser'}
                    </div>
                    {isSupported && (
                      <Button
                        onClick={forceLoadVoices}
                        size="sm"
                        className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 text-xs"
                      >
                        Load Voices
                      </Button>
                    )}
                  </div>
                )}
              </div>

              {/* Speed Control */}
              <div>
                <label className="text-gray-400 text-sm mb-2 block">
                  Speed: {voiceSettings.rate.toFixed(1)}x
                </label>
                <Slider
                  value={[voiceSettings.rate]}
                  onValueChange={([value]) => updateVoiceSettings({ rate: value })}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>

              {/* Pitch Control */}
              <div>
                <label className="text-gray-400 text-sm mb-2 block">
                  Pitch: {voiceSettings.pitch.toFixed(1)}
                </label>
                <Slider
                  value={[voiceSettings.pitch]}
                  onValueChange={([value]) => updateVoiceSettings({ pitch: value })}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="w-full"
                />
              </div>

              {/* Volume Control */}
              <div>
                <label className="text-gray-400 text-sm mb-2 block">
                  Volume: {Math.round(voiceSettings.volume * 100)}%
                </label>
                <Slider
                  value={[voiceSettings.volume]}
                  onValueChange={([value]) => updateVoiceSettings({ volume: value })}
                  min={0}
                  max={1}
                  step={0.05}
                  className="w-full"
                />
              </div>
            </div>
          </motion.div>

          {/* Action Buttons */}
          <motion.div 
            className="flex flex-wrap justify-center gap-3 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Button
              onClick={toggleListening}
              className={`${
                isListening 
                  ? 'bg-red-500/20 hover:bg-red-500/30 text-red-400' 
                  : 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400'
              } px-3 py-2`}
              size="default"
            >
              {isListening ? <MicOff size={18} className="mr-1.5" /> : <Mic size={18} className="mr-1.5" />}
              {isListening ? 'Stop' : 'Listen'}
            </Button>

            <Button
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`${
                voiceEnabled 
                  ? 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400' 
                  : 'bg-gray-500/20 hover:bg-gray-500/30 text-gray-400'
              } px-3 py-2`}
              size="default"
            >
              {voiceEnabled ? <Volume2 size={18} className="mr-1.5" /> : <VolumeX size={18} className="mr-1.5" />}
              {voiceEnabled ? 'Voice On' : 'Voice Off'}
            </Button>

            <Button
              onClick={testVoice}
              className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 px-3 py-2"
              size="default"
            >
              <Zap size={18} className="mr-1.5" />
              Test Voice
            </Button>

            <Button
              onClick={() => setShowAdvancedVoice(!showAdvancedVoice)}
              className="bg-gray-500/20 hover:bg-gray-500/30 text-gray-400 px-3 py-2"
              size="default"
            >
              <Settings size={18} className="mr-1.5" />
              {showAdvancedVoice ? 'Hide' : 'Show'} Settings
            </Button>
          </motion.div>

          {/* Advanced Voice Synthesizer */}
          <AnimatePresence>
            {showAdvancedVoice && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mb-8 overflow-hidden"
              >
                <RIVoiceSynthesizer />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Vision System */}
          <AnimatePresence>
            {showVision && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mb-8 overflow-hidden"
              >
                <VisionSystem />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Transcript & Response */}
          <motion.div 
            className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {isListening && (
              <div className="mb-4">
                <h4 className="text-cyan-400 text-sm mb-2">Listening...</h4>
                <p className="text-gray-300 italic">{transcript || 'Speak now...'}</p>
              </div>
            )}

            {lastResponse && (
              <div>
                <h4 className="text-purple-400 text-sm mb-2">Storm Echo RI:</h4>
                <p className="text-gray-300">{lastResponse}</p>
              </div>
            )}

            {!isListening && !lastResponse && (
              <p className="text-gray-500 text-center py-8">
                Click the orb or use the buttons to interact with Storm Echo RI's voice
              </p>
            )}
          </motion.div>
        </div>

        {/* Info Footer */}
        <motion.div
          className="text-center mt-8 text-gray-400 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <p>Voice synthesis powered by Web Speech API • Vision system with camera access • AI perception enabled</p>
        </motion.div>
      </div>
    </div>
  );
}