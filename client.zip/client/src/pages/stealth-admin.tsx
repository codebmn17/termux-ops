import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Eye, EyeOff, Shield, ShieldOff, DollarSign, 
  Activity, AlertTriangle, Key, Power, Lock,
  TrendingUp, Users, BarChart3, Cpu
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { GalaxyBackground } from '@/components/galaxy-background';
import { BiometricAuth } from '@/components/biometric-auth';

export default function StealthAdmin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [stealthPassphrase, setStealthPassphrase] = useState('');
  const [isStealthMode, setIsStealthMode] = useState(false);
  const [showRealEarnings, setShowRealEarnings] = useState(false);
  const [showKillSwitchAuth, setShowKillSwitchAuth] = useState(false);
  const [showSettingsAuth, setShowSettingsAuth] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Handle biometric authentication success
  const handleAdminAuthenticated = () => {
    setIsAuthenticated(true);
  };

  // Handle kill switch authentication
  const handleKillSwitchAuthenticated = () => {
    setShowKillSwitchAuth(false);
    killSwitchMutation.mutate('authenticated');
  };

  // Handle settings authentication
  const handleSettingsAuthenticated = () => {
    setShowSettingsAuth(false);
    // Continue with settings change
  };

  // Get stealth settings
  const { data: stealthSettings, refetch: refetchSettings } = useQuery<any>({
    queryKey: ['/api/admin/stealth/settings'],
    enabled: isAuthenticated
  });

  // Get crypto mining stats
  const { data: miningStats } = useQuery<any>({
    queryKey: ['/api/admin/crypto/stats'],
    enabled: isAuthenticated,
    refetchInterval: 30000 // Every 30 seconds
  });

  // Get real earnings (requires stealth passphrase)
  const { data: realEarnings } = useQuery<any>({
    queryKey: ['/api/admin/stealth/earnings'],
    enabled: isAuthenticated && showRealEarnings
  });

  // Get decoy analytics
  const { data: decoyAnalytics } = useQuery<any>({
    queryKey: ['/api/admin/stealth/decoy-analytics'],
    enabled: isAuthenticated && isStealthMode
  });

  // Toggle phantom yield mode (requires biometric auth)
  const togglePhantomYieldMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      return apiRequest('POST', '/api/admin/stealth/phantom-yield', { enabled });
    },
    onSuccess: () => {
      refetchSettings();
      setShowSettingsAuth(false);
      toast({
        title: "Phantom Yield Updated",
        description: `Stealth mode ${stealthSettings?.phantomYieldEnabled ? 'disabled' : 'enabled'}`
      });
    }
  });

  const handlePhantomYieldToggle = (enabled: boolean) => {
    setShowSettingsAuth(true);
    // Store the intended action for after authentication
    window.pendingSettingsAction = () => togglePhantomYieldMutation.mutate(enabled);
  };

  // Verify stealth passphrase
  const verifyStealthMutation = useMutation({
    mutationFn: async (passphrase: string) => {
      return apiRequest('POST', '/api/admin/stealth/verify', { passphrase });
    },
    onSuccess: (data) => {
      if (data.verified) {
        setShowRealEarnings(true);
        toast({
          title: "Stealth Access Granted",
          description: "Real earnings now visible",
          className: "bg-purple-900/90 border-purple-500"
        });
      }
    },
    onError: () => {
      toast({
        title: "Invalid Passphrase",
        description: "Stealth access denied",
        variant: "destructive"
      });
    }
  });

  // Activate kill switch
  const killSwitchMutation = useMutation({
    mutationFn: async (phrase: string) => {
      if (phrase === 'authenticated') {
        // Biometric authentication passed, activate kill switch
        return apiRequest('POST', '/api/admin/stealth/kill-switch', { 
          phrase: 'phantom protocol shutdown immediate' 
        });
      }
      return apiRequest('POST', '/api/admin/stealth/kill-switch', { phrase });
    },
    onSuccess: (data) => {
      if (data.activated) {
        toast({
          title: "⚠️ KILL SWITCH ACTIVATED",
          description: "All monetization systems shut down",
          variant: "destructive"
        });
        refetchSettings();
      }
    }
  });

  // Toggle crypto mining
  const toggleMiningMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      return apiRequest('POST', '/api/admin/crypto/toggle', { enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/crypto/stats'] });
      toast({
        title: "Mining Status Updated",
        description: `Crypto mining ${miningStats?.active ? 'stopped' : 'started'}`
      });
    }
  });

  if (!isAuthenticated) {
    return (
      <div className="relative min-h-screen">
        <GalaxyBackground />
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <BiometricAuth
            userId="admin"
            purpose="admin"
            onAuthenticated={handleAdminAuthenticated}
            title="Stealth Admin Access"
            description="Restricted Area - Biometric Authentication Required"
          />
        </div>
      </div>
    );
  }

  // Kill Switch Authentication Modal
  if (showKillSwitchAuth) {
    return (
      <div className="relative min-h-screen">
        <GalaxyBackground />
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <BiometricAuth
            userId="admin"
            purpose="killswitch"
            onAuthenticated={handleKillSwitchAuthenticated}
            onCancel={() => setShowKillSwitchAuth(false)}
            title="Kill Switch Authentication"
            description="Critical Action - Biometric Verification Required"
          />
        </div>
      </div>
    );
  }

  // Settings Authentication Modal
  if (showSettingsAuth) {
    return (
      <div className="relative min-h-screen">
        <GalaxyBackground />
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <BiometricAuth
            userId="admin"
            purpose="settings"
            onAuthenticated={() => {
              handleSettingsAuthenticated();
              // Execute pending settings action
              if ((window as any).pendingSettingsAction) {
                (window as any).pendingSettingsAction();
                delete (window as any).pendingSettingsAction;
              }
            }}
            onCancel={() => setShowSettingsAuth(false)}
            title="Security Settings"
            description="Settings Change - Biometric Verification Required"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen">
      <GalaxyBackground />
      
      <div className="relative z-10 max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-['Orbitron'] font-bold text-red-400 mb-2">
            Stealth Admin Control Panel
          </h1>
          <p className="text-gray-400">
            Advanced monetization and security controls
          </p>
        </motion.div>

        <Tabs defaultValue="stealth" className="space-y-4">
          <TabsList className="bg-black/40 border border-red-500/30">
            <TabsTrigger value="stealth" className="data-[state=active]:bg-red-500/20">
              Stealth Mode
            </TabsTrigger>
            <TabsTrigger value="earnings" className="data-[state=active]:bg-red-500/20">
              Real Earnings
            </TabsTrigger>
            <TabsTrigger value="crypto" className="data-[state=active]:bg-red-500/20">
              Crypto Mining
            </TabsTrigger>
            <TabsTrigger value="killswitch" className="data-[state=active]:bg-red-500/20">
              Kill Switch
            </TabsTrigger>
          </TabsList>

          {/* Stealth Mode Tab */}
          <TabsContent value="stealth">
            <Card className="bg-black/60 backdrop-blur-md border-red-500/30">
              <CardHeader>
                <CardTitle className="text-xl text-red-300">Phantom Yield Mode</CardTitle>
                <CardDescription className="text-gray-400">
                  Hide real earnings behind decoy analytics
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label className="text-gray-300">Enable Phantom Yield</Label>
                    <p className="text-sm text-gray-500">
                      Show fake traffic analytics instead of real earnings
                    </p>
                  </div>
                  <Switch
                    checked={stealthSettings?.phantomYieldEnabled || false}
                    onCheckedChange={handlePhantomYieldToggle}
                  />
                </div>

                {stealthSettings?.phantomYieldEnabled && decoyAnalytics && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-4 bg-black/40 rounded-lg border border-gray-700"
                  >
                    <h3 className="text-lg font-semibold text-gray-300 mb-3">
                      Decoy Analytics (Public View)
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Visitors</p>
                        <p className="text-xl font-bold text-gray-300">{decoyAnalytics.visitors}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Page Views</p>
                        <p className="text-xl font-bold text-gray-300">{decoyAnalytics.pageViews}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Bounce Rate</p>
                        <p className="text-xl font-bold text-gray-300">{decoyAnalytics.bounceRate}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Avg Duration</p>
                        <p className="text-xl font-bold text-gray-300">{decoyAnalytics.avgSessionDuration}</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Real Earnings Tab */}
          <TabsContent value="earnings">
            <Card className="bg-black/60 backdrop-blur-md border-red-500/30">
              <CardHeader>
                <CardTitle className="text-xl text-red-300">Encrypted Earnings Access</CardTitle>
                <CardDescription className="text-gray-400">
                  Requires stealth passphrase for decryption
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!showRealEarnings ? (
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    verifyStealthMutation.mutate(stealthPassphrase);
                  }} className="space-y-4">
                    <div>
                      <Label htmlFor="stealth-pass" className="text-gray-300">
                        Stealth Passphrase
                      </Label>
                      <Input
                        id="stealth-pass"
                        type="password"
                        value={stealthPassphrase}
                        onChange={(e) => setStealthPassphrase(e.target.value)}
                        className="bg-black/40 border-red-500/30 text-white"
                        placeholder="Enter stealth passphrase"
                      />
                    </div>
                    <Button
                      type="submit"
                      className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30"
                      disabled={verifyStealthMutation.isPending}
                    >
                      <Key size={20} className="mr-2" />
                      Decrypt Earnings
                    </Button>
                  </form>
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-4"
                  >
                    <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/30">
                      <h3 className="text-lg font-semibold text-green-300 mb-3">
                        Real Earnings (Decrypted)
                      </h3>
                      {realEarnings && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-sm text-gray-400">Total Revenue</p>
                            <p className="text-2xl font-bold text-green-400">
                              ${realEarnings.totalRevenue?.toFixed(2) || '0.00'}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-400">Crypto Earnings</p>
                            <p className="text-2xl font-bold text-orange-400">
                              ${realEarnings.cryptoEarnings?.toFixed(2) || '0.00'}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-400">Affiliate Income</p>
                            <p className="text-2xl font-bold text-blue-400">
                              ${realEarnings.affiliateIncome?.toFixed(2) || '0.00'}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Crypto Mining Tab */}
          <TabsContent value="crypto">
            <Card className="bg-black/60 backdrop-blur-md border-red-500/30">
              <CardHeader>
                <CardTitle className="text-xl text-red-300">Crypto Mining Control</CardTitle>
                <CardDescription className="text-gray-400">
                  Automated Monero mining with auto-trade to stablecoin
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label className="text-gray-300">Mining Status</Label>
                    <p className="text-sm text-gray-500">
                      {miningStats?.active ? 'Mining in progress' : 'Mining stopped'}
                    </p>
                  </div>
                  <Switch
                    checked={miningStats?.active || false}
                    onCheckedChange={(checked) => toggleMiningMutation.mutate(checked)}
                  />
                </div>

                {miningStats && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-black/40 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-500">Hash Rate</p>
                      <p className="text-xl font-bold text-orange-400">{miningStats.hashRate} H/s</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Wallet Balance</p>
                      <p className="text-xl font-bold text-orange-400">
                        {miningStats.walletBalance?.toFixed(8)} XMR
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Total Mined</p>
                      <p className="text-xl font-bold text-orange-400">
                        {miningStats.totalMined?.toFixed(8)} XMR
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Auto-Trade</p>
                      <p className="text-xl font-bold text-orange-400">
                        {miningStats.autoTradeEnabled ? 'Enabled' : 'Disabled'}
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Kill Switch Tab */}
          <TabsContent value="killswitch">
            <Card className="bg-black/60 backdrop-blur-md border-red-600/50">
              <CardHeader>
                <CardTitle className="text-xl text-red-400 flex items-center gap-2">
                  <AlertTriangle size={24} />
                  Emergency Kill Switch
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Instantly shut down all monetization systems
                </CardDescription>
              </CardHeader>
              <CardContent>
                {stealthSettings?.killSwitchActive ? (
                  <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/30">
                    <h3 className="text-lg font-semibold text-red-400 mb-2">
                      ⚠️ KILL SWITCH ACTIVE
                    </h3>
                    <p className="text-gray-300 mb-2">
                      All monetization systems have been shut down
                    </p>
                    <p className="text-sm text-gray-500">
                      Activated at: {new Date(stealthSettings.killSwitchActivatedAt!).toLocaleString()}
                    </p>
                  </div>
                ) : (
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    killSwitchMutation.mutate(killSwitchPhrase);
                  }} className="space-y-4">
                    <div>
                      <Label htmlFor="kill-phrase" className="text-gray-300">
                        Kill Switch Activation Phrase
                      </Label>
                      <Input
                        id="kill-phrase"
                        type="text"
                        value={killSwitchPhrase}
                        onChange={(e) => setKillSwitchPhrase(e.target.value)}
                        className="bg-black/40 border-red-600/30 text-white"
                        placeholder="Enter kill switch phrase"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        This action will immediately shut down all monetization
                      </p>
                    </div>
                    <Button
                      type="button"
                      onClick={() => setShowKillSwitchAuth(true)}
                      className="bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-600/30"
                      disabled={killSwitchMutation.isPending}
                    >
                      <Power size={20} className="mr-2" />
                      Activate Kill Switch
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}