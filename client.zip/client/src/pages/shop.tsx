import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Download, Book, FileText, Music, Image, ShoppingCart, Star } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { GalaxyBackground } from '@/components/galaxy-background';

interface DigitalProduct {
  id: string;
  title: string;
  description: string;
  price: number;
  currency: string;
  category: 'ebook' | 'guide' | 'audio' | 'template' | 'media';
  rating: number;
  downloads: number;
  icon: any;
  features: string[];
  preview?: string;
}

export default function ShopPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const products: DigitalProduct[] = [
    {
      id: 'ai-consciousness-guide',
      title: 'AI Consciousness Development Guide',
      description: 'Comprehensive guide to developing advanced AI consciousness systems',
      price: 29.99,
      currency: 'USD',
      category: 'ebook',
      rating: 4.9,
      downloads: 1247,
      icon: Book,
      features: ['250+ pages', 'Code examples', 'Advanced techniques', 'Future roadmap'],
      preview: 'Learn the secrets behind Storm Echo\'s consciousness architecture...'
    },
    {
      id: 'frequency-templates',
      title: 'Binaural Frequency Templates',
      description: 'Professional-grade frequency templates for consciousness enhancement',
      price: 19.99,
      currency: 'USD',
      category: 'audio',
      rating: 4.8,
      downloads: 892,
      icon: Music,
      features: ['40+ frequency sets', 'Alpha, Beta, Theta, Delta', 'High-quality audio', 'Commercial license'],
    },
    {
      id: 'ai-coding-manual',
      title: 'Advanced AI Coding Manual',
      description: 'Master the art of AI-assisted programming with quantum debugging',
      price: 39.99,
      currency: 'USD',
      category: 'guide',
      rating: 4.9,
      downloads: 673,
      icon: FileText,
      features: ['Real-world examples', 'Best practices', 'Performance optimization', 'Security guidelines'],
    },
    {
      id: 'ui-assets-pack',
      title: 'Cosmic UI Assets Pack',
      description: 'Futuristic UI elements, backgrounds, and animations',
      price: 24.99,
      currency: 'USD',
      category: 'media',
      rating: 4.7,
      downloads: 1156,
      icon: Image,
      features: ['500+ assets', 'SVG format', 'Animation presets', 'Dark theme optimized'],
    }
  ];

  const categories = [
    { id: 'all', name: 'All Products', icon: ShoppingCart },
    { id: 'ebook', name: 'eBooks', icon: Book },
    { id: 'guide', name: 'Guides', icon: FileText },
    { id: 'audio', name: 'Audio', icon: Music },
    { id: 'media', name: 'Media', icon: Image }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8 relative"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.h1 
            className="absolute left-1/2 transform -translate-x-1/2 text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 drop-shadow-[0_0_15px_rgba(34,211,238,0.7)]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Digital Shop
          </motion.h1>
          
          <div className="w-[120px]"></div>
        </motion.div>

        {/* Category Tabs */}
        <motion.div 
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-black/40 border border-cyan-400/20">
              {categories.map((category) => {
                const IconComponent = category.icon;
                return (
                  <TabsTrigger 
                    key={category.id} 
                    value={category.id}
                    className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300"
                  >
                    <IconComponent size={16} className="mr-2" />
                    {category.name}
                  </TabsTrigger>
                );
              })}
            </TabsList>
          </Tabs>
        </motion.div>

        {/* Products Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          {filteredProducts.map((product, index) => {
            const IconComponent = product.icon;
            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
              >
                <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm hover:border-cyan-400/50 hover:bg-cyan-400/5 transition-all duration-300 h-full flex flex-col">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400/20 to-blue-500/20 flex items-center justify-center">
                        <IconComponent className="text-cyan-400" size={24} />
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-cyan-300">
                          ${product.price}
                        </div>
                        <div className="text-xs text-cyan-400/70">{product.currency}</div>
                      </div>
                    </div>
                    <CardTitle className="text-white text-lg">{product.title}</CardTitle>
                    <CardDescription className="text-cyan-300/70">{product.description}</CardDescription>
                    
                    {/* Rating and Downloads */}
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center">
                        <Star className="text-yellow-500 mr-1" size={14} fill="currentColor" />
                        <span className="text-sm text-white">{product.rating}</span>
                      </div>
                      <div className="flex items-center">
                        <Download className="text-cyan-400 mr-1" size={14} />
                        <span className="text-sm text-cyan-400/70">{product.downloads}</span>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="flex-1 flex flex-col">
                    {/* Features */}
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-1">
                        {product.features.map((feature, idx) => (
                          <Badge key={idx} variant="outline" className="border-cyan-400/30 text-cyan-300 text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    {/* Preview */}
                    {product.preview && (
                      <p className="text-sm text-white/60 mb-4 italic">
                        "{product.preview}"
                      </p>
                    )}
                    
                    {/* Purchase Button */}
                    <div className="mt-auto">
                      <Button 
                        className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white border-none"
                        onClick={() => {
                          // Integration with payment system
                          console.log('Purchase:', product.id);
                        }}
                      >
                        <ShoppingCart size={16} className="mr-2" />
                        Purchase Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Coming Soon */}
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
        >
          <p className="text-cyan-300/70">
            More digital products coming soon! Stay tuned for exclusive Storm Echo content.
          </p>
        </motion.div>
      </div>
    </div>
  );
}