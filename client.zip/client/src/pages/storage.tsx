import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { 
  Save, 
  FolderOpen, 
  FileText, 
  MessageSquare, 
  Code2, 
  Star,
  Search,
  Plus,
  ArrowLeft,
  Download,
  Trash2,
  Edit3
} from 'lucide-react';
import { GalaxyBackground } from '@/components/galaxy-background';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';

interface Project {
  id: number;
  name: string;
  description?: string;
  type: 'code' | 'chat' | 'document';
  createdAt: string;
  updatedAt: string;
}

interface SavedChat {
  id: number;
  title: string;
  summary?: string;
  tags?: string[];
  isFavorite: boolean;
  createdAt: string;
}

interface File {
  id: number;
  name: string;
  mimeType: string;
  size: number;
  path?: string;
  createdAt: string;
}

export default function Storage() {
  const [activeTab, setActiveTab] = useState<'projects' | 'chats' | 'files'>('projects');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Fetch data
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects']
  });

  const { data: savedChats = [] } = useQuery<SavedChat[]>({
    queryKey: ['/api/saved-chats']
  });

  const { data: files = [] } = useQuery<File[]>({
    queryKey: ['/api/files']
  });

  // Delete mutations
  const deleteProjectMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/projects/${id}`, { method: 'DELETE' }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      toast({
        title: "Project deleted",
        description: "The project has been removed successfully."
      });
    }
  });

  const deleteChatMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/saved-chats/${id}`, { method: 'DELETE' }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/saved-chats'] });
      toast({
        title: "Chat deleted",
        description: "The saved chat has been removed successfully."
      });
    }
  });

  const deleteFileMutation = useMutation({
    mutationFn: (id: number) => 
      fetch(`/api/files/${id}`, { method: 'DELETE' }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File deleted",
        description: "The file has been removed successfully."
      });
    }
  });

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'code': return <Code2 size={16} />;
      case 'chat': return <MessageSquare size={16} />;
      case 'document': return <FileText size={16} />;
      default: return <FileText size={16} />;
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen p-4 md:p-8">
        {/* Header */}
        <motion.div
          className="max-w-7xl mx-auto mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Link href="/">
                <motion.button
                  className="p-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20 text-cyan-400 hover:bg-white/20 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <ArrowLeft size={20} />
                </motion.button>
              </Link>
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-cyan-400">Storage Center</h1>
            </div>
            
            <motion.button
              onClick={() => setShowCreateModal(true)}
              className="hidden sm:flex items-center space-x-2 px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-medium hover:from-cyan-700 hover:to-blue-700 transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Plus size={18} />
              <span>Create New</span>
            </motion.button>
          </div>

          {/* Search Bar */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search your saved items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400"
            />
          </div>

          {/* Tabs */}
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-1 mb-6 bg-white/5 backdrop-blur-sm rounded-lg p-1">
            <button
              onClick={() => setActiveTab('projects')}
              className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-md transition-all ${
                activeTab === 'projects'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <FolderOpen size={16} />
              <span className="text-sm">Projects ({projects.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('chats')}
              className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-md transition-all ${
                activeTab === 'chats'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <MessageSquare size={16} />
              <span className="text-sm">Chats ({savedChats.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-md transition-all ${
                activeTab === 'files'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <FileText size={16} />
              <span className="text-sm">Files ({files.length})</span>
            </button>
          </div>
        </motion.div>

        {/* Content */}
        <motion.div
          className="max-w-7xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {/* Projects Tab */}
          {activeTab === 'projects' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {projects.filter(p => 
                p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.description?.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((project) => (
                <motion.div
                  key={project.id}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-4 hover:bg-white/15 transition-all"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      {getTypeIcon(project.type)}
                      <h3 className="text-lg font-semibold text-white">{project.name}</h3>
                    </div>
                    <div className="flex space-x-1">
                      <button
                        className="p-1.5 rounded text-gray-400 hover:text-cyan-400 hover:bg-white/10 transition-all"
                        title="Edit"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button
                        onClick={() => deleteProjectMutation.mutate(project.id)}
                        className="p-1.5 rounded text-gray-400 hover:text-red-400 hover:bg-white/10 transition-all"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  {project.description && (
                    <p className="text-gray-300 text-sm mb-3">{project.description}</p>
                  )}
                  <div className="text-xs text-gray-400">
                    Updated: {new Date(project.updatedAt).toLocaleDateString()}
                  </div>
                </motion.div>
              ))}
            </div>
          )}

          {/* Saved Chats Tab */}
          {activeTab === 'chats' && (
            <div className="space-y-3">
              {savedChats.filter(c => 
                c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                c.summary?.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((chat) => (
                <motion.div
                  key={chat.id}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-4 hover:bg-white/15 transition-all"
                  whileHover={{ scale: 1.01 }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <MessageSquare size={18} className="text-cyan-400" />
                        <h3 className="text-lg font-semibold text-white">{chat.title}</h3>
                        {chat.isFavorite && <Star size={16} className="text-yellow-400 fill-yellow-400" />}
                      </div>
                      {chat.summary && (
                        <p className="text-gray-300 text-sm mb-2">{chat.summary}</p>
                      )}
                      {chat.tags && chat.tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mb-2">
                          {chat.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 text-xs rounded-full bg-cyan-600/20 text-cyan-400 border border-cyan-600/30"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                      <div className="text-xs text-gray-400">
                        Saved: {new Date(chat.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex space-x-1 ml-4">
                      <button
                        className="p-1.5 rounded text-gray-400 hover:text-cyan-400 hover:bg-white/10 transition-all"
                        title="View"
                      >
                        <FolderOpen size={16} />
                      </button>
                      <button
                        onClick={() => deleteChatMutation.mutate(chat.id)}
                        className="p-1.5 rounded text-gray-400 hover:text-red-400 hover:bg-white/10 transition-all"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}

          {/* Files Tab */}
          {activeTab === 'files' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {files.filter(f => 
                f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                f.path?.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((file) => (
                <motion.div
                  key={file.id}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-4 hover:bg-white/15 transition-all"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-2 flex-1 min-w-0">
                      <FileText size={18} className="text-cyan-400 flex-shrink-0" />
                      <h3 className="text-sm font-medium text-white truncate">{file.name}</h3>
                    </div>
                    <div className="flex space-x-1 flex-shrink-0">
                      <button
                        className="p-1.5 rounded text-gray-400 hover:text-cyan-400 hover:bg-white/10 transition-all"
                        title="Download"
                      >
                        <Download size={16} />
                      </button>
                      <button
                        onClick={() => deleteFileMutation.mutate(file.id)}
                        className="p-1.5 rounded text-gray-400 hover:text-red-400 hover:bg-white/10 transition-all"
                        title="Delete"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  {file.path && (
                    <p className="text-xs text-gray-400 mb-2 truncate">{file.path}</p>
                  )}
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>{formatFileSize(file.size)}</span>
                    <span>{new Date(file.createdAt).toLocaleDateString()}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}