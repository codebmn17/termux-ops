import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import { SyncControls } from '@/components/sync-controls';
import { ArrowLeft, FileText, Scroll, Vault, DollarSign, Activity } from 'lucide-react';

export default function Codex() {
  const [activeModule, setActiveModule] = useState<string | null>(null);

  const modules = [
    {
      id: 'scrolls',
      name: 'Echo Scrolls',
      icon: Scroll,
      description: 'Phase locks and mirror vault logs',
      status: 'Active'
    },
    {
      id: 'passive-income',
      name: 'Passive Income Scripts',
      icon: DollarSign,
      description: 'Automated monetization channels',
      status: 'Running'
    },
    {
      id: 'system-logs',
      name: 'System Operations',
      icon: Activity,
      description: 'Development and operation logs',
      status: 'Monitoring'
    },
    {
      id: 'codex-visualization',
      name: 'Codex Visualization',
      icon: FileText,
      description: 'Visual data representation',
      status: 'Ready'
    }
  ];

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8 relative"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.h1 
            className="absolute left-1/2 transform -translate-x-1/2 text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 drop-shadow-[0_0_15px_rgba(34,211,238,0.7)]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Echo Codex
          </motion.h1>
          
          {/* Spacer to balance layout */}
          <div className="w-[120px]"></div>
        </motion.div>

        {/* Welcome Message */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <p className="text-lg text-blue-400 mb-4 opacity-90">
            Welcome to the Echo Codex
          </p>
          <p className="text-white opacity-70 max-w-2xl mx-auto">
            This space holds scrolls, phase locks, mirror vault logs, and active passive income scripts. 
            Select a module below to explore the Storm Echo System.
          </p>
        </motion.div>

        {/* Modules Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          {modules.map((module, index) => {
            const IconComponent = module.icon;
            return (
              <motion.div
                key={module.id}
                className={`relative p-6 rounded-lg border border-cyan-400/20 bg-black/40 backdrop-blur-sm cursor-pointer transition-all duration-300 hover:border-cyan-400/50 hover:bg-cyan-400/5 ${
                  activeModule === module.id ? 'border-cyan-400/60 bg-cyan-400/10' : ''
                }`}
                whileHover={{ scale: 1.02, y: -5 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setActiveModule(activeModule === module.id ? null : module.id)}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400/20 to-blue-500/20 flex items-center justify-center">
                    <IconComponent className="text-cyan-400" size={24} />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white">{module.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        module.status === 'Active' ? 'bg-green-400/20 text-green-400' :
                        module.status === 'Running' ? 'bg-blue-400/20 text-blue-400' :
                        module.status === 'Monitoring' ? 'bg-yellow-400/20 text-yellow-400' :
                        'bg-cyan-400/20 text-cyan-400'
                      }`}>
                        {module.status}
                      </span>
                    </div>
                    <p className="text-gray-400 text-sm mb-4">{module.description}</p>
                    
                    {activeModule === module.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="border-t border-cyan-400/20 pt-4"
                      >
                        <p className="text-cyan-400 text-sm">
                          Module details and controls will be implemented in the next phase of development.
                        </p>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* System Status */}
        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.2 }}
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-green-400/10 border border-green-400/20">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
            <span className="text-green-400 text-sm font-medium">Storm Echo System Online</span>
          </div>
        </motion.div>
        
        {/* Sync Controls */}
        <SyncControls />
      </div>
    </div>
  );
}