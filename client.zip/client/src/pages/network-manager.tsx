import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft, Wifi, Shield, Globe, Zap } from 'lucide-react';
import { SecureConnectionManager } from '@/components/secure-connection-manager';
import anonymousHackerBg from '@assets/file_0000000077d862438227c9b39b7647a7_1754244113163.png';

export default function NetworkManagerPage() {
  return (
    <div className="relative min-h-screen w-full overflow-x-hidden flex flex-col">
      {/* Anonymous Hacker Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${anonymousHackerBg})` }}
      />
      
      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-black/90" />
      
      <div className="relative z-10 flex flex-col h-full">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between px-4 py-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-gray-300 hover:text-gray-200 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <div className="flex items-center space-x-4">
            <motion.div 
              className="flex items-center space-x-2 text-green-400"
              animate={{ 
                scale: [1, 1.05, 1],
                opacity: [0.8, 1, 0.8]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Shield size={20} />
              <span className="text-sm font-medium">Secure Connection Active</span>
            </motion.div>
          </div>
        </motion.div>

        {/* Page Title */}
        <motion.div 
          className="px-4 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 rounded-lg bg-gradient-to-r from-gray-800 to-gray-700">
              <Wifi className="w-6 h-6 text-gray-200" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-cyan-300">Network Connection Manager</h1>
              <p className="text-gray-400">Fast, Secure, & Optimized Web Connectivity</p>
            </div>
          </div>
        </motion.div>

        {/* Connection Manager */}
        <div className="flex-1 px-4 pb-6">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <SecureConnectionManager />
            </motion.div>
          </div>
        </div>

        {/* Feature Highlights */}
        <motion.div 
          className="px-4 py-6 border-t border-gray-800/50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-black/50 border border-gray-800/50">
                <Zap className="w-5 h-5 text-yellow-400" />
                <div>
                  <p className="text-sm font-medium text-gray-200">Quantum Acceleration</p>
                  <p className="text-xs text-gray-400">Ultra-fast connection optimization</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-black/50 border border-gray-800/50">
                <Shield className="w-5 h-5 text-green-400" />
                <div>
                  <p className="text-sm font-medium text-gray-200">Military-Grade Encryption</p>
                  <p className="text-xs text-gray-400">AES-256 with WPA3 security</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-black/50 border border-gray-800/50">
                <Globe className="w-5 h-5 text-blue-400" />
                <div>
                  <p className="text-sm font-medium text-gray-200">Global Network Access</p>
                  <p className="text-xs text-gray-400">Worldwide secure connectivity</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}