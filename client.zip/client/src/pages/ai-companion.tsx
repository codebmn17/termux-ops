import { motion } from 'framer-motion';
import { EnhancedAIChat } from '@/components/enhanced-ai-chat';
import { Brain, Sparkles, Code } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function AICompanionPage() {
  const handleCodeGenerated = (code: string, language: string) => {
    // In a real implementation, this would integrate with the code editor
    console.log('Generated code:', { code, language });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/20 to-cyan-900/20">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10"></div>
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400 rounded-full"
            initial={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
            }}
            animate={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
            }}
            transition={{
              duration: Math.random() * 20 + 20,
              repeat: Infinity,
              repeatType: 'reverse',
            }}
          />
        ))}
      </div>

      {/* Header */}
      <motion.header
        className="relative z-10 p-6 flex items-center justify-between border-b border-cyan-400/30 bg-gray-900/50 backdrop-blur-md"
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" className="text-cyan-400 hover:bg-cyan-400/20">
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <Brain className="w-8 h-8 text-cyan-400" />
            <div>
              <h1 className="text-2xl font-bold text-cyan-400">Super Intelligent AI Companion</h1>
              <p className="text-sm text-gray-400">Real-time super intelligent development assistance</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
          <Code className="w-5 h-5 text-cyan-400" />
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="relative z-10 container mx-auto p-6">
        <motion.div
          className="w-full h-[calc(100vh-200px)]"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <EnhancedAIChat 
            title="Super Intelligent AI Companion"
            enableCodeGeneration={true}
            enableVoice={true}
            enablePersonalities={true}
            mode="coding"
            onCodeGenerated={handleCodeGenerated}
          />
        </motion.div>

        {/* Feature Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="p-4 bg-gray-900/50 backdrop-blur-md rounded-lg border border-cyan-400/30">
            <h3 className="text-cyan-400 font-semibold mb-2">Real-time Assistance</h3>
            <p className="text-gray-400 text-sm">Get instant help while coding with super intelligent suggestions and error detection.</p>
          </div>
          <div className="p-4 bg-gray-900/50 backdrop-blur-md rounded-lg border border-purple-400/30">
            <h3 className="text-purple-400 font-semibold mb-2">Code Generation</h3>
            <p className="text-gray-400 text-sm">Generate complete components, APIs, and features with Storm Echo RI patterns.</p>
          </div>
          <div className="p-4 bg-gray-900/50 backdrop-blur-md rounded-lg border border-green-400/30">
            <h3 className="text-green-400 font-semibold mb-2">Smart Debugging</h3>
            <p className="text-gray-400 text-sm">Identify and fix issues quickly with AI-powered debugging assistance.</p>
          </div>
        </motion.div>
      </main>
    </div>
  );
}