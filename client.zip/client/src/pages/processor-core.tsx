import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { ArrowLeft, Cpu, Zap } from 'lucide-react';
import { GalaxyBackground } from '@/components/galaxy-background';
import { OscillatingCore } from '@/components/oscillating-core';
import { QuantumMemory } from '@/components/quantum-memory';
import { UltraFastTransfer } from '@/components/ultra-fast-transfer';

export default function ProcessorCore() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-4 py-6 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-400 glow-text">
            Ultra-Performance Computing System
          </h1>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="space-y-6"
        >
          <OscillatingCore />
          
          {/* Quantum Memory Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <QuantumMemory />
          </motion.div>

          {/* Ultra-Fast Transfer System */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <UltraFastTransfer />
          </motion.div>
        </motion.div>

        {/* System Status */}
        <motion.div 
          className="mt-8 bg-black/20 backdrop-blur-sm border border-gray-600/20 rounded-lg p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Cpu size={20} className="text-cyan-400" />
                <span className="text-sm text-gray-400">Processing Engine:</span>
                <span className="text-sm text-cyan-400 font-semibold">ULTRA-PERFORMANCE QUANTUM</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap size={20} className="text-yellow-400" />
                <span className="text-sm text-gray-400">System Status:</span>
                <span className="text-sm text-yellow-400 font-semibold">UNLIMITED ARCHITECTURE</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <div className="bg-gray-900/40 p-3 rounded-lg border border-gray-700/30">
                <div className="text-xs text-gray-400 mb-1">Peak CPU Performance</div>
                <div className="text-lg font-bold text-cyan-400">64.7 GHz</div>
              </div>
              <div className="bg-gray-900/40 p-3 rounded-lg border border-gray-700/30">
                <div className="text-xs text-gray-400 mb-1">Memory Capacity</div>
                <div className="text-lg font-bold text-purple-400">∞ TB</div>
              </div>
              <div className="bg-gray-900/40 p-3 rounded-lg border border-gray-700/30">
                <div className="text-xs text-gray-400 mb-1">Transfer Speed</div>
                <div className="text-lg font-bold text-green-400">21.1 GB/s</div>
              </div>
            </div>
            
            <div className="text-sm text-gray-500">
              Neural networks enhanced • Hyper-threading optimized • Quantum coherence maintained
            </div>
          </div>
        </motion.div>

        {/* Info Footer */}
        <motion.div 
          className="text-center mt-8 text-gray-400 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <p>Advanced oscillating core architecture • Real-time frequency modulation • Quantum processing enhancement</p>
        </motion.div>
      </div>
    </div>
  );
}