import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { ArrowLeft } from 'lucide-react';
import { GalaxyBackground } from '@/components/galaxy-background';
import { StartupAccelerator } from '@/components/startup-accelerator';

export default function StartupAcceleratorPage() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-4 py-6 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 glow-text">
            Quick-Load Startup Accelerator
          </h1>
        </motion.div>

        {/* Main Content */}
        <motion.div 
          className="max-w-6xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <StartupAccelerator />
        </motion.div>

        {/* Info Footer */}
        <motion.div
          className="text-center mt-12 text-gray-400 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <p>Advanced performance optimization for Storm Echo RI • Real-time system monitoring</p>
        </motion.div>
      </div>
    </div>
  );
}