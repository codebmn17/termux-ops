import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { ArrowLeft, Bot, Zap, TrendingUp, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DynamicAIUpdater } from '@/components/dynamic-ai-updater';
import { AIAutomationEngine } from '@/components/ai-automation-engine';

export default function AIAutomationPage() {
  const [activeTab, setActiveTab] = useState('updater');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Background Effects */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-gray-900 to-black" />
      <div className="fixed inset-0 bg-[url('/grid.svg')] opacity-10" />
      
      {/* Animated Background Particles */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Header */}
        <motion.div
          className="flex items-center justify-between p-6 border-b border-gray-700/50 backdrop-blur-sm bg-gray-900/50"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <Bot className="w-8 h-8 text-cyan-400" />
            <div>
              <h1 className="text-2xl font-bold text-cyan-400">AI Automation & Updates</h1>
              <p className="text-sm text-gray-400">Dynamic AI evolution and intelligent automation</p>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">
            {/* Introduction */}
            <motion.div
              className="text-center mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <h2 className="text-3xl font-bold text-white mb-4">
                Autonomous Intelligence Evolution
              </h2>
              <p className="text-gray-300 text-lg max-w-3xl mx-auto">
                Experience the future of AI with self-updating intelligence, autonomous task execution, 
                and continuous system optimization. Storm Echo RI evolves in real-time to provide 
                ever-improving performance and capabilities.
              </p>
            </motion.div>

            {/* Feature Tabs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-8">
                  <TabsTrigger 
                    value="updater" 
                    className="flex items-center space-x-2"
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>Dynamic AI Updates</span>
                  </TabsTrigger>
                  <TabsTrigger 
                    value="automation" 
                    className="flex items-center space-x-2"
                  >
                    <Activity className="w-4 h-4" />
                    <span>Automation Engine</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="updater" className="mt-0">
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <DynamicAIUpdater />
                  </motion.div>
                </TabsContent>

                <TabsContent value="automation" className="mt-0">
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <AIAutomationEngine />
                  </motion.div>
                </TabsContent>
              </Tabs>
            </motion.div>

            {/* Feature Cards */}
            <motion.div
              className="grid md:grid-cols-2 gap-6 mt-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="p-6 bg-gray-900/50 backdrop-blur-md rounded-lg border border-cyan-400/30">
                <div className="flex items-center space-x-3 mb-4">
                  <TrendingUp className="w-6 h-6 text-cyan-400" />
                  <h3 className="text-xl font-semibold text-white">Real-time Evolution</h3>
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  AI personalities and capabilities continuously evolve based on interactions, 
                  learning patterns, and performance metrics. Each update enhances intelligence 
                  and user experience.
                </p>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Automatic personality refinements</li>
                  <li>• Performance optimization updates</li>
                  <li>• Learning algorithm improvements</li>
                  <li>• Capability expansions</li>
                </ul>
              </div>

              <div className="p-6 bg-gray-900/50 backdrop-blur-md rounded-lg border border-purple-400/30">
                <div className="flex items-center space-x-3 mb-4">
                  <Activity className="w-6 h-6 text-purple-400" />
                  <h3 className="text-xl font-semibold text-white">Intelligent Automation</h3>
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  Autonomous task execution handles system maintenance, optimization, and enhancement 
                  without manual intervention. The AI manages itself intelligently.
                </p>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Continuous performance monitoring</li>
                  <li>• Automatic memory optimization</li>
                  <li>• Security threat detection</li>
                  <li>• User experience enhancements</li>
                </ul>
              </div>

              <div className="p-6 bg-gray-900/50 backdrop-blur-md rounded-lg border border-green-400/30">
                <div className="flex items-center space-x-3 mb-4">
                  <Zap className="w-6 h-6 text-green-400" />
                  <h3 className="text-xl font-semibold text-white">Predictive Intelligence</h3>
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  Advanced algorithms predict system needs and user requirements, proactively 
                  implementing improvements before issues arise.
                </p>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Predictive maintenance scheduling</li>
                  <li>• Proactive capability enhancement</li>
                  <li>• User need anticipation</li>
                  <li>• Resource optimization</li>
                </ul>
              </div>

              <div className="p-6 bg-gray-900/50 backdrop-blur-md rounded-lg border border-orange-400/30">
                <div className="flex items-center space-x-3 mb-4">
                  <Bot className="w-6 h-6 text-orange-400" />
                  <h3 className="text-xl font-semibold text-white">Autonomous Learning</h3>
                </div>
                <p className="text-gray-300 text-sm mb-4">
                  The AI continuously learns from every interaction, adapting its responses, 
                  personality traits, and problem-solving approaches without human intervention.
                </p>
                <ul className="space-y-2 text-sm text-gray-400">
                  <li>• Pattern recognition improvement</li>
                  <li>• Response quality enhancement</li>
                  <li>• Context understanding evolution</li>
                  <li>• Personalization refinement</li>
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}