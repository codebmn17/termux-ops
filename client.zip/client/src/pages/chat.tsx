import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import { EnhancedAIChat } from '@/components/enhanced-ai-chat';
import { ArrowLeft, MessageSquare } from 'lucide-react';

export default function Chat() {
  const [sessionId] = useState(() => 'demo-session-' + Date.now());

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <MessageSquare className="text-cyan-400" size={24} />
            <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-400 glow-text">
              Storm Echo RI
            </h1>
          </motion.div>
        </motion.div>

        {/* Enhanced Chat Interface */}
        <motion.div
          className="max-w-7xl mx-auto h-[calc(100vh-200px)]"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <EnhancedAIChat 
            title="Storm Echo RI Chat"
            enableCodeGeneration={true}
            enableVoice={true}
            enablePersonalities={true}
            mode="chat"
          />
        </motion.div>

        {/* Info Footer */}
        <motion.div
          className="text-center mt-8 text-gray-400 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
        >
          <p>Powered by OpenAI GPT-4o • Storm Echo RI System</p>
        </motion.div>
      </div>
    </div>
  );
}