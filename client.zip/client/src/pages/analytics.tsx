import React from 'react';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';

export default function AnalyticsPage() {
  return <AnalyticsDashboard />;
}