import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Book, 
  Code, 
  Pyramid, 
  Globe, 
  Lock, 
  ExternalLink,
  Search,
  ChevronRight,
  Brain,
  Cpu,
  Shield,
  Zap,
  Star,
  Eye
} from 'lucide-react';
import { Link } from 'wouter';

interface Resource {
  id: string;
  title: string;
  description: string;
  url: string;
  type: 'book' | 'course' | 'documentation' | 'research' | 'tool';
  difficulty?: 'beginner' | 'intermediate' | 'advanced' | 'expert';
}

interface Category {
  id: string;
  name: string;
  icon: any;
  color: string;
  description: string;
  resources: Resource[];
}

export default function Library() {
  const [selectedCategory, setSelectedCategory] = useState<string>('technology');
  const [searchQuery, setSearchQuery] = useState('');

  const categories: Category[] = [
    {
      id: 'technology',
      name: 'Modern Technology',
      icon: Code,
      color: 'from-cyan-500 to-blue-600',
      description: 'Programming, AI, and cutting-edge tech resources',
      resources: [
        {
          id: 'mdn',
          title: 'MDN Web Docs',
          description: 'Comprehensive web development documentation',
          url: 'https://developer.mozilla.org/',
          type: 'documentation',
          difficulty: 'beginner'
        },
        {
          id: 'arxiv',
          title: 'arXiv.org',
          description: 'Open-access archive for scientific papers in AI, physics, mathematics',
          url: 'https://arxiv.org/',
          type: 'research',
          difficulty: 'advanced'
        },
        {
          id: 'openai-docs',
          title: 'OpenAI Documentation',
          description: 'Official docs for GPT models and AI integration',
          url: 'https://platform.openai.com/docs',
          type: 'documentation',
          difficulty: 'intermediate'
        },
        {
          id: 'github',
          title: 'GitHub',
          description: 'World\'s largest code repository and collaboration platform',
          url: 'https://github.com',
          type: 'tool',
          difficulty: 'beginner'
        },
        {
          id: 'papers-with-code',
          title: 'Papers With Code',
          description: 'Machine learning papers with implementation code',
          url: 'https://paperswithcode.com/',
          type: 'research',
          difficulty: 'advanced'
        },
        {
          id: 'huggingface',
          title: 'Hugging Face',
          description: 'AI models, datasets, and machine learning resources',
          url: 'https://huggingface.co/',
          type: 'tool',
          difficulty: 'intermediate'
        }
      ]
    },
    {
      id: 'ancient',
      name: 'Ancient Wisdom',
      icon: Pyramid,
      color: 'from-amber-500 to-orange-600',
      description: 'Ancient civilizations, sacred geometry, and esoteric knowledge',
      resources: [
        {
          id: 'sacred-texts',
          title: 'Sacred Texts Archive',
          description: 'Ancient religious and philosophical texts from around the world',
          url: 'https://www.sacred-texts.com/',
          type: 'book',
          difficulty: 'intermediate'
        },
        {
          id: 'emerald-tablets',
          title: 'The Emerald Tablets of Thoth',
          description: 'Translation of ancient Atlantean wisdom',
          url: 'https://www.crystalinks.com/emerald.html',
          type: 'book',
          difficulty: 'advanced'
        },
        {
          id: 'graham-hancock',
          title: 'Graham Hancock Official',
          description: 'Research on lost civilizations and ancient mysteries',
          url: 'https://grahamhancock.com/',
          type: 'research',
          difficulty: 'intermediate'
        },
        {
          id: 'ancient-origins',
          title: 'Ancient Origins',
          description: 'Archaeological discoveries and ancient history',
          url: 'https://www.ancient-origins.net/',
          type: 'research',
          difficulty: 'beginner'
        },
        {
          id: 'digital-egypt',
          title: 'Digital Egypt for Universities',
          description: 'UCL\'s comprehensive resource on ancient Egypt',
          url: 'https://www.ucl.ac.uk/museums-static/digitalegypt/',
          type: 'documentation',
          difficulty: 'intermediate'
        },
        {
          id: 'akashic-records',
          title: 'Edgar Cayce\'s A.R.E.',
          description: 'Association for Research and Enlightenment - Akashic Records research',
          url: 'https://www.edgarcayce.org/',
          type: 'research',
          difficulty: 'advanced'
        },
        {
          id: 'sumerian-tablets',
          title: 'CDLI - Cuneiform Digital Library Initiative',
          description: 'Digital collection of cuneiform inscriptions and ancient Sumerian texts',
          url: 'https://cdli.ucla.edu/',
          type: 'documentation',
          difficulty: 'expert'
        }
      ]
    },
    {
      id: 'consciousness',
      name: 'Consciousness Studies',
      icon: Brain,
      color: 'from-purple-500 to-violet-600',
      description: 'Mind, consciousness, and human potential',
      resources: [
        {
          id: 'noetic',
          title: 'Institute of Noetic Sciences',
          description: 'Research on consciousness and human potential',
          url: 'https://noetic.org/',
          type: 'research',
          difficulty: 'intermediate'
        },
        {
          id: 'monroe-institute',
          title: 'The Monroe Institute',
          description: 'Consciousness exploration through sound technology',
          url: 'https://www.monroeinstitute.org/',
          type: 'course',
          difficulty: 'advanced'
        },
        {
          id: 'binaural-beats',
          title: 'Binaural Beat Research',
          description: 'Scientific studies on brainwave entrainment',
          url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4428073/',
          type: 'research',
          difficulty: 'advanced'
        },
        {
          id: 'heartmath',
          title: 'HeartMath Institute',
          description: 'Heart-brain coherence and emotional regulation',
          url: 'https://www.heartmath.org/',
          type: 'research',
          difficulty: 'beginner'
        }
      ]
    },
    {
      id: 'advanced',
      name: 'Advanced Research',
      icon: Shield,
      color: 'from-red-500 to-pink-600',
      description: 'Declassified documents, FOIA archives, and deep research',
      resources: [
        {
          id: 'cia-reading-room',
          title: 'CIA Reading Room',
          description: 'Declassified CIA documents and FOIA releases',
          url: 'https://www.cia.gov/readingroom/',
          type: 'documentation',
          difficulty: 'expert'
        },
        {
          id: 'black-vault',
          title: 'The Black Vault',
          description: 'Largest private collection of declassified documents',
          url: 'https://www.theblackvault.com/',
          type: 'documentation',
          difficulty: 'advanced'
        },
        {
          id: 'wikileaks',
          title: 'WikiLeaks',
          description: 'Classified and restricted document archive',
          url: 'https://wikileaks.org/',
          type: 'documentation',
          difficulty: 'expert'
        },
        {
          id: 'nsa-declassified',
          title: 'NSA Declassified',
          description: 'National Security Agency declassified materials',
          url: 'https://www.nsa.gov/news-features/declassified-documents/',
          type: 'documentation',
          difficulty: 'expert'
        },
        {
          id: 'fbi-vault',
          title: 'FBI Vault',
          description: 'FBI records released under FOIA',
          url: 'https://vault.fbi.gov/',
          type: 'documentation',
          difficulty: 'advanced'
        }
      ]
    },
    {
      id: 'quantum',
      name: 'Quantum & Physics',
      icon: Zap,
      color: 'from-indigo-500 to-blue-600',
      description: 'Quantum mechanics, theoretical physics, and energy research',
      resources: [
        {
          id: 'quantum-computing',
          title: 'IBM Quantum',
          description: 'Access to real quantum computers and learning resources',
          url: 'https://quantum-computing.ibm.com/',
          type: 'tool',
          difficulty: 'advanced'
        },
        {
          id: 'cern',
          title: 'CERN Document Server',
          description: 'Particle physics research and Large Hadron Collider data',
          url: 'https://cds.cern.ch/',
          type: 'research',
          difficulty: 'expert'
        },
        {
          id: 'physics-stack',
          title: 'Physics Stack Exchange',
          description: 'Q&A for active researchers and students of physics',
          url: 'https://physics.stackexchange.com/',
          type: 'documentation',
          difficulty: 'intermediate'
        }
      ]
    },
    {
      id: 'security',
      name: 'Security & Privacy',
      icon: Lock,
      color: 'from-gray-600 to-gray-800',
      description: 'Cybersecurity, privacy tools, and secure communications',
      resources: [
        {
          id: 'tor-project',
          title: 'Tor Project',
          description: 'Anonymous communication and privacy protection (merged with Tails 2024)',
          url: 'https://www.torproject.org/',
          type: 'tool',
          difficulty: 'intermediate'
        },
        {
          id: 'tails-os',
          title: 'Tails Operating System',
          description: 'Amnesic incognito live OS - leaves no traces, routes through Tor',
          url: 'https://tails.boum.org/',
          type: 'tool',
          difficulty: 'advanced'
        },
        {
          id: 'whonix',
          title: 'Whonix',
          description: 'Anonymous OS through Tor - runs in VMs for maximum isolation',
          url: 'https://www.whonix.org/',
          type: 'tool',
          difficulty: 'expert'
        },
        {
          id: 'qubes-os',
          title: 'Qubes OS',
          description: 'Security through isolation - compartmentalized operating system',
          url: 'https://www.qubes-os.org/',
          type: 'tool',
          difficulty: 'expert'
        },
        {
          id: 'signal',
          title: 'Signal Messenger',
          description: 'End-to-end encrypted messaging with disappearing messages',
          url: 'https://signal.org/',
          type: 'tool',
          difficulty: 'beginner'
        },
        {
          id: 'protonmail',
          title: 'ProtonMail',
          description: 'End-to-end encrypted email service from Switzerland',
          url: 'https://proton.me/',
          type: 'tool',
          difficulty: 'beginner'
        },
        {
          id: 'eff',
          title: 'Electronic Frontier Foundation',
          description: 'Digital rights, privacy, and security resources',
          url: 'https://www.eff.org/',
          type: 'documentation',
          difficulty: 'beginner'
        },
        {
          id: 'privacytools',
          title: 'Privacy Guides',
          description: 'Privacy-respecting software and services',
          url: 'https://www.privacyguides.org/',
          type: 'documentation',
          difficulty: 'beginner'
        },
        {
          id: 'ahmia',
          title: 'Ahmia Search Engine',
          description: 'Clean dark web search - filters illegal content, indexes .onion sites',
          url: 'https://ahmia.fi/',
          type: 'tool',
          difficulty: 'intermediate'
        },
        {
          id: 'duckduckgo-onion',
          title: 'DuckDuckGo Onion',
          description: 'Privacy search engine with .onion access',
          url: 'https://3g2upl4pq6kufc4m.onion/',
          type: 'tool',
          difficulty: 'intermediate'
        },
        {
          id: 'veracrypt',
          title: 'VeraCrypt',
          description: 'Open-source disk encryption software - successor to TrueCrypt',
          url: 'https://www.veracrypt.fr/',
          type: 'tool',
          difficulty: 'intermediate'
        },
        {
          id: 'have-i-been-pwned',
          title: 'Have I Been Pwned',
          description: 'Check if your data has been compromised',
          url: 'https://haveibeenpwned.com/',
          type: 'tool',
          difficulty: 'beginner'
        },
        {
          id: 'onionshare',
          title: 'OnionShare',
          description: 'Securely share files through Tor network anonymously',
          url: 'https://onionshare.org/',
          type: 'tool',
          difficulty: 'intermediate'
        }
      ]
    }
  ];

  const selectedCategoryData = categories.find(cat => cat.id === selectedCategory);
  
  const filteredResources = selectedCategoryData?.resources.filter(resource =>
    resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    resource.description.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const getDifficultyColor = (difficulty?: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-400 border-green-400/30';
      case 'intermediate': return 'text-yellow-400 border-yellow-400/30';
      case 'advanced': return 'text-orange-400 border-orange-400/30';
      case 'expert': return 'text-red-400 border-red-400/30';
      default: return 'text-gray-400 border-gray-400/30';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'book': return Book;
      case 'course': return Brain;
      case 'documentation': return Globe;
      case 'research': return Eye;
      case 'tool': return Cpu;
      default: return Star;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900">
      {/* Cosmic Background */}
      <div className="fixed inset-0 opacity-30">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2220%22%20height%3D%2220%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%3E%3Ccircle%20cx%3D%222%22%20cy%3D%222%22%20r%3D%221%22%20fill%3D%22white%22%20opacity%3D%220.3%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E')]" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 to-purple-500 mb-4">
            Quantum Knowledge Library
          </h1>
          <p className="text-gray-300 text-lg">Access the universe of information</p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="max-w-2xl mx-auto mb-8"
        >
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search resources..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-800/50 backdrop-blur-sm border border-purple-400/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 transition-all"
            />
          </div>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-8"
        >
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <motion.button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-lg flex items-center space-x-2 transition-all ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r ' + category.color + ' text-white shadow-lg'
                    : 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon size={20} />
                <span className="font-medium">{category.name}</span>
              </motion.button>
            );
          })}
        </motion.div>

        {/* Category Description */}
        <AnimatePresence mode="wait">
          {selectedCategoryData && (
            <motion.div
              key={selectedCategory}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-center mb-8"
            >
              <p className="text-gray-400">{selectedCategoryData.description}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Resources Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedCategory}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredResources.map((resource, index) => {
              const TypeIcon = getTypeIcon(resource.type);
              return (
                <motion.a
                  key={resource.id}
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="group relative bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-lg p-6 hover:bg-gray-800/50 hover:border-purple-400/50 transition-all"
                  whileHover={{ scale: 1.02 }}
                >
                  {/* Type Badge */}
                  <div className="absolute top-4 right-4">
                    <TypeIcon size={20} className="text-gray-500" />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-semibold text-white mb-2 pr-8">
                    {resource.title}
                  </h3>
                  <p className="text-gray-400 text-sm mb-4">
                    {resource.description}
                  </p>

                  {/* Footer */}
                  <div className="flex items-center justify-between">
                    {resource.difficulty && (
                      <span className={`text-xs px-2 py-1 border rounded-full ${getDifficultyColor(resource.difficulty)}`}>
                        {resource.difficulty}
                      </span>
                    )}
                    <div className="flex items-center text-purple-400 group-hover:text-purple-300 transition-colors">
                      <span className="text-sm">Visit</span>
                      <ExternalLink size={16} className="ml-1" />
                    </div>
                  </div>

                  {/* Hover Effect */}
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-purple-600/0 to-cyan-600/0 group-hover:from-purple-600/10 group-hover:to-cyan-600/10 transition-all pointer-events-none" />
                </motion.a>
              );
            })}
          </motion.div>
        </AnimatePresence>

        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <Link href="/">
            <motion.button
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-violet-600 text-white rounded-lg font-medium hover:from-purple-700 hover:to-violet-700 transition-all shadow-lg hover:shadow-purple-500/25"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Return to Echo Chamber
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}