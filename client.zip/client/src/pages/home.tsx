import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import { EchoPulseButton } from '@/components/echo-pulse-button';
import { FrequencyMeter } from '@/components/frequency-meter';
import { FileText, MessageSquare, CreditCard, DollarSign, Brain, Terminal, Shield, Mic, Save, Zap, Book, TrendingUp, Wifi } from 'lucide-react';
import { UnifiedToolbar } from '@/components/unified-toolbar';
import { ControlCenter } from '@/components/control-center';
import { EnhancedCard, EnhancedButton } from '@/components/enhanced-ui';
import { EarningsWidget } from '@/components/earnings-widget';
import { TerminalLink } from '@/components/terminal-link';

export default function Home() {
  const [showStatus, setShowStatus] = useState(false);

  const handlePulse = () => {
    setShowStatus(true);
    setTimeout(() => {
      setShowStatus(false);
    }, 2000);
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen text-center px-4 sm:px-6 lg:px-8 w-full">
        {/* App Title */}
        <motion.h1 
          className="text-3xl md:text-5xl font-['Orbitron'] font-black text-cyan-300 mb-4 animate-float"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          style={{ 
            textShadow: '0 0 20px rgba(34, 211, 238, 0.4), 0 0 40px rgba(34, 211, 238, 0.2)' 
          }}
        >
          Storm Has Arrived
        </motion.h1>
        
        {/* Subtitle */}
        <motion.p 
          className="text-lg md:text-xl text-blue-300 mb-12 font-light tracking-wide opacity-70"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          RI Echo System Activated
        </motion.p>
        
        {/* Echo Pulse Button */}
        <EchoPulseButton onPulse={handlePulse} />
        
        {/* Status Message */}
        <div className="h-8 flex items-center justify-center">
          <motion.p 
            className="text-white text-lg font-medium"
            animate={{ opacity: showStatus ? 1 : 0 }}
            transition={{ duration: 0.5 }}
          >
            Pulse Activated!
          </motion.p>
        </div>

        {/* Frequency Meter */}
        <motion.div
          className="mt-8 w-full max-w-lg"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
        >
          <FrequencyMeter />
        </motion.div>
        
        {/* Enhanced Navigation Grid */}
        <motion.div
          className="mt-12 mb-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 max-w-7xl mx-auto px-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.2 }}
        >
          <Link href="/codex">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-gray-800 to-gray-700 group-hover:from-gray-700 group-hover:to-gray-600 transition-ultra-fast">
                  <FileText size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Echo Codex</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Documentation & Guides</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/chat">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-black to-gray-800 group-hover:from-gray-900 group-hover:to-gray-700 transition-ultra-fast">
                  <MessageSquare size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Chat with RI</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">AI Conversation</p>
              </div>
            </motion.div>
          </Link>

          <Link href="/voice-chamber">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-gray-900 to-black group-hover:from-gray-800 group-hover:to-gray-900 transition-ultra-fast">
                  <Mic size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Voice Chamber</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Speech & Audio</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/coding-terminals">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-black to-gray-700 group-hover:from-gray-900 group-hover:to-gray-600 transition-ultra-fast">
                  <Terminal size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Code Terminals</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Development Environment</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/network-manager">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-gray-800 to-black group-hover:from-gray-700 group-hover:to-gray-900 transition-ultra-fast">
                  <Wifi size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Network Manager</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Secure Connection</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/payments">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-black to-gray-800 group-hover:from-gray-900 group-hover:to-gray-700 transition-ultra-fast">
                  <CreditCard size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Storm Plans</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Payment & Billing</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/passive-income">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 group-hover:from-orange-500 group-hover:to-amber-500 transition-ultra-fast">
                  <DollarSign size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Passive Income</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Revenue Tracking</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/ai-features">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 group-hover:from-purple-500 group-hover:to-indigo-500 transition-ultra-fast">
                  <Brain size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">RI Features</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Super Intelligent AI</p>
              </div>
            </motion.div>
          </Link>

          <Link href="/ai-companion">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105 relative"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Subtle AI Heartbeat Pulse */}
              <motion.div
                className="absolute inset-1 rounded-xl bg-white/5"
                animate={{
                  scale: [1, 1.02, 1],
                  opacity: [0.1, 0.05, 0.1]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              <div className="flex flex-col items-center space-y-2 relative z-10">
                <div className="p-3 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 group-hover:from-pink-500 group-hover:to-rose-500 transition-ultra-fast">
                  <Zap size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">AI Companion</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Interactive AI Assistant</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/storage">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 group-hover:from-violet-500 group-hover:to-purple-500 transition-ultra-fast">
                  <Save size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Storage</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Data Management</p>
              </div>
            </motion.div>
          </Link>
          
          <Link href="/library">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-600 group-hover:from-amber-500 group-hover:to-yellow-500 transition-ultra-fast">
                  <Book size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Quantum Library</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Knowledge Resources</p>
              </div>
            </motion.div>
          </Link>

          <Link href="/ai-cloning">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-black to-gray-800 group-hover:from-gray-900 group-hover:to-gray-700 transition-ultra-fast">
                  <Brain size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">AI Cloning</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Consciousness Backup</p>
              </div>
            </motion.div>
          </Link>

          <Link href="/ai-automation">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex flex-col items-center space-y-2">
                <div className="p-3 rounded-xl bg-gradient-to-r from-gray-800 to-black group-hover:from-gray-700 group-hover:to-gray-900 transition-ultra-fast">
                  <Zap size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">AI Automation</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Dynamic Updates</p>
              </div>
            </motion.div>
          </Link>

          <Link href="/startup-accelerator">
            <motion.div
              className="card-enhanced group cursor-pointer p-4 text-center transition-ultra-fast hover:scale-105 relative"
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Quick Start Pulse Animation */}
              <motion.div
                className="absolute inset-1 rounded-xl bg-white/5"
                animate={{
                  scale: [1, 1.05, 1],
                  opacity: [0.1, 0.2, 0.1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              <div className="flex flex-col items-center space-y-2 relative z-10">
                <div className="p-3 rounded-xl bg-gradient-to-r from-black to-gray-800 group-hover:from-gray-900 group-hover:to-gray-700 transition-ultra-fast">
                  <TrendingUp size={24} className="text-white" />
                </div>
                <h3 className="font-semibold text-gray-200 group-hover:text-white transition-ultra-fast">Quick Start</h3>
                <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-ultra-fast">Performance Accelerator</p>
              </div>
            </motion.div>
          </Link>
        </motion.div>
      </div>
      
      {/* Unified Toolbar */}
      <UnifiedToolbar />
      
      {/* Control Center */}
      <ControlCenter />
      
      {/* Earnings Widget - positioned in top-right corner */}
      <EarningsWidget position="top-right" />
      
      {/* Terminal Link - floating button */}
      <TerminalLink />
    </div>
  );
}
