import { TerminalSettings } from '@/components/terminal-settings';
import { motion } from 'framer-motion';
import { GalaxyBackground } from '@/components/galaxy-background';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'wouter';

export default function TerminalSettingsPage() {
  return (
    <div className="relative min-h-screen">
      <GalaxyBackground />
      
      <div className="relative z-10 max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
        <div className="mb-6">
          <Link href="/max-terminal">
            <Button
              variant="outline"
              size="sm"
              className="bg-black/50 border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Terminal
            </Button>
          </Link>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <TerminalSettings />
        </motion.div>
      </div>
    </div>
  );
}