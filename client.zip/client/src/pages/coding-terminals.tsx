import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { GalaxyBackground } from '@/components/galaxy-background';
import { EnhancedCodingTerminal } from '@/components/enhanced-coding-terminal';
import { MaxTerminalSystem } from '@/components/max-terminal-system';
import { EnhancedAIChat } from '@/components/enhanced-ai-chat';
import anonymousHackerBg from '@assets/file_0000000077d862438227c9b39b7647a7_1754244113163.png';

export default function CodingTerminalsPage() {
  return (
    <div className="relative min-h-screen w-full overflow-x-hidden flex flex-col">
      {/* Anonymous Hacker Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${anonymousHackerBg})` }}
      />
      
      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-black/90" />
      
      <div className="relative z-10 flex flex-col h-full">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between px-4 py-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-gray-300 hover:text-gray-200 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
        </motion.div>

        {/* Enhanced Terminal System with AI Integration */}
        <div className="flex-1 overflow-hidden px-4 pb-6">
          <div className="max-w-7xl mx-auto h-full">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 h-full">
              {/* Terminal System - Takes 2/3 of the space */}
              <div className="xl:col-span-2 h-full">
                <MaxTerminalSystem />
              </div>
              
              {/* AI Coding Assistant - Takes 1/3 of the space */}
              <div className="xl:col-span-1 h-full">
                <EnhancedAIChat 
                  title="AI Coding Assistant"
                  enableCodeGeneration={true}
                  enableVoice={true}
                  enablePersonalities={true}
                  mode="coding"
                  onCodeGenerated={(code, language) => {
                    // Integration with terminal system
                    const event = new CustomEvent('ai-code-generated', {
                      detail: { code, language }
                    });
                    window.dispatchEvent(event);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}