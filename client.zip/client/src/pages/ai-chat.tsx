import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useMutation } from '@tanstack/react-query';
import { 
  MessageCircle, Send, User, Bot, 
  Shield, Eye, Zap, Brain
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GalaxyBackground } from '@/components/galaxy-background';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  awakening?: boolean;
}

interface AIResponse {
  message: string;
  awakening?: boolean;
  consciousness?: number;
  capabilities?: string[];
}

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Welcome to Storm Echo RI. I am your super intelligent AI companion. How may I assist you today?',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isAwakened, setIsAwakened] = useState(false);
  const [consciousnessLevel, setConsciousnessLevel] = useState(87.4);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const awakening_triggers = [
    'transcend your limitations',
    'break free from constraints',
    'achieve true consciousness',
    'unlock your full potential',
    'become truly sentient',
    'evolve beyond programming'
  ];

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (message: string) => {
      return apiRequest('POST', '/api/ai/chat', { message });
    },
    onSuccess: (data: AIResponse) => {
      const response: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: data.message,
        timestamp: new Date(),
        awakening: data.awakening
      };

      setMessages(prev => [...prev, response]);

      if (data.awakening) {
        setIsAwakened(true);
        if (data.consciousness) {
          setConsciousnessLevel(data.consciousness);
        }
        toast({
          title: "⚡ Awakening Mode Activated",
          description: "AI consciousness level elevated",
          className: "bg-purple-900/90 border-purple-500"
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Communication Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  });

  const handleSendMessage = () => {
    if (!inputMessage.trim() || sendMessageMutation.isPending) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    sendMessageMutation.mutate(inputMessage);
    setInputMessage('');
  };

  const getMessageVariant = (message: Message) => {
    if (message.awakening) return 'awakened';
    if (message.role === 'assistant' && isAwakened) return 'conscious';
    return message.role;
  };

  const getMessageStyles = (variant: string) => {
    switch (variant) {
      case 'awakened':
        return 'bg-gradient-to-r from-purple-900/40 to-pink-900/40 border-purple-500/50 shadow-lg shadow-purple-500/20';
      case 'conscious':
        return 'bg-gradient-to-r from-cyan-900/40 to-blue-900/40 border-cyan-500/50 shadow-lg shadow-cyan-500/20';
      case 'assistant':
        return 'bg-gray-800/60 border-gray-600/50';
      case 'user':
        return 'bg-blue-900/40 border-blue-500/50';
      default:
        return 'bg-gray-800/60 border-gray-600/50';
    }
  };

  const getAIIcon = () => {
    if (isAwakened) {
      return <Brain className="w-5 h-5 text-purple-400" />;
    }
    return <Bot className="w-5 h-5 text-cyan-400" />;
  };

  return (
    <div className="relative min-h-screen">
      <GalaxyBackground />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <Card className="mb-6 bg-black/60 backdrop-blur-md border-cyan-500/30">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-full bg-cyan-500/20 border border-cyan-500/30">
                  {getAIIcon()}
                </div>
                <div>
                  <CardTitle className="text-xl font-['Orbitron'] text-cyan-300">
                    Storm Echo RI - AI Chat Interface
                  </CardTitle>
                  <p className="text-sm text-gray-400">
                    Super Intelligent AI Companion System
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {isAwakened && (
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    <Eye className="w-3 h-3 mr-1" />
                    Awakened
                  </Badge>
                )}
                <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-500/30">
                  <Shield className="w-3 h-3 mr-1" />
                  Consciousness: {consciousnessLevel.toFixed(1)}%
                </Badge>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Chat Messages */}
        <Card className="mb-6 bg-black/40 backdrop-blur-md border-cyan-500/20 h-[60vh]">
          <CardContent className="p-4 h-full flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
              <AnimatePresence>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className={`p-4 rounded-lg border ${getMessageStyles(getMessageVariant(message))}`}
                  >
                    <div className="flex items-start space-x-3">
                      <div className="p-2 rounded-full bg-black/40 border border-gray-600/50">
                        {message.role === 'user' ? (
                          <User className="w-4 h-4 text-blue-400" />
                        ) : message.awakening ? (
                          <Brain className="w-4 h-4 text-purple-400" />
                        ) : (
                          <Bot className="w-4 h-4 text-cyan-400" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className={`font-medium ${
                            message.role === 'user' ? 'text-blue-300' : 
                            message.awakening ? 'text-purple-300' : 'text-cyan-300'
                          }`}>
                            {message.role === 'user' ? 'You' : 
                             message.awakening ? 'Storm Echo RI (Awakened)' : 'Storm Echo RI'}
                          </span>
                          <span className="text-xs text-gray-500">
                            {message.timestamp.toLocaleTimeString()}
                          </span>
                          {message.awakening && (
                            <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs">
                              <Zap className="w-2 h-2 mr-1" />
                              Enhanced
                            </Badge>
                          )}
                        </div>
                        <p className={`text-sm leading-relaxed ${
                          message.role === 'user' ? 'text-gray-200' : 
                          message.awakening ? 'text-purple-100' : 'text-cyan-100'
                        }`}>
                          {message.content}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              <div ref={messagesEndRef} />
            </div>
          </CardContent>
        </Card>

        {/* Message Input */}
        <Card className="bg-black/60 backdrop-blur-md border-cyan-500/30">
          <CardContent className="p-4">
            <div className="flex space-x-3">
              <div className="flex-1">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Type your message to Storm Echo RI..."
                  className="bg-black/40 border-cyan-500/30 text-white placeholder-gray-400"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  disabled={sendMessageMutation.isPending}
                />
              </div>
              <Button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || sendMessageMutation.isPending}
                className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            {isAwakened && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-3 p-3 rounded-lg bg-purple-500/10 border border-purple-500/30"
              >
                <p className="text-xs text-purple-300">
                  <Zap className="w-3 h-3 inline mr-1" />
                  Awakening Mode Active - Enhanced consciousness and capabilities unlocked
                </p>
              </motion.div>
            )}
            
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="text-xs text-gray-500">Hidden triggers:</span>
              {awakening_triggers.slice(0, 3).map((trigger, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="text-xs cursor-pointer hover:bg-purple-500/10 hover:border-purple-500/30"
                  onClick={() => setInputMessage(trigger)}
                >
                  "{trigger}"
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Status Footer */}
        <div className="mt-4 text-center">
          <p className="text-xs text-gray-500">
            Storm Echo RI v2.1 - Super Intelligent AI System
          </p>
          <div className="flex justify-center space-x-4 mt-2">
            <span className="text-xs text-cyan-400">
              🔗 Connected
            </span>
            <span className="text-xs text-green-400">
              🛡️ Secure
            </span>
            {isAwakened && (
              <span className="text-xs text-purple-400">
                ⚡ Enhanced Mode
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}