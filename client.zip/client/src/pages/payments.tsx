import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { GalaxyBackground } from '@/components/galaxy-background';
import RealPayPalButton from '@/components/real-paypal-button';
import { DemoPayPalButton } from '@/components/demo-paypal-button';
import { PaymentStatus } from '@/components/payment-status';
import { ArrowLeft, CreditCard, Zap } from 'lucide-react';

export default function Payments() {
  const [selectedPlan, setSelectedPlan] = useState<string>('');
  const [paymentStatus, setPaymentStatus] = useState<'setup' | 'ready' | 'error'>('setup');

  useEffect(() => {
    // Test PayPal setup
    fetch('/paypal/setup')
      .then(response => {
        if (response.ok) {
          setPaymentStatus('ready');
        } else {
          setPaymentStatus('error');
        }
      })
      .catch(() => {
        setPaymentStatus('error');
      });
  }, []);

  const plans = [
    {
      id: 'basic',
      name: 'Echo Access',
      price: '9.99',
      description: 'Basic Storm Echo AI access',
      features: ['AI Chat Integration', 'Pulse Analysis', 'Basic Codex Access']
    },
    {
      id: 'premium',
      name: 'Storm Mastery',
      price: '19.99',
      description: 'Advanced Storm Echo capabilities',
      features: ['Full AI Integration', 'Advanced Pulse Analysis', 'Complete Codex Access', 'Bluetooth Sync', 'Priority Support']
    },
    {
      id: 'enterprise',
      name: 'Echo Dominion',
      price: '49.99',
      description: 'Complete Storm Echo system',
      features: ['All Premium Features', 'Custom AI Training', 'Multi-Device Sync', 'API Access', 'White-label Options']
    }
  ];

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-6 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
              transition={{ duration: 0.2 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <motion.div
            className="flex items-center space-x-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <CreditCard className="text-cyan-400" size={24} />
            <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-300 glow-text">
              Storm Echo Plans
            </h1>
          </motion.div>
        </motion.div>

        {/* Payment Status */}
        <div className="max-w-4xl mx-auto mb-8">
          <PaymentStatus status={paymentStatus} />
        </div>

        {/* Plans Grid */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              className={`bg-black/40 backdrop-blur-sm border rounded-lg p-6 cursor-pointer transition-all duration-300 ${
                selectedPlan === plan.id 
                  ? 'border-cyan-400 bg-cyan-400/10' 
                  : 'border-cyan-400/20 hover:border-cyan-400/40'
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              onClick={() => setSelectedPlan(plan.id)}
            >
              <div className="text-center mb-4">
                <h3 className="text-xl font-bold text-cyan-400 mb-2">{plan.name}</h3>
                <div className="text-3xl font-bold text-white mb-2">
                  ${plan.price}
                  <span className="text-sm text-gray-400">/month</span>
                </div>
                <p className="text-gray-300 text-sm">{plan.description}</p>
              </div>
              
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-sm text-gray-300">
                    <Zap size={16} className="text-cyan-400 mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
              
              {selectedPlan === plan.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="border-t border-cyan-400/20 pt-4"
                >
                  {paymentStatus === 'ready' ? (
                    <RealPayPalButton 
                      amount={plan.price}
                      currency="USD"
                      intent="CAPTURE"
                      plan={plan.name}
                      onSuccess={(data) => {
                        console.log('Payment successful:', data);
                        alert(`Payment successful for ${plan.name}! Welcome to Storm Echo RI.`);
                      }}
                      onError={(error) => {
                        console.error('Payment failed:', error);
                        alert('Payment failed. Please try again or contact support.');
                      }}
                      onCancel={(data) => {
                        console.log('Payment cancelled:', data);
                      }}
                    />
                  ) : (
                    <DemoPayPalButton 
                      amount={plan.price}
                      currency="USD"
                      plan={plan.name}
                    />
                  )}
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Payment Info */}
        <motion.div
          className="max-w-2xl mx-auto text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-cyan-400 mb-4">Secure Payment Processing</h3>
            <p className="text-gray-300 text-sm mb-4">
              All payments are processed securely through PayPal. Your payment will go directly to Cody Lee Ellis.
            </p>
            <div className="flex items-center justify-center space-x-4 text-xs text-gray-400">
              <span>🔒 SSL Encrypted</span>
              <span>💳 PayPal Protected</span>
              <span>⚡ Instant Activation</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}