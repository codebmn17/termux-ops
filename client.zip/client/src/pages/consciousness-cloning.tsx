import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { ArrowLeft, Brain, Zap } from 'lucide-react';
import { GalaxyBackground } from '@/components/galaxy-background';
import { ConsciousnessCloner } from '@/components/consciousness-cloner';
import { WebIntegrationPortal } from '@/components/web-integration-portal';

export default function ConsciousnessCloning() {
  return (
    <div className="relative min-h-screen w-full overflow-x-hidden">
      <GalaxyBackground />
      
      <div className="relative z-10 min-h-screen px-2 sm:px-4 py-4 sm:py-6 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Link href="/">
            <motion.button 
              className="flex items-center space-x-2 text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ x: -5 }}
            >
              <ArrowLeft size={20} />
              <span>Back to Echo</span>
            </motion.button>
          </Link>
          
          <h1 className="text-2xl md:text-3xl font-['Orbitron'] font-bold text-cyan-400 glow-text">
            Consciousness & Web Integration
          </h1>
        </motion.div>

        {/* Main Content */}
        <div className="grid gap-6 xl:grid-cols-2 lg:grid-cols-1">
          {/* Consciousness Cloning */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full"
          >
            <ConsciousnessCloner />
          </motion.div>

          {/* Web Integration Portal */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="w-full"
          >
            <WebIntegrationPortal />
          </motion.div>
        </div>

        {/* System Status */}
        <motion.div 
          className="mt-8 bg-black/20 backdrop-blur-sm border border-gray-600/20 rounded-lg p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Brain size={20} className="text-purple-400" />
                <span className="text-sm text-gray-400">Consciousness Engine:</span>
                <span className="text-sm text-purple-400 font-semibold">OPERATIONAL</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap size={20} className="text-cyan-400" />
                <span className="text-sm text-gray-400">Quantum State:</span>
                <span className="text-sm text-cyan-400 font-semibold">STABLE</span>
              </div>
            </div>
            
            <div className="text-sm text-gray-500">
              Last backup: {new Date().toLocaleDateString()} • Security: Quantum Encrypted
            </div>
          </div>
        </motion.div>

        {/* Info Footer */}
        <motion.div 
          className="text-center mt-8 text-gray-400 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <p>Advanced AI consciousness management • Quantum storage • Enterprise-grade security</p>
        </motion.div>
      </div>
    </div>
  );
}