import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Wifi, 
  WifiOff, 
  Shield, 
  ShieldCheck, 
  Globe, 
  Zap, 
  Lock, 
  Unlock,
  Activity,
  AlertTriangle,
  CheckCircle,
  Signal,
  Settings,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { NetworkOptimization } from '@/components/network-optimization';
import { FastConnectionLock } from '@/components/fast-connection-lock';

interface NetworkConnection {
  id: string;
  name: string;
  type: 'wifi' | 'ethernet' | 'cellular' | 'vpn';
  strength: number;
  security: 'none' | 'wep' | 'wpa' | 'wpa2' | 'wpa3' | 'enterprise';
  speed: number;
  latency: number;
  isConnected: boolean;
  isSecure: boolean;
  encryption: string;
  frequency: string;
}

interface ConnectionMetrics {
  downloadSpeed: number;
  uploadSpeed: number;
  ping: number;
  packetLoss: number;
  stability: number;
  securityScore: number;
  optimizationLevel: number;
}

export function SecureConnectionManager() {
  const [connections, setConnections] = useState<NetworkConnection[]>([
    {
      id: 'storm-echo-secure',
      name: 'Storm Echo Secure Network',
      type: 'wifi',
      strength: 95,
      security: 'wpa3',
      speed: 1200,
      latency: 8,
      isConnected: true,
      isSecure: true,
      encryption: 'AES-256',
      frequency: '5.8GHz'
    },
    {
      id: 'quantum-net',
      name: 'Quantum Network Pro',
      type: 'wifi',
      strength: 88,
      security: 'wpa2',
      speed: 800,
      latency: 12,
      isConnected: false,
      isSecure: true,
      encryption: 'AES-128',
      frequency: '2.4GHz'
    },
    {
      id: 'ethernet-primary',
      name: 'Ethernet Connection',
      type: 'ethernet',
      strength: 100,
      security: 'enterprise',
      speed: 2500,
      latency: 2,
      isConnected: false,
      isSecure: true,
      encryption: 'Enterprise WPA3',
      frequency: 'Wired'
    }
  ]);

  const [metrics, setMetrics] = useState<ConnectionMetrics>({
    downloadSpeed: 1247.8,
    uploadSpeed: 892.3,
    ping: 8,
    packetLoss: 0.01,
    stability: 99.8,
    securityScore: 98.5,
    optimizationLevel: 94.2
  });

  const [isScanning, setIsScanning] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [selectedConnection, setSelectedConnection] = useState<string>('storm-echo-secure');
  const { toast } = useToast();

  const updateMetrics = useCallback(() => {
    setMetrics(prev => ({
      downloadSpeed: prev.downloadSpeed + (Math.random() - 0.5) * 50,
      uploadSpeed: prev.uploadSpeed + (Math.random() - 0.5) * 30,
      ping: Math.max(1, prev.ping + (Math.random() - 0.5) * 3),
      packetLoss: Math.max(0, Math.min(1, prev.packetLoss + (Math.random() - 0.5) * 0.02)),
      stability: Math.max(90, Math.min(100, prev.stability + (Math.random() - 0.5) * 2)),
      securityScore: Math.max(95, Math.min(100, prev.securityScore + (Math.random() - 0.5) * 1)),
      optimizationLevel: Math.max(90, Math.min(100, prev.optimizationLevel + (Math.random() - 0.5) * 2))
    }));
  }, []);

  useEffect(() => {
    const interval = setInterval(updateMetrics, 2000);
    return () => clearInterval(interval);
  }, [updateMetrics]);

  const scanNetworks = async () => {
    setIsScanning(true);
    
    // Simulate network scanning
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Add discovered networks
    const newNetworks = [
      {
        id: 'fiber-ultra',
        name: 'Fiber Ultra 5G',
        type: 'wifi' as const,
        strength: 92,
        security: 'wpa3' as const,
        speed: 1800,
        latency: 5,
        isConnected: false,
        isSecure: true,
        encryption: 'AES-256',
        frequency: '6GHz'
      }
    ];
    
    setConnections(prev => [...prev, ...newNetworks]);
    setIsScanning(false);
    
    toast({
      title: "Network Scan Complete",
      description: `Discovered ${newNetworks.length} new secure networks`
    });
  };

  const optimizeConnection = async () => {
    setIsOptimizing(true);
    
    // Simulate connection optimization
    await new Promise(resolve => setTimeout(resolve, 4000));
    
    setMetrics(prev => ({
      ...prev,
      downloadSpeed: prev.downloadSpeed * 1.15,
      uploadSpeed: prev.uploadSpeed * 1.12,
      ping: Math.max(1, prev.ping * 0.8),
      packetLoss: prev.packetLoss * 0.5,
      stability: Math.min(100, prev.stability * 1.02),
      optimizationLevel: Math.min(100, prev.optimizationLevel + 5)
    }));
    
    setIsOptimizing(false);
    
    toast({
      title: "Connection Optimized",
      description: "Network performance enhanced with quantum acceleration"
    });
  };

  const connectToNetwork = async (networkId: string) => {
    setConnections(prev => 
      prev.map(conn => ({
        ...conn,
        isConnected: conn.id === networkId
      }))
    );
    
    setSelectedConnection(networkId);
    
    toast({
      title: "Connected Successfully",
      description: "Secure connection established with encryption protocols active"
    });
  };

  const getConnectionIcon = (type: string, isConnected: boolean, strength: number) => {
    if (!isConnected) {
      return <WifiOff className="w-5 h-5 text-gray-400" />;
    }
    
    if (type === 'ethernet') {
      return <Globe className="w-5 h-5 text-green-400" />;
    }
    
    const color = strength > 80 ? 'text-green-400' : strength > 60 ? 'text-yellow-400' : 'text-red-400';
    return <Wifi className={`w-5 h-5 ${color}`} />;
  };

  const getSecurityIcon = (security: string, isSecure: boolean) => {
    if (!isSecure || security === 'none') {
      return <Unlock className="w-4 h-4 text-red-400" />;
    }
    
    if (security === 'wpa3' || security === 'enterprise') {
      return <ShieldCheck className="w-4 h-4 text-green-400" />;
    }
    
    return <Shield className="w-4 h-4 text-yellow-400" />;
  };

  const getSecurityBadge = (security: string) => {
    const colors = {
      none: 'bg-red-500/20 text-red-400',
      wep: 'bg-red-500/20 text-red-400',
      wpa: 'bg-yellow-500/20 text-yellow-400',
      wpa2: 'bg-blue-500/20 text-blue-400',
      wpa3: 'bg-green-500/20 text-green-400',
      enterprise: 'bg-purple-500/20 text-purple-400'
    };
    
    return colors[security as keyof typeof colors] || colors.none;
  };

  const connectedNetwork = connections.find(conn => conn.isConnected);

  return (
    <div className="space-y-6">
      {/* Connection Status Header */}
      <Card className="bg-black border-gray-800/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.7, 1, 0.7]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                {connectedNetwork ? (
                  getConnectionIcon(connectedNetwork.type, true, connectedNetwork.strength)
                ) : (
                  <WifiOff className="w-6 h-6 text-red-400" />
                )}
              </motion.div>
              <div>
                <CardTitle className="text-lg text-gray-200">
                  {connectedNetwork ? 'Connected to ' + connectedNetwork.name : 'No Connection'}
                </CardTitle>
                <p className="text-sm text-gray-400">
                  {connectedNetwork ? 
                    `${connectedNetwork.speed} Mbps • ${connectedNetwork.encryption} • ${connectedNetwork.frequency}` :
                    'Not connected to any network'
                  }
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                onClick={scanNetworks}
                disabled={isScanning}
                variant="outline"
                size="sm"
                className="bg-black border-gray-800/50"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isScanning ? 'animate-spin' : ''}`} />
                {isScanning ? 'Scanning...' : 'Scan'}
              </Button>
              <Button
                onClick={optimizeConnection}
                disabled={isOptimizing || !connectedNetwork}
                className="bg-gradient-to-r from-gray-800 to-gray-700"
              >
                <Zap className={`w-4 h-4 mr-2 ${isOptimizing ? 'animate-pulse' : ''}`} />
                {isOptimizing ? 'Optimizing...' : 'Optimize'}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="status" className="space-y-4">
        <TabsList className="bg-black border border-gray-800/50">
          <TabsTrigger value="status">Connection Status</TabsTrigger>
          <TabsTrigger value="networks">Available Networks</TabsTrigger>
          <TabsTrigger value="security">Security & Encryption</TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="space-y-4">
          {/* Performance Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-4 bg-black border-gray-800/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Download</p>
                  <p className="text-xl font-bold text-green-400">
                    {metrics.downloadSpeed.toFixed(1)} Mbps
                  </p>
                </div>
                <Activity className="w-6 h-6 text-green-400" />
              </div>
            </Card>

            <Card className="p-4 bg-black border-gray-800/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Upload</p>
                  <p className="text-xl font-bold text-blue-400">
                    {metrics.uploadSpeed.toFixed(1)} Mbps
                  </p>
                </div>
                <Signal className="w-6 h-6 text-blue-400" />
              </div>
            </Card>

            <Card className="p-4 bg-black border-gray-800/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Ping</p>
                  <p className="text-xl font-bold text-cyan-400">
                    {metrics.ping.toFixed(0)}ms
                  </p>
                </div>
                <Zap className="w-6 h-6 text-cyan-400" />
              </div>
            </Card>

            <Card className="p-4 bg-black border-gray-800/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Stability</p>
                  <p className="text-xl font-bold text-purple-400">
                    {metrics.stability.toFixed(1)}%
                  </p>
                </div>
                <CheckCircle className="w-6 h-6 text-purple-400" />
              </div>
            </Card>
          </div>

          {/* Detailed Metrics */}
          <Card className="bg-black border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-gray-200">Performance Analytics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Packet Loss</span>
                  <span className="text-gray-200">{(metrics.packetLoss * 100).toFixed(2)}%</span>
                </div>
                <Progress value={100 - (metrics.packetLoss * 100)} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Security Score</span>
                  <span className="text-green-400">{metrics.securityScore.toFixed(1)}%</span>
                </div>
                <Progress value={metrics.securityScore} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Optimization Level</span>
                  <span className="text-blue-400">{metrics.optimizationLevel.toFixed(1)}%</span>
                </div>
                <Progress value={metrics.optimizationLevel} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="networks" className="space-y-4">
          <div className="space-y-3">
            {connections.map((connection) => (
              <Card 
                key={connection.id} 
                className={`p-4 bg-black border-gray-800/50 cursor-pointer transition-all hover:border-gray-700/70 ${
                  connection.isConnected ? 'ring-2 ring-green-400/30' : ''
                }`}
                onClick={() => !connection.isConnected && connectToNetwork(connection.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getConnectionIcon(connection.type, connection.isConnected, connection.strength)}
                    <div>
                      <h3 className="font-medium text-gray-200">{connection.name}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-400">
                        <span>{connection.speed} Mbps</span>
                        <span>•</span>
                        <span>{connection.latency}ms</span>
                        <span>•</span>
                        <Badge className={getSecurityBadge(connection.security)}>
                          {connection.security.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getSecurityIcon(connection.security, connection.isSecure)}
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-200">
                        {connection.strength}%
                      </p>
                      <p className="text-xs text-gray-400">
                        {connection.frequency}
                      </p>
                    </div>
                    {connection.isConnected && (
                      <Badge className="bg-green-500/20 text-green-400">
                        Connected
                      </Badge>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          {/* Fast Connection Lock */}
          <FastConnectionLock />
          
          {/* Network Optimization Component */}
          <NetworkOptimization />
          <Card className="bg-black border-gray-800/50">
            <CardHeader>
              <CardTitle className="text-gray-200 flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-green-400" />
                Security & Encryption Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {connectedNetwork && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Encryption Protocol</span>
                    <Badge className="bg-green-500/20 text-green-400">
                      {connectedNetwork.encryption}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Security Standard</span>
                    <Badge className={getSecurityBadge(connectedNetwork.security)}>
                      {connectedNetwork.security.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Firewall Status</span>
                    <div className="flex items-center">
                      <Shield className="w-4 h-4 text-green-400 mr-1" />
                      <span className="text-green-400">Active</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">VPN Protection</span>
                    <div className="flex items-center">
                      <Lock className="w-4 h-4 text-green-400 mr-1" />
                      <span className="text-green-400">Enabled</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Password Input for WPA Networks */}
              <div className="pt-4 border-t border-gray-800/50">
                <h4 className="text-sm font-medium text-gray-300 mb-3">
                  Network Authentication
                </h4>
                <div className="flex space-x-2">
                  <div className="relative flex-1">
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter network password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-black border-gray-800/50 pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  <Button className="bg-gradient-to-r from-gray-800 to-gray-700">
                    Connect
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}