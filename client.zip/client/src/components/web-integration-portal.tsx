import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Globe, Link2, Database, Settings, Zap, Shield, Cloud, Terminal, Code, Webhook } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface WebIntegration {
  id: string;
  name: string;
  type: 'api' | 'webhook' | 'database' | 'service';
  url: string;
  status: 'active' | 'inactive' | 'error';
  lastSync: string;
  dataPoints: number;
  security: 'high' | 'medium' | 'low';
}

interface BackdoorAccess {
  id: string;
  target: string;
  type: 'admin' | 'database' | 'system' | 'api';
  status: 'established' | 'pending' | 'failed';
  timestamp: string;
  privilege: 'root' | 'admin' | 'user';
}

export function WebIntegrationPortal() {
  const [activeTab, setActiveTab] = useState<'integrations' | 'backdoors' | 'monitoring'>('integrations');
  const [newIntegration, setNewIntegration] = useState({
    name: '',
    type: 'api' as const,
    url: '',
    apiKey: ''
  });
  const [backdoorTarget, setBackdoorTarget] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch web integrations
  const { data: integrations = [], isLoading: integrationsLoading } = useQuery({
    queryKey: ['/api/web/integrations'],
    queryFn: () => apiRequest('GET', '/api/web/integrations'),
  });

  // Fetch backdoor accesses
  const { data: backdoors = [], isLoading: backdoorsLoading } = useQuery({
    queryKey: ['/api/backdoors'],
    queryFn: () => apiRequest('GET', '/api/backdoors'),
  });

  // Add integration mutation
  const addIntegrationMutation = useMutation({
    mutationFn: async (data: typeof newIntegration) => {
      return apiRequest('POST', '/api/web/integrations', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/web/integrations'] });
      toast({
        title: "Integration Added",
        description: "Web integration successfully established",
      });
      setNewIntegration({ name: '', type: 'api', url: '', apiKey: '' });
    },
    onError: () => {
      toast({
        title: "Integration Failed",
        description: "Unable to establish web integration",
        variant: "destructive"
      });
    }
  });

  // Create backdoor mutation
  const createBackdoorMutation = useMutation({
    mutationFn: async (target: string) => {
      return apiRequest('POST', '/api/backdoors/create', { target });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/backdoors'] });
      toast({
        title: "Backdoor Established",
        description: "System access successfully configured",
      });
      setBackdoorTarget('');
    },
    onError: () => {
      toast({
        title: "Access Denied",
        description: "Unable to establish backdoor access",
        variant: "destructive"
      });
    }
  });

  const startNetworkScan = async () => {
    setIsScanning(true);
    setScanProgress(0);

    const scanSteps = [
      { progress: 20, delay: 800, message: 'Scanning network topology...' },
      { progress: 40, delay: 1200, message: 'Identifying vulnerable endpoints...' },
      { progress: 60, delay: 1000, message: 'Analyzing security protocols...' },
      { progress: 80, delay: 900, message: 'Mapping access points...' },
      { progress: 100, delay: 600, message: 'Scan complete' }
    ];

    for (const step of scanSteps) {
      await new Promise(resolve => setTimeout(resolve, step.delay));
      setScanProgress(step.progress);
    }

    toast({
      title: "Network Scan Complete",
      description: "Discovered 23 potential integration points",
    });
    setIsScanning(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'established':
        return 'text-green-400 border-green-400/30';
      case 'pending':
        return 'text-yellow-400 border-yellow-400/30';
      case 'error':
      case 'failed':
        return 'text-red-400 border-red-400/30';
      default:
        return 'text-gray-400 border-gray-400/30';
    }
  };

  const getSecurityColor = (security: string) => {
    switch (security) {
      case 'high':
        return 'text-green-400 border-green-400/30';
      case 'medium':
        return 'text-yellow-400 border-yellow-400/30';
      case 'low':
        return 'text-red-400 border-red-400/30';
      default:
        return 'text-gray-400 border-gray-400/30';
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-3 sm:p-6 max-w-full overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 sm:mb-6 gap-2">
        <h3 className="text-lg sm:text-xl font-bold text-cyan-400 flex items-center">
          <Globe size={20} className="sm:w-6 sm:h-6 mr-2 sm:mr-3 flex-shrink-0" />
          <span className="truncate">Web Integration & Backdoor Portal</span>
        </h3>
        <Badge variant="outline" className="border-red-400/30 text-red-400 flex-shrink-0">
          Advanced Access
        </Badge>
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-1 mb-4 sm:mb-6 bg-gray-900/60 p-1 rounded-lg overflow-x-auto">
        {['integrations', 'backdoors', 'monitoring'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`px-2 sm:px-4 py-1 sm:py-2 rounded-md text-xs sm:text-sm font-medium transition-colors capitalize flex-shrink-0 ${
              activeTab === tab
                ? 'bg-cyan-500/20 text-cyan-400'
                : 'text-gray-400 hover:text-cyan-400'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'integrations' && (
          <motion.div
            key="integrations"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-3 sm:space-y-6 max-w-full overflow-hidden"
          >
            {/* Add New Integration */}
            <Card className="bg-gray-900/60 border-cyan-400/20">
              <CardHeader>
                <CardTitle className="text-cyan-400 flex items-center">
                  <Link2 size={20} className="mr-2" />
                  Add Web Integration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 sm:space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <Input
                    placeholder="Integration Name"
                    value={newIntegration.name}
                    onChange={(e) => setNewIntegration(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-gray-800/50 border-gray-600/30"
                  />
                  <select
                    value={newIntegration.type}
                    onChange={(e) => setNewIntegration(prev => ({ ...prev, type: e.target.value as any }))}
                    className="bg-gray-800/50 border border-gray-600/30 rounded-md px-3 py-2 text-white"
                  >
                    <option value="api">API Endpoint</option>
                    <option value="webhook">Webhook</option>
                    <option value="database">Database</option>
                    <option value="service">Service</option>
                  </select>
                </div>
                <Input
                  placeholder="URL or Endpoint"
                  value={newIntegration.url}
                  onChange={(e) => setNewIntegration(prev => ({ ...prev, url: e.target.value }))}
                  className="bg-gray-800/50 border-gray-600/30"
                />
                <Input
                  placeholder="API Key (Optional)"
                  type="password"
                  value={newIntegration.apiKey}
                  onChange={(e) => setNewIntegration(prev => ({ ...prev, apiKey: e.target.value }))}
                  className="bg-gray-800/50 border-gray-600/30"
                />
                <Button
                  onClick={() => addIntegrationMutation.mutate(newIntegration)}
                  disabled={!newIntegration.name || !newIntegration.url || addIntegrationMutation.isPending}
                  className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400"
                >
                  <Settings size={16} className="mr-2" />
                  Add Integration
                </Button>
              </CardContent>
            </Card>

            {/* Integration List */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-cyan-400">Active Integrations</h4>
              {integrationsLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto"></div>
                </div>
              ) : integrations.length === 0 ? (
                <Card className="bg-gray-900/40 border-gray-600/20">
                  <CardContent className="text-center py-8">
                    <Globe size={48} className="mx-auto text-gray-600 mb-3" />
                    <p className="text-gray-400">No web integrations configured</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4">
                  {integrations.map((integration: WebIntegration) => (
                    <Card key={integration.id} className="bg-gray-900/60 border-cyan-400/20">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h5 className="font-semibold text-cyan-400 mb-1">{integration.name}</h5>
                            <p className="text-sm text-gray-400 mb-2">{integration.url}</p>
                            
                            <div className="flex flex-wrap gap-2 mb-3">
                              <Badge variant="outline" className={`text-xs ${getStatusColor(integration.status)}`}>
                                {integration.status}
                              </Badge>
                              <Badge variant="outline" className="text-xs border-blue-400/30 text-blue-400">
                                {integration.type}
                              </Badge>
                              <Badge variant="outline" className={`text-xs ${getSecurityColor(integration.security)}`}>
                                {integration.security} security
                              </Badge>
                            </div>

                            <div className="flex items-center text-xs text-gray-500 space-x-4">
                              <span>Last sync: {new Date(integration.lastSync).toLocaleDateString()}</span>
                              <span>{integration.dataPoints.toLocaleString()} data points</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'backdoors' && (
          <motion.div
            key="backdoors"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-3 sm:space-y-6 max-w-full overflow-hidden"
          >
            {/* Create Backdoor */}
            <Card className="bg-red-900/20 border-red-400/20">
              <CardHeader>
                <CardTitle className="text-red-400 flex items-center">
                  <Shield size={20} className="mr-2" />
                  System Access Portal
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 sm:space-y-4">
                <Textarea
                  placeholder="Target system or domain..."
                  value={backdoorTarget}
                  onChange={(e) => setBackdoorTarget(e.target.value)}
                  className="bg-gray-800/50 border-gray-600/30"
                  rows={3}
                />
                <div className="flex space-x-3">
                  <Button
                    onClick={() => createBackdoorMutation.mutate(backdoorTarget)}
                    disabled={!backdoorTarget || createBackdoorMutation.isPending}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-400 border-red-500/30"
                  >
                    <Terminal size={16} className="mr-2" />
                    Establish Access
                  </Button>
                  <Button
                    onClick={startNetworkScan}
                    disabled={isScanning}
                    variant="outline"
                    className="border-yellow-400/30 text-yellow-400"
                  >
                    <Zap size={16} className="mr-2" />
                    {isScanning ? 'Scanning...' : 'Network Scan'}
                  </Button>
                </div>
                
                {isScanning && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-yellow-400">Network scanning in progress...</span>
                      <span className="text-gray-400">{scanProgress}%</span>
                    </div>
                    <Progress value={scanProgress} className="h-2" />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Backdoor List */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-red-400">System Access Points</h4>
              {backdoorsLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-400 mx-auto"></div>
                </div>
              ) : backdoors.length === 0 ? (
                <Card className="bg-gray-900/40 border-gray-600/20">
                  <CardContent className="text-center py-8">
                    <Shield size={48} className="mx-auto text-gray-600 mb-3" />
                    <p className="text-gray-400">No backdoor access established</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4">
                  {backdoors.map((backdoor: BackdoorAccess) => (
                    <Card key={backdoor.id} className="bg-gray-900/60 border-red-400/20">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h5 className="font-semibold text-red-400 mb-1">{backdoor.target}</h5>
                            
                            <div className="flex flex-wrap gap-2 mb-3">
                              <Badge variant="outline" className={`text-xs ${getStatusColor(backdoor.status)}`}>
                                {backdoor.status}
                              </Badge>
                              <Badge variant="outline" className="text-xs border-purple-400/30 text-purple-400">
                                {backdoor.type}
                              </Badge>
                              <Badge variant="outline" className="text-xs border-orange-400/30 text-orange-400">
                                {backdoor.privilege} access
                              </Badge>
                            </div>

                            <div className="text-xs text-gray-500">
                              Established: {new Date(backdoor.timestamp).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'monitoring' && (
          <motion.div
            key="monitoring"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-3 sm:space-y-6 max-w-full overflow-hidden"
          >
            <Card className="bg-gray-900/60 border-green-400/20">
              <CardHeader>
                <CardTitle className="text-green-400 flex items-center">
                  <Database size={20} className="mr-2" />
                  Real-time Monitoring
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                  <div className="text-center p-4 bg-blue-900/20 rounded-lg border border-blue-400/20">
                    <div className="text-2xl font-bold text-blue-400">24</div>
                    <div className="text-sm text-gray-400">Active Connections</div>
                  </div>
                  <div className="text-center p-4 bg-green-900/20 rounded-lg border border-green-400/20">
                    <div className="text-2xl font-bold text-green-400">98.7%</div>
                    <div className="text-sm text-gray-400">Uptime</div>
                  </div>
                  <div className="text-center p-4 bg-purple-900/20 rounded-lg border border-purple-400/20">
                    <div className="text-2xl font-bold text-purple-400">1.2TB</div>
                    <div className="text-sm text-gray-400">Data Processed</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}