import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Code, Play, Pause, RotateCcw, Maximize, Zap, Brain, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';

interface CodeParticle {
  id: string;
  x: number;
  y: number;
  z: number;
  char: string;
  velocity: { x: number; y: number; z: number };
  color: string;
  opacity: number;
  life: number;
}

interface HolographicProjectionProps {
  code: string;
  language: string;
  title: string;
  isActive?: boolean;
}

export function HolographicCodeProjection({ 
  code, 
  language, 
  title, 
  isActive = false 
}: HolographicProjectionProps) {
  const [isProjecting, setIsProjecting] = useState(false);
  const [projectionIntensity, setProjectionIntensity] = useState([75]);
  const [rotationSpeed, setRotationSpeed] = useState([50]);
  const [particles, setParticles] = useState<CodeParticle[]>([]);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  const codeLines = code.split('\n').filter(line => line.trim());

  // Generate holographic particles from code
  const generateParticles = () => {
    const newParticles: CodeParticle[] = [];
    const centerX = 400;
    const centerY = 300;
    
    codeLines.forEach((line, lineIndex) => {
      [...line].forEach((char, charIndex) => {
        if (char.trim()) {
          const angle = (charIndex / line.length) * Math.PI * 2;
          const radius = 100 + (lineIndex * 15);
          
          newParticles.push({
            id: `${lineIndex}-${charIndex}`,
            x: centerX + Math.cos(angle) * radius,
            y: centerY + Math.sin(angle) * radius,
            z: lineIndex * 20,
            char,
            velocity: {
              x: (Math.random() - 0.5) * 0.5,
              y: (Math.random() - 0.5) * 0.5,
              z: (Math.random() - 0.5) * 0.5
            },
            color: getCharacterColor(char),
            opacity: 0.8,
            life: 1.0
          });
        }
      });
    });
    
    setParticles(newParticles);
  };

  const getCharacterColor = (char: string) => {
    if (/[{}()[\]]/.test(char)) return '#00ffff'; // Cyan for brackets
    if (/[a-zA-Z_]/.test(char)) return '#ff00ff'; // Magenta for letters
    if (/[0-9]/.test(char)) return '#ffff00'; // Yellow for numbers
    if (/[=+\-*/<>!]/.test(char)) return '#ff4444'; // Red for operators
    return '#ffffff'; // White for others
  };

  // Canvas animation loop
  const animate = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas with fade effect
    ctx.fillStyle = 'rgba(10, 10, 15, 0.1)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw holographic grid
    drawHolographicGrid(ctx);

    // Update and draw particles
    const time = Date.now() * 0.001;
    const speed = rotationSpeed[0] / 100;

    particles.forEach((particle, index) => {
      // Rotate particles around center
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      
      const angle = time * speed + (index * 0.1);
      const radius = 50 + Math.sin(time + index) * 30;
      
      particle.x = centerX + Math.cos(angle) * radius;
      particle.y = centerY + Math.sin(angle) * radius;
      particle.z = Math.sin(time * 2 + index) * 50;

      // Calculate 3D projection
      const perspective = 300;
      const scale = perspective / (perspective + particle.z);
      const projectedX = particle.x * scale;
      const projectedY = particle.y * scale;

      // Draw particle with glow effect
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      
      // Main character
      ctx.fillStyle = particle.color;
      ctx.globalAlpha = particle.opacity * (projectionIntensity[0] / 100);
      ctx.font = `${12 * scale}px 'Courier New', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(particle.char, projectedX, projectedY);

      // Glow effect
      ctx.globalCompositeOperation = 'lighter';
      ctx.shadowColor = particle.color;
      ctx.shadowBlur = 10 * scale;
      ctx.fillText(particle.char, projectedX, projectedY);

      ctx.restore();
    });

    if (isProjecting) {
      animationRef.current = requestAnimationFrame(animate);
    }
  };

  const drawHolographicGrid = (ctx: CanvasRenderingContext2D) => {
    const width = ctx.canvas.width;
    const height = ctx.canvas.height;
    
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.2)';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 10]);

    // Vertical lines
    for (let x = 0; x < width; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Horizontal lines
    for (let y = 0; y < height; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    ctx.setLineDash([]);
  };

  const startProjection = () => {
    setIsProjecting(true);
    generateParticles();
  };

  const stopProjection = () => {
    setIsProjecting(false);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };

  const resetProjection = () => {
    stopProjection();
    setCurrentLineIndex(0);
    setParticles([]);
  };

  useEffect(() => {
    if (isProjecting) {
      animate();
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isProjecting, particles, rotationSpeed, projectionIntensity]);

  useEffect(() => {
    if (isActive && !isProjecting) {
      startProjection();
    }
  }, [isActive]);

  return (
    <motion.div
      className="relative w-full h-full bg-gradient-to-br from-gray-900 via-purple-900/20 to-cyan-900/20 rounded-lg overflow-hidden border border-cyan-400/30"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header Controls */}
      <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="border-cyan-400 text-cyan-400">
            <Brain className="w-3 h-3 mr-1" />
            {language}
          </Badge>
          <h3 className="text-cyan-400 font-semibold">{title}</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={isProjecting ? stopProjection : startProjection}
            className="text-cyan-400 hover:bg-cyan-400/20"
          >
            {isProjecting ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={resetProjection}
            className="text-cyan-400 hover:bg-cyan-400/20"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Holographic Canvas */}
      <canvas
        ref={canvasRef}
        width={800}
        height={600}
        className="w-full h-full"
        style={{ background: 'transparent' }}
      />

      {/* Control Panel */}
      <motion.div
        className="absolute bottom-4 left-4 right-4 bg-gray-900/80 backdrop-blur-md rounded-lg p-4 border border-cyan-400/30"
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-cyan-400 text-sm mb-2 block">
              <Sparkles className="w-4 h-4 inline mr-1" />
              Projection Intensity
            </label>
            <Slider
              value={projectionIntensity}
              onValueChange={setProjectionIntensity}
              max={100}
              step={1}
              className="w-full"
            />
            <span className="text-cyan-400/70 text-xs">{projectionIntensity[0]}%</span>
          </div>
          
          <div>
            <label className="text-cyan-400 text-sm mb-2 block">
              <Zap className="w-4 h-4 inline mr-1" />
              Rotation Speed
            </label>
            <Slider
              value={rotationSpeed}
              onValueChange={setRotationSpeed}
              max={100}
              step={1}
              className="w-full"
            />
            <span className="text-cyan-400/70 text-xs">{rotationSpeed[0]}%</span>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <span className="text-cyan-400/70 text-sm">
              {isProjecting ? 'Holographic Projection Active' : 'Projection Standby'}
            </span>
          </div>
          
          <div className="text-cyan-400/70 text-sm">
            Lines: {codeLines.length} | Particles: {particles.length}
          </div>
        </div>
      </motion.div>

      {/* Particle Effect Overlay */}
      <AnimatePresence>
        {isProjecting && (
          <motion.div
            className="absolute inset-0 pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-cyan-400 rounded-full"
                initial={{
                  x: Math.random() * 800,
                  y: Math.random() * 600,
                  opacity: 0
                }}
                animate={{
                  x: Math.random() * 800,
                  y: Math.random() * 600,
                  opacity: [0, 1, 0]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.1
                }}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default HolographicCodeProjection;