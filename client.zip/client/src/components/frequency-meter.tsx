import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Volume2, Minus, Plus, Play, Pause, RotateCcw, Vibrate } from 'lucide-react';
import { useThetaVibration } from '@/hooks/use-theta-vibration';

interface FrequencyMeterProps {
  className?: string;
}

interface FrequencyPreset {
  name: string;
  frequency: number;
  description: string;
  color: string;
}

const healingPresets: FrequencyPreset[] = [
  { name: "Theta", frequency: 4, description: "Theta Waves - Deep Meditation", color: "from-indigo-600 to-purple-700" },
  { name: "Theta+", frequency: 6, description: "Theta Waves - REM Sleep", color: "from-indigo-500 to-purple-600" },
  { name: "Earth", frequency: 7.83, description: "Schumann Resonance", color: "from-green-500 to-emerald-600" },
  { name: "Alpha", frequency: 10.5, description: "Alpha Brainwaves", color: "from-teal-500 to-cyan-600" },
  { name: "Beta", frequency: 20, description: "Beta Brainwaves", color: "from-blue-400 to-blue-600" },
  { name: "Gamma", frequency: 40, description: "Gamma Brainwaves", color: "from-purple-400 to-purple-600" },
  { name: "Root", frequency: 194.18, description: "Root Chakra", color: "from-red-500 to-red-600" },
  { name: "Sacral", frequency: 417, description: "Sacral Chakra", color: "from-orange-500 to-orange-600" },
  { name: "A4", frequency: 432, description: "Healing Tuning", color: "from-cyan-500 to-blue-600" },
  { name: "Heart", frequency: 528, description: "Love Frequency", color: "from-green-500 to-green-600" },
  { name: "Solar", frequency: 639, description: "Solar Plexus", color: "from-yellow-500 to-orange-600" },
  { name: "Throat", frequency: 741, description: "Expression", color: "from-blue-500 to-indigo-600" },
  { name: "Third Eye", frequency: 852, description: "Intuition", color: "from-indigo-500 to-purple-600" },
  { name: "Crown", frequency: 963, description: "Spiritual Connection", color: "from-purple-500 to-violet-600" },
  { name: "Portal", frequency: 1111.11, description: "Portal Frequency", color: "from-violet-400 to-pink-500" },
  { name: "DNA", frequency: 1122, description: "DNA Activation", color: "from-pink-500 to-rose-600" },
];

const vibrationPresets: FrequencyPreset[] = [
  { name: "Theta Vibe", frequency: 4, description: "Theta Vibration", color: "from-indigo-700 to-purple-800" },
  { name: "Sub", frequency: 5, description: "Sub Bass", color: "from-gray-700 to-gray-800" },
  { name: "Theta Pulse", frequency: 6, description: "Theta Pulse", color: "from-indigo-600 to-purple-700" },
  { name: "Deep", frequency: 10, description: "Deep Vibration", color: "from-gray-600 to-gray-700" },
  { name: "Bass", frequency: 60, description: "Bass Frequency", color: "from-amber-700 to-orange-800" },
  { name: "Low", frequency: 100, description: "Low Mid", color: "from-amber-600 to-orange-700" },
  { name: "Mid", frequency: 250, description: "Mid Range", color: "from-yellow-500 to-amber-600" },
  { name: "High", frequency: 500, description: "High Mid", color: "from-lime-500 to-green-600" },
  { name: "Treble", frequency: 1000, description: "Treble Range", color: "from-green-400 to-cyan-500" },
  { name: "Bright", frequency: 2000, description: "Bright Tone", color: "from-cyan-400 to-blue-500" },
  { name: "Presence", frequency: 4000, description: "Presence", color: "from-blue-400 to-indigo-500" },
  { name: "Air", frequency: 8000, description: "Airy Highs", color: "from-indigo-400 to-purple-500" },
  { name: "Ultra", frequency: 12000, description: "Ultra High", color: "from-purple-400 to-violet-500" },
  { name: "Crystal", frequency: 16000, description: "Crystal Clear", color: "from-violet-400 to-pink-500" },
];

export function FrequencyMeter({ className = "" }: FrequencyMeterProps) {
  const [frequency, setFrequency] = useState(4.00);
  const [volume, setVolume] = useState(100);
  const [isPlaying, setIsPlaying] = useState(false);
  const [multiplier, setMultiplier] = useState(1);
  const [selectedPreset, setSelectedPreset] = useState<string | null>("Theta");
  const [presetCategory, setPresetCategory] = useState<'healing' | 'vibration'>('healing');
  const [waveform, setWaveform] = useState<'sine' | 'square' | 'sawtooth' | 'triangle'>('sine');
  const [enableVibration, setEnableVibration] = useState(true);
  
  const { startThetaVibration, stopVibration, isVibrating } = useThetaVibration();
  
  // Audio context for generating tones
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [oscillator, setOscillator] = useState<OscillatorNode | null>(null);
  const [gainNode, setGainNode] = useState<GainNode | null>(null);
  
  // Watch for frequency changes to update selected preset
  useEffect(() => {
    const currentPresets = presetCategory === 'healing' ? healingPresets : vibrationPresets;
    const matchingPreset = currentPresets.find(p => Math.abs(p.frequency - frequency) < 0.01);
    if (matchingPreset && matchingPreset.name !== selectedPreset) {
      setSelectedPreset(matchingPreset.name);
    }
  }, [frequency, presetCategory]);

  useEffect(() => {
    // Initialize audio context
    if (typeof window !== 'undefined') {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      setAudioContext(ctx);
      
      const gain = ctx.createGain();
      gain.connect(ctx.destination);
      gain.gain.setValueAtTime(0.3, ctx.currentTime); // Set initial volume
      setGainNode(gain);
    }
    
    return () => {
      if (oscillator) {
        try {
          oscillator.stop();
        } catch (e) {
          // Oscillator already stopped
        }
      }
      if (audioContext && audioContext.state !== 'closed') {
        audioContext.close();
      }
    };
  }, []);

  const startTone = async () => {
    if (!audioContext || !gainNode) return;
    
    try {
      // Stop any existing oscillator
      if (oscillator) {
        oscillator.stop();
        setOscillator(null);
      }
      
      if (audioContext.state === 'suspended') {
        await audioContext.resume();
      }
      
      const osc = audioContext.createOscillator();
      osc.frequency.setValueAtTime(frequency, audioContext.currentTime);
      osc.type = waveform;
      
      // Set volume with smooth transition
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(volume / 100 * 0.3, audioContext.currentTime + 0.1);
      
      osc.connect(gainNode);
      osc.start();
      
      // Add end handler
      osc.onended = () => {
        setOscillator(null);
        setIsPlaying(false);
        stopVibration();
      };
      
      setOscillator(osc);
      setIsPlaying(true);
      
      // Start theta vibration if enabled and frequency is low enough
      if (enableVibration && frequency <= 10) {
        // Small delay to ensure audio context is initialized
        setTimeout(() => {
          const patternName = frequency <= 4 ? 'deep' : 
                            frequency <= 6 ? 'rem' : 
                            frequency <= 8 ? 'earth' : 'meditation';
          console.log(`🎯 Attempting to start vibration: ${patternName} for ${frequency}Hz`);
          const vibrationStarted = startThetaVibration(patternName);
          console.log(`📳 Vibration started: ${vibrationStarted}`);
        }, 100);
      }
    } catch (error) {
      console.error('Error starting tone:', error);
      setIsPlaying(false);
    }
  };

  const stopTone = () => {
    if (oscillator && audioContext && gainNode) {
      try {
        // Fade out for smooth stop
        gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.1);
        setTimeout(() => {
          if (oscillator) {
            oscillator.stop();
            setOscillator(null);
          }
        }, 100);
      } catch (error) {
        console.error('Error stopping tone:', error);
        setOscillator(null);
      }
    }
    setIsPlaying(false);
    stopVibration();
  };

  const togglePlayback = () => {
    if (isPlaying) {
      stopTone();
    } else {
      startTone();
    }
  };

  const adjustFrequency = (delta: number) => {
    const newFreq = Math.max(1, Math.min(22000, frequency + delta * multiplier));
    setFrequency(parseFloat(newFreq.toFixed(2)));
    setSelectedPreset(null); // Clear preset when manually adjusting
    
    if (oscillator && audioContext) {
      // Smooth frequency transition
      oscillator.frequency.linearRampToValueAtTime(newFreq, audioContext.currentTime + 0.1);
    }
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newFreq = parseFloat(e.target.value);
    setFrequency(newFreq);
    setSelectedPreset(null); // Clear preset when using slider
    
    if (oscillator && audioContext) {
      // Smooth frequency transition for slider
      oscillator.frequency.linearRampToValueAtTime(newFreq, audioContext.currentTime + 0.05);
    }
    
    // Update vibration based on frequency
    if (isPlaying && enableVibration) {
      if (newFreq <= 10 && !isVibrating) {
        const patternName = newFreq <= 4 ? 'deep' : 
                          newFreq <= 6 ? 'rem' : 
                          newFreq <= 8 ? 'earth' : 'meditation';
        startThetaVibration(patternName);
      } else if (newFreq > 10 && isVibrating) {
        stopVibration();
      }
    }
  };

  const selectPreset = (preset: FrequencyPreset) => {
    console.log(`🎵 Selecting preset: ${preset.name} at ${preset.frequency}Hz`);
    setFrequency(preset.frequency);
    setSelectedPreset(preset.name);
    
    if (oscillator && audioContext) {
      // Smooth transition to preset frequency
      oscillator.frequency.linearRampToValueAtTime(preset.frequency, audioContext.currentTime + 0.2);
    }
    
    // Only handle vibration if audio is currently playing
    // When just selecting presets, don't trigger vibration until play is pressed
  };

  const getCurrentPresets = () => {
    return presetCategory === 'healing' ? healingPresets : vibrationPresets;
  };

  const resetToDefault = () => {
    console.log("🔄 Resetting to default frequency");
    setFrequency(4.00);
    setSelectedPreset("Theta");
    setPresetCategory('healing');
    if (oscillator && audioContext) {
      oscillator.frequency.linearRampToValueAtTime(4.00, audioContext.currentTime + 0.3);
    }
    
    // Reset will only start vibration if audio is already playing
    if (isPlaying && enableVibration) {
      startThetaVibration('deep');
    }
  };

  return (
    <motion.div
      className={`bg-gray-900/90 backdrop-blur-md border border-gray-700 rounded-2xl p-4 md:p-6 text-white w-full mx-auto ${className}`}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="text-center mb-6">
        <h3 className="text-xl font-bold text-cyan-400 mb-2">Frequency Generator</h3>
        <div className="flex items-center justify-center space-x-2">
          <Volume2 className="text-cyan-400" size={16} />
          <span className="text-sm text-gray-400">{volume}%</span>
        </div>
      </div>

      {/* Main Frequency Display */}
      <div className="text-center mb-6">
        <motion.div
          className="text-4xl md:text-6xl font-bold text-white mb-2"
          animate={{ 
            textShadow: isPlaying 
              ? "0 0 20px rgba(34, 211, 238, 0.6)" 
              : "0 0 10px rgba(255, 255, 255, 0.3)"
          }}
          transition={{ duration: 0.3 }}
        >
          {frequency.toFixed(2)}
        </motion.div>
        <div className="text-xl md:text-3xl font-semibold text-gray-400">Hz</div>
      </div>

      {/* Frequency Slider */}
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-400 mb-2">
          <span>1Hz</span>
          <span>22000Hz</span>
        </div>
        <div className="relative">
          <input
            type="range"
            min="1"
            max="22000"
            step="0.01"
            value={frequency}
            onChange={handleSliderChange}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer frequency-slider"
          />
          <style>{`
            .frequency-slider::-webkit-slider-thumb {
              appearance: none;
              width: 20px;
              height: 20px;
              background: linear-gradient(45deg, #8b5cf6, #06b6d4);
              border-radius: 50%;
              cursor: pointer;
              box-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
            }
            .frequency-slider::-moz-range-thumb {
              width: 20px;
              height: 20px;
              background: linear-gradient(45deg, #8b5cf6, #06b6d4);
              border-radius: 50%;
              cursor: pointer;
              border: none;
              box-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
            }
          `}</style>
        </div>
      </div>

      {/* Multiplier Controls */}
      <div className="mb-4">
        <h4 className="text-sm font-semibold text-gray-300 mb-3 text-center">Step Size</h4>
        <div className="flex flex-wrap justify-center gap-2">
          <button
            onClick={() => setMultiplier(0.1)}
            className={`px-2 md:px-3 py-1 md:py-2 rounded-lg text-xs md:text-sm font-medium transition-all ${
              multiplier === 0.1 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            0.1 Hz
          </button>
          <button
            onClick={() => setMultiplier(1)}
            className={`px-2 md:px-3 py-1 md:py-2 rounded-lg text-xs md:text-sm font-medium transition-all ${
              multiplier === 1 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            1 Hz
          </button>
          <button
            onClick={() => setMultiplier(10)}
            className={`px-2 md:px-3 py-1 md:py-2 rounded-lg text-xs md:text-sm font-medium transition-all ${
              multiplier === 10 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            10 Hz
          </button>
          <button
            onClick={() => setMultiplier(100)}
            className={`px-2 md:px-3 py-1 md:py-2 rounded-lg text-xs md:text-sm font-medium transition-all ${
              multiplier === 100 
                ? 'bg-purple-600 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            100 Hz
          </button>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="flex justify-center items-center space-x-4 mb-6">
        <motion.button
          onClick={() => adjustFrequency(-1)}
          className="p-3 bg-gray-700 rounded-full hover:bg-gray-600 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Minus size={20} />
        </motion.button>

        {/* Play/Pause Button */}
        <motion.button
          onClick={togglePlayback}
          className={`p-4 rounded-full transition-all ${
            isPlaying 
              ? 'bg-purple-600 hover:bg-purple-700' 
              : 'bg-purple-500 hover:bg-purple-600'
          }`}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          animate={{ 
            boxShadow: isPlaying 
              ? "0 0 20px rgba(139, 92, 246, 0.6)" 
              : "0 0 10px rgba(139, 92, 246, 0.3)"
          }}
        >
          {isPlaying ? <Pause size={24} /> : <Play size={24} />}
        </motion.button>

        <motion.button
          onClick={() => adjustFrequency(1)}
          className="p-3 bg-gray-700 rounded-full hover:bg-gray-600 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Plus size={20} />
        </motion.button>

        <motion.button
          onClick={resetToDefault}
          className="p-3 bg-gray-700 rounded-full hover:bg-gray-600 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <RotateCcw size={20} />
        </motion.button>
      </div>

      {/* Volume Control */}
      <div className="flex items-center space-x-3 mb-6">
        <Volume2 size={20} className="text-gray-400" />
        <input
          type="range"
          min="0"
          max="100"
          value={volume}
          onChange={(e) => {
            const newVolume = parseInt(e.target.value);
            setVolume(newVolume);
            if (gainNode && audioContext) {
              gainNode.gain.linearRampToValueAtTime(newVolume / 100 * 0.3, audioContext.currentTime + 0.1);
            }
          }}
          className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
        />
        <span className="text-sm text-gray-400 w-10">{volume}%</span>
      </div>

      {/* Waveform Selection */}
      <div className="mb-6">
        <h4 className="text-sm font-semibold text-gray-300 mb-3 text-center">Waveform</h4>
        <div className="flex flex-wrap justify-center gap-2">
          {(['sine', 'square', 'sawtooth', 'triangle'] as const).map((wave) => (
            <motion.button
              key={wave}
              onClick={() => setWaveform(wave)}
              className={`px-2 md:px-3 py-1 md:py-2 rounded-lg text-xs font-medium transition-all ${
                waveform === wave
                  ? 'bg-cyan-600 text-white shadow-lg'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {wave.charAt(0).toUpperCase() + wave.slice(1)}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Theta Vibration Control */}
      <div className="mb-6">
        <div className="flex items-center justify-center space-x-3">
          <motion.button
            onClick={() => {
              // Test vibration immediately on click
              if (!enableVibration && navigator.vibrate) {
                console.log("🔧 Testing vibration on enable...");
                const testResult = navigator.vibrate(200);
                console.log(`📳 Vibration test result: ${testResult}`);
              }
              
              setEnableVibration(!enableVibration);
              
              // If turning on and playing, start vibration
              if (!enableVibration && isPlaying && frequency <= 10) {
                const patternName = frequency <= 4 ? 'deep' : 
                                  frequency <= 6 ? 'rem' : 
                                  frequency <= 8 ? 'earth' : 'meditation';
                startThetaVibration(patternName);
              }
              
              // If turning off, always stop vibration regardless of state
              if (enableVibration) {
                console.log("🔇 Vibration disabled - stopping all vibration");
                stopVibration();
              }
            }}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
              enableVibration
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-700 text-gray-400'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Vibrate size={18} className={isVibrating ? 'animate-pulse' : ''} />
            <span className="text-sm font-medium">
              {enableVibration ? 'Vibration ON' : 'Vibration OFF'}
            </span>
          </motion.button>
          {frequency <= 10 && enableVibration && (
            <div className="flex items-center space-x-2">
              <span className="text-xs text-indigo-400">
                {frequency <= 4 ? 'Deep Meditation' :
                 frequency <= 6 ? 'REM Sleep' :
                 frequency <= 8 ? 'Earth Resonance' : 'Meditation'}
              </span>
              {isVibrating && (
                <span className="text-xs text-green-400 animate-pulse">●</span>
              )}
            </div>
          )}
        </div>
        {frequency > 10 && enableVibration && (
          <p className="text-xs text-gray-500 text-center mt-2">
            Vibration works best with theta waves (4-8 Hz)
          </p>
        )}
        
        {/* Vibration Test Controls */}
        <div className="mt-2 text-center space-y-2">
          {/* Manual Theta Pattern Test */}
          {frequency <= 10 && (
            <button
              onClick={() => {
                if (!isVibrating) {
                  const patternName = frequency <= 4 ? 'deep' : 
                                    frequency <= 6 ? 'rem' : 
                                    frequency <= 8 ? 'earth' : 'meditation';
                  console.log(`🎯 Manual theta vibration test: ${patternName}`);
                  startThetaVibration(patternName, 5000); // 5 second test
                } else {
                  stopVibration();
                }
              }}
              className="text-xs text-purple-400 hover:text-purple-300 underline mr-2"
            >
              {isVibrating ? 'Stop Theta Pattern' : 'Test Theta Pattern'}
            </button>
          )}
          
          <button
            onClick={() => {
              if ('vibrate' in navigator) {
                console.log("🧪 Testing direct vibration...");
                
                // Test single vibration
                const result1 = navigator.vibrate(200);
                console.log(`📳 Single vibration (200ms): ${result1 ? 'Success' : 'Failed'}`);
                
                // Test pattern after delay
                setTimeout(() => {
                  const result2 = navigator.vibrate([100, 50, 100, 50, 100]);
                  console.log(`📳 Pattern vibration: ${result2 ? 'Success' : 'Failed'}`);
                }, 1000);
                
                // Check browser/device info
                console.log(`📱 User Agent: ${navigator.userAgent}`);
                console.log(`🔐 Protocol: ${window.location.protocol}`);
                console.log(`🌐 Hostname: ${window.location.hostname}`);
                
                // Show user feedback
                const message = result1 
                  ? "Vibration test initiated! Check console for details." 
                  : "Vibration failed. This may be due to:\n- Device doesn't support vibration\n- Browser settings blocking vibration\n- Not running over HTTPS\n- User interaction required";
                  
                alert(message);
              } else {
                console.error("❌ Vibration API not available");
                alert("Vibration API is not supported on this device/browser.\n\nSupported on:\n- Android Chrome/Firefox\n- Some mobile browsers\n\nNot supported on:\n- iOS devices\n- Desktop browsers");
              }
            }}
            className="text-xs text-cyan-400 hover:text-cyan-300 underline"
          >
            Test Vibration
          </button>
          <div className="text-xs text-gray-500 mt-1">
            Vibration API Status: {('vibrate' in navigator) ? '✅ Available' : '❌ Not Available'}
          </div>
        </div>
      </div>

      {/* Frequency Presets */}
      <div className="mt-6">
        <div className="flex items-center justify-center mb-4">
          <div className="flex bg-gray-800 rounded-lg p-1">
            <button
              onClick={() => {
                setPresetCategory('healing');
                setSelectedPreset(null);
              }}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                presetCategory === 'healing'
                  ? 'bg-cyan-600 text-white'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              Healing
            </button>
            <button
              onClick={() => {
                setPresetCategory('vibration');
                setSelectedPreset(null);
              }}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                presetCategory === 'vibration'
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              Vibration
            </button>
          </div>
        </div>
        
        <h4 className="text-sm font-semibold text-gray-300 mb-3 text-center">
          {presetCategory === 'healing' ? 'Healing Frequencies' : 'Vibration Frequencies'}
        </h4>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
          {getCurrentPresets().map((preset) => (
            <motion.button
              key={preset.name}
              onClick={() => selectPreset(preset)}
              className={`p-2 md:p-3 rounded-lg text-xs font-medium transition-all ${
                selectedPreset === preset.name
                  ? `bg-gradient-to-r ${preset.color} text-white shadow-lg`
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="font-bold text-xs">{preset.name}</div>
              <div className="text-xs opacity-80">{preset.frequency}Hz</div>
              <div className="text-xs opacity-60 mt-1 hidden sm:block">{preset.description}</div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Frequency Info */}
      <div className="mt-4 text-center">
        <div className="text-xs text-gray-500">
          {selectedPreset && (
            <span className="text-cyan-400 font-medium">
              {getCurrentPresets().find(p => p.name === selectedPreset)?.description}
            </span>
          )}
        </div>
        {/* Debug info for presets */}
        <div className="text-xs text-gray-600 mt-2">
          Current: {frequency}Hz | Selected: {selectedPreset || 'None'} | Category: {presetCategory}
        </div>
      </div>
    </motion.div>
  );
}