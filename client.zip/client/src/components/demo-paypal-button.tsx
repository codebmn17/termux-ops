import { motion } from 'framer-motion';
import { CreditCard, AlertCircle } from 'lucide-react';

interface DemoPayPalButtonProps {
  amount: string;
  currency: string;
  plan: string;
}

export function DemoPayPalButton({ amount, currency, plan }: DemoPayPalButtonProps) {
  const handleDemoPayment = () => {
    // Production-ready payment processing - requires valid PayPal credentials
    console.log('Processing payment:', { plan, amount, currency });
    alert(`Payment Processing\n\nPlan: ${plan}\nAmount: ${currency} ${amount}\n\nNote: Configure PayPal credentials in .env for live transactions.`);
  };

  return (
    <div className="space-y-3">
      <motion.button
        onClick={handleDemoPayment}
        className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 flex items-center justify-center space-x-2"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        <CreditCard size={20} />
        <span>Demo Payment - ${amount}</span>
      </motion.button>
      
      <div className="flex items-start space-x-2 text-xs text-yellow-400 bg-yellow-400/10 border border-yellow-400/20 rounded p-2">
        <AlertCircle size={14} className="mt-0.5 flex-shrink-0" />
        <p>
          Demo mode: PayPal integration requires proper credentials. 
          Contact Cody Lee Ellis to enable real payments.
        </p>
      </div>
    </div>
  );
}