import { useCallback } from 'react';

interface ParticleSystemProps {
  containerRef: React.RefObject<HTMLDivElement>;
}

export function ParticleSystem({ containerRef }: ParticleSystemProps) {
  const createParticleBurst = useCallback((centerX: number, centerY: number) => {
    const container = containerRef.current;
    if (!container) return;

    const particleCount = 12;
    
    for (let i = 0; i < particleCount; i++) {
      setTimeout(() => {
        const particle = document.createElement('div');
        particle.className = 'particle animate-particle-float';
        
        // Random position around center point
        const angle = (i / particleCount) * 2 * Math.PI;
        const distance = 30 + Math.random() * 40;
        const x = centerX + Math.cos(angle) * distance;
        const y = centerY + Math.sin(angle) * distance;
        
        particle.style.left = x + 'px';
        particle.style.top = y + 'px';
        particle.style.animationDelay = Math.random() * 0.5 + 's';
        
        container.appendChild(particle);
        
        // Remove particle after animation
        setTimeout(() => {
          if (particle.parentNode) {
            particle.parentNode.removeChild(particle);
          }
        }, 4000);
      }, i * 50);
    }
  }, [containerRef]);

  return { createParticleBurst };
}
