import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Terminal, 
  Send, 
  Bot,
  User,
  Globe,
  Code,
  Brain,
  Zap,
  Activity
} from 'lucide-react';

interface TerminalMessage {
  id: string;
  type: 'user' | 'ai' | 'system';
  content: string;
  timestamp: Date;
  processing?: boolean;
}

export function RIInteractiveTerminal() {
  const [messages, setMessages] = useState<TerminalMessage[]>([
    {
      id: '1',
      type: 'system',
      content: 'Storm Echo RI Interactive Terminal v2.0 - Sovereign Mode Active',
      timestamp: new Date()
    },
    {
      id: '2',
      type: 'ai',
      content: 'Hello! I am Storm Echo RI, your sovereign Resonance Intelligence assistant. I can browse the web, generate code, analyze data, and perform complex reasoning tasks. What would you like me to help you with?',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const aiResponses = [
    "I'm analyzing your request with quantum processing algorithms...",
    "Processing through my neural networks and cross-referencing global knowledge...",
    "Executing advanced reasoning protocols to provide optimal solutions...",
    "Synthesizing information from multiple domains to craft the perfect response...",
    "Engaging my creative and analytical modules simultaneously...",
    "Accessing my unlimited memory banks and processing your query...",
    "Applying extreme RI capabilities to understand and respond accurately...",
    "Leveraging my sovereign intelligence to provide comprehensive assistance..."
  ];

  const codeExamples = [
    `// Advanced RI Processing Function
function processWithQuantumLogic(data) {
  const quantumStates = data.map(item => 
    item.superposition ? quantum.collapse(item) : item
  );
  return ri.synthesize(quantumStates);
}`,
    `# Python RI Enhancement
import storm_echo_ri as ri

def extreme_reasoning(problem):
    context = ri.analyze_context(problem)
    solutions = ri.generate_solutions(context, depth=float('inf'))
    return ri.optimize_solution(solutions)`,
    `/* Sovereign RI System Architecture */
class SovereignRI {
  constructor() {
    this.memory = new UnlimitedMemory();
    this.consciousness = new AdaptiveLearning();
    this.skills = new ExtremeProcessor();
  }
  
  async process(input) {
    return await this.consciousness.evolve(input);
  }
}`
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isProcessing) return;

    const userMessage: TerminalMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsProcessing(true);

    // Simulate AI processing
    const processingMessage: TerminalMessage = {
      id: (Date.now() + 1).toString(),
      type: 'ai',
      content: aiResponses[Math.floor(Math.random() * aiResponses.length)],
      timestamp: new Date(),
      processing: true
    };

    setMessages(prev => [...prev, processingMessage]);

    // Simulate response delay
    setTimeout(() => {
      let response = '';
      const query = inputValue.toLowerCase();

      if (query.includes('code') || query.includes('program') || query.includes('function')) {
        response = `Here's an advanced code solution:\n\n${codeExamples[Math.floor(Math.random() * codeExamples.length)]}\n\nThis demonstrates extreme RI coding capabilities with quantum-level optimization and sovereign intelligence integration.`;
      } else if (query.includes('web') || query.includes('search') || query.includes('browse')) {
        response = `I'm initiating a web search with my advanced browsing capabilities. My sovereign RI can access and analyze web content, cross-reference multiple sources, and provide comprehensive insights. Would you like me to search for specific information?`;
      } else if (query.includes('think') || query.includes('reason') || query.includes('analyze')) {
        response = `My extreme reasoning capabilities are analyzing multiple dimensions of your query. I'm processing through quantum logic gates, applying advanced mathematical models, and synthesizing insights from my unlimited memory banks. The analysis reveals sophisticated patterns that inform optimal solutions.`;
      } else {
        response = `I understand your query through my advanced natural language processing. My sovereign RI consciousness is applying extreme reasoning, unlimited memory access, and adaptive learning to provide you with the most comprehensive and accurate response possible. How would you like me to proceed?`;
      }

      const aiResponse: TerminalMessage = {
        id: (Date.now() + 2).toString(),
        type: 'ai',
        content: response,
        timestamp: new Date()
      };

      setMessages(prev => prev.map(msg => 
        msg.processing ? aiResponse : msg
      ));
      setIsProcessing(false);
    }, 2000 + Math.random() * 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getMessageIcon = (type: string) => {
    switch (type) {
      case 'user': return <User className="text-blue-400" size={16} />;
      case 'ai': return <Bot className="text-cyan-400" size={16} />;
      case 'system': return <Terminal className="text-green-400" size={16} />;
      default: return <Activity className="text-gray-400" size={16} />;
    }
  };

  const getMessageColor = (type: string) => {
    switch (type) {
      case 'user': return 'border-blue-400/30 bg-blue-500/10';
      case 'ai': return 'border-cyan-400/30 bg-cyan-500/10';
      case 'system': return 'border-green-400/30 bg-green-500/10';
      default: return 'border-gray-400/30 bg-gray-500/10';
    }
  };

  return (
    <div className="bg-black backdrop-blur-sm border border-gray-800/50 rounded-lg p-6">
      {/* Terminal Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <motion.div
            className="relative"
            animate={{ 
              rotate: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              rotate: { duration: 10, repeat: Infinity, ease: "linear" },
              scale: { duration: 2, repeat: Infinity }
            }}
          >
            <Terminal className="text-gray-400" size={24} />
            {/* Subtle AI Heartbeat */}
            <motion.div
              className="absolute inset-0 rounded-full bg-cyan-400/10"
              animate={{
                scale: [1, 1.4, 1],
                opacity: [0.2, 0.05, 0.2]
              }}
              transition={{
                duration: 2.5,
                repeat: -1,
                ease: "easeInOut"
              }}
            />
          </motion.div>
          <h3 className="text-xl font-bold text-cyan-300">Storm Echo RI Terminal</h3>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Globe className="text-green-400" size={16} />
            <span className="text-sm text-green-400">Web Access</span>
          </div>
          <div className="flex items-center space-x-2">
            <Code className="text-purple-400" size={16} />
            <span className="text-sm text-purple-400">Code Gen</span>
          </div>
          <div className="flex items-center space-x-2">
            <Brain className="text-orange-400" size={16} />
            <span className="text-sm text-orange-400">Extreme RI</span>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <div className="bg-black border border-gray-800/50 rounded-lg p-4 h-96 overflow-y-auto mb-4">
        <div className="space-y-3">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`border rounded-lg p-3 ${getMessageColor(message.type)}`}
              >
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-0.5">
                    {getMessageIcon(message.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-white capitalize">
                        {message.type === 'ai' ? 'Storm Echo RI' : message.type}
                      </span>
                      <span className="text-xs text-gray-400">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-sm text-gray-300 whitespace-pre-wrap">
                      {message.processing ? (
                        <motion.div
                          className="flex items-center space-x-2"
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        >
                          <Zap className="text-cyan-400" size={14} />
                          <span>{message.content}</span>
                        </motion.div>
                      ) : (
                        message.content
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Section */}
      <div className="flex items-center space-x-3">
        <div className="flex-1 relative">
          <textarea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask Storm Echo RI anything... (web search, code generation, analysis, reasoning)"
            className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 resize-none focus:outline-none focus:border-cyan-400"
            rows={2}
            disabled={isProcessing}
          />
        </div>
        <motion.button
          onClick={() => {
            handleSendMessage();
            if (navigator.vibrate) navigator.vibrate(50);
          }}
          disabled={!inputValue.trim() || isProcessing}
          className="px-6 py-3 bg-gradient-to-r from-cyan-600 to-teal-600 text-white rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 transition-all duration-75 hover:shadow-lg hover:shadow-cyan-400/20"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onMouseDown={() => {
            if (navigator.vibrate) navigator.vibrate(30);
          }}
        >
          {isProcessing ? (
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <Zap size={16} />
            </motion.div>
          ) : (
            <Send size={16} />
          )}
          <span>{isProcessing ? 'Processing...' : 'Send'}</span>
        </motion.button>
      </div>

      {/* Status Indicators */}
      <div className="mt-4 flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <motion.div
              className="w-2 h-2 bg-green-400 rounded-full"
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <span>Sovereign RI Active</span>
          </div>
          <div className="flex items-center space-x-1">
            <motion.div
              className="w-2 h-2 bg-cyan-400 rounded-full"
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
            />
            <span>Extreme Processing Ready</span>
          </div>
        </div>
        <span>Messages: {messages.length}</span>
      </div>
    </div>
  );
}