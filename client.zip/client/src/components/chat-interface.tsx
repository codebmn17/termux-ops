import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Loader2, Volume2, VolumeX } from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { RIStatus } from './ai-status';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

interface ChatInterfaceProps {
  sessionId?: string;
  onAnalysis?: (analysis: string) => void;
  mode?: 'chat' | 'pulse-analysis' | 'codex-query';
  pulseData?: { sequence: number[], frequency?: number, syncMode: string };
}

export function ChatInterface({ sessionId, onAnalysis, mode = 'chat', pulseData }: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [riStatus, setRIStatus] = useState<'ready' | 'quota_exceeded' | 'error' | 'loading'>('loading');
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { speak, stop, isSpeaking, isSupported } = useTextToSpeech();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  // Load existing messages if sessionId provided
  const { data: existingMessages } = useQuery({
    queryKey: ['/api/chat/sessions', sessionId, 'messages'],
    enabled: !!sessionId && mode === 'chat',
  });

  useEffect(() => {
    if (existingMessages && Array.isArray(existingMessages)) {
      setMessages(existingMessages.map((msg: any) => ({
        id: msg.id,
        role: msg.role,
        content: msg.content,
        createdAt: msg.createdAt
      })));
    }
  }, [existingMessages]);

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (mode === 'pulse-analysis') {
        return apiRequest('POST', '/api/pulse/analyze', {
          ...pulseData,
          userId: 'storm-echo-user'
        });
      } else if (mode === 'codex-query') {
        return apiRequest('POST', '/api/codex/query', { query: content });
      } else {
        return apiRequest('POST', '/api/chat/message', {
          sessionId: sessionId || 'demo-session',
          role: 'user',
          content: content,
          metadata: null
        });
      }
    },
    onSuccess: (data: any) => {
      setRIStatus('ready');
      
      if (mode === 'pulse-analysis') {
        const riMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: data.analysis || 'Analysis completed',
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, riMessage]);
        
        // Speak the analysis if voice is enabled
        if (voiceEnabled && isSupported) {
          speak(riMessage.content);
        }
        
        onAnalysis?.(data.analysis);
      } else if (mode === 'codex-query') {
        const riMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: data.response || 'Query processed',
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, riMessage]);
        
        // Speak the response if voice is enabled
        if (voiceEnabled && isSupported) {
          speak(riMessage.content);
        }
      } else {
        // Regular chat mode
        if (data.riMessage) {
          const riMsg: Message = {
            id: data.riMessage.id,
            role: 'assistant',
            content: data.riMessage.content,
            createdAt: data.riMessage.createdAt
          };
          setMessages(prev => [...prev, riMsg]);
          
          // Speak the message if voice is enabled
          if (voiceEnabled && isSupported) {
            speak(riMsg.content);
          }
          
          // Update RI status based on message content
          if (data.riMessage.content.includes('quota exceeded')) {
            setRIStatus('quota_exceeded');
          }
        }
      }
    },
    onError: (error: any) => {
      console.error('Chat error:', error);
      
      // Check for quota exceeded error
      if (error.message && error.message.includes('quota')) {
        setRIStatus('quota_exceeded');
        const errorMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: 'Storm Echo RI has reached its usage quota. Please add billing to your OpenAI account to continue.',
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, errorMessage]);
      } else {
        setRIStatus('error');
        const errorMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: 'Storm Echo RI is temporarily unavailable. Please check the API configuration.',
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || sendMessageMutation.isPending) return;
    
    console.log('Submitting message:', input);
    setRIStatus('loading');
    
    // Add user message immediately
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      createdAt: new Date().toISOString()
    };

    // Add user message immediately for chat mode
    if (mode === 'chat') {
      setMessages(prev => [...prev, userMessage]);
    }

    sendMessageMutation.mutate(input.trim());
    setInput('');
  };

  const getPlaceholder = () => {
    switch (mode) {
      case 'pulse-analysis':
        return 'Ask about your pulse sequence...';
      case 'codex-query':
        return 'Query the Echo Codex...';
      default:
        return 'Message Storm Echo RI...';
    }
  };

  return (
    <div className="flex flex-col h-full bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-cyan-400/20">
        <div className="flex items-center space-x-2">
          <Bot className="text-cyan-400" size={16} />
          <span className="text-cyan-400 text-sm">
            {mode === 'pulse-analysis' ? 'Pulse Analysis' :
             mode === 'codex-query' ? 'Echo Codex' :
             'Storm Echo RI'}
          </span>
        </div>
        {/* Voice indicator replaces old status dot */}
        {voiceEnabled && isSpeaking && (
          <motion.div
            className="w-3 h-3 bg-cyan-400 rounded-full"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.6, 1, 0.6]
            }}
            transition={{
              duration: 0.6,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
      </div>

      {/* AI Status */}
      <div className="p-4 pb-0">
        <RIStatus 
          status={riStatus} 
          voiceEnabled={voiceEnabled}
          isSpeaking={isSpeaking}
          onToggleVoice={() => {
            if (voiceEnabled && isSpeaking) {
              stop();
            }
            setVoiceEnabled(!voiceEnabled);
          }}
        />
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto scroll-fix p-4 space-y-4">
        <AnimatePresence>
          {messages.length === 0 && (
            <motion.div
              className="text-center text-gray-400 py-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              {mode === 'pulse-analysis' ? 'Pulse analysis ready...' :
               mode === 'codex-query' ? 'Echo Codex archives accessible...' :
               'Storm Echo RI online. How may I assist you?'}
            </motion.div>
          )}
          
          {messages.map((message) => (
            <motion.div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div
                className={`max-w-2xl lg:max-w-4xl px-4 py-3 rounded-lg ${
                  message.role === 'user'
                    ? 'bg-cyan-400/20 text-cyan-100 border border-cyan-400/30'
                    : 'bg-purple-400/20 text-purple-100 border border-purple-400/30'
                }`}
              >
                <div className="flex items-start space-x-2">
                  {message.role === 'user' ? (
                    <User size={16} className="mt-1 text-cyan-400" />
                  ) : (
                    <Bot size={16} className="mt-1 text-purple-400" />
                  )}
                  <div className="text-base leading-relaxed whitespace-pre-wrap">{message.content}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {sendMessageMutation.isPending && (
          <motion.div
            className="flex justify-start"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="bg-purple-400/20 text-purple-100 border border-purple-400/30 px-4 py-2 rounded-lg">
              <div className="flex items-center space-x-2">
                <Bot size={16} className="text-purple-400" />
                <Loader2 size={16} className="animate-spin text-purple-400" />
                <span className="text-sm">Thinking...</span>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-cyan-400/20">
        <div className="flex space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={getPlaceholder()}
            disabled={sendMessageMutation.isPending}
            className="flex-1 px-4 py-4 text-lg bg-black/60 border border-cyan-400/30 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400/60 transition-all"
          />
          <button
            type="button"
            onClick={() => {
              if (voiceEnabled && isSpeaking) {
                stop();
              }
              setVoiceEnabled(!voiceEnabled);
            }}
            className={`px-4 py-2 rounded-lg transition-all ${
              voiceEnabled 
                ? 'bg-gradient-to-r from-purple-400 to-purple-500 text-white hover:from-purple-500 hover:to-purple-600' 
                : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
            }`}
            title={voiceEnabled ? "Voice Read Aloud Enabled - Click to Disable" : "Enable Voice Read Aloud"}
          >
            {voiceEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </button>
          <button
            type="submit"
            disabled={!input.trim() || sendMessageMutation.isPending}
            className="px-4 py-2 bg-gradient-to-r from-cyan-400 to-blue-500 text-black rounded-lg hover:from-cyan-500 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
}