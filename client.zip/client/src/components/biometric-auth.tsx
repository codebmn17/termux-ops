import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Fingerprint, Lock, Shield, AlertTriangle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { biometricAuth, BiometricAuthResult } from '@/lib/webauthn';
import { useToast } from '@/hooks/use-toast';

interface BiometricAuthProps {
  userId: string;
  purpose: 'admin' | 'killswitch' | 'settings';
  onAuthenticated: () => void;
  onCancel?: () => void;
  title?: string;
  description?: string;
}

export function BiometricAuth({ 
  userId, 
  purpose, 
  onAuthenticated, 
  onCancel,
  title = "Biometric Authentication",
  description = "Use your fingerprint to verify your identity"
}: BiometricAuthProps) {
  const [isSupported, setIsSupported] = useState(false);
  const [hasCredentials, setHasCredentials] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [showPasscodeFallback, setShowPasscodeFallback] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [lockoutTime, setLockoutTime] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    checkBiometricSupport();
    checkLockoutStatus();
    
    // Update lockout timer every second
    const timer = setInterval(checkLockoutStatus, 1000);
    return () => clearInterval(timer);
  }, []);

  const checkBiometricSupport = async () => {
    const supported = biometricAuth.isWebAuthnSupported();
    const platformAuth = await biometricAuth.isPlatformAuthenticatorAvailable();
    const credentials = await biometricAuth.hasRegisteredCredentials(userId);
    
    setIsSupported(supported && platformAuth);
    setHasCredentials(credentials);
    
    // If no biometric support or credentials, show passcode fallback
    if (!supported || !platformAuth || !credentials) {
      setShowPasscodeFallback(true);
    }
  };

  const checkLockoutStatus = () => {
    if (biometricAuth.isLockedOut()) {
      setLockoutTime(biometricAuth.getRemainingLockoutTime());
    } else {
      setLockoutTime(0);
    }
  };

  const handleBiometricAuth = async () => {
    if (lockoutTime > 0) {
      toast({
        title: "Access Locked",
        description: `Please wait ${lockoutTime} more minutes`,
        variant: "destructive"
      });
      return;
    }

    setIsAuthenticating(true);
    
    try {
      const result: BiometricAuthResult = await biometricAuth.authenticateBiometric(userId, purpose);
      
      if (result.success) {
        toast({
          title: "Authentication Successful",
          description: "Biometric verification completed",
          className: "bg-green-900/90 border-green-500"
        });
        onAuthenticated();
      } else {
        toast({
          title: "Authentication Failed",
          description: result.error || "Biometric verification failed",
          variant: "destructive"
        });
        
        if (result.fallbackToPasscode) {
          setShowPasscodeFallback(true);
        }
      }
    } catch (error) {
      toast({
        title: "Authentication Error",
        description: "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleRegisterBiometric = async () => {
    setIsRegistering(true);
    
    try {
      const result: BiometricAuthResult = await biometricAuth.registerBiometric(userId);
      
      if (result.success) {
        toast({
          title: "Registration Successful",
          description: "Biometric authentication is now enabled",
          className: "bg-green-900/90 border-green-500"
        });
        setHasCredentials(true);
        setShowPasscodeFallback(false);
      } else {
        toast({
          title: "Registration Failed",
          description: result.error || "Failed to register biometric authentication",
          variant: "destructive"
        });
        
        if (result.fallbackToPasscode) {
          setShowPasscodeFallback(true);
        }
      }
    } catch (error) {
      toast({
        title: "Registration Error",
        description: "An unexpected error occurred during registration",
        variant: "destructive"
      });
    } finally {
      setIsRegistering(false);
    }
  };

  const handlePasscodeAuth = () => {
    // Simple passcode verification for fallback
    const adminPasscode = "StormEcho2025!";
    const killswitchPasscode = "phantom protocol shutdown immediate";
    
    let expectedPasscode = adminPasscode;
    if (purpose === 'killswitch') {
      expectedPasscode = killswitchPasscode;
    }
    
    if (passcode === expectedPasscode) {
      toast({
        title: "Authentication Successful",
        description: "Passcode verification completed",
        className: "bg-green-900/90 border-green-500"
      });
      onAuthenticated();
    } else {
      toast({
        title: "Invalid Passcode",
        description: "The entered passcode is incorrect",
        variant: "destructive"
      });
    }
  };

  const getPurposeIcon = () => {
    switch (purpose) {
      case 'admin':
        return <Shield className="w-6 h-6 text-blue-400" />;
      case 'killswitch':
        return <AlertTriangle className="w-6 h-6 text-red-400" />;
      case 'settings':
        return <Lock className="w-6 h-6 text-purple-400" />;
      default:
        return <Fingerprint className="w-6 h-6 text-cyan-400" />;
    }
  };

  const getPurposeColor = () => {
    switch (purpose) {
      case 'admin':
        return 'border-blue-500/30';
      case 'killswitch':
        return 'border-red-500/30';
      case 'settings':
        return 'border-purple-500/30';
      default:
        return 'border-cyan-500/30';
    }
  };

  if (lockoutTime > 0) {
    return (
      <Card className={`w-full max-w-md bg-black/60 backdrop-blur-md ${getPurposeColor()}`}>
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Clock className="w-12 h-12 text-red-400" />
          </div>
          <CardTitle className="text-xl text-red-400">Access Locked</CardTitle>
          <CardDescription className="text-gray-400">
            Too many failed attempts. Please wait {lockoutTime} minutes.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <p className="text-sm text-gray-500">
              The portal will automatically unlock when the lockout period expires.
            </p>
            {onCancel && (
              <Button 
                onClick={onCancel}
                variant="outline"
                className="mt-4 bg-gray-700/20 hover:bg-gray-700/30 text-gray-300 border-gray-600"
              >
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`w-full max-w-md bg-black/60 backdrop-blur-md ${getPurposeColor()}`}>
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          {getPurposeIcon()}
        </div>
        <CardTitle className="text-xl text-cyan-300">{title}</CardTitle>
        <CardDescription className="text-gray-400">
          {description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <AnimatePresence mode="wait">
          {isSupported && hasCredentials && !showPasscodeFallback ? (
            <motion.div
              key="biometric"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <div className="text-center">
                <motion.div
                  animate={isAuthenticating ? { scale: [1, 1.1, 1] } : {}}
                  transition={{ duration: 1, repeat: isAuthenticating ? Infinity : 0 }}
                  className="inline-flex p-4 rounded-full bg-cyan-500/10 border border-cyan-500/30 mb-4"
                >
                  <Fingerprint 
                    className={`w-8 h-8 ${isAuthenticating ? 'text-cyan-300' : 'text-cyan-400'}`} 
                  />
                </motion.div>
                <p className="text-sm text-gray-300 mb-4">
                  {isAuthenticating ? 'Scanning...' : 'Tap to authenticate with your fingerprint'}
                </p>
              </div>
              
              <Button
                onClick={handleBiometricAuth}
                disabled={isAuthenticating}
                className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30"
              >
                {isAuthenticating ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <Fingerprint className="w-5 h-5 mr-2" />
                  </motion.div>
                ) : (
                  <Fingerprint className="w-5 h-5 mr-2" />
                )}
                {isAuthenticating ? 'Authenticating...' : 'Tap to Unlock'}
              </Button>
              
              <Button
                onClick={() => setShowPasscodeFallback(true)}
                variant="outline"
                className="w-full bg-gray-700/20 hover:bg-gray-700/30 text-gray-300 border-gray-600"
              >
                Use Passcode Instead
              </Button>
            </motion.div>
          ) : isSupported && !hasCredentials && !showPasscodeFallback ? (
            <motion.div
              key="register"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <Alert className="bg-blue-500/10 border-blue-500/30">
                <Fingerprint className="h-4 w-4" />
                <AlertDescription className="text-blue-300">
                  No biometric credentials found. Register your fingerprint for secure access.
                </AlertDescription>
              </Alert>
              
              <Button
                onClick={handleRegisterBiometric}
                disabled={isRegistering}
                className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30"
              >
                {isRegistering ? 'Registering...' : 'Register Fingerprint'}
              </Button>
              
              <Button
                onClick={() => setShowPasscodeFallback(true)}
                variant="outline"
                className="w-full bg-gray-700/20 hover:bg-gray-700/30 text-gray-300 border-gray-600"
              >
                Use Passcode Instead
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="passcode"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <Alert className="bg-yellow-500/10 border-yellow-500/30">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-yellow-300">
                  {!isSupported 
                    ? "Biometric authentication not supported on this device."
                    : "Using passcode fallback authentication."
                  }
                </AlertDescription>
              </Alert>
              
              <div>
                <label className="text-sm text-gray-300 mb-2 block">
                  {purpose === 'killswitch' ? 'Kill Switch Phrase' : 'Admin Passcode'}
                </label>
                <Input
                  type="password"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder={purpose === 'killswitch' ? 'Enter kill switch phrase' : 'Enter admin passcode'}
                  className="bg-black/40 border-gray-600 text-white"
                  onKeyPress={(e) => e.key === 'Enter' && handlePasscodeAuth()}
                />
              </div>
              
              <Button
                onClick={handlePasscodeAuth}
                disabled={!passcode.trim()}
                className="w-full bg-gray-600/20 hover:bg-gray-600/30 text-gray-300 border border-gray-600"
              >
                <Lock className="w-5 h-5 mr-2" />
                Authenticate
              </Button>
              
              {isSupported && (
                <Button
                  onClick={() => setShowPasscodeFallback(false)}
                  variant="outline"
                  className="w-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border-cyan-500/30"
                >
                  Try Biometric Again
                </Button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
        
        {onCancel && (
          <Button 
            onClick={onCancel}
            variant="outline"
            className="w-full bg-gray-700/20 hover:bg-gray-700/30 text-gray-300 border-gray-600"
          >
            Cancel
          </Button>
        )}
      </CardContent>
    </Card>
  );
}