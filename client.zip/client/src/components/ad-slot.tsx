import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

interface AdSlotProps {
  position: 'top' | 'bottom' | 'sidebar' | 'banner';
  size?: 'small' | 'medium' | 'large';
  className?: string;
}

export function AdSlot({ position, size = 'medium', className = '' }: AdSlotProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if ads are enabled via environment variable
    const adsEnabled = import.meta.env.VITE_ADS_ENABLED === 'true';
    setIsVisible(adsEnabled);
  }, []);

  if (!isVisible) {
    return null;
  }

  const sizeClasses = {
    small: 'w-64 h-16',
    medium: 'w-80 h-24', 
    large: 'w-96 h-32'
  };

  const positionClasses = {
    top: 'fixed top-4 right-4 z-50',
    bottom: 'fixed bottom-4 right-4 z-50',
    sidebar: 'sticky top-4',
    banner: 'w-full'
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} ${positionClasses[position]} ${className} border border-cyan-400/20 bg-black/60 backdrop-blur-sm rounded-lg p-4 relative group`}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
    >
      {/* Close button */}
      <button
        onClick={() => setIsVisible(false)}
        className="absolute top-1 right-1 text-cyan-400/50 hover:text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <X size={12} />
      </button>

      {/* Ad content placeholder */}
      <div className="h-full flex items-center justify-center text-center">
        <div className="text-cyan-400/70 text-xs">
          <div className="mb-1">Advertisement</div>
          <div className="text-cyan-400/50 text-[10px]">
            Support Storm Echo
          </div>
        </div>
      </div>
    </motion.div>
  );
}