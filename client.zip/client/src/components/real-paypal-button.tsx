// Real PayPal Button Component - Integrates with actual PayPal API
import React, { useEffect, useState } from "react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "paypal-button": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      >;
    }
  }
}

interface RealPayPalButtonProps {
  amount: string;
  currency: string;
  intent: string;
  plan: string;
  onSuccess?: (data: any) => void;
  onError?: (error: any) => void;
  onCancel?: (data: any) => void;
}

export default function RealPayPalButton({
  amount,
  currency,
  intent,
  plan,
  onSuccess,
  onError,
  onCancel
}: RealPayPalButtonProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [paypalReady, setPaypalReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createOrder = async () => {
    try {
      const orderPayload = {
        amount: amount,
        currency: currency,
        intent: intent,
      };
      
      const response = await fetch("/paypal/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderPayload),
      });
      
      if (!response.ok) {
        throw new Error(`PayPal order creation failed: ${response.statusText}`);
      }
      
      const output = await response.json();
      return { orderId: output.id };
    } catch (error) {
      console.error('Failed to create PayPal order:', error);
      setError('Failed to create payment order. Please try again.');
      throw error;
    }
  };

  const captureOrder = async (orderId: string) => {
    try {
      const response = await fetch(`/paypal/order/${orderId}/capture`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
      
      if (!response.ok) {
        throw new Error(`PayPal capture failed: ${response.statusText}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Failed to capture PayPal order:', error);
      setError('Payment capture failed. Please contact support.');
      throw error;
    }
  };

  const handleApprove = async (data: any) => {
    try {
      const orderData = await captureOrder(data.orderId);
      console.log("Payment successful:", orderData);
      if (onSuccess) {
        onSuccess(orderData);
      }
    } catch (error) {
      if (onError) {
        onError(error);
      }
    }
  };

  const handleCancel = async (data: any) => {
    console.log("Payment cancelled:", data);
    if (onCancel) {
      onCancel(data);
    }
  };

  const handleError = async (error: any) => {
    console.error("PayPal error:", error);
    setError('Payment error occurred. Please try again.');
    if (onError) {
      onError(error);
    }
  };

  useEffect(() => {
    const loadPayPalSDK = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Check if PayPal credentials are configured
        const setupResponse = await fetch("/api/paypal/setup");
        if (!setupResponse.ok) {
          throw new Error('PayPal not configured. Please add your PayPal credentials.');
        }
        
        if (!(window as any).paypal) {
          const script = document.createElement("script");
          script.src = import.meta.env.PROD
            ? "https://www.paypal.com/web-sdk/v6/core"
            : "https://www.sandbox.paypal.com/web-sdk/v6/core";
          script.async = true;
          script.onload = () => initPayPal();
          script.onerror = () => {
            setError('Failed to load PayPal SDK');
            setIsLoading(false);
          };
          document.body.appendChild(script);
        } else {
          await initPayPal();
        }
      } catch (error) {
        console.error("Failed to load PayPal SDK:", error);
        setError(error instanceof Error ? error.message : 'PayPal configuration error');
        setIsLoading(false);
      }
    };

    loadPayPalSDK();
  }, []);

  const initPayPal = async () => {
    try {
      const clientToken: string = await fetch("/api/paypal/setup")
        .then((res) => {
          if (!res.ok) {
            throw new Error('PayPal setup failed');
          }
          return res.json();
        })
        .then((data) => {
          return data.clientToken;
        });

      const sdkInstance = await (window as any).paypal.createInstance({
        clientToken,
        components: ["paypal-payments"],
      });

      const paypalCheckout = sdkInstance.createPayPalOneTimePaymentSession({
        onApprove: handleApprove,
        onCancel: handleCancel,
        onError: handleError,
      });

      const onClick = async () => {
        try {
          setError(null);
          const checkoutOptionsPromise = createOrder();
          await paypalCheckout.start(
            { paymentFlow: "auto" },
            checkoutOptionsPromise,
          );
        } catch (error) {
          console.error('PayPal checkout error:', error);
          setError('Failed to start payment process');
        }
      };

      const paypalButton = document.getElementById("real-paypal-button");
      if (paypalButton) {
        paypalButton.addEventListener("click", onClick);
        setPaypalReady(true);
      }

      setIsLoading(false);

      return () => {
        if (paypalButton) {
          paypalButton.removeEventListener("click", onClick);
        }
      };
    } catch (error) {
      console.error('PayPal initialization error:', error);
      setError('Failed to initialize PayPal. Please check your configuration.');
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full">
      {error && (
        <div className="mb-4 p-3 bg-red-900/20 border border-red-500/20 rounded-lg">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}
      
      {isLoading ? (
        <div className="flex items-center justify-center p-4 bg-gray-800/40 rounded-lg">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-cyan-400"></div>
          <span className="ml-2 text-gray-400">Loading PayPal...</span>
        </div>
      ) : paypalReady ? (
        <paypal-button 
          id="real-paypal-button" 
          className="w-full cursor-pointer bg-[#0070ba] hover:bg-[#005ea6] text-white font-semibold py-3 px-6 rounded-lg transition-colors"
        >
          Pay ${amount} {currency.toUpperCase()} - {plan}
        </paypal-button>
      ) : (
        <div className="p-4 bg-gray-800/40 rounded-lg text-center">
          <p className="text-gray-400">PayPal unavailable</p>
          <p className="text-sm text-gray-500 mt-1">Please check your PayPal configuration</p>
        </div>
      )}
    </div>
  );
}