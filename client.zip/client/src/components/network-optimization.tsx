import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Zap, CheckCircle, Activity, Wifi, Shield } from 'lucide-react';

interface OptimizationMetrics {
  bandwidth: number;
  latency: number;
  throughput: number;
  packetLoss: number;
  jitter: number;
  encryption: number;
}

export function NetworkOptimization() {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationProgress, setOptimizationProgress] = useState(0);
  const [metrics, setMetrics] = useState<OptimizationMetrics>({
    bandwidth: 85.2,
    latency: 12.8,
    throughput: 78.5,
    packetLoss: 0.15,
    jitter: 2.3,
    encryption: 94.7
  });

  const [improvements, setImprovements] = useState<string[]>([]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isOptimizing) {
      interval = setInterval(() => {
        setOptimizationProgress(prev => {
          if (prev >= 100) {
            setIsOptimizing(false);
            setImprovements([
              'Bandwidth optimized to maximum capacity',
              'Latency reduced by 35%',
              'Packet routing optimized',
              'DNS queries accelerated',
              'Connection stability enhanced',
              'Security protocols strengthened'
            ]);
            
            // Update metrics with improvements
            setMetrics(prev => ({
              bandwidth: Math.min(100, prev.bandwidth + 12.5),
              latency: Math.max(5, prev.latency * 0.65),
              throughput: Math.min(100, prev.throughput + 18.2),
              packetLoss: Math.max(0, prev.packetLoss * 0.3),
              jitter: Math.max(0.5, prev.jitter * 0.4),
              encryption: Math.min(100, prev.encryption + 4.1)
            }));
            
            return 100;
          }
          return prev + (Math.random() * 8 + 2);
        });
      }, 200);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isOptimizing]);

  const startOptimization = () => {
    setIsOptimizing(true);
    setOptimizationProgress(0);
    setImprovements([]);
  };

  const getMetricColor = (value: number, invert = false) => {
    if (invert) {
      return value < 30 ? 'text-green-400' : value < 70 ? 'text-yellow-400' : 'text-red-400';
    }
    return value > 90 ? 'text-green-400' : value > 70 ? 'text-yellow-400' : 'text-red-400';
  };

  const getProgressColor = (value: number) => {
    return value > 90 ? 'bg-green-500' : value > 70 ? 'bg-yellow-500' : 'bg-red-500';
  };

  return (
    <Card className="bg-black border-gray-800/50">
      <CardHeader>
        <CardTitle className="flex items-center text-gray-200">
          <Zap className="w-5 h-5 mr-2 text-yellow-400" />
          Network Optimization Engine
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Optimization Controls */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-400">
              Quantum acceleration protocols ready
            </p>
            <p className="text-xs text-gray-500">
              AI-powered connection enhancement
            </p>
          </div>
          <Button
            onClick={startOptimization}
            disabled={isOptimizing}
            className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500"
          >
            <Zap className={`w-4 h-4 mr-2 ${isOptimizing ? 'animate-pulse' : ''}`} />
            {isOptimizing ? 'Optimizing...' : 'Optimize Network'}
          </Button>
        </div>

        {/* Optimization Progress */}
        {isOptimizing && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Optimization Progress</span>
              <span className="text-sm text-yellow-400">{optimizationProgress.toFixed(0)}%</span>
            </div>
            <Progress 
              value={optimizationProgress} 
              className="h-2"
            />
            <div className="text-xs text-gray-500">
              {optimizationProgress < 25 && 'Analyzing network topology...'}
              {optimizationProgress >= 25 && optimizationProgress < 50 && 'Optimizing routing protocols...'}
              {optimizationProgress >= 50 && optimizationProgress < 75 && 'Enhancing bandwidth allocation...'}
              {optimizationProgress >= 75 && optimizationProgress < 100 && 'Finalizing quantum acceleration...'}
              {optimizationProgress >= 100 && 'Optimization complete!'}
            </div>
          </motion.div>
        )}

        {/* Performance Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Bandwidth</span>
              <span className={`text-sm font-medium ${getMetricColor(metrics.bandwidth)}`}>
                {metrics.bandwidth.toFixed(1)}%
              </span>
            </div>
            <div className="relative">
              <Progress value={metrics.bandwidth} className="h-2" />
              <div 
                className={`absolute top-0 left-0 h-2 rounded-full transition-all duration-500 ${getProgressColor(metrics.bandwidth)}`}
                style={{ width: `${metrics.bandwidth}%` }}
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Latency</span>
              <span className={`text-sm font-medium ${getMetricColor(metrics.latency, true)}`}>
                {metrics.latency.toFixed(1)}ms
              </span>
            </div>
            <div className="relative">
              <Progress value={100 - (metrics.latency / 20 * 100)} className="h-2" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Throughput</span>
              <span className={`text-sm font-medium ${getMetricColor(metrics.throughput)}`}>
                {metrics.throughput.toFixed(1)}%
              </span>
            </div>
            <div className="relative">
              <Progress value={metrics.throughput} className="h-2" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Packet Loss</span>
              <span className={`text-sm font-medium ${getMetricColor(metrics.packetLoss * 100, true)}`}>
                {(metrics.packetLoss * 100).toFixed(2)}%
              </span>
            </div>
            <div className="relative">
              <Progress value={100 - (metrics.packetLoss * 100)} className="h-2" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Jitter</span>
              <span className={`text-sm font-medium ${getMetricColor(metrics.jitter, true)}`}>
                {metrics.jitter.toFixed(1)}ms
              </span>
            </div>
            <div className="relative">
              <Progress value={100 - (metrics.jitter / 10 * 100)} className="h-2" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Encryption</span>
              <span className={`text-sm font-medium ${getMetricColor(metrics.encryption)}`}>
                {metrics.encryption.toFixed(1)}%
              </span>
            </div>
            <div className="relative">
              <Progress value={metrics.encryption} className="h-2" />
            </div>
          </div>
        </div>

        {/* Improvement Results */}
        {improvements.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3"
          >
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <h4 className="text-sm font-medium text-green-400">Optimization Complete</h4>
            </div>
            <div className="space-y-2">
              {improvements.map((improvement, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-2 text-sm text-gray-300"
                >
                  <CheckCircle className="w-3 h-3 text-green-400" />
                  <span>{improvement}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Quick Stats */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-800/50">
          <div className="flex items-center space-x-4 text-xs text-gray-400">
            <div className="flex items-center space-x-1">
              <Wifi className="w-3 h-3" />
              <span>5G Ultra</span>
            </div>
            <div className="flex items-center space-x-1">
              <Shield className="w-3 h-3" />
              <span>WPA3</span>
            </div>
            <div className="flex items-center space-x-1">
              <Activity className="w-3 h-3" />
              <span>AI Enhanced</span>
            </div>
          </div>
          <Badge className="bg-green-500/20 text-green-400 border-green-400/30">
            Optimized
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}