import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Cpu, Activity, BarChart3, TrendingUp, Settings } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface CoreMetrics {
  frequency: number;
  temperature: number;
  voltage: number;
  efficiency: number;
  throughput: number;
  oscillations: number;
}

interface ProcessingCore {
  id: string;
  name: string;
  type: 'primary' | 'oscillating' | 'quantum' | 'neural';
  status: 'active' | 'optimizing' | 'overclocked' | 'quantum_locked';
  metrics: CoreMetrics;
  utilization: number;
}

export function OscillatingCore() {
  const [cores, setCores] = useState<ProcessingCore[]>([
    {
      id: 'core_1',
      name: 'Storm Echo Prime Core',
      type: 'primary',
      status: 'active',
      metrics: {
        frequency: 24.8,
        temperature: 28,
        voltage: 1.45,
        efficiency: 99.98,
        throughput: 58750,
        oscillations: 0
      },
      utilization: 87
    },
    {
      id: 'core_2', 
      name: 'Quantum Oscillating Core',
      type: 'oscillating',
      status: 'overclocked',
      metrics: {
        frequency: 32.4,
        temperature: 26,
        voltage: 1.52,
        efficiency: 99.99,
        throughput: 127800,
        oscillations: 8247
      },
      utilization: 94
    },
    {
      id: 'core_3',
      name: 'Neural Processing Unit',
      type: 'neural',
      status: 'quantum_locked',
      metrics: {
        frequency: 41.2,
        temperature: 24,
        voltage: 1.60,
        efficiency: 99.995,
        throughput: 246500,
        oscillations: 15890
      },
      utilization: 91
    },
    {
      id: 'core_4',
      name: 'Hyper-Threading Engine',
      type: 'quantum',
      status: 'optimizing',
      metrics: {
        frequency: 48.6,
        temperature: 22,
        voltage: 1.68,
        efficiency: 99.998,
        throughput: 367400,
        oscillations: 25150
      },
      utilization: 96
    },
    {
      id: 'core_5',
      name: 'Ultra-Boost Amplifier',
      type: 'quantum',
      status: 'overclocked',
      metrics: {
        frequency: 56.2,
        temperature: 20,
        voltage: 1.75,
        efficiency: 99.999,
        throughput: 498200,
        oscillations: 38450
      },
      utilization: 98
    },
    {
      id: 'core_6',
      name: 'Infinity Processing Unit',
      type: 'neural',
      status: 'quantum_locked',
      metrics: {
        frequency: 64.7,
        temperature: 18,
        voltage: 1.82,
        efficiency: 99.9995,
        throughput: 687600,
        oscillations: 52890
      },
      utilization: 99
    }
  ]);

  const [systemMetrics, setSystemMetrics] = useState({
    totalThroughput: 0,
    averageEfficiency: 0,
    totalOscillations: 0,
    overallTemperature: 0,
    quantumCoherence: 0,
    neuralConnectivity: 0,
    hyperThreadingEfficiency: 0
  });

  const [isOptimizing, setIsOptimizing] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Real-time core monitoring and oscillation simulation
    intervalRef.current = setInterval(() => {
      setCores(prevCores => 
        prevCores.map(core => {
          const baseFreq = core.type === 'oscillating' ? 32.4 : 
                          core.type === 'quantum' ? 48.6 :
                          core.type === 'neural' ? 41.2 : 24.8;
          
          // Oscillating core frequency modulation
          const oscillationFactor = core.type === 'oscillating' ? 
            Math.sin(Date.now() / 1000) * 0.5 + 1 : 1;
          
          // Quantum resonance effect
          const quantumBoost = core.type === 'quantum' ? 
            Math.cos(Date.now() / 800) * 0.3 + 1 : 1;

          const newFrequency = baseFreq * oscillationFactor * quantumBoost;
          const newThroughput = Math.floor(newFrequency * 12000 + Math.random() * 5000);
          const newOscillations = core.type === 'oscillating' || core.type === 'quantum' ? 
            core.metrics.oscillations + Math.floor(Math.random() * 5) + 1 : 0;

          return {
            ...core,
            metrics: {
              ...core.metrics,
              frequency: Number(newFrequency.toFixed(1)),
              temperature: Math.max(30, core.metrics.temperature + (Math.random() - 0.5) * 2),
              throughput: newThroughput,
              oscillations: newOscillations,
              efficiency: Math.min(99.9, core.metrics.efficiency + (Math.random() - 0.5) * 0.5)
            },
            utilization: Math.min(100, Math.max(80, core.utilization + (Math.random() - 0.5) * 5))
          };
        })
      );
    }, 100);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  useEffect(() => {
    // Calculate system-wide metrics
    const totalThroughput = cores.reduce((sum, core) => sum + core.metrics.throughput, 0);
    const averageEfficiency = cores.reduce((sum, core) => sum + core.metrics.efficiency, 0) / cores.length;
    const totalOscillations = cores.reduce((sum, core) => sum + core.metrics.oscillations, 0);
    const overallTemperature = cores.reduce((sum, core) => sum + core.metrics.temperature, 0) / cores.length;
    const quantumCoherence = cores.filter(c => c.type === 'quantum' || c.type === 'oscillating').length * 25;

    setSystemMetrics({
      totalThroughput,
      averageEfficiency: Number(averageEfficiency.toFixed(1)),
      totalOscillations,
      overallTemperature: Number(overallTemperature.toFixed(1)),
      quantumCoherence,
      neuralConnectivity: cores.filter(c => c.type === 'neural').reduce((sum, c) => sum + c.metrics.efficiency, 0),
      hyperThreadingEfficiency: cores.filter(c => c.name.includes('Hyper')).reduce((sum, c) => sum + c.utilization, 0)
    });
  }, [cores]);

  const optimizeSystem = async () => {
    setIsOptimizing(true);
    
    // Simulate optimization process
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 200));
      
      setCores(prevCores => 
        prevCores.map(core => ({
          ...core,
          metrics: {
            ...core.metrics,
            frequency: core.metrics.frequency * (1 + i / 1000),
            efficiency: Math.min(99.9, core.metrics.efficiency + i / 50),
            throughput: Math.floor(core.metrics.throughput * (1 + i / 500))
          }
        }))
      );
    }
    
    setIsOptimizing(false);
  };

  const getCoreStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 border-green-400/30';
      case 'overclocked': return 'text-cyan-400 border-cyan-400/30';
      case 'quantum_locked': return 'text-purple-400 border-purple-400/30';
      case 'optimizing': return 'text-yellow-400 border-yellow-400/30';
      default: return 'text-gray-400 border-gray-400/30';
    }
  };

  const getCoreTypeIcon = (type: string) => {
    switch (type) {
      case 'primary': return <Cpu size={20} className="text-blue-400" />;
      case 'oscillating': return <Activity size={20} className="text-cyan-400" />;
      case 'neural': return <BarChart3 size={20} className="text-purple-400" />;
      case 'quantum': return <Zap size={20} className="text-yellow-400" />;
      default: return <Settings size={20} className="text-gray-400" />;
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <Zap size={24} className="mr-3" />
          Enhanced Quantum Processing Cores
        </h3>
        <Badge variant="outline" className="border-green-400/30 text-green-400">
          Quantum Enhanced
        </Badge>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-6">
        <Card className="bg-gray-900/60 border-cyan-400/20">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-cyan-400">
              {(systemMetrics.totalThroughput / 1000).toFixed(1)}K
            </div>
            <div className="text-sm text-gray-400">Total Throughput</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900/60 border-green-400/20">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-400">
              {systemMetrics.averageEfficiency}%
            </div>
            <div className="text-sm text-gray-400">Avg Efficiency</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900/60 border-purple-400/20">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">
              {systemMetrics.totalOscillations.toLocaleString()}
            </div>
            <div className="text-sm text-gray-400">Oscillations</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900/60 border-orange-400/20">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-400">
              {systemMetrics.overallTemperature}°C
            </div>
            <div className="text-sm text-gray-400">Temperature</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900/60 border-yellow-400/20">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-400">
              {systemMetrics.quantumCoherence}%
            </div>
            <div className="text-sm text-gray-400">Quantum Lock</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-900/60 border-pink-400/20">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-pink-400">
              {systemMetrics.neuralConnectivity.toFixed(1)}%
            </div>
            <div className="text-sm text-gray-400">Neural Net</div>
          </CardContent>
        </Card>
      </div>

      {/* Individual Cores */}
      <div className="grid gap-4 mb-6">
        {cores.map((core, index) => (
          <motion.div
            key={core.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-gray-900/60 border-cyan-400/20 hover:border-cyan-400/40 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    {getCoreTypeIcon(core.type)}
                    <div>
                      <h4 className="font-semibold text-cyan-400">{core.name}</h4>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className={`text-xs ${getCoreStatusColor(core.status)}`}>
                          {core.status.replace('_', ' ')}
                        </Badge>
                        <Badge variant="outline" className="text-xs border-blue-400/30 text-blue-400">
                          {core.type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-400">
                      {core.metrics.frequency} GHz
                    </div>
                    <div className="text-sm text-gray-400">
                      {core.utilization}% util
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-gray-400">Throughput</div>
                    <div className="font-semibold text-cyan-400">
                      {core.metrics.throughput.toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Efficiency</div>
                    <div className="font-semibold text-green-400">
                      {core.metrics.efficiency}%
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Temperature</div>
                    <div className="font-semibold text-orange-400">
                      {core.metrics.temperature.toFixed(1)}°C
                    </div>
                  </div>
                  {(core.type === 'oscillating' || core.type === 'quantum') && (
                    <div>
                      <div className="text-sm text-gray-400">Oscillations</div>
                      <div className="font-semibold text-purple-400">
                        {core.metrics.oscillations.toLocaleString()}
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Core Utilization</span>
                    <span className="text-cyan-400">{core.utilization}%</span>
                  </div>
                  <Progress value={core.utilization} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* System Controls */}
      <div className="flex items-center justify-between p-4 bg-gray-900/40 rounded-lg border border-gray-600/20">
        <div className="flex items-center space-x-4">
          <TrendingUp size={20} className="text-green-400" />
          <div>
            <div className="font-semibold text-green-400">System Performance</div>
            <div className="text-sm text-gray-400">
              All cores operating at optimal efficiency
            </div>
          </div>
        </div>
        
        <Button
          onClick={optimizeSystem}
          disabled={isOptimizing}
          className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border-cyan-500/30"
        >
          {isOptimizing ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="mr-2"
              >
                <Settings size={16} />
              </motion.div>
              Optimizing...
            </>
          ) : (
            <>
              <Zap size={16} className="mr-2" />
              Quantum Boost
            </>
          )}
        </Button>
      </div>
    </div>
  );
}