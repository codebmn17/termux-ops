import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Wifi, WifiOff, Shield, Zap, Globe } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface ConnectionStatus {
  isConnected: boolean;
  connectionType: 'wifi' | 'ethernet' | 'cellular';
  speed: number;
  strength: number;
  security: 'secure' | 'unsecure';
  latency: number;
}

export function ConnectionStatusIndicator() {
  const [status, setStatus] = useState<ConnectionStatus>({
    isConnected: true,
    connectionType: 'wifi',
    speed: 1247.8,
    strength: 95,
    security: 'secure',
    latency: 8
  });

  useEffect(() => {
    const updateStatus = () => {
      setStatus(prev => ({
        ...prev,
        speed: prev.speed + (Math.random() - 0.5) * 20,
        strength: Math.max(80, Math.min(100, prev.strength + (Math.random() - 0.5) * 5)),
        latency: Math.max(5, Math.min(15, prev.latency + (Math.random() - 0.5) * 2))
      }));
    };

    const interval = setInterval(updateStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  const getConnectionIcon = () => {
    if (!status.isConnected) {
      return <WifiOff className="w-4 h-4 text-red-400" />;
    }

    if (status.connectionType === 'ethernet') {
      return <Globe className="w-4 h-4 text-green-400" />;
    }

    const color = status.strength > 80 ? 'text-green-400' : 
                  status.strength > 60 ? 'text-yellow-400' : 'text-red-400';
    return <Wifi className={`w-4 h-4 ${color}`} />;
  };

  const getStatusColor = () => {
    if (!status.isConnected) return 'bg-red-500/20 text-red-400 border-red-400/30';
    if (status.security === 'secure') return 'bg-green-500/20 text-green-400 border-green-400/30';
    return 'bg-yellow-500/20 text-yellow-400 border-yellow-400/30';
  };

  return (
    <motion.div
      className="fixed top-4 right-4 z-50 flex items-center space-x-2 p-2 rounded-lg bg-black/80 backdrop-blur-md border border-gray-800/50"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.7, 1, 0.7]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        {getConnectionIcon()}
      </motion.div>

      <div className="flex items-center space-x-2">
        <Badge className={getStatusColor()}>
          {status.isConnected ? (
            <div className="flex items-center space-x-1">
              <Shield className="w-3 h-3" />
              <span className="text-xs">
                {status.speed.toFixed(0)} Mbps
              </span>
            </div>
          ) : (
            <span className="text-xs">Disconnected</span>
          )}
        </Badge>

        {status.isConnected && (
          <Badge className="bg-blue-500/20 text-blue-400 border-blue-400/30">
            <div className="flex items-center space-x-1">
              <Zap className="w-3 h-3" />
              <span className="text-xs">{status.latency}ms</span>
            </div>
          </Badge>
        )}
      </div>
    </motion.div>
  );
}