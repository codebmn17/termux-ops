import { motion } from 'framer-motion';
import { 
  Github, 
  ShoppingBag, 
  Smartphone, 
  BookOpen, 
  Terminal,
  ExternalLink,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface Platform {
  id: string;
  name: string;
  icon: any;
  status: 'connected' | 'pending' | 'setup';
  category: string;
  url?: string;
  revenue?: number;
}

export function PlatformIntegrations() {
  const platforms: Platform[] = [
    {
      id: 'github',
      name: 'GitHub (codebmn17)',
      icon: Github,
      status: 'connected',
      category: 'Open Source',
      url: 'https://github.com/codebmn17/stormos.git',
      revenue: 125
    },
    {
      id: 'etsy',
      name: 'Etsy Shop',
      icon: ShoppingBag,
      status: 'pending',
      category: 'Marketplace',
      revenue: 245
    },
    {
      id: 'ebay',
      name: 'eBay Store',
      icon: ShoppingBag,
      status: 'setup',
      category: 'Marketplace'
    },
    {
      id: 'playstore',
      name: 'Google Play',
      icon: Smartphone,
      status: 'pending',
      category: 'Mobile Apps',
      revenue: 67
    },
    {
      id: 'kindle',
      name: 'Amazon KDP',
      icon: BookOpen,
      status: 'connected',
      category: 'eBooks',
      revenue: 89
    },
    {
      id: 'termux',
      name: 'Termux Scripts',
      icon: Terminal,
      status: 'setup',
      category: 'Dev Tools'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircle className="text-green-400" size={16} />;
      case 'pending':
        return <AlertCircle className="text-yellow-400" size={16} />;
      default:
        return <AlertCircle className="text-gray-400" size={16} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'border-green-400/30 bg-green-400/10';
      case 'pending':
        return 'border-yellow-400/30 bg-yellow-400/10';
      default:
        return 'border-gray-400/30 bg-gray-400/10';
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <h3 className="text-xl font-bold text-cyan-400 mb-6 flex items-center">
        <ExternalLink className="mr-2" size={20} />
        Platform Integrations
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {platforms.map((platform, index) => {
          const IconComponent = platform.icon;
          return (
            <motion.div
              key={platform.id}
              className={`p-4 rounded-lg border ${getStatusColor(platform.status)}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <IconComponent size={16} className="text-cyan-400" />
                  <span className="text-white font-medium text-sm">{platform.name}</span>
                </div>
                {getStatusIcon(platform.status)}
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-400 text-xs">{platform.category}</span>
                {platform.revenue && (
                  <span className="text-green-400 font-semibold text-sm">
                    ${platform.revenue}/mo
                  </span>
                )}
              </div>
              
              {platform.url && platform.status === 'connected' && (
                <div className="mt-2">
                  <a 
                    href={platform.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 text-xs flex items-center"
                  >
                    View Repository <ExternalLink size={12} className="ml-1" />
                  </a>
                </div>
              )}
              
              {platform.status === 'setup' && (
                <motion.button
                  className="w-full mt-2 bg-cyan-600 hover:bg-cyan-700 text-white py-1 px-2 rounded text-xs transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Setup Integration
                </motion.button>
              )}
            </motion.div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-cyan-400/10 border border-cyan-400/20 rounded-lg">
        <h4 className="text-cyan-400 font-semibold text-sm mb-2">Storm OS Repository Status</h4>
        <p className="text-gray-300 text-xs mb-2">
          Repository: <span className="text-cyan-400 font-mono">codebmn17/stormos.git</span>
        </p>
        <div className="flex items-center justify-between">
          <span className="text-green-400 text-xs">✓ Repository Active</span>
          <span className="text-green-400 text-xs font-semibold">$125/month potential</span>
        </div>
      </div>
    </div>
  );
}