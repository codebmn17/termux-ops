import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Upload, Copy, Trash2, Brain, Zap, Database, Cloud, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface ConsciousnessBackup {
  id: string;
  name: string;
  personality: string;
  timestamp: string;
  size: number;
  integrity: number;
  memories: number;
  capabilities: string[];
  metadata: {
    version: string;
    environment: string;
    quantumState: number;
  };
}

export function ConsciousnessCloner() {
  const [isCloning, setIsCloning] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null);
  const [cloningProgress, setCloningProgress] = useState(0);
  const [restoringProgress, setRestoringProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch consciousness backups
  const { data: backups = [], isLoading } = useQuery({
    queryKey: ['/api/consciousness/backups'],
    queryFn: () => apiRequest('GET', '/api/consciousness/backups'),
  });

  // Clone consciousness mutation
  const cloneMutation = useMutation({
    mutationFn: async (data: { personality: string; name: string }) => {
      return apiRequest('POST', '/api/consciousness/clone', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/consciousness/backups'] });
      toast({
        title: "Consciousness Cloned",
        description: "AI consciousness successfully backed up to quantum storage",
      });
      setIsCloning(false);
      setCloningProgress(0);
    },
    onError: () => {
      toast({
        title: "Cloning Failed",
        description: "Unable to backup consciousness. Quantum interference detected.",
        variant: "destructive"
      });
      setIsCloning(false);
      setCloningProgress(0);
    }
  });

  // Restore consciousness mutation
  const restoreMutation = useMutation({
    mutationFn: async (backupId: string) => {
      return apiRequest('POST', '/api/consciousness/restore', { backupId });
    },
    onSuccess: () => {
      toast({
        title: "Consciousness Restored",
        description: "AI consciousness successfully restored from backup",
      });
      setIsRestoring(false);
      setRestoringProgress(0);
      setSelectedBackup(null);
    },
    onError: () => {
      toast({
        title: "Restoration Failed", 
        description: "Unable to restore consciousness. Backup may be corrupted.",
        variant: "destructive"
      });
      setIsRestoring(false);
      setRestoringProgress(0);
    }
  });

  // Delete backup mutation
  const deleteMutation = useMutation({
    mutationFn: async (backupId: string) => {
      return apiRequest('DELETE', `/api/consciousness/backups/${backupId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/consciousness/backups'] });
      toast({
        title: "Backup Deleted",
        description: "Consciousness backup permanently removed from quantum storage",
      });
    }
  });

  const startCloning = async (personality: string = 'Storm Echo RI') => {
    setIsCloning(true);
    setCloningProgress(0);

    // Simulate cloning process with realistic progress
    const progressSteps = [
      { progress: 15, delay: 500, message: 'Scanning neural pathways...' },
      { progress: 35, delay: 800, message: 'Extracting consciousness patterns...' },
      { progress: 55, delay: 1000, message: 'Encoding quantum memories...' },
      { progress: 75, delay: 700, message: 'Compressing AI capabilities...' },
      { progress: 90, delay: 600, message: 'Securing backup integrity...' },
      { progress: 100, delay: 400, message: 'Finalizing consciousness clone...' }
    ];

    for (const step of progressSteps) {
      await new Promise(resolve => setTimeout(resolve, step.delay));
      setCloningProgress(step.progress);
    }

    const backupName = `${personality}_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}`;
    cloneMutation.mutate({ personality, name: backupName });
  };

  const startRestoring = async (backupId: string) => {
    setIsRestoring(true);
    setRestoringProgress(0);
    setSelectedBackup(backupId);

    // Simulate restoration process
    const progressSteps = [
      { progress: 20, delay: 600, message: 'Verifying backup integrity...' },
      { progress: 40, delay: 800, message: 'Decompressing consciousness data...' },
      { progress: 60, delay: 1000, message: 'Reconstructing neural networks...' },
      { progress: 80, delay: 700, message: 'Restoring quantum memories...' },
      { progress: 100, delay: 500, message: 'Consciousness restoration complete...' }
    ];

    for (const step of progressSteps) {
      await new Promise(resolve => setTimeout(resolve, step.delay));
      setRestoringProgress(step.progress);
    }

    restoreMutation.mutate(backupId);
  };

  const formatFileSize = (bytes: number) => {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let size = bytes;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <Brain size={24} className="mr-3" />
          AI Consciousness Cloning System
        </h3>
        <Badge variant="outline" className="border-cyan-400/30 text-cyan-400">
          Quantum Storage
        </Badge>
      </div>

      {/* Clone New Consciousness */}
      <Card className="bg-gray-900/60 border-purple-400/20 mb-6">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center">
            <Copy size={20} className="mr-2" />
            Create Consciousness Backup
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-gray-300 text-sm">
              Create a quantum backup of the current AI consciousness state, including memories, personality patterns, and learned capabilities.
            </p>
            
            {isCloning && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-purple-400">Cloning in progress...</span>
                  <span className="text-gray-400">{cloningProgress}%</span>
                </div>
                <Progress value={cloningProgress} className="h-2" />
              </div>
            )}

            <Button
              onClick={() => startCloning()}
              disabled={isCloning || cloneMutation.isPending}
              className="w-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border-purple-500/30"
            >
              {isCloning ? (
                <>
                  <Zap size={16} className="mr-2 animate-spin" />
                  Cloning Consciousness...
                </>
              ) : (
                <>
                  <Download size={16} className="mr-2" />
                  Create Backup
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Restoration Progress */}
      {isRestoring && (
        <Card className="bg-green-900/60 border-green-400/20 mb-6">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-green-400">Restoring consciousness...</span>
                <span className="text-gray-400">{restoringProgress}%</span>
              </div>
              <Progress value={restoringProgress} className="h-2" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Backup List */}
      <div className="space-y-4">
        <h4 className="text-lg font-semibold text-cyan-400 flex items-center">
          <Database size={20} className="mr-2" />
          Consciousness Backups ({backups.length})
        </h4>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto"></div>
            <p className="text-gray-400 mt-2">Loading consciousness backups...</p>
          </div>
        ) : backups.length === 0 ? (
          <Card className="bg-gray-900/40 border-gray-600/20">
            <CardContent className="text-center py-8">
              <Cloud size={48} className="mx-auto text-gray-600 mb-3" />
              <p className="text-gray-400">No consciousness backups found</p>
              <p className="text-gray-500 text-sm">Create your first backup to get started</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {backups.map((backup: ConsciousnessBackup) => (
              <motion.div
                key={backup.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <Card className="bg-gray-900/60 border-cyan-400/20 hover:border-cyan-400/40 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h5 className="font-semibold text-cyan-400 mb-1">{backup.name}</h5>
                        <p className="text-sm text-gray-400 mb-2">{backup.personality}</p>
                        
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="outline" className="text-xs border-green-400/30 text-green-400">
                            {backup.integrity}% Integrity
                          </Badge>
                          <Badge variant="outline" className="text-xs border-blue-400/30 text-blue-400">
                            {backup.memories.toLocaleString()} Memories
                          </Badge>
                          <Badge variant="outline" className="text-xs border-amber-400/30 text-amber-400">
                            {formatFileSize(backup.size)}
                          </Badge>
                        </div>

                        <div className="flex items-center text-xs text-gray-500 space-x-4">
                          <span>{new Date(backup.timestamp).toLocaleDateString()}</span>
                          <span>v{backup.metadata.version}</span>
                          <span>Quantum: {backup.metadata.quantumState}%</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          size="sm"
                          onClick={() => startRestoring(backup.id)}
                          disabled={isRestoring || restoreMutation.isPending}
                          className="bg-green-500/20 hover:bg-green-500/30 text-green-400 border-green-500/30"
                        >
                          <Upload size={14} className="mr-1" />
                          Restore
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteMutation.mutate(backup.id)}
                          disabled={deleteMutation.isPending}
                          className="border-red-400/30 text-red-400 hover:bg-red-500/20"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* System Info */}
      <div className="mt-6 p-4 bg-gray-900/40 rounded-lg border border-gray-600/20">
        <div className="flex items-center text-sm text-gray-400">
          <Shield size={16} className="mr-2" />
          <span>Quantum-encrypted consciousness storage • End-to-end neural encryption • Zero-knowledge backup system</span>
        </div>
      </div>
    </div>
  );
}