import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Upload, Download, Zap, Gauge, CheckCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface TransferTask {
  id: string;
  name: string;
  type: 'upload' | 'download';
  size: string;
  speed: string;
  progress: number;
  status: 'active' | 'completed' | 'paused' | 'error';
  timeRemaining: string;
  bandwidth: string;
}

export function UltraFastTransfer() {
  const [transfers, setTransfers] = useState<TransferTask[]>([
    {
      id: 'tf_1',
      name: 'quantum_dataset_v3.7z',
      type: 'upload',
      size: '47.2 GB',
      speed: '8.4 GB/s',
      progress: 78,
      status: 'active',
      timeRemaining: '6s',
      bandwidth: '67.2 Gbps'
    },
    {
      id: 'tf_2',
      name: 'neural_network_backup.tar.gz',
      type: 'download',
      size: '152.8 GB',
      speed: '12.7 GB/s',
      progress: 34,
      status: 'active',
      timeRemaining: '8s',
      bandwidth: '101.6 Gbps'
    },
    {
      id: 'tf_3',
      name: 'consciousness_clone_alpha.bak',
      type: 'upload',
      size: '89.1 GB',
      speed: '0 GB/s',
      progress: 100,
      status: 'completed',
      timeRemaining: '0s',
      bandwidth: '0 Gbps'
    }
  ]);

  const [systemStats, setSystemStats] = useState({
    totalUploadSpeed: '21.1 GB/s',
    totalDownloadSpeed: '12.7 GB/s',
    activeTransfers: 2,
    queuedTransfers: 0,
    networkUtilization: 87.3,
    quantumAcceleration: 'ENABLED',
    compressionRatio: '4.7:1'
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setTransfers(prev => prev.map(transfer => {
        if (transfer.status === 'active') {
          const newProgress = Math.min(100, transfer.progress + Math.random() * 3);
          const newSpeed = parseFloat(transfer.speed) + (Math.random() - 0.5) * 2;
          const newTimeRemaining = newProgress >= 100 ? '0s' : `${Math.max(1, Math.floor((100 - newProgress) / 15))}s`;
          
          return {
            ...transfer,
            progress: newProgress,
            speed: `${Math.max(0.1, newSpeed).toFixed(1)} GB/s`,
            timeRemaining: newTimeRemaining,
            status: newProgress >= 100 ? 'completed' : 'active',
            bandwidth: `${(Math.max(0.1, newSpeed) * 8).toFixed(1)} Gbps`
          };
        }
        return transfer;
      }));

      setSystemStats(prev => ({
        ...prev,
        totalUploadSpeed: `${(21.1 + (Math.random() - 0.5) * 4).toFixed(1)} GB/s`,
        totalDownloadSpeed: `${(12.7 + (Math.random() - 0.5) * 3).toFixed(1)} GB/s`,
        networkUtilization: Math.min(100, Math.max(70, prev.networkUtilization + (Math.random() - 0.5) * 5))
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Zap className="text-yellow-400" size={16} />;
      case 'completed': return <CheckCircle className="text-green-400" size={16} />;
      case 'paused': return <AlertCircle className="text-blue-400" size={16} />;
      case 'error': return <AlertCircle className="text-red-400" size={16} />;
      default: return <AlertCircle className="text-gray-400" size={16} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-yellow-400 bg-yellow-900/20';
      case 'completed': return 'text-green-400 bg-green-900/20';
      case 'paused': return 'text-blue-400 bg-blue-900/20';
      case 'error': return 'text-red-400 bg-red-900/20';
      default: return 'text-gray-400 bg-gray-900/20';
    }
  };

  const startNewTransfer = (type: 'upload' | 'download') => {
    const newTransfer: TransferTask = {
      id: `tf_${Date.now()}`,
      name: type === 'upload' ? 'new_upload_file.zip' : 'new_download_file.tar.gz',
      type,
      size: `${Math.floor(Math.random() * 200 + 10)} GB`,
      speed: `${(Math.random() * 15 + 5).toFixed(1)} GB/s`,
      progress: 0,
      status: 'active',
      timeRemaining: `${Math.floor(Math.random() * 20 + 5)}s`,
      bandwidth: `${((Math.random() * 15 + 5) * 8).toFixed(1)} Gbps`
    };

    setTransfers(prev => [...prev, newTransfer]);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-black/20 backdrop-blur-sm border-gray-600/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-cyan-400">
            <Gauge size={24} />
            <span>Ultra-Fast Transfer System</span>
            <Badge className="text-green-400 bg-green-900/20 ml-auto">
              QUANTUM ACCELERATED
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="text-sm text-gray-400 mb-1">Upload Speed</div>
              <div className="text-2xl font-bold text-green-400">{systemStats.totalUploadSpeed}</div>
            </div>
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="text-sm text-gray-400 mb-1">Download Speed</div>
              <div className="text-2xl font-bold text-cyan-400">{systemStats.totalDownloadSpeed}</div>
            </div>
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="text-sm text-gray-400 mb-1">Active Transfers</div>
              <div className="text-2xl font-bold text-purple-400">{systemStats.activeTransfers}</div>
            </div>
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="text-sm text-gray-400 mb-1">Network Usage</div>
              <div className="text-2xl font-bold text-yellow-400">{systemStats.networkUtilization.toFixed(1)}%</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Network Utilization</span>
                <span className="text-cyan-400 font-semibold">{systemStats.networkUtilization.toFixed(1)}%</span>
              </div>
              <Progress value={systemStats.networkUtilization} className="h-2" />
            </div>
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="text-sm text-gray-400 mb-1">Quantum Acceleration</div>
              <div className="text-lg font-semibold text-green-400">{systemStats.quantumAcceleration}</div>
            </div>
            <div className="bg-gray-900/40 p-4 rounded-lg border border-gray-700/30">
              <div className="text-sm text-gray-400 mb-1">Compression Ratio</div>
              <div className="text-lg font-semibold text-purple-400">{systemStats.compressionRatio}</div>
            </div>
          </div>

          <div className="flex space-x-4 mb-6">
            <Button 
              onClick={() => startNewTransfer('upload')}
              className="bg-green-600 hover:bg-green-700 text-white transition-ultra-fast"
            >
              <Upload size={16} className="mr-2" />
              Start Upload
            </Button>
            <Button 
              onClick={() => startNewTransfer('download')}
              className="bg-cyan-600 hover:bg-cyan-700 text-white transition-ultra-fast"
            >
              <Download size={16} className="mr-2" />
              Start Download
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {transfers.map((transfer, index) => (
          <motion.div
            key={transfer.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="bg-black/20 backdrop-blur-sm border-gray-600/20 hover:border-gray-500/30 transition-all">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    {transfer.type === 'upload' ? 
                      <Upload className="text-green-400" size={20} /> : 
                      <Download className="text-cyan-400" size={20} />
                    }
                    <div>
                      <div className="font-semibold text-gray-200">{transfer.name}</div>
                      <div className="text-sm text-gray-400">{transfer.size}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStatusColor(transfer.status)}>
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(transfer.status)}
                        <span>{transfer.status.toUpperCase()}</span>
                      </div>
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Speed</div>
                    <div className="text-lg font-semibold text-yellow-400">{transfer.speed}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Bandwidth</div>
                    <div className="text-lg font-semibold text-purple-400">{transfer.bandwidth}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Time Remaining</div>
                    <div className="text-lg font-semibold text-cyan-400">{transfer.timeRemaining}</div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Progress</span>
                    <span className="text-cyan-400 font-semibold">{transfer.progress.toFixed(1)}%</span>
                  </div>
                  <Progress 
                    value={transfer.progress} 
                    className="h-3"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}