import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface EnhancedCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export function EnhancedCard({ children, className = '', hover = true, glow = false }: EnhancedCardProps) {
  return (
    <motion.div
      className={`card-enhanced ${hover ? 'hover:scale-[1.02]' : ''} ${glow ? 'glow-border' : ''} ${className}`}
      whileHover={hover ? { y: -2 } : undefined}
      transition={{ duration: 0.1, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

interface EnhancedButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
  loading?: boolean;
}

export function EnhancedButton({ 
  children, 
  onClick, 
  variant = 'primary', 
  size = 'md', 
  className = '',
  disabled = false,
  loading = false
}: EnhancedButtonProps) {
  const baseClass = 'btn-enhanced font-semibold transition-ultra-fast relative overflow-hidden';
  
  const variants = {
    primary: 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500',
    secondary: 'bg-gradient-to-r from-gray-700 to-gray-600 hover:from-gray-600 hover:to-gray-500',
    accent: 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500',
    success: 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500',
    warning: 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500',
    danger: 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500'
  };
  
  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg'
  };

  return (
    <motion.button
      className={`${baseClass} ${variants[variant]} ${sizes[size]} ${className} ${
        disabled ? 'opacity-50 cursor-not-allowed' : ''
      }`}
      onClick={disabled ? undefined : onClick}
      whileHover={disabled ? undefined : { scale: 1.02 }}
      whileTap={disabled ? undefined : { scale: 0.98 }}
      disabled={disabled || loading}
    >
      {loading && (
        <motion.div
          className="absolute inset-0 bg-white/20"
          animate={{ x: ['-100%', '100%'] }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        />
      )}
      <span className="relative z-10">{children}</span>
    </motion.button>
  );
}

interface EnhancedInputProps {
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  type?: string;
  className?: string;
  multiline?: boolean;
  rows?: number;
  icon?: React.ReactNode;
}

export function EnhancedInput({ 
  value, 
  onChange, 
  placeholder, 
  type = 'text', 
  className = '',
  multiline = false,
  rows = 3,
  icon
}: EnhancedInputProps) {
  const baseClass = 'input-enhanced w-full';

  if (multiline) {
    return (
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-3 text-gray-400 z-10">
            {icon}
          </div>
        )}
        <Textarea
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          placeholder={placeholder}
          rows={rows}
          className={`${baseClass} ${icon ? 'pl-10' : ''} ${className} resize-none`}
        />
      </div>
    );
  }

  return (
    <div className="relative">
      {icon && (
        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 z-10">
          {icon}
        </div>
      )}
      <Input
        type={type}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder}
        className={`${baseClass} ${icon ? 'pl-10' : ''} ${className}`}
      />
    </div>
  );
}

interface EnhancedBadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'warning' | 'info' | 'error' | 'default';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  pulse?: boolean;
}

export function EnhancedBadge({ 
  children, 
  variant = 'default', 
  size = 'md', 
  className = '',
  pulse = false
}: EnhancedBadgeProps) {
  const baseClass = 'badge-enhanced inline-flex items-center justify-center';
  
  const variants = {
    success: 'badge-success',
    warning: 'badge-warning',
    info: 'badge-info',
    error: 'badge-error',
    default: 'bg-gray-900/30 text-gray-400 border-gray-500/30'
  };
  
  const sizes = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1.5 text-sm',
    lg: 'px-4 py-2 text-base'
  };

  return (
    <motion.span
      className={`${baseClass} ${variants[variant]} ${sizes[size]} ${className}`}
      animate={pulse ? { scale: [1, 1.05, 1] } : undefined}
      transition={pulse ? { duration: 0.6, repeat: Infinity } : undefined}
    >
      {children}
    </motion.span>
  );
}

interface EnhancedProgressProps {
  value: number;
  max?: number;
  className?: string;
  animated?: boolean;
  color?: 'cyan' | 'green' | 'blue' | 'purple' | 'amber';
  showValue?: boolean;
}

export function EnhancedProgress({ 
  value, 
  max = 100, 
  className = '',
  animated = true,
  color = 'cyan',
  showValue = false
}: EnhancedProgressProps) {
  const percentage = (value / max) * 100;
  
  const colors = {
    cyan: 'from-cyan-400 to-blue-500',
    green: 'from-green-400 to-emerald-500',
    blue: 'from-blue-400 to-indigo-500',
    purple: 'from-purple-400 to-pink-500',
    amber: 'from-amber-400 to-orange-500'
  };

  return (
    <div className={`progress-enhanced ${className}`}>
      <motion.div
        className={`progress-fill bg-gradient-to-r ${colors[color]}`}
        initial={{ width: 0 }}
        animate={{ width: `${percentage}%` }}
        transition={animated ? { duration: 0.3, ease: "easeOut" } : { duration: 0 }}
      />
      {showValue && (
        <div className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white">
          {Math.round(percentage)}%
        </div>
      )}
    </div>
  );
}

interface EnhancedStatusIndicatorProps {
  status: 'online' | 'offline' | 'busy' | 'away';
  size?: 'sm' | 'md' | 'lg';
  pulse?: boolean;
  className?: string;
}

export function EnhancedStatusIndicator({ 
  status, 
  size = 'md', 
  pulse = true, 
  className = '' 
}: EnhancedStatusIndicatorProps) {
  const colors = {
    online: 'bg-green-400',
    offline: 'bg-gray-400',
    busy: 'bg-red-400',
    away: 'bg-yellow-400'
  };
  
  const sizes = {
    sm: 'w-2 h-2',
    md: 'w-3 h-3',
    lg: 'w-4 h-4'
  };

  return (
    <motion.div
      className={`${sizes[size]} ${colors[status]} rounded-full ${className}`}
      animate={pulse && status === 'online' ? { scale: [1, 1.2, 1] } : undefined}
      transition={pulse ? { duration: 0.6, repeat: Infinity } : undefined}
    />
  );
}

interface EnhancedTooltipProps {
  children: React.ReactNode;
  content: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
}

export function EnhancedTooltip({ children, content, position = 'top' }: EnhancedTooltipProps) {
  const [isVisible, setIsVisible] = React.useState(false);
  
  const positions = {
    top: 'bottom-full left-1/2 transform -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 transform -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 transform -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 transform -translate-y-1/2 ml-2'
  };

  return (
    <div 
      className="relative inline-block"
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            className={`absolute ${positions[position]} z-50 px-2 py-1 text-xs text-white bg-gray-900 rounded shadow-lg border border-gray-700`}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.05 }}
          >
            {content}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}