import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export function HolographicDisplay() {
  const [time, setTime] = useState(new Date());
  const [dataFlow, setDataFlow] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
      setDataFlow(prev => (prev + Math.random() * 10) % 100);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed top-4 left-4 z-30 perspective-1000 max-w-[calc(100vw-2rem)]">
      <motion.div
        className="relative w-64 h-32 bg-gradient-to-br from-cyan-900/20 to-blue-900/20 backdrop-blur-md border border-cyan-400/30 rounded-lg overflow-hidden"
        initial={{ opacity: 0, rotateY: -30 }}
        animate={{ opacity: 1, rotateY: 0 }}
        transition={{ duration: 0.8 }}
        style={{
          boxShadow: '0 0 30px rgba(0, 255, 255, 0.5)',
          transform: 'perspective(1000px) rotateX(10deg)'
        }}
      >
        {/* Holographic Grid */}
        <div className="absolute inset-0 opacity-30">
          <svg className="w-full h-full">
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(0, 255, 255, 0.5)" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Content */}
        <div className="relative z-10 p-4">
          <div className="text-cyan-400 font-mono text-xs mb-2 animate-pulse">
            STORM ECHO RI SYSTEM
          </div>
          
          <div className="flex justify-between items-center mb-2">
            <div className="text-white text-lg font-bold">
              {time.toLocaleTimeString()}
            </div>
            <div className="text-cyan-400 text-xs">
              {time.toLocaleDateString()}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="text-xs text-gray-400">Data Flow:</div>
            <div className="flex-1 bg-gray-700/50 rounded-full h-2 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-cyan-400 to-blue-400"
                style={{ width: `${dataFlow}%` }}
                animate={{ width: `${dataFlow}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
            <div className="text-cyan-400 text-xs font-mono">
              {dataFlow.toFixed(0)}%
            </div>
          </div>
        </div>

        {/* Holographic Effect */}
        <div className="absolute inset-0 bg-gradient-to-t from-transparent via-cyan-400/10 to-transparent opacity-50 animate-scan" />
      </motion.div>
    </div>
  );
}