import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Bot, 
  Settings, 
  Clock, 
  Target, 
  Zap, 
  Brain, 
  Activity, 
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';

interface AutomationTask {
  id: string;
  name: string;
  description: string;
  type: 'optimization' | 'learning' | 'maintenance' | 'enhancement';
  frequency: 'continuous' | 'hourly' | 'daily' | 'weekly';
  status: 'running' | 'paused' | 'completed' | 'error';
  lastRun: Date;
  nextRun: Date;
  successRate: number;
  impact: number;
}

interface AutomationMetrics {
  totalTasks: number;
  activeTasks: number;
  completedToday: number;
  systemEfficiency: number;
  automationLevel: number;
  errorRate: number;
}

export function AIAutomationEngine() {
  const [tasks, setTasks] = useState<AutomationTask[]>([]);
  // Fetch real automation metrics from API
  const { data: automationData } = useQuery({
    queryKey: ['/api/automation/metrics'],
    refetchInterval: 10000
  });

  const [metrics, setMetrics] = useState<AutomationMetrics>({
    totalTasks: 0,
    activeTasks: 0,
    completedToday: 0,
    systemEfficiency: 0,
    automationLevel: 0,
    errorRate: 0
  });

  // Update metrics when real data arrives
  useEffect(() => {
    if (automationData) {
      setMetrics({
        totalTasks: automationData.totalTasks || 0,
        activeTasks: automationData.activeTasks || 0,
        completedToday: automationData.completedToday || 0,
        systemEfficiency: automationData.systemEfficiency || 0,
        automationLevel: automationData.automationLevel || 0,
        errorRate: automationData.errorRate || 0
      });
    }
  }, [automationData]);
  const [isEngineActive, setIsEngineActive] = useState(true);
  const [selectedTask, setSelectedTask] = useState<string | null>(null);

  // Fetch real automation tasks from API
  const { data: tasksData } = useQuery({
    queryKey: ['/api/automation/tasks'],
    refetchInterval: 30000
  });

  // Initialize automation tasks from API data
  useEffect(() => {
    if (tasksData && Array.isArray(tasksData)) {
      setTasks(tasksData);
    }
  }, [tasksData]);

  // Task execution simulation removed - now handled by real API data

  const toggleTask = (taskId: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { 
            ...task, 
            status: task.status === 'running' ? 'paused' : 'running',
            nextRun: task.status === 'paused' 
              ? new Date(Date.now() + 60 * 1000) // Resume in 1 minute
              : task.nextRun
          }
        : task
    ));
  };

  const restartTask = (taskId: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { 
            ...task, 
            status: 'running',
            lastRun: new Date(),
            nextRun: new Date(Date.now() + 60 * 1000), // Next run in 1 minute
            successRate: Math.min(100, task.successRate + 1)
          }
        : task
    ));
  };

  const getTaskIcon = (type: AutomationTask['type']) => {
    switch (type) {
      case 'optimization': return Target;
      case 'learning': return Brain;
      case 'maintenance': return Settings;
      case 'enhancement': return Zap;
      default: return Bot;
    }
  };

  const getStatusColor = (status: AutomationTask['status']) => {
    switch (status) {
      case 'running': return 'text-green-400 bg-green-500/20 border-green-400/30';
      case 'paused': return 'text-yellow-400 bg-yellow-500/20 border-yellow-400/30';
      case 'completed': return 'text-blue-400 bg-blue-500/20 border-blue-400/30';
      case 'error': return 'text-red-400 bg-red-500/20 border-red-400/30';
      default: return 'text-gray-400 bg-gray-500/20 border-gray-400/30';
    }
  };

  const getFrequencyBadge = (frequency: AutomationTask['frequency']) => {
    const colors = {
      continuous: 'bg-purple-500/20 text-purple-400',
      hourly: 'bg-blue-500/20 text-blue-400',
      daily: 'bg-green-500/20 text-green-400',
      weekly: 'bg-orange-500/20 text-orange-400'
    };
    
    return colors[frequency] || 'bg-gray-500/20 text-gray-400';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-2xl font-bold text-cyan-400 mb-2">AI Automation Engine</h2>
        <p className="text-gray-300 text-sm">
          Autonomous task execution and intelligent system management
        </p>
      </motion.div>

      {/* Engine Control */}
      <motion.div
        className="flex items-center justify-between p-4 bg-gray-900/30 rounded-lg border border-gray-700/50"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div className="flex items-center space-x-3">
          <Bot className="w-6 h-6 text-cyan-400" />
          <div>
            <h3 className="text-lg font-semibold text-white">Automation Engine</h3>
            <p className="text-sm text-gray-400">
              {isEngineActive ? 'Active - Processing tasks automatically' : 'Paused - Manual control only'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <span className="text-sm text-gray-400">Engine Status</span>
          <Switch
            checked={isEngineActive}
            onCheckedChange={setIsEngineActive}
          />
        </div>
      </motion.div>

      {/* Metrics Dashboard */}
      <motion.div
        className="grid grid-cols-2 md:grid-cols-3 gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <Card className="p-4 bg-gray-900/50 border-gray-700/50">
          <div className="flex items-center justify-between mb-2">
            <Activity className="w-5 h-5 text-green-400" />
            <span className="text-lg font-bold text-green-400">{metrics.activeTasks}</span>
          </div>
          <p className="text-sm text-gray-300">Active Tasks</p>
          <p className="text-xs text-gray-500">of {metrics.totalTasks} total</p>
        </Card>

        <Card className="p-4 bg-gray-900/50 border-gray-700/50">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-5 h-5 text-blue-400" />
            <span className="text-lg font-bold text-blue-400">{metrics.completedToday}</span>
          </div>
          <p className="text-sm text-gray-300">Completed Today</p>
          <p className="text-xs text-gray-500">executions</p>
        </Card>

        <Card className="p-4 bg-gray-900/50 border-gray-700/50">
          <div className="flex items-center justify-between mb-2">
            <Target className="w-5 h-5 text-cyan-400" />
            <span className="text-lg font-bold text-cyan-400">{metrics.systemEfficiency.toFixed(1)}%</span>
          </div>
          <p className="text-sm text-gray-300">System Efficiency</p>
          <p className="text-xs text-gray-500">automated optimization</p>
        </Card>

        <Card className="p-4 bg-gray-900/50 border-gray-700/50">
          <div className="flex items-center justify-between mb-2">
            <Zap className="w-5 h-5 text-purple-400" />
            <span className="text-lg font-bold text-purple-400">{metrics.automationLevel.toFixed(1)}%</span>
          </div>
          <p className="text-sm text-gray-300">Automation Level</p>
          <p className="text-xs text-gray-500">task coverage</p>
        </Card>

        <Card className="p-4 bg-gray-900/50 border-gray-700/50">
          <div className="flex items-center justify-between mb-2">
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            <span className="text-lg font-bold text-orange-400">{metrics.errorRate.toFixed(1)}%</span>
          </div>
          <p className="text-sm text-gray-300">Error Rate</p>
          <p className="text-xs text-gray-500">last 24 hours</p>
        </Card>

        <Card className="p-4 bg-gray-900/50 border-gray-700/50">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-5 h-5 text-yellow-400" />
            <span className="text-lg font-bold text-yellow-400">24/7</span>
          </div>
          <p className="text-sm text-gray-300">Uptime</p>
          <p className="text-xs text-gray-500">continuous operation</p>
        </Card>
      </motion.div>

      {/* Task List */}
      <motion.div
        className="space-y-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <h3 className="text-lg font-semibold text-white">Automation Tasks</h3>
        
        <div className="space-y-3">
          {tasks.map((task) => {
            const Icon = getTaskIcon(task.type);
            const isSelected = selectedTask === task.id;
            
            return (
              <motion.div
                key={task.id}
                className={`p-4 bg-gray-900/40 rounded-lg border transition-colors cursor-pointer ${
                  isSelected 
                    ? 'border-cyan-400/50 bg-cyan-900/10' 
                    : 'border-gray-700/50 hover:border-gray-600/50'
                }`}
                onClick={() => setSelectedTask(isSelected ? null : task.id)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <Icon className="w-5 h-5 text-cyan-400 mt-0.5" />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="text-sm font-semibold text-white">{task.name}</h4>
                        <Badge className={`text-xs px-2 py-0.5 ${getStatusColor(task.status)}`}>
                          {task.status}
                        </Badge>
                        <Badge className={`text-xs px-2 py-0.5 ${getFrequencyBadge(task.frequency)}`}>
                          {task.frequency}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-400 mb-2">{task.description}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>Success: {task.successRate.toFixed(1)}%</span>
                        <span>Impact: {task.impact}%</span>
                        <span>Last: {task.lastRun.toLocaleTimeString()}</span>
                        <span>Next: {task.nextRun.toLocaleTimeString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleTask(task.id);
                      }}
                      size="sm"
                      variant="outline"
                    >
                      {task.status === 'running' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </Button>
                    {task.status === 'error' && (
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          restartTask(task.id);
                        }}
                        size="sm"
                        variant="outline"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}