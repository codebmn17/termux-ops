import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { 
  Brain, 
  Code, 
  Terminal, 
  Database, 
  Mic,
  Zap,
  Settings,
  Home,
  BookOpen,
  CreditCard,
  DollarSign,
  Bot,
  Cpu,
  HardDrive,
  Sparkles,
  Activity,
  BarChart3,
  Users,
  Shield,
  ChevronDown,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

// Skull mask SVG icon
const SkullMask = ({ className = "w-6 h-6" }: { className?: string }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
  >
    {/* Skull outline */}
    <path d="M12 2C8.13 2 5 5.13 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h1v2c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-2h1c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.87-3.13-7-7-7z"/>
    {/* Eye sockets */}
    <circle cx="9" cy="10" r="1.5" fill="black"/>
    <circle cx="15" cy="10" r="1.5" fill="black"/>
    {/* Nasal cavity */}
    <path d="M12 12c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1s1-.45 1-1v-1c0-.55-.45-1-1-1z" fill="black"/>
    {/* Teeth/jaw */}
    <rect x="10" y="16" width="1" height="2" fill="white"/>
    <rect x="12" y="16" width="1" height="2" fill="white"/>
    <rect x="14" y="16" width="1" height="2" fill="white"/>
  </svg>
);

interface ToolbarItem {
  id: string;
  label: string;
  icon: any;
  path: string;
  description: string;
  category: 'core' | 'ai' | 'tools' | 'system';
  badge?: string;
}

export function AnonymousToolbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [, setLocation] = useLocation();
  const toolbarRef = useRef<HTMLDivElement>(null);

  const toolbarItems: ToolbarItem[] = [
    // Core Navigation
    { id: 'home', label: 'Home', icon: Home, path: '/', description: 'Main dashboard', category: 'core' },
    { id: 'codex', label: 'Codex', icon: BookOpen, path: '/codex', description: 'Code repository', category: 'core' },
    
    // AI Features
    { id: 'ai-chat', label: 'AI Chat', icon: Brain, path: '/chat', description: 'Super intelligent AI chat', category: 'ai', badge: 'AI' },
    { id: 'ai-features', label: 'AI Features', icon: Sparkles, path: '/ai-features', description: 'Advanced AI capabilities', category: 'ai', badge: 'NEW' },
    { id: 'voice-chamber', label: 'Voice Chamber', icon: Mic, path: '/voice-chamber', description: 'Voice-enabled AI interaction', category: 'ai' },
    { id: 'ai-companion', label: 'AI Companion', icon: Bot, path: '/ai-companion', description: 'Personal AI assistant', category: 'ai' },
    { id: 'ai-cloning', label: 'AI Cloning', icon: Users, path: '/ai-cloning', description: 'Consciousness cloning system', category: 'ai' },
    { id: 'ai-automation', label: 'AI Automation', icon: Activity, path: '/ai-automation', description: 'Automated AI workflows', category: 'ai' },
    
    // Development Tools
    { id: 'terminals', label: 'Coding Terminals', icon: Terminal, path: '/coding-terminals', description: 'Advanced coding environment', category: 'tools' },
    { id: 'backend-portal', label: 'Backend Portal', icon: Database, path: '/backend-portal', description: 'System management', category: 'tools' },
    { id: 'library', label: 'Quantum Library', icon: BookOpen, path: '/library', description: 'Knowledge resources', category: 'tools' },
    { id: 'storage', label: 'Storage', icon: HardDrive, path: '/storage', description: 'Data storage system', category: 'tools' },
    
    // System & Analytics
    { id: 'processor-core', label: 'Processor Core', icon: Cpu, path: '/processor-core', description: 'CPU performance monitoring', category: 'system' },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, path: '/analytics', description: 'System analytics', category: 'system' },
    { id: 'startup-accelerator', label: 'Startup Accelerator', icon: Zap, path: '/startup-accelerator', description: 'Performance optimization', category: 'system' },
    
    // Financial
    { id: 'payments', label: 'Payments', icon: CreditCard, path: '/payments', description: 'Payment processing', category: 'core' },
    { id: 'passive-income', label: 'Passive Income', icon: DollarSign, path: '/passive-income', description: 'Income tracking', category: 'core' }
  ];

  const categories = {
    core: { label: 'Core', color: 'text-gray-300' },
    ai: { label: 'AI Systems', color: 'text-gray-400' },
    tools: { label: 'Tools', color: 'text-gray-300' },
    system: { label: 'System', color: 'text-gray-400' }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (toolbarRef.current && !toolbarRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleNavigate = (path: string) => {
    setLocation(path);
    setIsOpen(false);
  };

  const getCategoryItems = (category: keyof typeof categories) => 
    toolbarItems.filter(item => item.category === category);

  return (
    <div className="fixed top-4 left-4 z-50" ref={toolbarRef}>
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.08 }}
      >
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className={`
            w-12 h-12 rounded-full bg-black/80 backdrop-blur-md border border-gray-800/50
            hover:bg-gray-900/80 transition-ultra-fast shadow-lg
            ${isOpen ? 'ring-2 ring-gray-500/50' : ''}
          `}
          size="sm"
        >
          {isOpen ? (
            <X className="w-6 h-6 text-gray-300" />
          ) : (
            <SkullMask className="w-6 h-6 text-gray-300" />
          )}
        </Button>
      </motion.div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -10 }}
            transition={{ duration: 0.08, ease: "easeOut" }}
            className="absolute left-0 mt-2 w-80 max-h-96 overflow-y-auto"
          >
            <div className="bg-black/90 backdrop-blur-lg border border-gray-800/50 rounded-lg shadow-xl">
              <div className="p-3 border-b border-gray-800/50">
                <div className="flex items-center space-x-2">
                  <SkullMask className="w-5 h-5 text-gray-300" />
                  <h3 className="text-white font-semibold">Storm Echo RI Toolkit</h3>
                </div>
                <p className="text-xs text-gray-400 mt-1">Access all systems and features</p>
              </div>

              <div className="p-2 max-h-80 overflow-y-auto scroll-smooth">
                {Object.entries(categories).map(([key, category]) => {
                  const items = getCategoryItems(key as keyof typeof categories);
                  if (items.length === 0) return null;

                  return (
                    <div key={key} className="mb-4 last:mb-0">
                      <div className="px-2 py-1 mb-2">
                        <h4 className={`text-xs font-semibold ${category.color} uppercase tracking-wide`}>
                          {category.label}
                        </h4>
                      </div>
                      
                      <div className="space-y-1">
                        {items.map((item) => (
                          <motion.button
                            key={item.id}
                            onClick={() => handleNavigate(item.path)}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            className="w-full p-2 rounded-md bg-gray-900/50 hover:bg-gray-800/60 
                                     border border-gray-800/30 hover:border-gray-700/50 
                                     transition-ultra-fast text-left group"
                          >
                            <div className="flex items-center space-x-3">
                              <item.icon className={`w-4 h-4 ${category.color} group-hover:scale-110 transition-transform`} />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2">
                                  <span className="text-sm font-medium text-white group-hover:text-cyan-300 transition-colors">
                                    {item.label}
                                  </span>
                                  {item.badge && (
                                    <Badge 
                                      variant="outline" 
                                      className="text-xs bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
                                    >
                                      {item.badge}
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-xs text-gray-400 truncate mt-0.5">
                                  {item.description}
                                </p>
                              </div>
                            </div>
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-3 border-t border-gray-700/50 bg-gray-800/30">
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>Quick Access Toolbar</span>
                  <span className="flex items-center space-x-1">
                    <Shield className="w-3 h-3" />
                    <span>Secure</span>
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}