import { useEffect, useState } from 'react';
import { masterLoop } from '@/lib/master-loop';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Link, Link2Off, Terminal } from 'lucide-react';
import { motion } from 'framer-motion';

export function TerminalStatusMonitor() {
  const [sessions, setSessions] = useState(masterLoop.getAllSessionsStatus());

  useEffect(() => {
    const interval = setInterval(() => {
      setSessions(masterLoop.getAllSessionsStatus());
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-black/70 border-cyan-500/30 p-4">
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-5 h-5 text-cyan-400" />
        <h3 className="text-lg font-semibold text-cyan-300">Terminal AI Status</h3>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {sessions.map((session) => (
          <motion.div
            key={session.id}
            className="p-3 bg-black/50 border border-cyan-500/20 rounded-lg"
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center justify-between mb-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              {session.aiLinked ? (
                <Link className="w-4 h-4 text-green-400" />
              ) : (
                <Link2Off className="w-4 h-4 text-red-400" />
              )}
            </div>
            
            <h4 className="text-sm font-medium text-white mb-1">{session.name}</h4>
            
            <Badge
              variant={session.status === 'active' ? 'default' : 'secondary'}
              className={`text-xs ${
                session.status === 'active' 
                  ? 'bg-green-500/20 text-green-300 border-green-500/30' 
                  : session.status === 'idle'
                  ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
                  : 'bg-red-500/20 text-red-300 border-red-500/30'
              }`}
            >
              {session.status}
            </Badge>
            
            <p className="text-xs text-gray-400 mt-2">
              Last: {new Date(session.lastActivity).toLocaleTimeString()}
            </p>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}