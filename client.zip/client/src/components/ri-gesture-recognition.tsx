import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Hand, Eye, Zap, Activity, Sparkles } from 'lucide-react';

interface GestureData {
  id: string;
  type: 'wave' | 'point' | 'swipe' | 'circle' | 'unknown';
  confidence: number;
  timestamp: Date;
  x: number;
  y: number;
}

interface MouseTrail {
  x: number;
  y: number;
  timestamp: number;
}

export function RIGestureRecognition() {
  const [isActive, setIsActive] = useState(false);
  const [currentGesture, setCurrentGesture] = useState<GestureData | null>(null);
  const [gestureHistory, setGestureHistory] = useState<GestureData[]>([]);
  const [mouseTrail, setMouseTrail] = useState<MouseTrail[]>([]);
  const [isDetecting, setIsDetecting] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const trailRef = useRef<MouseTrail[]>([]);
  const animationRef = useRef<number>();

  // Gesture pattern recognition
  const recognizeGesture = useCallback((trail: MouseTrail[]): GestureData => {
    if (trail.length < 5) {
      return {
        id: Date.now().toString(),
        type: 'unknown',
        confidence: 0,
        timestamp: new Date(),
        x: trail[trail.length - 1]?.x || 0,
        y: trail[trail.length - 1]?.y || 0
      };
    }

    const startPoint = trail[0];
    const endPoint = trail[trail.length - 1];
    const midPoint = trail[Math.floor(trail.length / 2)];
    
    const totalDistance = trail.reduce((acc, point, index) => {
      if (index === 0) return 0;
      const prev = trail[index - 1];
      return acc + Math.sqrt(Math.pow(point.x - prev.x, 2) + Math.pow(point.y - prev.y, 2));
    }, 0);

    const straightLineDistance = Math.sqrt(
      Math.pow(endPoint.x - startPoint.x, 2) + Math.pow(endPoint.y - startPoint.y, 2)
    );

    const circularityRatio = totalDistance / (straightLineDistance || 1);
    
    // Detect gesture patterns
    let gestureType: GestureData['type'] = 'unknown';
    let confidence = 0;

    if (circularityRatio > 3 && totalDistance > 100) {
      gestureType = 'circle';
      confidence = Math.min(0.9, circularityRatio / 5);
    } else if (straightLineDistance > 80 && circularityRatio < 1.5) {
      const angle = Math.atan2(endPoint.y - startPoint.y, endPoint.x - startPoint.x);
      if (Math.abs(angle) < Math.PI / 4 || Math.abs(angle) > 3 * Math.PI / 4) {
        gestureType = 'swipe';
        confidence = 0.8;
      }
    } else if (totalDistance < 50 && trail.length > 10) {
      gestureType = 'point';
      confidence = 0.7;
    } else if (totalDistance > 60 && circularityRatio > 1.5 && circularityRatio < 3) {
      gestureType = 'wave';
      confidence = 0.75;
    }

    return {
      id: Date.now().toString(),
      type: gestureType,
      confidence,
      timestamp: new Date(),
      x: endPoint.x,
      y: endPoint.y
    };
  }, []);

  // Mouse trail animation
  useEffect(() => {
    const animate = () => {
      setMouseTrail(current => {
        const now = Date.now();
        return current.filter(point => now - point.timestamp < 2000);
      });
      animationRef.current = requestAnimationFrame(animate);
    };
    
    if (isActive) {
      animationRef.current = requestAnimationFrame(animate);
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isActive]);

  // Mouse tracking
  useEffect(() => {
    if (!isActive || !containerRef.current) return;

    const container = containerRef.current;
    let isTracking = false;

    const handleMouseDown = (e: MouseEvent) => {
      isTracking = true;
      setIsDetecting(true);
      trailRef.current = [];
      
      const rect = container.getBoundingClientRect();
      const point = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        timestamp: Date.now()
      };
      
      trailRef.current.push(point);
      setMouseTrail([point]);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isTracking) return;
      
      const rect = container.getBoundingClientRect();
      const point = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        timestamp: Date.now()
      };
      
      trailRef.current.push(point);
      setMouseTrail(current => [...current, point]);
    };

    const handleMouseUp = () => {
      if (!isTracking) return;
      
      isTracking = false;
      setIsDetecting(false);
      
      const gesture = recognizeGesture(trailRef.current);
      if (gesture.confidence > 0.5) {
        setCurrentGesture(gesture);
        setGestureHistory(prev => [gesture, ...prev.slice(0, 9)]);
        
        // Clear current gesture after delay
        setTimeout(() => setCurrentGesture(null), 3000);
      }
      
      // Clear trail
      setTimeout(() => {
        setMouseTrail([]);
        trailRef.current = [];
      }, 1000);
    };

    container.addEventListener('mousedown', handleMouseDown);
    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseup', handleMouseUp);
    container.addEventListener('mouseleave', handleMouseUp);

    return () => {
      container.removeEventListener('mousedown', handleMouseDown);
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseup', handleMouseUp);
      container.removeEventListener('mouseleave', handleMouseUp);
    };
  }, [isActive, recognizeGesture]);

  const getGestureIcon = (type: GestureData['type']) => {
    switch (type) {
      case 'wave': return <Hand className="text-yellow-400" size={16} />;
      case 'point': return <Eye className="text-blue-400" size={16} />;
      case 'swipe': return <Zap className="text-green-400" size={16} />;
      case 'circle': return <Activity className="text-purple-400" size={16} />;
      default: return <Sparkles className="text-gray-400" size={16} />;
    }
  };

  const getGestureColor = (type: GestureData['type']) => {
    switch (type) {
      case 'wave': return 'text-yellow-400';
      case 'point': return 'text-blue-400';
      case 'swipe': return 'text-green-400';
      case 'circle': return 'text-purple-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <Hand className="mr-2" size={20} />
          RI Gesture Recognition
        </h3>
        <motion.button
          onClick={() => setIsActive(!isActive)}
          className={`px-4 py-2 rounded-lg transition-colors ${
            isActive 
              ? 'bg-cyan-400/20 text-cyan-400' 
              : 'bg-gray-600/20 text-gray-400'
          }`}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {isActive ? 'Active' : 'Inactive'}
        </motion.button>
      </div>

      {/* Gesture Detection Area */}
      <div
        ref={containerRef}
        className={`relative h-64 rounded-lg border-2 border-dashed transition-colors mb-6 ${
          isActive 
            ? 'border-cyan-400/50 bg-cyan-400/5' 
            : 'border-gray-600/50 bg-gray-600/5'
        }`}
      >
        {!isActive && (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-gray-400">Activate to start gesture recognition</p>
          </div>
        )}
        
        {isActive && (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-cyan-400/70">
              {isDetecting ? 'Detecting gesture...' : 'Draw gestures here'}
            </p>
          </div>
        )}

        {/* Mouse Trail */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {mouseTrail.length > 1 && (
            <path
              d={`M ${mouseTrail.map(point => `${point.x},${point.y}`).join(' L ')}`}
              fill="none"
              stroke="url(#trailGradient)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
          <defs>
            <linearGradient id="trailGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(6, 182, 212, 0.8)" />
              <stop offset="100%" stopColor="rgba(6, 182, 212, 0.2)" />
            </linearGradient>
          </defs>
        </svg>

        {/* Trail Points */}
        {mouseTrail.map((point, index) => (
          <motion.div
            key={index}
            className="absolute w-2 h-2 bg-cyan-400 rounded-full pointer-events-none"
            style={{
              left: point.x - 4,
              top: point.y - 4,
            }}
            initial={{ scale: 1, opacity: 1 }}
            animate={{ scale: 0, opacity: 0 }}
            transition={{ duration: 2 }}
          />
        ))}
      </div>

      {/* Current Gesture Display */}
      <AnimatePresence>
        {currentGesture && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-4 p-4 bg-black/20 rounded-lg border border-cyan-400/30"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {getGestureIcon(currentGesture.type)}
                <div>
                  <p className={`font-semibold capitalize ${getGestureColor(currentGesture.type)}`}>
                    {currentGesture.type} Gesture
                  </p>
                  <p className="text-sm text-gray-400">
                    Confidence: {Math.round(currentGesture.confidence * 100)}%
                  </p>
                </div>
              </div>
              <div className="text-right text-xs text-gray-500">
                {currentGesture.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Gesture History */}
      {gestureHistory.length > 0 && (
        <div>
          <h4 className="text-lg font-semibold text-cyan-400 mb-3">Recent Gestures</h4>
          <div className="space-y-2">
            {gestureHistory.slice(0, 5).map((gesture) => (
              <motion.div
                key={gesture.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between p-2 bg-black/20 rounded"
              >
                <div className="flex items-center space-x-2">
                  {getGestureIcon(gesture.type)}
                  <span className={`text-sm capitalize ${getGestureColor(gesture.type)}`}>
                    {gesture.type}
                  </span>
                  <span className="text-xs text-gray-500">
                    ({Math.round(gesture.confidence * 100)}%)
                  </span>
                </div>
                <span className="text-xs text-gray-500">
                  {gesture.timestamp.toLocaleTimeString()}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}