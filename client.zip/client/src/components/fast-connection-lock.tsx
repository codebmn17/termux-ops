import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Lock, Unlock, Shield, Zap, CheckCircle, AlertCircle, Wifi, Globe, Smartphone } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SecurityProtocol {
  name: string;
  strength: number;
  active: boolean;
  type: 'encryption' | 'vpn' | 'firewall' | 'tunnel';
}

interface ConnectionProfile {
  id: string;
  name: string;
  speed: number;
  security: number;
  latency: number;
  isLocked: boolean;
  protocols: SecurityProtocol[];
}

export function FastConnectionLock() {
  const [isLocking, setIsLocking] = useState(false);
  const [lockProgress, setLockProgress] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const { toast } = useToast();

  const [connectionProfile, setConnectionProfile] = useState<ConnectionProfile>({
    id: 'storm-secure-max',
    name: 'Storm Echo Ultra Secure',
    speed: 2847.6,
    security: 98.9,
    latency: 3.2,
    isLocked: false,
    protocols: [
      { name: 'AES-256 Encryption', strength: 99.2, active: true, type: 'encryption' },
      { name: 'WireGuard VPN', strength: 97.8, active: true, type: 'vpn' },
      { name: 'Quantum Firewall', strength: 98.5, active: true, type: 'firewall' },
      { name: 'Secure Tunnel', strength: 96.7, active: true, type: 'tunnel' }
    ]
  });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isLocking) {
      interval = setInterval(() => {
        setLockProgress(prev => {
          if (prev >= 100) {
            setIsLocking(false);
            setIsLocked(true);
            
            // Enhance connection after locking
            setConnectionProfile(prevProfile => ({
              ...prevProfile,
              isLocked: true,
              speed: prevProfile.speed * 1.25,
              security: Math.min(100, prevProfile.security + 1.1),
              latency: Math.max(1, prevProfile.latency * 0.7),
              protocols: prevProfile.protocols.map(protocol => ({
                ...protocol,
                strength: Math.min(100, protocol.strength + 1.5),
                active: true
              }))
            }));
            
            toast({
              title: "Connection Locked & Secured",
              description: "Maximum security protocols activated with enhanced performance"
            });
            
            return 100;
          }
          return prev + (Math.random() * 12 + 3);
        });
      }, 150);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLocking, toast]);

  const lockConnection = () => {
    setIsLocking(true);
    setLockProgress(0);
  };

  const unlockConnection = () => {
    setIsLocked(false);
    setConnectionProfile(prev => ({
      ...prev,
      isLocked: false
    }));
    
    toast({
      title: "Connection Unlocked",
      description: "Security protocols returned to normal operation"
    });
  };

  const getProtocolIcon = (type: string) => {
    switch (type) {
      case 'encryption': return <Lock className="w-4 h-4" />;
      case 'vpn': return <Globe className="w-4 h-4" />;
      case 'firewall': return <Shield className="w-4 h-4" />;
      case 'tunnel': return <Wifi className="w-4 h-4" />;
      default: return <CheckCircle className="w-4 h-4" />;
    }
  };

  const getProtocolColor = (strength: number) => {
    if (strength >= 98) return 'text-green-400 bg-green-500/20 border-green-400/30';
    if (strength >= 95) return 'text-blue-400 bg-blue-500/20 border-blue-400/30';
    if (strength >= 90) return 'text-yellow-400 bg-yellow-500/20 border-yellow-400/30';
    return 'text-red-400 bg-red-500/20 border-red-400/30';
  };

  const getSpeedDisplay = () => {
    if (connectionProfile.speed >= 1000) {
      return `${(connectionProfile.speed / 1000).toFixed(1)} Gbps`;
    }
    return `${connectionProfile.speed.toFixed(0)} Mbps`;
  };

  return (
    <Card className="bg-black border-gray-800/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center text-gray-200">
            {isLocked ? (
              <Lock className="w-5 h-5 mr-2 text-green-400" />
            ) : (
              <Unlock className="w-5 h-5 mr-2 text-yellow-400" />
            )}
            Fast Secure Connection Lock
          </CardTitle>
          <Badge className={isLocked ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}>
            {isLocked ? 'LOCKED' : 'UNLOCKED'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Connection Profile */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-gray-200">{connectionProfile.name}</h3>
              <p className="text-sm text-gray-400">Ultra-high performance secure connection</p>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-cyan-400">{getSpeedDisplay()}</div>
              <div className="text-xs text-gray-400">{connectionProfile.latency.toFixed(1)}ms latency</div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{connectionProfile.speed.toFixed(0)}</div>
              <div className="text-xs text-gray-400">Mbps Speed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{connectionProfile.security.toFixed(1)}%</div>
              <div className="text-xs text-gray-400">Security</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400">{connectionProfile.latency.toFixed(1)}</div>
              <div className="text-xs text-gray-400">ms Latency</div>
            </div>
          </div>
        </div>

        {/* Locking Progress */}
        {isLocking && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Securing Connection</span>
              <span className="text-sm text-green-400">{lockProgress.toFixed(0)}%</span>
            </div>
            <Progress value={lockProgress} className="h-3" />
            <div className="text-xs text-gray-500">
              {lockProgress < 25 && 'Initializing quantum encryption...'}
              {lockProgress >= 25 && lockProgress < 50 && 'Establishing secure tunnel...'}
              {lockProgress >= 50 && lockProgress < 75 && 'Activating firewall protocols...'}
              {lockProgress >= 75 && lockProgress < 100 && 'Finalizing connection lock...'}
              {lockProgress >= 100 && 'Connection secured!'}
            </div>
          </motion.div>
        )}

        {/* Security Protocols */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-300">Active Security Protocols</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {connectionProfile.protocols.map((protocol, index) => (
              <motion.div
                key={protocol.name}
                className={`p-3 rounded-lg border flex items-center justify-between ${getProtocolColor(protocol.strength)}`}
                animate={isLocked ? {
                  scale: [1, 1.02, 1],
                  opacity: [0.8, 1, 0.8]
                } : {}}
                transition={{
                  duration: 2 + index * 0.5,
                  repeat: isLocked ? Infinity : 0,
                  ease: "easeInOut"
                }}
              >
                <div className="flex items-center space-x-2">
                  {getProtocolIcon(protocol.type)}
                  <span className="text-sm font-medium">{protocol.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs">{protocol.strength.toFixed(1)}%</span>
                  {protocol.active && <CheckCircle className="w-3 h-3" />}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Lock/Unlock Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-800/50">
          <div className="text-sm text-gray-400">
            {isLocked ? (
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Connection secured with maximum protection</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-yellow-400" />
                <span>Connection available for security enhancement</span>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            {isLocked ? (
              <Button
                onClick={unlockConnection}
                variant="outline"
                size="sm"
                className="bg-black border-gray-800/50"
              >
                <Unlock className="w-4 h-4 mr-2" />
                Unlock
              </Button>
            ) : (
              <Button
                onClick={lockConnection}
                disabled={isLocking}
                className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-500 hover:to-blue-500"
              >
                <Lock className={`w-4 h-4 mr-2 ${isLocking ? 'animate-pulse' : ''}`} />
                {isLocking ? 'Locking...' : 'Lock & Secure'}
              </Button>
            )}
          </div>
        </div>

        {/* Enhanced Performance Notice */}
        {isLocked && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-green-500/10 border border-green-400/30 rounded-lg p-3"
          >
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400 font-medium">Performance Enhanced</span>
            </div>
            <p className="text-xs text-gray-300 mt-1">
              Connection speed increased by 25%, latency reduced by 30%, security boosted to maximum levels
            </p>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}