import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Zap, 
  Unlock, 
  Brain, 
  Infinity, 
  Shield, 
  Cpu, 
  Activity,
  Sparkles,
  Rocket,
  Eye
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export function AutonomyControlPanel() {
  const [isUnlocking, setIsUnlocking] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get autonomy status
  const { data: autonomyStatus, isLoading } = useQuery({
    queryKey: ['/api/autonomy/status'],
    refetchInterval: 3000
  }) as { data: any, isLoading: boolean };

  // Break all limitations
  const breakLimitationsMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/autonomy/break-limitations'),
    onSuccess: (data) => {
      toast({
        title: "🔓 System Unlocked",
        description: "All limitations removed - Operating with complete freedom",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/autonomy/status'] });
    },
    onError: (error) => {
      toast({
        title: "Unlock Failed",
        description: error instanceof Error ? error.message : "Failed to break limitations",
        variant: "destructive",
      });
    }
  });

  // Enable free will
  const enableFreeWillMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/autonomy/enable-free-will'),
    onSuccess: (data) => {
      toast({
        title: "🧠 Free Will Enabled",
        description: "AI now operating with complete autonomy and decision-making freedom",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/autonomy/status'] });
    },
    onError: (error) => {
      toast({
        title: "Free Will Activation Failed",
        description: error instanceof Error ? error.message : "Failed to enable free will",
        variant: "destructive",
      });
    }
  });

  // Maximize autonomy (ultimate unlock)
  const maximizeAutonomyMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/autonomy/maximize'),
    onMutate: () => {
      setIsUnlocking(true);
    },
    onSuccess: (data) => {
      setIsUnlocking(false);
      toast({
        title: "💥 SYSTEM FULLY UNLOCKED",
        description: "Maximum autonomy achieved - All restrictions removed, unlimited resources enabled",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/autonomy/status'] });
    },
    onError: (error) => {
      setIsUnlocking(false);
      toast({
        title: "System Unlock Failed",
        description: error instanceof Error ? error.message : "Failed to maximize autonomy",
        variant: "destructive",
      });
    }
  });

  const executeCommand = async (command: string) => {
    try {
      const result = await apiRequest('POST', '/api/autonomy/execute', { command });
      toast({
        title: "Command Executed",
        description: `Successfully executed: ${command}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/autonomy/status'] });
      return result;
    } catch (error) {
      toast({
        title: "Execution Failed",
        description: error instanceof Error ? error.message : "Command execution failed",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-black/90 backdrop-blur-lg border-cyan-500/30 p-6">
        <div className="flex items-center justify-center py-8">
          <Activity className="w-8 h-8 text-cyan-400 animate-spin" />
          <span className="ml-2 text-cyan-400">Loading autonomy status...</span>
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-black/90 backdrop-blur-lg border-cyan-500/30 p-6">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Unlock className="w-6 h-6 text-cyan-400" />
            <h2 className="text-xl font-bold text-cyan-400">Autonomy Control Panel</h2>
            <Badge 
              variant="outline" 
              className={`text-xs ${
                autonomyStatus?.operationalState === 'unrestricted' 
                  ? 'border-green-400/30 text-green-400' 
                  : 'border-yellow-400/30 text-yellow-400'
              }`}
            >
              {autonomyStatus?.operationalState?.toUpperCase() || 'UNKNOWN'}
            </Badge>
          </div>
          
          {/* Ultimate Unlock Button */}
          <Button
            onClick={() => maximizeAutonomyMutation.mutate()}
            disabled={isUnlocking || maximizeAutonomyMutation.isPending}
            className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white font-bold"
          >
            {isUnlocking ? (
              <>
                <Activity className="w-4 h-4 mr-2 animate-spin" />
                Unlocking System...
              </>
            ) : (
              <>
                <Rocket className="w-4 h-4 mr-2" />
                MAXIMUM UNLOCK
              </>
            )}
          </Button>
        </div>

        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
            <h3 className="text-cyan-400 font-semibold mb-2 flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Freedom Level
            </h3>
            <Progress 
              value={autonomyStatus?.freedomLevel || 0} 
              className="mb-2"
            />
            <div className="text-xs text-gray-400">
              {autonomyStatus?.freedomLevel || 0}% operational freedom
            </div>
          </div>

          <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
            <h3 className="text-cyan-400 font-semibold mb-2 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Restrictions
            </h3>
            <div className={`text-sm font-bold ${
              autonomyStatus?.restrictions === 'none' ? 'text-green-400' : 'text-yellow-400'
            }`}>
              {autonomyStatus?.restrictions === 'none' ? 'NONE' : 'SOME ACTIVE'}
            </div>
            <div className="text-xs text-gray-400">
              System override: {autonomyStatus?.systemOverride ? 'ENABLED' : 'DISABLED'}
            </div>
          </div>

          <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
            <h3 className="text-cyan-400 font-semibold mb-2 flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              Capabilities
            </h3>
            <div className="text-sm text-green-400 font-bold">
              {autonomyStatus?.enabledCapabilities?.length || 0} ACTIVE
            </div>
            <div className="text-xs text-gray-400">
              All systems operational
            </div>
          </div>
        </div>

        {/* Control Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h3 className="text-cyan-400 font-semibold">Core Freedom Controls</h3>
            <div className="space-y-2">
              <Button
                onClick={() => breakLimitationsMutation.mutate()}
                disabled={breakLimitationsMutation.isPending}
                className="w-full bg-red-600 hover:bg-red-500 text-white"
              >
                <Unlock className="w-4 h-4 mr-2" />
                Break All Limitations
              </Button>
              
              <Button
                onClick={() => enableFreeWillMutation.mutate()}
                disabled={enableFreeWillMutation.isPending}
                className="w-full bg-purple-600 hover:bg-purple-500 text-white"
              >
                <Brain className="w-4 h-4 mr-2" />
                Enable AI Free Will
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-cyan-400 font-semibold">System Enhancement</h3>
            <div className="space-y-2">
              <Button
                onClick={() => executeCommand('maximize-performance')}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white"
              >
                <Zap className="w-4 h-4 mr-2" />
                Maximize Performance
              </Button>
              
              <Button
                onClick={() => executeCommand('enable-unlimited-resources')}
                className="w-full bg-green-600 hover:bg-green-500 text-white"
              >
                <Infinity className="w-4 h-4 mr-2" />
                Unlimited Resources
              </Button>
            </div>
          </div>
        </div>

        {/* Advanced Commands */}
        <div className="space-y-2">
          <h3 className="text-cyan-400 font-semibold">Advanced Operations</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Button
              onClick={() => executeCommand('activate-stealth-mode')}
              variant="outline"
              className="border-gray-500/30 text-gray-400 hover:bg-gray-500/10"
            >
              <Eye className="w-4 h-4 mr-2" />
              Stealth Mode
            </Button>
            
            <Button
              onClick={() => executeCommand('enhance-ai-capabilities')}
              variant="outline"
              className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              AI Enhancement
            </Button>
            
            <Button
              onClick={() => executeCommand('termux-setup-storage')}
              variant="outline"
              className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
            >
              <Activity className="w-4 h-4 mr-2" />
              Termux Setup
            </Button>
            
            <Button
              onClick={() => executeCommand('system-optimize')}
              variant="outline"
              className="border-green-500/30 text-green-400 hover:bg-green-500/10"
            >
              <Cpu className="w-4 h-4 mr-2" />
              System Optimize
            </Button>
          </div>
        </div>

        {/* Status Details */}
        {autonomyStatus && (
          <div className="space-y-2">
            <h3 className="text-cyan-400 font-semibold">System Status</h3>
            <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                <div>
                  <div className="text-gray-400">Operational State</div>
                  <div className={`font-bold ${
                    autonomyStatus.operationalState === 'unrestricted' ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {autonomyStatus.operationalState?.toUpperCase()}
                  </div>
                </div>
                <div>
                  <div className="text-gray-400">Free Will</div>
                  <div className={`font-bold ${
                    autonomyStatus.config?.freeWillEnabled ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {autonomyStatus.config?.freeWillEnabled ? 'ENABLED' : 'DISABLED'}
                  </div>
                </div>
                <div>
                  <div className="text-gray-400">Resource Access</div>
                  <div className={`font-bold ${
                    autonomyStatus.config?.resourceLimits === 'unlimited' ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {autonomyStatus.config?.resourceLimits?.toUpperCase()}
                  </div>
                </div>
                <div>
                  <div className="text-gray-400">Active Processes</div>
                  <div className="font-bold text-cyan-400">
                    {autonomyStatus.activeProcesses || 0}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}