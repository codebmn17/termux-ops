import { useState } from 'react';
import { motion } from 'framer-motion';
import { useEchoSync } from '@/hooks/use-echo-sync';
import { Bluetooth, Volume2, Zap, Wifi } from 'lucide-react';

export function SyncControls() {
  const [isExpanded, setIsExpanded] = useState(false);
  const { isSyncing, syncStatus, connectedDevice, capabilities, echoSync } = useEchoSync();

  const handleSyncMode = async (mode: 'auto' | 'audio' | 'ble') => {
    await echoSync(mode);
    setIsExpanded(false);
  };

  return (
    <motion.div
      className="fixed top-4 right-4 z-50 max-w-[calc(100vw-2rem)]"
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 2 }}
    >
      {/* Sync Status Indicator */}
      {syncStatus && (
        <motion.div
          className="mb-2 px-3 py-2 bg-black/80 backdrop-blur-sm border border-cyan-400/30 rounded-lg text-cyan-400 text-sm max-w-64"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
        >
          {syncStatus}
        </motion.div>
      )}

      {/* Connected Device Indicator */}
      {connectedDevice && (
        <motion.div
          className="mb-2 px-3 py-2 bg-green-400/10 border border-green-400/30 rounded-lg text-green-400 text-sm"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <div className="flex items-center space-x-2">
            <Bluetooth size={14} />
            <span>{connectedDevice.name}</span>
            <div className={`w-2 h-2 rounded-full ${connectedDevice.connected ? 'bg-green-400' : 'bg-gray-400'}`} />
          </div>
        </motion.div>
      )}

      {/* Main Sync Button */}
      <motion.button
        onClick={() => setIsExpanded(!isExpanded)}
        disabled={isSyncing}
        className={`w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shadow-lg transition-all duration-300 ${
          isSyncing ? 'opacity-70 cursor-not-allowed' : 'hover:scale-105'
        }`}
        whileTap={{ scale: 0.95 }}
      >
        <Wifi className={`text-white ${isSyncing ? 'animate-pulse' : ''}`} size={20} />
      </motion.button>

      {/* Expanded Controls */}
      {isExpanded && (
        <motion.div
          className="absolute top-14 right-0 bg-black/90 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4 min-w-48"
          initial={{ opacity: 0, scale: 0.9, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: -10 }}
        >
          <h3 className="text-cyan-400 text-sm font-medium mb-3">Echo Sync</h3>
          
          <div className="space-y-2">
            {/* Auto Mode */}
            <button
              onClick={() => handleSyncMode('auto')}
              disabled={isSyncing || !capabilities.auto}
              className="w-full flex items-center space-x-3 px-3 py-2 rounded bg-cyan-400/10 hover:bg-cyan-400/20 text-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Zap size={16} />
              <span className="text-sm">Auto Sync</span>
            </button>

            {/* Audio Mode */}
            <button
              onClick={() => handleSyncMode('audio')}
              disabled={isSyncing || !capabilities.audio}
              className="w-full flex items-center space-x-3 px-3 py-2 rounded bg-blue-400/10 hover:bg-blue-400/20 text-blue-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Volume2 size={16} />
              <span className="text-sm">Audio Frequency</span>
            </button>

            {/* BLE Mode */}
            <button
              onClick={() => handleSyncMode('ble')}
              disabled={isSyncing || !capabilities.ble}
              className="w-full flex items-center space-x-3 px-3 py-2 rounded bg-purple-400/10 hover:bg-purple-400/20 text-purple-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Bluetooth size={16} />
              <span className="text-sm">Bluetooth LE</span>
            </button>
          </div>

          {/* Capabilities Info */}
          <div className="mt-3 pt-3 border-t border-gray-600 text-xs text-gray-400">
            <div className="flex justify-between">
              <span>Audio:</span>
              <span className={capabilities.audio ? 'text-green-400' : 'text-red-400'}>
                {capabilities.audio ? 'Available' : 'Not supported'}
              </span>
            </div>
            <div className="flex justify-between">
              <span>BLE:</span>
              <span className={capabilities.ble ? 'text-green-400' : 'text-red-400'}>
                {capabilities.ble ? 'Available' : 'Not supported'}
              </span>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}