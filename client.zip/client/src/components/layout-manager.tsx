import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Maximize2, Minimize2, Settings, X } from 'lucide-react';

interface LayoutManagerProps {
  children: React.ReactNode;
}

export function LayoutManager({ children }: LayoutManagerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [layoutMode, setLayoutMode] = useState<'normal' | 'compact' | 'expanded'>('normal');
  const [showLayoutControls, setShowLayoutControls] = useState(false);

  // Handle fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  // Handle layout changes
  const cycleLayoutMode = () => {
    setLayoutMode(prev => {
      switch (prev) {
        case 'normal': return 'compact';
        case 'compact': return 'expanded';
        case 'expanded': return 'normal';
        default: return 'normal';
      }
    });
  };

  // Listen for fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  return (
    <div className={`relative min-h-screen transition-all duration-300 ${
      layoutMode === 'compact' ? 'p-2' : layoutMode === 'expanded' ? 'p-8' : 'p-4'
    }`}>
      {/* Layout Controls - Top Right - Viewport Safe */}
      <motion.div
        className="fixed top-4 right-4 z-40 flex items-center space-x-2 max-w-[calc(100vw-2rem)]"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {/* Layout Mode Toggle */}
        <motion.button
          onClick={cycleLayoutMode}
          className="p-2 bg-gray-800/80 hover:bg-gray-700/80 rounded-lg border border-gray-600/50 backdrop-blur-sm transition-all"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          title={`Layout: ${layoutMode}`}
        >
          <Settings size={16} className="text-cyan-400" />
        </motion.button>

        {/* Fullscreen Toggle */}
        <motion.button
          onClick={toggleFullscreen}
          className="p-2 bg-gray-800/80 hover:bg-gray-700/80 rounded-lg border border-gray-600/50 backdrop-blur-sm transition-all"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
        >
          {isFullscreen ? (
            <Minimize2 size={16} className="text-purple-400" />
          ) : (
            <Maximize2 size={16} className="text-purple-400" />
          )}
        </motion.button>

        {/* Layout Controls Toggle */}
        <motion.button
          onClick={() => setShowLayoutControls(!showLayoutControls)}
          className="p-2 bg-gray-800/80 hover:bg-gray-700/80 rounded-lg border border-gray-600/50 backdrop-blur-sm transition-all"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          title="Layout Options"
        >
          {showLayoutControls ? (
            <X size={16} className="text-red-400" />
          ) : (
            <Settings size={16} className="text-green-400" />
          )}
        </motion.button>
      </motion.div>

      {/* Layout Controls Panel - Viewport Safe */}
      {showLayoutControls && (
        <motion.div
          className="fixed top-16 right-4 left-4 sm:left-auto sm:w-64 z-50 bg-gray-900/90 backdrop-blur-md border border-cyan-400/30 rounded-lg p-4 shadow-2xl max-w-[calc(100vw-2rem)]"
          initial={{ opacity: 0, scale: 0.9, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: -20 }}
        >
          <h3 className="text-cyan-400 font-semibold mb-3 text-sm">Layout Options</h3>
          
          <div className="space-y-2">
            <button
              onClick={() => setLayoutMode('normal')}
              className={`w-full px-3 py-2 rounded-lg border transition-all text-sm ${
                layoutMode === 'normal'
                  ? 'bg-cyan-600/30 border-cyan-400 text-cyan-300'
                  : 'bg-gray-800/50 border-gray-600 text-gray-300 hover:bg-gray-700/50'
              }`}
            >
              Normal Layout
            </button>
            
            <button
              onClick={() => setLayoutMode('compact')}
              className={`w-full px-3 py-2 rounded-lg border transition-all text-sm ${
                layoutMode === 'compact'
                  ? 'bg-cyan-600/30 border-cyan-400 text-cyan-300'
                  : 'bg-gray-800/50 border-gray-600 text-gray-300 hover:bg-gray-700/50'
              }`}
            >
              Compact Layout
            </button>
            
            <button
              onClick={() => setLayoutMode('expanded')}
              className={`w-full px-3 py-2 rounded-lg border transition-all text-sm ${
                layoutMode === 'expanded'
                  ? 'bg-cyan-600/30 border-cyan-400 text-cyan-300'
                  : 'bg-gray-800/50 border-gray-600 text-gray-300 hover:bg-gray-700/50'
              }`}
            >
              Expanded Layout
            </button>
          </div>

          <div className="mt-3 pt-3 border-t border-gray-700 text-xs text-gray-400">
            <div className="flex justify-between">
              <span>Mode:</span>
              <span className="text-cyan-400 capitalize">{layoutMode}</span>
            </div>
          </div>
        </motion.div>
      )}

      {/* Main Content */}
      <div className={`transition-all duration-300 ${
        layoutMode === 'compact' ? 'max-w-4xl mx-auto' : 
        layoutMode === 'expanded' ? 'max-w-7xl mx-auto' : 'max-w-6xl mx-auto'
      }`}>
        {children}
      </div>
    </div>
  );
}