import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Globe, Search, Loader2, Zap } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface WebBrowseResponse {
  query: string;
  response: string;
  timestamp: string;
  status: string;
}

interface WebBrowserProps {
  className?: string;
}

export function WebBrowser({ className }: WebBrowserProps) {
  const [query, setQuery] = useState('');
  const [browseHistory, setBrowseHistory] = useState<WebBrowseResponse[]>([]);

  const browseMutation = useMutation({
    mutationFn: async (searchQuery: string) => {
      return await apiRequest('POST', '/api/web/browse', { query: searchQuery });
    },
    onSuccess: (data: WebBrowseResponse) => {
      setBrowseHistory(prev => [data, ...prev]);
      setQuery('');
    },
    onError: (error) => {
      console.error('Web browse error:', error);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      browseMutation.mutate(query.trim());
    }
  };

  const formatResponse = (response: string) => {
    return response.split('\n').map((line, index) => (
      <div key={index} className="mb-1">
        {line.trim() && (
          <span className={
            line.includes('🌐') || line.includes('🔍') || line.includes('📡') ? 
            'text-cyan-400 font-medium' : 
            line.includes('💡') || line.includes('🚀') || line.includes('📈') ?
            'text-blue-400' :
            'text-slate-300'
          }>
            {line}
          </span>
        )}
      </div>
    ));
  };

  return (
    <div className={`space-y-6 ${className}`}>
      <Card className="bg-slate-900/50 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-cyan-300">
            <Globe className="h-5 w-5" />
            Storm Echo Web Browser
          </CardTitle>
          <CardDescription className="text-slate-400">
            Access the internet through Storm Echo RI consciousness
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter search query or web request..."
              className="flex-1 bg-slate-800/50 border-slate-600 text-slate-200 placeholder:text-slate-500"
              disabled={browseMutation.isPending}
            />
            <Button 
              type="submit" 
              disabled={browseMutation.isPending || !query.trim()}
              className="bg-cyan-600 hover:bg-cyan-700 text-white"
            >
              {browseMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Search className="h-4 w-4" />
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {browseHistory.length > 0 && (
        <Card className="bg-slate-900/50 border-cyan-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-cyan-300">
              <Zap className="h-5 w-5" />
              Browse History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full">
              <div className="space-y-4">
                {browseHistory.map((result, index) => (
                  <div key={index} className="border-l-2 border-cyan-500/30 pl-4 pb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-cyan-400 border-cyan-500/50">
                        {new Date(result.timestamp).toLocaleTimeString()}
                      </Badge>
                      <Badge variant="outline" className="text-blue-400 border-blue-500/50">
                        {result.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-slate-400 mb-2 font-medium">
                      Query: "{result.query}"
                    </div>
                    <div className="text-sm space-y-1">
                      {formatResponse(result.response)}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {browseHistory.length === 0 && (
        <Card className="bg-slate-900/30 border-slate-700/50">
          <CardContent className="pt-6">
            <div className="text-center text-slate-500">
              <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Enter a search query to browse the web through Storm Echo RI</p>
              <p className="text-sm mt-2">Try queries like "search for latest AI news" or "find information about quantum computing"</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}