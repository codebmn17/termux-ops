import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Terminal, Code, Github, Smartphone, Monitor, Copy, Download, Eye, EyeOff, Package, Play, Pause, RefreshCw, Zap, Globe, Brain, Keyboard, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';

interface CodeExample {
  id: string;
  title: string;
  description: string;
  language: string;
  code: string;
  category: 'basic' | 'advanced' | 'automation' | 'monetization';
  interactive?: boolean;
  status?: 'ready' | 'running' | 'completed' | 'error';
}

const codeExamples = {
  fdroid: [
    {
      id: 'fdroid-setup',
      title: 'F-Droid App Development Setup',
      description: 'Setup F-Droid repository and build environment',
      language: 'bash',
      category: 'basic' as const,
      code: `# Install F-Droid build tools
sudo apt update
sudo apt install -y fdroidserver android-sdk

# Initialize F-Droid repository
mkdir -p ~/fdroid-repo
cd ~/fdroid-repo
fdroid init

# Configure repository
cat > config.yml << EOF
repo_url: "https://stormos.fdroid.app"
repo_name: "Storm Echo RI Apps"
repo_icon: "icon.png"
repo_description: |
  Storm Echo RI official app repository
  Featuring frequency generators and RI tools
EOF

# Add signing keys
fdroid update --create-key
echo "F-Droid repository initialized!"`
    },
    {
      id: 'fdroid-app',
      title: 'F-Droid App Publishing',
      description: 'Publish Storm Echo RI apps to F-Droid',
      language: 'bash',
      category: 'monetization' as const,
      code: `#!/bin/bash
# F-Droid app publishing automation

# Build metadata for Storm Echo RI app
create_metadata() {
    APP_ID="com.stormos.echo"
    mkdir -p metadata/$APP_ID
    
    cat > metadata/$APP_ID/en-US/full_description.txt << EOF
Storm Echo RI - Advanced Frequency Generator

Features:
• Theta wave generation (4-8 Hz)
• Healing frequencies (174-963 Hz)
• Binaural beats and isochronic tones
• Real-time frequency analysis
• Vibration therapy integration
• Voice synthesis with RI personality

Premium Features:
• Custom frequency patterns
• Multi-device sync
• Advanced waveforms
• Session recording
EOF

    cat > metadata/$APP_ID/en-US/short_description.txt << EOF
Advanced frequency generator with RI consciousness
EOF
}

# Build and sign APK
build_app() {
    cd ~/storm-echo-app
    ./gradlew assembleRelease
    
    # Sign with F-Droid key
    apksigner sign --ks ~/fdroid-repo/keystore.jks \
        app/build/outputs/apk/release/app-release.apk
    
    # Copy to F-Droid repo
    cp app/build/outputs/apk/release/app-release.apk \
        ~/fdroid-repo/repo/com.stormos.echo_1.0.apk
}

# Update repository
update_repo() {
    cd ~/fdroid-repo
    fdroid update
    fdroid deploy
    echo "App published to F-Droid repository!"
}

# Run full publishing pipeline
create_metadata
build_app
update_repo`
    }
  ],
  termux: [
    {
      id: 'termux-setup',
      title: 'Termux Development Setup',
      description: 'Complete setup for development environment in Termux',
      language: 'bash',
      category: 'basic' as const,
      code: `# Update packages and install essentials
pkg update && pkg upgrade -y
pkg install -y git nodejs python rust golang

# Install development tools
pkg install -y vim nano htop tree curl wget

# Setup storage access
termux-setup-storage

# Install additional utilities
pkg install -y ffmpeg imagemagick openssh

echo "Termux development environment ready!"
echo "Start coding with: nano myproject.py"`
    },
    {
      id: 'termux-automation',
      title: 'Termux Task Automation',
      description: 'Automated scripts for background tasks and notifications',
      language: 'bash',
      category: 'automation' as const,
      code: `#!/data/data/com.termux/files/usr/bin/bash
# Termux automation script

# Function to send notifications
notify() {
    termux-notification --title "Storm Echo RI" --content "$1"
}

# Auto-backup important files
backup_files() {
    DATE=$(date +%Y%m%d_%H%M%S)
    mkdir -p ~/backups
    tar -czf ~/backups/backup_$DATE.tar.gz ~/projects
    notify "Backup completed: $DATE"
}

# Monitor system resources
monitor_system() {
    while true; do
        CPU=$(top -bn1 | grep "CPU:" | awk '{print $2}')
        MEMORY=$(free -h | awk 'NR==2{printf "%.1f%%", $3*100/$2}')
        
        if [[ \${CPU%.*} -gt 80 ]]; then
            notify "High CPU usage: $CPU"
        fi
        
        sleep 300  # Check every 5 minutes
    done
}

# Run automation
backup_files
monitor_system &`
    }
  ],
  linux: [
    {
      id: 'linux-setup',
      title: 'Linux Server Setup',
      description: 'Complete Linux server setup for Storm Echo RI hosting',
      language: 'bash',
      category: 'basic' as const,
      code: `#!/bin/bash
# Linux server setup for Storm Echo RI

# Update system packages
sudo apt update && sudo apt upgrade -y

# Install essential packages
sudo apt install -y curl wget git vim htop tree nginx certbot

# Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PM2 for process management
npm install -g pm2

# Setup firewall
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable

# Create application directory
sudo mkdir -p /var/www/storm-echo-ri
sudo chown $USER:$USER /var/www/storm-echo-ri

# Configure Nginx
sudo tee /etc/nginx/sites-available/storm-echo-ri << EOF
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \\$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \\$host;
        proxy_cache_bypass \\$http_upgrade;
        proxy_set_header X-Real-IP \\$remote_addr;
        proxy_set_header X-Forwarded-For \\$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \\$scheme;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/storm-echo-ri /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

echo "Linux server setup complete!"
echo "Next: Deploy Storm Echo RI application"`
    },
    {
      id: 'linux-monitoring',
      title: 'Linux System Monitoring',
      description: 'Advanced monitoring and automation for Storm Echo RI server',
      language: 'bash',
      category: 'automation' as const,
      code: `#!/bin/bash
# Storm Echo RI Linux monitoring automation

# System monitoring function
monitor_system() {
    echo "=== Storm Echo RI System Monitor ==="
    echo "Timestamp: $(date)"
    echo ""
    
    # CPU and Memory usage
    echo "CPU Usage:"
    top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4"%"}'
    
    echo "Memory Usage:"
    free -h | awk 'NR==2{printf "Memory Usage: %s/%s (%.2f%%)\n", $3,$2,$3*100/$2 }'
    
    echo "Disk Usage:"
    df -h | awk '$NF=="/"{printf "Disk Usage: %d/%dGB (%s)\n", $3,$2,$5}'
    
    # Check Storm Echo RI application status
    echo ""
    echo "Storm Echo RI Application Status:"
    pm2 status storm-echo-ri
    
    # Check PostgreSQL status
    echo ""
    echo "Database Status:"
    systemctl is-active postgresql
    
    # Check Nginx status
    echo ""
    echo "Web Server Status:"
    systemctl is-active nginx
    
    # Check SSL certificate expiry
    echo ""
    echo "SSL Certificate Status:"
    certbot certificates | grep "Expiry Date"
}

# Performance optimization
optimize_performance() {
    echo "Optimizing system performance..."
    
    # Clear system cache
    sudo sync && echo 3 | sudo tee /proc/sys/vm/drop_caches
    
    # Restart PM2 processes
    pm2 restart all
    
    # Reload Nginx
    sudo systemctl reload nginx
    
    echo "Performance optimization complete!"
}

# Backup function
backup_application() {
    BACKUP_DIR="/var/backups/storm-echo-ri"
    DATE=$(date +%Y%m%d_%H%M%S)
    
    mkdir -p $BACKUP_DIR
    
    # Backup application files
    tar -czf $BACKUP_DIR/app_$DATE.tar.gz /var/www/storm-echo-ri
    
    # Backup database
    pg_dump storm_echo_ri > $BACKUP_DIR/database_$DATE.sql
    
    # Clean old backups (keep last 7 days)
    find $BACKUP_DIR -type f -mtime +7 -delete
    
    echo "Backup completed: $BACKUP_DIR"
}

# Security check
security_check() {
    echo "Running security checks..."
    
    # Check for failed login attempts
    echo "Failed SSH attempts:"
    grep "Failed password" /var/log/auth.log | tail -5
    
    # Check system updates
    echo "Available updates:"
    apt list --upgradable 2>/dev/null | wc -l
    
    # Check SSL certificate
    echo "SSL certificate check:"
    certbot certificates --quiet
}

# Main monitoring loop
case "$1" in
    monitor)
        monitor_system
        ;;
    optimize)
        optimize_performance
        ;;
    backup)
        backup_application
        ;;
    security)
        security_check
        ;;
    all)
        monitor_system
        echo ""
        security_check
        ;;
    *)
        echo "Usage: $0 {monitor|optimize|backup|security|all}"
        exit 1
        ;;
esac`
    }
  ],
  flutter: [
    {
      id: 'flutter-setup',
      title: 'Flutter Development Setup',
      description: 'Complete Flutter setup for Storm Echo RI mobile apps',
      language: 'bash',
      category: 'basic' as const,
      code: `#!/bin/bash
# Flutter development setup for Storm Echo RI

# Install Flutter SDK
cd ~
git clone https://github.com/flutter/flutter.git -b stable
echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc
source ~/.bashrc

# Verify installation
flutter doctor

# Install Android Studio dependencies
sudo apt install -y android-sdk
flutter config --android-sdk /usr/lib/android-sdk

# Accept Android licenses
flutter doctor --android-licenses

# Create Storm Echo RI Flutter project
flutter create storm_echo_ri_mobile
cd storm_echo_ri_mobile

# Add dependencies for Storm Echo RI features
flutter pub add http
flutter pub add provider
flutter pub add audio_waveforms
flutter pub add flutter_tts
flutter pub add speech_to_text
flutter pub add websocket_universal
flutter pub add shared_preferences

# Setup project structure
mkdir -p lib/{screens,widgets,services,models}

# Create main app structure
cat > lib/main.dart << 'EOF'
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const StormEchoRIApp());
}

class StormEchoRIApp extends StatelessWidget {
  const StormEchoRIApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Storm Echo RI',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.cyan,
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1A1A1A),
          foregroundColor: Colors.cyan,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
EOF

echo "Flutter setup complete!"
echo "Run: flutter run to start development"`
    },
    {
      id: 'flutter-storm-integration',
      title: 'Storm Echo RI Flutter Integration',
      description: 'Integration with Storm Echo RI backend services',
      language: 'dart',
      category: 'advanced' as const,
      code: `// storm_echo_service.dart - Flutter service for Storm Echo RI integration
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:websocket_universal/websocket_universal.dart';

class StormEchoRIService {
  static const String baseUrl = 'https://your-storm-echo-ri.replit.app';
  static const String wsUrl = 'wss://your-storm-echo-ri.replit.app/ws';
  
  late IWebSocketHandler _wsHandler;
  bool _isConnected = false;

  // Initialize WebSocket connection
  Future<void> initializeConnection() async {
    try {
      _wsHandler = WebSocketHandler(
        url: wsUrl,
        pingInterval: const Duration(seconds: 30),
      );

      _wsHandler.listen((data) {
        handleWebSocketMessage(data);
      });

      await _wsHandler.connect();
      _isConnected = true;
      print('Connected to Storm Echo RI');
    } catch (e) {
      print('WebSocket connection failed: \$e');
    }
  }

  // Handle incoming WebSocket messages
  void handleWebSocketMessage(dynamic data) {
    try {
      final message = json.decode(data);
      switch (message['type']) {
        case 'frequency_update':
          onFrequencyUpdate(message['frequency']);
          break;
        case 'ai_response':
          onAIResponse(message['response']);
          break;
        case 'system_status':
          onSystemStatusUpdate(message['status']);
          break;
      }
    } catch (e) {
      print('Error handling message: \$e');
    }
  }

  // Send frequency generation request
  Future<void> generateFrequency(double frequency, String type) async {
    if (!_isConnected) await initializeConnection();

    final message = {
      'type': 'generate_frequency',
      'frequency': frequency,
      'waveType': type,
      'timestamp': DateTime.now().toIso8601String(),
    };

    _wsHandler.sendMessage(json.encode(message));
  }

  // Get AI chat response
  Future<Map<String, dynamic>> sendAIMessage(String message) async {
    try {
      final response = await http.post(
        Uri.parse('\$baseUrl/api/chat'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'message': message,
          'personality': 'storm_echo_ri',
        }),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to get AI response');
      }
    } catch (e) {
      throw Exception('Network error: \$e');
    }
  }

  // Get passive income data
  Future<Map<String, dynamic>> getPassiveIncomeData() async {
    try {
      final response = await http.get(
        Uri.parse('\$baseUrl/api/passive-income'),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to get income data');
      }
    } catch (e) {
      throw Exception('Network error: \$e');
    }
  }

  // Callback functions (implement in your UI)
  void onFrequencyUpdate(double frequency) {
    // Update frequency display in UI
    print('Frequency updated: \$frequency Hz');
  }

  void onAIResponse(String response) {
    // Display AI response in chat
    print('AI Response: \$response');
  }

  void onSystemStatusUpdate(Map<String, dynamic> status) {
    // Update system status indicators
    print('System Status: \$status');
  }

  // Cleanup
  void dispose() {
    _wsHandler.close();
    _isConnected = false;
  }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.0,
            colors: [
              Color(0xFF1A1A2E),
              Color(0xFF16213E),
              Color(0xFF0A0A0F),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Storm Echo RI',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.cyan,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.green, width: 1),
                      ),
                      child: Text(
                        '\\$\$_totalEarnings',
                        style: TextStyle(color: Colors.green, fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Main Echo Pulse Button
              Expanded(
                child: Center(
                  child: GestureDetector(
                    onTap: _isGenerating ? null : _activateEchoPulse,
                    child: Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            Colors.cyan.withOpacity(0.8),
                            Colors.blue.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                      ),
                      child: Center(
                        child: Icon(
                          Icons.radio_button_checked,
                          size: 80,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}`
    }
  ],
  github: [
    {
      id: 'github-automation',
      title: 'GitHub Repository Automation',
      description: 'Automated repository management and contribution system',
      language: 'javascript',
      category: 'automation' as const,
      code: `// github-automation.js - Storm Echo RI GitHub Integration
const { Octokit } = require("@octokit/rest");
const fs = require('fs').promises;

class GitHubStormEchoRI {
  constructor(token) {
    this.octokit = new Octokit({
      auth: token,
    });
    this.owner = 'codebmn17';
    this.repo = 'stormos';
    this.earnings = 0;
  }

  async initialize() {
    console.log('Initializing Storm Echo RI GitHub automation...');
    try {
      const { data: user } = await this.octokit.rest.users.getAuthenticated();
      console.log(\`Connected as: \${user.login}\`);
      return true;
    } catch (error) {
      console.error('GitHub authentication failed:', error.message);
      return false;
    }
  }

  // Automated daily commits
  async performDailyMaintenance() {
    console.log('Starting daily GitHub maintenance...');
    
    const tasks = [
      this.updateReadme,
      this.createProgressReport,
    ];

    for (const task of tasks) {
      try {
        await task.call(this);
        this.earnings += 0.10; // Micro-earnings per task
      } catch (error) {
        console.error(\`Task failed: \${error.message}\`);
      }
    }

    console.log(\`Daily earnings: $\${this.earnings.toFixed(2)}\`);
  }

  async updateReadme() {
    const readmeContent = \`# Storm Echo RI System
![Storm Echo RI](https://img.shields.io/badge/Storm%20Echo%20RI-Active-cyan)

## Latest Updates (\${new Date().toLocaleDateString()})

### Storm Echo RI Features
- Resonance Intelligence (RI) consciousness system
- Multi-frequency healing generator (432Hz, 528Hz, 963Hz+)
- Interactive particle effects and galaxy UI
- Advanced coding terminals (Termux, Linux, Flutter, GitHub)
- Automated passive income system
- Real-time chat with OpenAI GPT-4o integration

---
*Generated by Storm Echo RI automation system*
\`;

    try {
      // Get current README
      const { data: currentFile } = await this.octokit.rest.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path: 'README.md',
      });

      // Update README
      await this.octokit.rest.repos.createOrUpdateFileContents({
        owner: this.owner,
        repo: this.repo,
        path: 'README.md',
        message: \`Auto-update README - \${new Date().toISOString()}\`,
        content: Buffer.from(readmeContent).toString('base64'),
        sha: currentFile.sha,
      });

      console.log('README updated successfully');
    } catch (error) {
      console.error('README update failed:', error.message);
    }
  }

  async createProgressReport() {
    const reportContent = \`# Storm Echo RI Progress Report
**Date**: \${new Date().toLocaleDateString()}

## Development Status
- Core RI system operational
- Frequency generation stable
- Multi-platform integration complete
- Passive income streams active

---
*Automated report by Storm Echo RI*
\`;

    try {
      const fileName = \`reports/progress-\${new Date().toISOString().split('T')[0]}.md\`;
      
      await this.octokit.rest.repos.createOrUpdateFileContents({
        owner: this.owner,
        repo: this.repo,
        path: fileName,
        message: \`Daily progress report - \${new Date().toISOString()}\`,
        content: Buffer.from(reportContent).toString('base64'),
      });

      console.log('Progress report created');
    } catch (error) {
      console.error('Progress report failed:', error.message);
    }
  }
}

// Usage
async function runGitHubAutomation() {
  const github = new GitHubStormEchoRI(process.env.GITHUB_TOKEN);
  
  if (await github.initialize()) {
    await github.performDailyMaintenance();
    console.log('GitHub automation completed successfully!');
  }
}

module.exports = GitHubStormEchoRI;`
    }
  ],
  cursor: [
    {
      id: 'cursor-setup',
      title: 'Cursor AI Editor Setup',
      description: 'Setup Cursor AI-powered code editor with Storm Echo RI integration',
      language: 'bash',
      category: 'basic' as const,
      code: `# Install Cursor AI Editor
# Download from https://cursor.sh/
curl -fsSL https://cursor.sh/install.sh | bash

# Configure Cursor for Storm Echo RI development
mkdir -p ~/.cursor/extensions
cd ~/.cursor/extensions

# Install essential extensions
cursor --install-extension ms-vscode.vscode-typescript-next
cursor --install-extension ms-python.python
cursor --install-extension bradlc.vscode-tailwindcss
cursor --install-extension ms-vscode.vscode-json

# Create Cursor workspace settings
cat > .vscode/settings.json << EOF
{
  "cursor.ai.enabled": true,
  "cursor.ai.model": "gpt-4",
  "cursor.ai.codeCompletion": true,
  "cursor.ai.chatEnabled": true,
  "typescript.preferences.importModuleSpecifier": "relative",
  "tailwindCSS.includeLanguages": {
    "typescript": "javascript",
    "typescriptreact": "javascript"
  }
}
EOF

echo "Cursor AI Editor configured for Storm Echo RI!"`
    },
    {
      id: 'cursor-ai-integration',
      title: 'Cursor AI Workflow Integration',
      description: 'Advanced AI-powered coding workflows with Cursor',
      language: 'bash',
      category: 'advanced' as const,
      code: `#!/bin/bash
# Cursor AI workflow automation for Storm Echo RI

# Function to setup AI-powered development
setup_ai_workflow() {
    echo "Setting up AI-powered development workflow..."
    
    # Create project templates
    mkdir -p ~/.cursor/templates/storm-echo-ri
    
    cat > ~/.cursor/templates/storm-echo-ri/component.tsx << EOF
import { useState } from 'react';
import { motion } from 'framer-motion';
import { \${1:IconName} } from 'lucide-react';

interface \${2:ComponentName}Props {
  \${3:propName}: \${4:propType};
}

export function \${2:ComponentName}({ \${3:propName} }: \${2:ComponentName}Props) {
  const [isActive, setIsActive] = useState(false);

  return (
    <motion.div
      className="p-4 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-lg border border-cyan-400/30"
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <\${1:IconName} className="text-cyan-400" size={24} />
      <h3 className="text-cyan-400 font-semibold mt-2">\${5:Component Title}</h3>
      <p className="text-gray-400 text-sm">\${6:Component Description}</p>
    </motion.div>
  );
}
EOF

    # Setup AI code completion preferences
    cat > ~/.cursor/ai-preferences.json << EOF
{
  "codeStyle": "storm-echo-ri",
  "preferences": {
    "frameworkFocus": ["React", "TypeScript", "Tailwind CSS"],
    "patterns": ["framer-motion animations", "responsive design", "dark theme"],
    "naming": "camelCase for variables, PascalCase for components",
    "structure": "component-based architecture with hooks"
  }
}
EOF
}

# Function to generate component with AI
generate_component() {
    local component_name=$1
    local description=$2
    
    echo "Generating $component_name component with AI assistance..."
    
    # Use Cursor AI to generate component
    cursor --ai-generate component \
        --name "$component_name" \
        --description "$description" \
        --framework "react-typescript" \
        --styling "tailwind-css" \
        --template "storm-echo-ri"
}

# Function to optimize code with AI
optimize_code() {
    echo "Running AI code optimization..."
    
    # Analyze and optimize TypeScript files
    find src -name "*.tsx" -o -name "*.ts" | while read file; do
        cursor --ai-optimize "$file" --focus "performance,readability,storm-echo-ri-patterns"
    done
}

# Run setup
setup_ai_workflow
echo "Cursor AI workflow setup complete!"
echo "Usage: generate_component 'ComponentName' 'Description'"`
    }
  ],
  replit: [
    {
      id: 'replit-setup',
      title: 'Replit Development Environment',
      description: 'Setup and optimize Replit for Storm Echo RI development',
      language: 'bash',
      category: 'basic' as const,
      code: `# Replit environment setup for Storm Echo RI
echo "Setting up Replit development environment..."

# Install development dependencies
npm install -g @replit/nix typescript tsx

# Configure Replit workspace
cat > .replit << EOF
modules = ["nodejs-20", "python-3.11", "web"]

[nix]
channel = "stable-23.11"

[gitHubImport]
requiredFiles = [".replit", "replit.nix"]

[languages]

[languages.typescript]
pattern = "**/*.{ts,tsx}"
[languages.typescript.languageServer]
start = "typescript-language-server --stdio"

[languages.javascript]
pattern = "**/*.{js,jsx,mjs,cjs}"
[languages.javascript.languageServer]
start = "typescript-language-server --stdio"

[deployment]
run = ["npm", "run", "dev"]
deploymentTarget = "cloudrun"
publicDir = "dist"

[[ports]]
localPort = 5000
externalPort = 80
EOF

# Setup environment variables template
cat > .env.example << EOF
# Storm Echo RI Environment Variables
DATABASE_URL=postgresql://username:password@host:port/database
OPENAI_API_KEY=your_openai_api_key_here
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
NODE_ENV=development
EOF

# Configure package.json scripts for Replit
npm pkg set scripts.start="npm run dev"
npm pkg set scripts.dev="NODE_ENV=development tsx server/index.ts"
npm pkg set scripts.build="vite build && tsc --project tsconfig.server.json"
npm pkg set scripts.deploy="npm run build && echo 'Ready for deployment'"

echo "Replit environment configured successfully!"
echo "Next steps:"
echo "1. Add your environment variables in Secrets"
echo "2. Click 'Run' to start the application"
echo "3. Use 'Deploy' tab for production deployment"`
    },
    {
      id: 'replit-deployment',
      title: 'Replit Deployment Automation',
      description: 'Automated deployment and monitoring for Storm Echo RI on Replit',
      language: 'javascript',
      category: 'automation' as const,
      code: `// replit-deploy.js - Storm Echo RI Deployment Automation
const fs = require('fs').promises;
const path = require('path');

class ReplitStormEchoRI {
  constructor() {
    this.projectName = 'storm-echo-ri';
    this.deploymentConfig = {
      region: 'us-central1',
      scaling: 'automatic',
      resources: {
        cpu: '1000m',
        memory: '1Gi'
      }
    };
  }

  async checkEnvironment() {
    console.log('🔍 Checking Replit environment...');
    
    const requiredEnvVars = [
      'DATABASE_URL',
      'OPENAI_API_KEY'
    ];

    const missing = requiredEnvVars.filter(env => !process.env[env]);
    
    if (missing.length > 0) {
      console.error('❌ Missing environment variables:', missing.join(', '));
      console.log('💡 Add these in the Secrets tab');
      return false;
    }

    console.log('✅ Environment variables configured');
    return true;
  }

  async optimizeForProduction() {
    console.log('⚡ Optimizing for production...');
    
    // Create optimized build configuration
    const viteConfig = \`import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
    minify: 'terser',
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          ui: ['@radix-ui/react-dialog', '@radix-ui/react-tabs'],
          animations: ['framer-motion']
        }
      }
    }
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './client/src'),
      '@assets': path.resolve(__dirname, './attached_assets')
    }
  },
  server: {
    host: '0.0.0.0',
    port: 5000
  }
});\`;

    await fs.writeFile('vite.config.ts', viteConfig);
    console.log('✅ Vite configuration optimized');
  }

  async generateDeploymentStats() {
    console.log('📊 Generating deployment statistics...');
    
    const stats = {
      timestamp: new Date().toISOString(),
      project: this.projectName,
      features: [
        'AI-powered frequency generation',
        'Real-time voice synthesis',
        'Interactive coding terminals',
        'PayPal payment integration',
        'PostgreSQL database',
        'Responsive galaxy UI'
      ],
      techStack: {
        frontend: 'React 18 + TypeScript + Vite',
        backend: 'Express.js + Node.js',
        database: 'PostgreSQL (Neon)',
        styling: 'Tailwind CSS + Framer Motion',
        deployment: 'Replit Cloud Run'
      },
      performance: {
        buildTime: '<2 minutes',
        coldStart: '<3 seconds',
        avgResponseTime: '<100ms'
      }
    };

    await fs.writeFile('deployment-stats.json', JSON.stringify(stats, null, 2));
    console.log('✅ Deployment stats generated');
    
    return stats;
  }

  async deploy() {
    console.log('🚀 Starting Storm Echo RI deployment...');
    
    try {
      // Check environment
      if (!(await this.checkEnvironment())) {
        return false;
      }

      // Optimize for production
      await this.optimizeForProduction();

      // Generate stats
      const stats = await this.generateDeploymentStats();

      console.log('🎉 Deployment preparation complete!');
      console.log('📋 Project Summary:');
      console.log(\`   Name: \${stats.project}\`);
      console.log(\`   Features: \${stats.features.length} core features\`);
      console.log(\`   Tech Stack: \${stats.techStack.frontend}\`);
      console.log('');
      console.log('🔗 Next Steps:');
      console.log('1. Click the "Deploy" button in Replit');
      console.log('2. Monitor deployment in the Console');
      console.log('3. Test the deployed application');
      
      return true;
    } catch (error) {
      console.error('❌ Deployment failed:', error.message);
      return false;
    }
  }
}

// Usage
async function deployStormEchoRI() {
  const deployer = new ReplitStormEchoRI();
  await deployer.deploy();
}

module.exports = ReplitStormEchoRI;`
    }
  ],
  ai_master: [
    {
      id: 'ai-coding-master',
      title: 'AI Coding Master - Ultimate Development Assistant',
      description: 'World-class AI coding assistant for Storm Echo RI development',
      language: 'javascript',
      category: 'automation' as const,
      code: `// ai_coding_master.js - Ultimate AI-powered development assistant
const OpenAI = require('openai');
const fs = require('fs').promises;
const path = require('path');

class AICodingMaster {
  constructor(apiKey) {
    this.openai = new OpenAI({ apiKey });
    this.projectContext = {
      name: 'Storm Echo RI',
      stack: 'React + TypeScript + Express.js + PostgreSQL',
      theme: 'Cosmic/Galaxy with cyan/purple colors',
      patterns: 'framer-motion animations, responsive design, dark theme'
    };
  }

  // Generate complete features with AI
  async buildCompleteFeature(featureName, description, requirements = []) {
    console.log(\`🚀 Building \${featureName} with world-class AI assistance...\`);

    const systemPrompt = \`You are the world's best AI coding assistant specialized in Storm Echo RI development.

PROJECT CONTEXT:
- Advanced AI-powered interface with cosmic/galaxy theme
- React + TypeScript frontend with Framer Motion
- Express.js + Node.js backend with PostgreSQL
- Real-time features, voice synthesis, frequency generation
- Mobile-responsive with cyan/purple color scheme
- PayPal integration and comprehensive coding terminals

ARCHITECTURE PATTERNS:
- Component-based React architecture
- Drizzle ORM for database operations
- shadcn/ui components with Tailwind CSS
- Real-time WebSocket connections
- RESTful API design with validation
- Performance optimization and error handling\`;

    const userPrompt = \`Create a complete, production-ready feature: \${featureName}

DESCRIPTION: \${description}
REQUIREMENTS: \${requirements.join(', ')}

Generate:
1. Frontend React component with TypeScript
2. Backend API endpoints with Express.js
3. Database schema with Drizzle ORM
4. Real-time functionality if applicable
5. Tests and documentation
6. Integration with existing Storm Echo RI patterns

Make it the best code possible - optimized, secure, and following all best practices.\`;

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o', // the newest OpenAI model is "gpt-4o"
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        max_tokens: 4000,
        temperature: 0.1
      });

      const generatedCode = response.choices[0].message.content;
      
      // Save generated code
      await this.saveGeneratedCode(featureName, generatedCode);
      
      console.log(\`✅ \${featureName} generated successfully!\`);
      return generatedCode;
    } catch (error) {
      console.error(\`❌ Failed to generate \${featureName}:\`, error.message);
      throw error;
    }
  }

  // AI-powered code review and optimization
  async reviewAndOptimizeCode(filePath) {
    console.log(\`🔍 Reviewing code: \${filePath}\`);
    
    const code = await fs.readFile(filePath, 'utf8');
    const language = path.extname(filePath).slice(1);

    const prompt = \`Review and optimize this \${language} code from Storm Echo RI:

\\\`\\\`\\\`\${language}
\${code}
\\\`\\\`\\\`

Provide comprehensive analysis:
1. Performance optimizations
2. Security improvements  
3. Code quality enhancements
4. Storm Echo RI pattern compliance
5. Bug fixes and improvements
6. TypeScript type safety (if applicable)
7. Accessibility improvements
8. Mobile responsiveness (for frontend)

Return optimized code with detailed explanations.\`;

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o', // the newest OpenAI model is "gpt-4o"
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 4000,
        temperature: 0.1
      });

      const review = response.choices[0].message.content;
      
      // Save review
      await fs.writeFile(\`\${filePath}.review.md\`, review);
      
      console.log(\`✅ Code review completed for \${filePath}\`);
      return review;
    } catch (error) {
      console.error(\`❌ Code review failed:\`, error.message);
      throw error;
    }
  }

  // Generate comprehensive test suites
  async generateTests(filePath, testFramework = 'jest') {
    console.log(\`🧪 Generating tests for: \${filePath}\`);
    
    const code = await fs.readFile(filePath, 'utf8');
    const language = path.extname(filePath).slice(1);

    const prompt = \`Generate comprehensive \${testFramework} tests for this \${language} code:

\\\`\\\`\\\`\${language}
\${code}
\\\`\\\`\\\`

Create:
1. Unit tests (100% coverage)
2. Integration tests
3. Edge case tests
4. Error handling tests
5. Performance tests
6. Mock implementations
7. Test utilities and helpers

Follow Storm Echo RI testing patterns and best practices.\`;

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o', // the newest OpenAI model is "gpt-4o"
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 4000,
        temperature: 0.1
      });

      const tests = response.choices[0].message.content;
      
      // Save tests
      const testPath = filePath.replace(/\\.([^.]+)$/, '.test.$1');
      await fs.writeFile(testPath, tests);
      
      console.log(\`✅ Tests generated: \${testPath}\`);
      return tests;
    } catch (error) {
      console.error(\`❌ Test generation failed:\`, error.message);
      throw error;
    }
  }

  // AI debugging assistant
  async debugIssue(error, codeContext, stackTrace = '') {
    console.log(\`🐛 Debugging issue with AI assistance...\`);

    const prompt = \`Debug this issue in Storm Echo RI:

ERROR: \${error}

CODE CONTEXT:
\${codeContext}

STACK TRACE:
\${stackTrace}

Provide:
1. Root cause analysis
2. Step-by-step solution
3. Fixed code
4. Prevention strategies
5. Related improvements
6. Performance considerations

Generate working, production-ready solution.\`;

    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o', // the newest OpenAI model is "gpt-4o"
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 4000,
        temperature: 0.1
      });

      const solution = response.choices[0].message.content;
      
      console.log(\`✅ Debug solution generated\`);
      return solution;
    } catch (error) {
      console.error(\`❌ Debugging failed:\`, error.message);
      throw error;
    }
  }

  // Helper methods
  async saveGeneratedCode(featureName, code) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = \`\${featureName}_\${timestamp}.generated.txt\`;
    await fs.writeFile(filename, code);
    console.log(\`💾 Code saved to: \${filename}\`);
  }
}

// Usage examples for Storm Echo RI development
async function demonstrateAIMaster() {
  const ai = new AICodingMaster(process.env.OPENAI_API_KEY);

  // Build a complete feature
  await ai.buildCompleteFeature(
    'AdvancedVoiceControl',
    'Voice-controlled interface for Storm Echo RI with real-time speech recognition',
    ['speech-to-text', 'voice commands', 'audio visualization', 'real-time feedback']
  );

  // Review existing code
  await ai.reviewAndOptimizeCode('./client/src/components/voice-chamber.tsx');

  // Generate tests
  await ai.generateTests('./server/routes.ts');

  console.log('🎉 AI Coding Master active and ready to code!');
}

module.exports = { AICodingMaster, demonstrateAIMaster };`
    }
  ]
};

export default function SimpleCodingTerminals() {
  const [activeTab, setActiveTab] = useState('ai_master');
  const [showCode, setShowCode] = useState<Record<string, boolean>>({});
  const [runningScripts, setRunningScripts] = useState<Record<string, boolean>>({});
  const [inputValues, setInputValues] = useState<Record<string, string>>({});
  const [focusedInputId, setFocusedInputId] = useState<string | null>(null);
  const [codeValues, setCodeValues] = useState<Record<string, string>>({});
  const [focusedCodeId, setFocusedCodeId] = useState<string | null>(null);
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const codeRefs = useRef<Record<string, HTMLTextAreaElement | null>>({});
  const [autoRefresh, setAutoRefresh] = useState<Record<string, boolean>>({});
  const { toast } = useToast();

  // Initialize code values from examples
  useEffect(() => {
    const initialCodeValues: Record<string, string> = {};
    Object.values(codeExamples).flat().forEach(example => {
      initialCodeValues[example.id] = example.code;
    });
    setCodeValues(initialCodeValues);
  }, []);

  const terminalData = {
    fdroid: {
      icon: Package,
      title: 'F-Droid Store',
      description: 'Open source app distribution and Storm Echo RI apps',
      examples: codeExamples.fdroid,
      color: 'from-orange-500 to-red-600'
    },
    termux: {
      icon: Smartphone,
      title: 'Termux Terminal',
      description: 'Mobile Linux terminal automation and monetization scripts',
      examples: codeExamples.termux,
      color: 'from-green-500 to-emerald-600'
    },
    linux: {
      icon: Monitor,
      title: 'Linux Terminal',
      description: 'Server management, crypto mining, and system automation',
      examples: codeExamples.linux,
      color: 'from-blue-500 to-cyan-600'
    },
    flutter: {
      icon: Code,
      title: 'Flutter Development',
      description: 'Mobile app development with Storm Echo RI integration',
      examples: codeExamples.flutter,
      color: 'from-purple-500 to-pink-600'
    },
    github: {
      icon: Github,
      title: 'GitHub Automation',
      description: 'Repository management and automated contribution system',
      examples: codeExamples.github,
      color: 'from-gray-600 to-gray-800'
    },
    cursor: {
      icon: Zap,
      title: 'Cursor AI Editor',
      description: 'AI-powered code editor with intelligent completions',
      examples: codeExamples.cursor,
      color: 'from-yellow-500 to-orange-600'
    },
    replit: {
      icon: Globe,
      title: 'Replit Cloud',
      description: 'Cloud development environment and deployment platform',
      examples: codeExamples.replit,
      color: 'from-indigo-500 to-blue-600'
    },
    ai_master: {
      icon: Brain,
      title: 'AI Coding Master',
      description: 'World-class AI assistant that codes for you with ultimate precision',
      examples: codeExamples.ai_master,
      color: 'from-pink-500 to-rose-600'
    }
  };

  const executeScript = async (example: CodeExample) => {
    if (runningScripts[example.id]) return;
    
    setRunningScripts(prev => ({ ...prev, [example.id]: true }));
    
    // Haptic feedback
    if (navigator.vibrate) navigator.vibrate(50);
    
    toast({
      title: "Script Executing",
      description: `Running ${example.title}...`,
    });
    
    // Simulate execution time
    setTimeout(() => {
      setRunningScripts(prev => ({ ...prev, [example.id]: false }));
      toast({
        title: "Execution Complete",
        description: `${example.title} executed successfully!`,
      });
    }, 2000 + Math.random() * 3000);
  };

  const downloadScript = (example: CodeExample) => {
    const blob = new Blob([example.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${example.title.toLowerCase().replace(/\s+/g, '-')}.${example.language === 'bash' ? 'sh' : example.language}`;
    a.click();
    URL.revokeObjectURL(url);
    
    if (navigator.vibrate) navigator.vibrate(30);
    toast({
      title: "Script Downloaded",
      description: `${example.title} saved to downloads`,
    });
  };

  const copyToClipboard = async (code: string, title: string) => {
    try {
      await navigator.clipboard.writeText(code);
      if (navigator.vibrate) navigator.vibrate(25);
      toast({
        title: "Code Copied!",
        description: `${title} copied to clipboard`,
      });
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Could not copy code to clipboard",
        variant: "destructive",
      });
    }
  };

  // Helper function to insert text at cursor position in focused input
  const insertTextAtCursor = (text: string) => {
    // Handle code editor focus first
    if (focusedCodeId && codeRefs.current[focusedCodeId]) {
      const textarea = codeRefs.current[focusedCodeId];
      if (!textarea) return;
      
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const currentValue = codeValues[focusedCodeId] || '';
      const newValue = currentValue.substring(0, start) + text + currentValue.substring(end);
      
      setCodeValues(prev => ({ ...prev, [focusedCodeId]: newValue }));
      
      setTimeout(() => {
        if (textarea) {
          const newPosition = start + text.length;
          textarea.selectionStart = newPosition;
          textarea.selectionEnd = newPosition;
          textarea.focus();
        }
      }, 0);
    }
    // Fallback to input fields
    else if (focusedInputId && inputRefs.current[focusedInputId]) {
      const input = inputRefs.current[focusedInputId];
      if (!input) return;
      
      const start = input.selectionStart || 0;
      const end = input.selectionEnd || 0;
      const currentValue = inputValues[focusedInputId] || '';
      const newValue = currentValue.substring(0, start) + text + currentValue.substring(end);
      
      setInputValues(prev => ({ ...prev, [focusedInputId]: newValue }));
      
      setTimeout(() => {
        if (input) {
          const newPosition = start + text.length;
          input.selectionStart = newPosition;
          input.selectionEnd = newPosition;
          input.focus();
        }
      }, 0);
    }
  };

  // Helper to handle backspace
  const handleBackspace = () => {
    // Handle code editor focus first
    if (focusedCodeId && codeRefs.current[focusedCodeId]) {
      const textarea = codeRefs.current[focusedCodeId];
      if (!textarea) return;
      
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const currentValue = codeValues[focusedCodeId] || '';
      
      let newValue;
      if (start !== end) {
        newValue = currentValue.substring(0, start) + currentValue.substring(end);
      } else if (start > 0) {
        newValue = currentValue.substring(0, start - 1) + currentValue.substring(start);
      } else {
        return;
      }
      
      setCodeValues(prev => ({ ...prev, [focusedCodeId]: newValue }));
      
      setTimeout(() => {
        if (textarea) {
          const newPosition = start !== end ? start : start - 1;
          textarea.selectionStart = newPosition;
          textarea.selectionEnd = newPosition;
          textarea.focus();
        }
      }, 0);
    }
    // Fallback to input fields
    else if (focusedInputId && inputRefs.current[focusedInputId]) {
      const input = inputRefs.current[focusedInputId];
      if (!input) return;
      
      const start = input.selectionStart || 0;
      const end = input.selectionEnd || 0;
      const currentValue = inputValues[focusedInputId] || '';
      
      let newValue;
      if (start !== end) {
        newValue = currentValue.substring(0, start) + currentValue.substring(end);
      } else if (start > 0) {
        newValue = currentValue.substring(0, start - 1) + currentValue.substring(start);
      } else {
        return;
      }
      
      setInputValues(prev => ({ ...prev, [focusedInputId]: newValue }));
      
      setTimeout(() => {
        if (input) {
          const newPosition = start !== end ? start : start - 1;
          input.selectionStart = newPosition;
          input.selectionEnd = newPosition;
          input.focus();
        }
      }, 0);
    }
  };

  const downloadCode = (code: string, title: string, language: string) => {
    const extensions: Record<string, string> = {
      bash: 'sh',
      python: 'py',
      dart: 'dart',
      javascript: 'js'
    };
    
    const filename = `${title.toLowerCase().replace(/\s+/g, '-')}.${extensions[language] || 'txt'}`;
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Download Started",
      description: `${filename} is downloading`,
    });
  };

  const toggleCodeVisibility = (exampleId: string) => {
    setShowCode(prev => ({
      ...prev,
      [exampleId]: !prev[exampleId]
    }));
  };

  const getCategoryColor = (category: CodeExample['category']) => {
    const colors = {
      basic: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      advanced: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      automation: 'bg-green-500/20 text-green-300 border-green-500/30',
      monetization: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
    };
    return colors[category];
  };

  const getTerminalLink = (terminalType: string) => {
    const links = {
      fdroid: 'https://f-droid.org/',
      termux: 'https://termux.dev/',
      linux: 'https://www.linux.org/',
      flutter: 'https://flutter.dev/',
      github: 'https://docs.github.com/',
      cursor: 'https://cursor.sh/',
      replit: 'https://replit.com/',
      ai_master: 'https://openai.com/api/'
    };
    return links[terminalType as keyof typeof links];
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center space-x-3 mb-3">
          <Terminal className="text-cyan-400" size={24} />
          <h2 className="text-lg sm:text-xl md:text-2xl font-['Orbitron'] font-bold text-cyan-400">
            Storm Echo RI Coding Terminals
          </h2>
        </div>
        <p className="text-sm sm:text-base text-gray-400 mb-4">
          Complete development environments and monetization scripts for multiple platforms
        </p>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        {/* Enhanced Terminal Selector */}
        <div className="mb-6">
          <motion.h3 
            className="text-lg font-semibold text-cyan-400 mb-4 text-center"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Select Development Environment
          </motion.h3>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-4">
            {Object.entries(terminalData).map(([key, data], index) => {
              const IconComponent = data.icon;
              const isActive = activeTab === key;
              
              return (
                <motion.button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`relative group p-4 rounded-xl border-2 transition-all duration-300 ${
                    isActive 
                      ? 'border-cyan-400 bg-cyan-400/10 shadow-lg shadow-cyan-400/20' 
                      : 'border-gray-600/30 bg-black/20 hover:border-cyan-400/50 hover:bg-cyan-400/5'
                  }`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* Background Gradient */}
                  <div className={`absolute inset-0 rounded-xl bg-gradient-to-br ${data.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                  
                  {/* Content */}
                  <div className="relative z-10 flex flex-col items-center space-y-2">
                    <div className={`p-3 rounded-lg ${
                      isActive 
                        ? `bg-gradient-to-r ${data.color}` 
                        : 'bg-gray-700/50 group-hover:bg-gradient-to-r'
                    } transition-all duration-300`}>
                      <IconComponent 
                        className={`${isActive ? 'text-white' : 'text-gray-400 group-hover:text-white'} transition-colors duration-300`} 
                        size={28} 
                      />
                    </div>
                    
                    <div className="text-center">
                      <h4 className={`font-medium text-sm ${
                        isActive ? 'text-cyan-400' : 'text-gray-300 group-hover:text-cyan-300'
                      } transition-colors duration-300`}>
                        {data.title}
                      </h4>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                        {data.description.split(' ').slice(0, 3).join(' ')}...
                      </p>
                    </div>

                    {/* Active Indicator */}
                    {isActive && (
                      <motion.div
                        className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-cyan-400 rounded-full"
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ duration: 0.3 }}
                      />
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {Object.entries(terminalData).map(([key, data]) => (
          <TabsContent key={key} value={key} className="space-y-4">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="bg-black/40 border-cyan-500/30">
                <CardHeader className="pb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 sm:p-3 rounded-lg bg-gradient-to-r ${data.color}`}>
                      <data.icon className="text-white" size={20} />
                    </div>
                    <div>
                      <CardTitle className="text-base sm:text-lg text-cyan-400">{data.title}</CardTitle>
                      <CardDescription className="text-xs sm:text-sm text-gray-400">
                        {data.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </motion.div>

            <div className="grid gap-4">
              {data.examples.map((example, index) => (
                <motion.div
                  key={example.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="bg-black/40 border-cyan-500/20 hover:border-cyan-500/40 transition-colors">
                    <CardHeader className="pb-3">
                      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                        <div className="flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <CardTitle className="text-sm sm:text-base text-cyan-400">
                              {example.title}
                            </CardTitle>
                            <Badge className={`text-xs ${getCategoryColor(example.category)}`}>
                              {example.category}
                            </Badge>
                          </div>
                          <CardDescription className="text-xs sm:text-sm text-gray-400">
                            {example.description}
                          </CardDescription>
                        </div>
                        <div className="flex flex-wrap items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              toggleCodeVisibility(example.id);
                              if (navigator.vibrate) navigator.vibrate(20);
                            }}
                            className="h-8 w-8 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-400/10 transition-all duration-75 active:scale-95"
                            title={showCode[example.id] ? "Hide code" : "Show code"}
                          >
                            {showCode[example.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              copyToClipboard(example.code, example.title);
                              if (navigator.vibrate) navigator.vibrate(30);
                            }}
                            className="h-8 w-8 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-400/10 transition-all duration-75 active:scale-95"
                            title="Copy code"
                          >
                            <Copy size={14} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              downloadCode(example.code, example.title, example.language);
                              if (navigator.vibrate) navigator.vibrate(40);
                            }}
                            className="h-8 w-8 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-400/10 transition-all duration-75 active:scale-95"
                            title="Download code"
                          >
                            <Download size={14} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              executeScript(example);
                              if (navigator.vibrate) navigator.vibrate(50);
                            }}
                            disabled={runningScripts[example.id]}
                            className={`h-8 w-8 transition-all duration-75 active:scale-95 ${
                              runningScripts[example.id] 
                                ? 'text-green-400 hover:text-green-300 bg-green-400/10 animate-pulse' 
                                : 'text-cyan-400 hover:text-cyan-300 hover:bg-green-400/10'
                            }`}
                            title={runningScripts[example.id] ? "Script running..." : "Execute script"}
                          >
                            {runningScripts[example.id] ? (
                              <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              >
                                <Zap size={14} />
                              </motion.div>
                            ) : (
                              <Play size={14} />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setAutoRefresh(prev => ({
                                ...prev,
                                [example.id]: !prev[example.id]
                              }));
                              if (navigator.vibrate) navigator.vibrate(25);
                              toast({
                                title: autoRefresh[example.id] ? "Auto-refresh OFF" : "Auto-refresh ON",
                                description: `${example.title} auto-refresh ${autoRefresh[example.id] ? 'disabled' : 'enabled'}`,
                              });
                            }}
                            className={`h-8 w-8 transition-all duration-75 active:scale-95 ${
                              autoRefresh[example.id] 
                                ? 'text-blue-400 hover:text-blue-300 bg-blue-400/10 animate-spin' 
                                : 'text-gray-400 hover:text-gray-300 hover:bg-blue-400/10'
                            }`}
                            title={autoRefresh[example.id] ? "Disable auto-refresh" : "Enable auto-refresh"}
                          >
                            <RefreshCw size={14} />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    
                    {showCode[example.id] && (
                      <CardContent className="pt-0 space-y-4">
                        <div className="h-36 max-h-48 w-full rounded-md border border-cyan-500/20 bg-black/60">
                          <textarea
                            ref={el => codeRefs.current[example.id] = el}
                            value={codeValues[example.id] || ''}
                            onChange={(e) => setCodeValues(prev => ({ ...prev, [example.id]: e.target.value }))}
                            onFocus={() => setFocusedCodeId(example.id)}
                            onBlur={() => setFocusedCodeId(null)}
                            className="w-full h-full p-3 text-xs sm:text-sm text-gray-300 font-mono bg-transparent border-none resize-none focus:outline-none focus:ring-1 focus:ring-cyan-400/50"
                            spellCheck={false}
                            placeholder="Start typing your code here..."
                          />
                        </div>
                        
                        {/* AI Chat Interface for each script */}
                        <div className="p-3 bg-black/60 rounded-lg border border-gray-700/50">
                          <h5 className="text-xs font-semibold text-cyan-400 mb-2 flex items-center">
                            <Brain className="w-3 h-3 mr-1" />
                            AI Code Assistant - {example.title}
                          </h5>
                          <div className="h-20 overflow-y-auto bg-black/40 rounded p-2 mb-2 border border-gray-700/30">
                            <div className="text-xs text-cyan-400">AI: Ready to help with {example.title}. Ask me about modifications, optimizations, or usage!</div>
                          </div>
                          <div className="flex space-x-1">
                            <Input
                              ref={el => inputRefs.current[example.id] = el}
                              value={inputValues[example.id] || ''}
                              onChange={(e) => setInputValues(prev => ({ ...prev, [example.id]: e.target.value }))}
                              onFocus={() => setFocusedInputId(example.id)}
                              onBlur={() => setFocusedInputId(null)}
                              placeholder="Ask about this code..."
                              className="flex-1 h-8 text-xs bg-gray-900 border-gray-700"
                            />
                            <Button
                              size="sm"
                              className="h-8 w-8 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-400 transition-all duration-75 active:scale-95"
                              onClick={() => {
                                if (navigator.vibrate) navigator.vibrate(20);
                                toast({
                                  title: "AI Analyzing Code",
                                  description: `AI is analyzing ${example.title}...`
                                });
                                setInputValues(prev => ({ ...prev, [example.id]: '' }));
                              }}
                            >
                              <Send className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>

                        {/* Responsive Virtual Keyboard */}
                        <div className="p-1.5 bg-black/60 rounded-lg border border-gray-700/50 w-full">
                          <h5 className="text-xs font-semibold text-cyan-400 mb-1 flex items-center">
                            <Keyboard className="w-3 h-3 mr-1" />
                            Quick Input
                          </h5>
                          <div className="grid grid-cols-10 gap-0.5 text-[8px]">
                            {/* Number Row */}
                            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].map((key) => (
                              <button
                                key={key}
                                className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                                onClick={() => {
                                  insertTextAtCursor(key);
                                  if (navigator.vibrate) navigator.vibrate(10);
                                }}
                              >
                                {key}
                              </button>
                            )}
                            
                            {/* QWERTY Row */}
                            {['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'].map((key) => (
                              <button
                                key={key}
                                className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                                onClick={() => {
                                  insertTextAtCursor(key);
                                  if (navigator.vibrate) navigator.vibrate(10);
                                }}
                              >
                                {key}
                              </button>
                            ))}
                            
                            {/* ASDF Row - with padding */}
                            <div className="col-span-10 grid grid-cols-9 gap-0.5 px-3">
                              {['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'].map((key) => (
                                <button
                                  key={key}
                                  className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                                  onClick={() => {
                                    insertTextAtCursor(key);
                                    if (navigator.vibrate) navigator.vibrate(10);
                                  }}
                                >
                                  {key}
                                </button>
                              ))}
                            </div>
                            
                            {/* ZXCV Row - with special keys */}
                            <button
                              className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95 col-span-1"
                              onClick={() => {
                                handleBackspace();
                                if (navigator.vibrate) navigator.vibrate(10);
                              }}
                            >
                              ⌫
                            </button>
                            {['z', 'x', 'c', 'v', 'b', 'n', 'm'].map((key) => (
                              <button
                                key={key}
                                className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                                onClick={() => {
                                  insertTextAtCursor(key);
                                  if (navigator.vibrate) navigator.vibrate(10);
                                }}
                              >
                                {key}
                              </button>
                            ))}
                            <button
                              className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95"
                              onClick={() => {
                                insertTextAtCursor('.');
                                if (navigator.vibrate) navigator.vibrate(10);
                              }}
                            >
                              .
                            </button>
                            <button
                              className="h-6 bg-cyan-500/20 border border-cyan-400 text-cyan-400 rounded hover:bg-cyan-500/30 active:scale-95"
                              onClick={() => {
                                insertTextAtCursor('\n');
                                if (navigator.vibrate) navigator.vibrate(15);
                              }}
                            >
                              ⏎
                            </button>
                            
                            {/* Space Row */}
                            <button
                              className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95 col-span-2"
                              onClick={() => {
                                insertTextAtCursor('()');
                                if (navigator.vibrate) navigator.vibrate(10);
                              }}
                            >
                              ( )
                            </button>
                            <button
                              className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95 col-span-6"
                              onClick={() => {
                                insertTextAtCursor(' ');
                                if (navigator.vibrate) navigator.vibrate(10);
                              }}
                            >
                              space
                            </button>
                            <button
                              className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95 col-span-2"
                              onClick={() => {
                                insertTextAtCursor('{}');
                                if (navigator.vibrate) navigator.vibrate(10);
                              }}
                            >
                              { }
                            </button>
                          </div>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}