import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Code, 
  Terminal, 
  Brain, 
  Cpu, 
  GitBranch, 
  Sparkles, 
  Power, 
  Lock, 
  Unlock,
  Zap,
  Database,
  Cloud,
  Send,
  Copy,
  Check,
  AlertCircle,
  Loader2,
  ChevronRight,
  FileCode,
  Bug,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';

interface AIAssistantSession {
  sessionId: string;
  userId: string;
  capabilities: {
    codeGeneration: boolean;
    codeReview: boolean;
    debugging: boolean;
    refactoring: boolean;
    documentation: boolean;
    testing: boolean;
    deployment: boolean;
    systemControl: boolean;
    termuxIntegration: boolean;
    autonomousMode: boolean;
    memorySize: 'unlimited' | 'large' | 'standard';
  };
  autonomousActions: boolean;
}

interface CodeSuggestion {
  type: 'generation' | 'completion' | 'refactor' | 'fix' | 'optimization';
  code: string;
  language: string;
  description: string;
  confidence: number;
  source: 'gemini' | 'copilot' | 'codewhisperer' | 'openai';
}

interface AssistantStatistics {
  sessionId: string;
  userId: string;
  memoryUsage: number;
  globalMemoryUsage: number;
  autonomousMode: boolean;
  uptime: number;
  totalSuggestions: number;
}

export function AICodingAssistant() {
  const [session, setSession] = useState<AIAssistantSession | null>(null);
  const [input, setInput] = useState('');
  const [language, setLanguage] = useState('typescript');
  const [suggestions, setSuggestions] = useState<CodeSuggestion[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [termuxOutput, setTermuxOutput] = useState('');
  const [autonomousMode, setAutonomousMode] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Initialize session
  const initSession = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/ai-assistant/session', {
        capabilities: {
          codeGeneration: true,
          codeReview: true,
          debugging: true,
          refactoring: true,
          documentation: true,
          testing: true,
          deployment: true,
          systemControl: true,
          termuxIntegration: true,
          autonomousMode: true,
          memorySize: 'unlimited'
        }
      });
    },
    onSuccess: (data) => {
      setSession(data);
      toast({
        title: "AI Assistant Ready",
        description: "Full autonomous coding capabilities activated with unlimited memory"
      });
    }
  });

  // Get session statistics
  const { data: stats } = useQuery({
    queryKey: session?.sessionId ? [`/api/ai-assistant/stats/${session.sessionId}`] : null,
    enabled: !!session?.sessionId,
    refetchInterval: 5000
  });

  // Generate code
  const generateCode = useMutation({
    mutationFn: async (prompt: string) => {
      if (!session) throw new Error('No session');
      
      return await apiRequest('POST', `/api/ai-assistant/generate`, {
        sessionId: session.sessionId,
        prompt,
        language,
        options: {
          useGemini: true,
          useCopilot: true,
          useCodeWhisperer: true,
          combineResults: true
        }
      });
    },
    onSuccess: (data) => {
      setSuggestions(data.suggestions || []);
      if (data.suggestions?.length > 0) {
        toast({
          title: "Code Generated",
          description: `Generated ${data.suggestions.length} suggestions from multiple AI assistants`
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Toggle autonomous mode
  const toggleAutonomous = useMutation({
    mutationFn: async (enable: boolean) => {
      if (!session) throw new Error('No session');
      
      return await apiRequest('POST', `/api/ai-assistant/autonomous`, {
        sessionId: session.sessionId,
        enable
      });
    },
    onSuccess: (_, enable) => {
      setAutonomousMode(enable);
      toast({
        title: enable ? "Autonomous Mode Activated" : "Autonomous Mode Disabled",
        description: enable ? 
          "AI will now operate independently with full system access" : 
          "Manual approval required for all actions"
      });
    }
  });

  // Execute Termux command
  const executeTermux = useMutation({
    mutationFn: async (command: string) => {
      if (!session) throw new Error('No session');
      
      return await apiRequest('POST', `/api/ai-assistant/termux`, {
        sessionId: session.sessionId,
        command
      });
    },
    onSuccess: (data) => {
      setTermuxOutput(prev => prev + '\n' + data.output);
      toast({
        title: "Command Executed",
        description: "Termux command completed successfully"
      });
    }
  });

  // Initialize on mount
  useEffect(() => {
    if (!session) {
      initSession.mutate();
    }
  }, []);

  // Auto-scroll output
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [termuxOutput]);

  const handleCopy = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleGenerate = () => {
    if (!input.trim()) return;
    generateCode.mutate(input);
  };

  const aiSourceColors = {
    gemini: 'text-blue-400 border-blue-400/30',
    copilot: 'text-purple-400 border-purple-400/30',
    codewhisperer: 'text-orange-400 border-orange-400/30',
    openai: 'text-green-400 border-green-400/30'
  };

  const aiSourceIcons = {
    gemini: <Cloud className="w-4 h-4" />,
    copilot: <GitBranch className="w-4 h-4" />,
    codewhisperer: <Code className="w-4 h-4" />,
    openai: <Brain className="w-4 h-4" />
  };

  return (
    <Card className="bg-black/90 backdrop-blur-lg border-cyan-500/30">
      <CardHeader className="border-b border-cyan-500/30">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-cyan-400">
            <Brain className="w-6 h-6" />
            AI Coding Assistant - Fully Autonomous
          </CardTitle>
          <div className="flex items-center gap-4">
            {/* Autonomous Mode Toggle */}
            <div className="flex items-center gap-2">
              <Label htmlFor="autonomous" className="text-sm text-gray-400">
                Autonomous Mode
              </Label>
              <Switch
                id="autonomous"
                checked={autonomousMode}
                onCheckedChange={(checked) => toggleAutonomous.mutate(checked)}
                disabled={!session || toggleAutonomous.isPending}
              />
              {autonomousMode ? (
                <Unlock className="w-4 h-4 text-green-400" />
              ) : (
                <Lock className="w-4 h-4 text-red-400" />
              )}
            </div>
            
            {/* Status Badge */}
            <Badge 
              variant="outline" 
              className={`${session ? 'border-green-400 text-green-400' : 'border-gray-400 text-gray-400'}`}
            >
              {session ? 'Connected' : 'Initializing'}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-4">
        <Tabs defaultValue="generate" className="w-full">
          <TabsList className="grid grid-cols-4 bg-black/50 border border-cyan-500/30">
            <TabsTrigger value="generate">Generate</TabsTrigger>
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            <TabsTrigger value="termux">Termux</TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
          </TabsList>

          {/* Code Generation Tab */}
          <TabsContent value="generate" className="space-y-4">
            <div className="space-y-4">
              <div className="flex gap-2">
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-40 bg-black/50 border-cyan-500/30">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="typescript">TypeScript</SelectItem>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="java">Java</SelectItem>
                    <SelectItem value="go">Go</SelectItem>
                    <SelectItem value="rust">Rust</SelectItem>
                    <SelectItem value="cpp">C++</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex-1 relative">
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Describe the code you want to generate... (e.g., 'Create a REST API with authentication')"
                    className="min-h-[100px] bg-black/50 border-cyan-500/30 text-white pr-12"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && e.ctrlKey) {
                        handleGenerate();
                      }
                    }}
                  />
                  <Button
                    onClick={handleGenerate}
                    disabled={!input.trim() || generateCode.isPending || !session}
                    size="icon"
                    className="absolute bottom-2 right-2 bg-cyan-600 hover:bg-cyan-500"
                  >
                    {generateCode.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>

              {/* AI Sources Status */}
              <div className="flex items-center gap-4 text-xs">
                <span className="text-gray-400">AI Sources:</span>
                <Badge variant="outline" className="border-blue-400/30 text-blue-400">
                  <Cloud className="w-3 h-3 mr-1" />
                  Gemini
                </Badge>
                <Badge variant="outline" className="border-purple-400/30 text-purple-400">
                  <GitBranch className="w-3 h-3 mr-1" />
                  Copilot
                </Badge>
                <Badge variant="outline" className="border-orange-400/30 text-orange-400">
                  <Code className="w-3 h-3 mr-1" />
                  CodeWhisperer
                </Badge>
                <Badge variant="outline" className="border-green-400/30 text-green-400">
                  <Brain className="w-3 h-3 mr-1" />
                  GPT-4
                </Badge>
              </div>
            </div>
          </TabsContent>

          {/* Suggestions Tab */}
          <TabsContent value="suggestions" className="space-y-4">
            <ScrollArea className="h-[400px]">
              {suggestions.length === 0 ? (
                <div className="text-center text-gray-400 py-8">
                  <Code className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No suggestions yet. Generate code to see AI suggestions.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {suggestions.map((suggestion, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-black/50 border border-cyan-500/30 rounded-lg p-4"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {aiSourceIcons[suggestion.source]}
                          <Badge 
                            variant="outline" 
                            className={aiSourceColors[suggestion.source]}
                          >
                            {suggestion.source}
                          </Badge>
                          <Badge variant="outline" className="border-gray-400">
                            {suggestion.type}
                          </Badge>
                          <span className="text-xs text-gray-400">
                            {(suggestion.confidence * 100).toFixed(0)}% confidence
                          </span>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleCopy(suggestion.code, index)}
                          className="hover:bg-cyan-500/10"
                        >
                          {copiedIndex === index ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                      <p className="text-sm text-gray-300 mb-2">{suggestion.description}</p>
                      <pre className="bg-black rounded p-3 overflow-x-auto">
                        <code className="text-xs text-cyan-300">{suggestion.code}</code>
                      </pre>
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          {/* Termux Integration Tab */}
          <TabsContent value="termux" className="space-y-4">
            <div className="space-y-4">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => executeTermux.mutate('deploy')}
                  disabled={!session || executeTermux.isPending}
                  className="border-cyan-500/30 hover:bg-cyan-500/10"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Deploy
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => executeTermux.mutate('backup')}
                  disabled={!session || executeTermux.isPending}
                  className="border-cyan-500/30 hover:bg-cyan-500/10"
                >
                  <Database className="w-4 h-4 mr-2" />
                  Backup
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => executeTermux.mutate('monitor')}
                  disabled={!session || executeTermux.isPending}
                  className="border-cyan-500/30 hover:bg-cyan-500/10"
                >
                  <Cpu className="w-4 h-4 mr-2" />
                  Monitor
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => executeTermux.mutate('sync')}
                  disabled={!session || executeTermux.isPending}
                  className="border-cyan-500/30 hover:bg-cyan-500/10"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Sync
                </Button>
              </div>

              <div 
                ref={outputRef}
                className="bg-black rounded-lg p-4 h-[300px] overflow-y-auto font-mono text-sm"
              >
                <pre className="text-green-400 whitespace-pre-wrap">
                  {termuxOutput || 'Termux output will appear here...'}
                </pre>
              </div>
            </div>
          </TabsContent>

          {/* Statistics Tab */}
          <TabsContent value="stats" className="space-y-4">
            {stats ? (
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400 text-sm">Memory Usage</span>
                    <Brain className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="text-2xl font-bold text-cyan-400">
                    {stats.memoryUsage} / ∞
                  </div>
                  <div className="text-xs text-gray-500">Local entries</div>
                </div>

                <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400 text-sm">Global Memory</span>
                    <Database className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="text-2xl font-bold text-cyan-400">
                    {stats.globalMemoryUsage}
                  </div>
                  <div className="text-xs text-gray-500">Persistent entries</div>
                </div>

                <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400 text-sm">Uptime</span>
                    <Power className="w-4 h-4 text-green-400" />
                  </div>
                  <div className="text-2xl font-bold text-green-400">
                    {Math.floor(stats.uptime / 1000 / 60)}m
                  </div>
                  <div className="text-xs text-gray-500">Session duration</div>
                </div>

                <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400 text-sm">Total Suggestions</span>
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                  </div>
                  <div className="text-2xl font-bold text-yellow-400">
                    {stats.totalSuggestions}
                  </div>
                  <div className="text-xs text-gray-500">Generated codes</div>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-400 py-8">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
                <p>Loading statistics...</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}