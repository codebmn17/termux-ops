import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { TerminalStatusMonitor } from '@/components/terminal-status-monitor';
import { SecureUpgradeTerminal } from '@/components/secure-upgrade-terminal';
import { AutoReportingPanel } from '@/components/auto-reporting-panel';
import TermuxGDrivePanel from '@/components/termux-gdrive-panel';
import { 
  Bitcoin, 
  DollarSign, 
  Database, 
  Search, 
  Shield, 
  Activity,
  Settings,
  Play,
  Pause,
  AlertCircle,
  Mail,
  Smartphone
} from 'lucide-react';

interface ModuleConfig {
  cryptoMiner: {
    enabled: boolean;
    coin: string;
    walletAddress: string;
    threads: number;
    stealthMode: boolean;
  };
  passiveIncome: {
    enabled: boolean;
    affiliateRotation: boolean;
    autoPosting: boolean;
    platforms: string[];
  };
  dataScraper: {
    enabled: boolean;
    autoScrape: boolean;
    trendingTopics: boolean;
    keywords: string[];
  };
  seoTraffic: {
    enabled: boolean;
    autoBacklinking: boolean;
    keywordOptimization: boolean;
    targetKeywords: string[];
  };
  stealthSecurity: {
    enabled: boolean;
    autoKillSuspicious: boolean;
    monitorConnections: boolean;
    scanInterval: number;
  };
}

export function TerminalSettings() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [moduleStatus, setModuleStatus] = useState<any[]>([]);
  const [config, setConfig] = useState<ModuleConfig>({
    cryptoMiner: {
      enabled: false,
      coin: 'monero',
      walletAddress: '',
      threads: 4,
      stealthMode: true
    },
    passiveIncome: {
      enabled: false,
      affiliateRotation: true,
      autoPosting: false,
      platforms: ['twitter', 'reddit']
    },
    dataScraper: {
      enabled: false,
      autoScrape: true,
      trendingTopics: true,
      keywords: ['AI', 'crypto', 'automation']
    },
    seoTraffic: {
      enabled: false,
      autoBacklinking: true,
      keywordOptimization: true,
      targetKeywords: ['AI automation', 'passive income']
    },
    stealthSecurity: {
      enabled: false,
      autoKillSuspicious: true,
      monitorConnections: true,
      scanInterval: 60
    }
  });

  useEffect(() => {
    fetchModuleStatus();
  }, []);

  const fetchModuleStatus = async () => {
    try {
      const response = await apiRequest('GET', '/api/terminal-modules/status');
      setModuleStatus(response.modules || []);
    } catch (error) {
      console.error('Failed to fetch module status:', error);
    }
  };

  const toggleModule = async (module: keyof ModuleConfig) => {
    setLoading(true);
    try {
      const newState = !config[module].enabled;
      setConfig(prev => ({
        ...prev,
        [module]: { ...prev[module], enabled: newState }
      }));

      // Module-specific toggle logic
      if (module === 'cryptoMiner') {
        if (newState) {
          await apiRequest('POST', '/api/terminal-modules/crypto-miner/start');
        } else {
          await apiRequest('POST', '/api/terminal-modules/crypto-miner/stop');
        }
      } else if (module === 'stealthSecurity') {
        if (newState) {
          await apiRequest('POST', '/api/terminal-modules/stealth-security/start');
        } else {
          await apiRequest('POST', '/api/terminal-modules/stealth-security/stop');
        }
      }

      toast({
        title: 'Module Updated',
        description: `${module} has been ${newState ? 'enabled' : 'disabled'}`,
      });

      fetchModuleStatus();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update module',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const updateCryptoConfig = async () => {
    try {
      await apiRequest('POST', '/api/terminal-modules/crypto-miner/config', {
        coin: config.cryptoMiner.coin,
        walletAddress: config.cryptoMiner.walletAddress,
        threads: config.cryptoMiner.threads,
        stealthMode: config.cryptoMiner.stealthMode,
        autoStart: config.cryptoMiner.enabled
      });
      
      toast({
        title: 'Configuration Saved',
        description: 'Crypto miner settings updated successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save configuration',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Terminal Module Settings</h2>
        <Button
          onClick={fetchModuleStatus}
          variant="outline"
          size="sm"
          className="bg-black/50 border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/10"
        >
          <Activity className="w-4 h-4 mr-2" />
          Refresh Status
        </Button>
      </div>

      {/* AI Status Monitor */}
      <TerminalStatusMonitor />

      <Tabs defaultValue="crypto" className="space-y-6">
        <TabsList className="grid grid-cols-8 w-full bg-black/50 border border-cyan-500/20">
          <TabsTrigger value="crypto" className="data-[state=active]:bg-cyan-500/20">
            <Bitcoin className="w-4 h-4 mr-2" />
            Crypto
          </TabsTrigger>
          <TabsTrigger value="income" className="data-[state=active]:bg-cyan-500/20">
            <DollarSign className="w-4 h-4 mr-2" />
            Income
          </TabsTrigger>
          <TabsTrigger value="scraper" className="data-[state=active]:bg-cyan-500/20">
            <Database className="w-4 h-4 mr-2" />
            Scraper
          </TabsTrigger>
          <TabsTrigger value="seo" className="data-[state=active]:bg-cyan-500/20">
            <Search className="w-4 h-4 mr-2" />
            SEO
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-cyan-500/20">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="upgrade" className="data-[state=active]:bg-red-500/20">
            <Settings className="w-4 h-4 mr-2" />
            Upgrade
          </TabsTrigger>
          <TabsTrigger value="reporting" className="data-[state=active]:bg-blue-500/20">
            <Mail className="w-4 h-4 mr-2" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="termux" className="data-[state=active]:bg-green-500/20">
            <Smartphone className="w-4 h-4 mr-2" />
            Termux
          </TabsTrigger>
        </TabsList>

        <TabsContent value="crypto">
          <Card className="bg-black/70 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300">Crypto Mining Module</CardTitle>
              <CardDescription className="text-gray-400">
                Configure cryptocurrency mining with auto-wallet sync
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="crypto-enabled" className="text-gray-200">Enable Mining</Label>
                <Switch
                  id="crypto-enabled"
                  checked={config.cryptoMiner.enabled}
                  onCheckedChange={() => toggleModule('cryptoMiner')}
                  disabled={loading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="coin-type" className="text-gray-200">Coin Type</Label>
                <select
                  id="coin-type"
                  value={config.cryptoMiner.coin}
                  onChange={(e) => setConfig(prev => ({
                    ...prev,
                    cryptoMiner: { ...prev.cryptoMiner, coin: e.target.value }
                  }))}
                  className="w-full px-3 py-2 bg-black/50 border border-cyan-500/30 rounded-md text-white"
                >
                  <option value="monero">Monero (Stealth)</option>
                  <option value="bitcoin">Bitcoin</option>
                  <option value="ethereum">Ethereum</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="wallet-address" className="text-gray-200">Wallet Address</Label>
                <Input
                  id="wallet-address"
                  type="text"
                  placeholder="Enter your wallet address"
                  value={config.cryptoMiner.walletAddress}
                  onChange={(e) => setConfig(prev => ({
                    ...prev,
                    cryptoMiner: { ...prev.cryptoMiner, walletAddress: e.target.value }
                  }))}
                  className="bg-black/50 border-cyan-500/30 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="threads" className="text-gray-200">Mining Threads: {config.cryptoMiner.threads}</Label>
                <input
                  id="threads"
                  type="range"
                  min="1"
                  max="8"
                  value={config.cryptoMiner.threads}
                  onChange={(e) => setConfig(prev => ({
                    ...prev,
                    cryptoMiner: { ...prev.cryptoMiner, threads: parseInt(e.target.value) }
                  }))}
                  className="w-full"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="stealth-mode" className="text-gray-200">Stealth Mode</Label>
                <Switch
                  id="stealth-mode"
                  checked={config.cryptoMiner.stealthMode}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    cryptoMiner: { ...prev.cryptoMiner, stealthMode: checked }
                  }))}
                />
              </div>

              <Button
                onClick={updateCryptoConfig}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white"
              >
                Save Configuration
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="income">
          <Card className="bg-black/70 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300">Passive Income Module</CardTitle>
              <CardDescription className="text-gray-400">
                Affiliate link rotation and auto-posting to social media
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="income-enabled" className="text-gray-200">Enable Module</Label>
                <Switch
                  id="income-enabled"
                  checked={config.passiveIncome.enabled}
                  onCheckedChange={() => toggleModule('passiveIncome')}
                  disabled={loading}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="affiliate-rotation" className="text-gray-200">Affiliate Link Rotation</Label>
                <Switch
                  id="affiliate-rotation"
                  checked={config.passiveIncome.affiliateRotation}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    passiveIncome: { ...prev.passiveIncome, affiliateRotation: checked }
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="auto-posting" className="text-gray-200">Auto-Posting</Label>
                <Switch
                  id="auto-posting"
                  checked={config.passiveIncome.autoPosting}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    passiveIncome: { ...prev.passiveIncome, autoPosting: checked }
                  }))}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-gray-200">Platforms</Label>
                <div className="space-y-2">
                  {['twitter', 'reddit', 'facebook', 'instagram'].map(platform => (
                    <label key={platform} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={config.passiveIncome.platforms.includes(platform)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setConfig(prev => ({
                              ...prev,
                              passiveIncome: {
                                ...prev.passiveIncome,
                                platforms: [...prev.passiveIncome.platforms, platform]
                              }
                            }));
                          } else {
                            setConfig(prev => ({
                              ...prev,
                              passiveIncome: {
                                ...prev.passiveIncome,
                                platforms: prev.passiveIncome.platforms.filter(p => p !== platform)
                              }
                            }));
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                      <span className="text-gray-200 capitalize">{platform}</span>
                    </label>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scraper">
          <Card className="bg-black/70 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300">Data Scraper Module</CardTitle>
              <CardDescription className="text-gray-400">
                Scrape trending topics and auto-generate content
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="scraper-enabled" className="text-gray-200">Enable Module</Label>
                <Switch
                  id="scraper-enabled"
                  checked={config.dataScraper.enabled}
                  onCheckedChange={() => toggleModule('dataScraper')}
                  disabled={loading}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="auto-scrape" className="text-gray-200">Auto-Scrape</Label>
                <Switch
                  id="auto-scrape"
                  checked={config.dataScraper.autoScrape}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    dataScraper: { ...prev.dataScraper, autoScrape: checked }
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="trending-topics" className="text-gray-200">Trending Topics</Label>
                <Switch
                  id="trending-topics"
                  checked={config.dataScraper.trendingTopics}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    dataScraper: { ...prev.dataScraper, trendingTopics: checked }
                  }))}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo">
          <Card className="bg-black/70 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300">SEO & Traffic Module</CardTitle>
              <CardDescription className="text-gray-400">
                Keyword targeting and backlink automation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="seo-enabled" className="text-gray-200">Enable Module</Label>
                <Switch
                  id="seo-enabled"
                  checked={config.seoTraffic.enabled}
                  onCheckedChange={() => toggleModule('seoTraffic')}
                  disabled={loading}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="auto-backlinking" className="text-gray-200">Auto-Backlinking</Label>
                <Switch
                  id="auto-backlinking"
                  checked={config.seoTraffic.autoBacklinking}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    seoTraffic: { ...prev.seoTraffic, autoBacklinking: checked }
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="keyword-optimization" className="text-gray-200">Keyword Optimization</Label>
                <Switch
                  id="keyword-optimization"
                  checked={config.seoTraffic.keywordOptimization}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    seoTraffic: { ...prev.seoTraffic, keywordOptimization: checked }
                  }))}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card className="bg-black/70 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300">Stealth Security Module</CardTitle>
              <CardDescription className="text-gray-400">
                Monitor connections and auto-kill suspicious processes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="security-enabled" className="text-gray-200">Enable Module</Label>
                <Switch
                  id="security-enabled"
                  checked={config.stealthSecurity.enabled}
                  onCheckedChange={() => toggleModule('stealthSecurity')}
                  disabled={loading}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="auto-kill" className="text-gray-200">Auto-Kill Suspicious</Label>
                <Switch
                  id="auto-kill"
                  checked={config.stealthSecurity.autoKillSuspicious}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    stealthSecurity: { ...prev.stealthSecurity, autoKillSuspicious: checked }
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="monitor-connections" className="text-gray-200">Monitor Connections</Label>
                <Switch
                  id="monitor-connections"
                  checked={config.stealthSecurity.monitorConnections}
                  onCheckedChange={(checked) => setConfig(prev => ({
                    ...prev,
                    stealthSecurity: { ...prev.stealthSecurity, monitorConnections: checked }
                  }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="scan-interval" className="text-gray-200">
                  Scan Interval: {config.stealthSecurity.scanInterval}s
                </Label>
                <input
                  id="scan-interval"
                  type="range"
                  min="30"
                  max="300"
                  step="30"
                  value={config.stealthSecurity.scanInterval}
                  onChange={(e) => setConfig(prev => ({
                    ...prev,
                    stealthSecurity: { ...prev.stealthSecurity, scanInterval: parseInt(e.target.value) }
                  }))}
                  className="w-full"
                />
              </div>

              {config.stealthSecurity.enabled && (
                <div className="p-3 bg-red-900/20 border border-red-500/30 rounded-md">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    <p className="text-sm text-red-300">
                      Security monitoring active. Suspicious processes will be terminated automatically.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upgrade">
          <SecureUpgradeTerminal />
        </TabsContent>

        <TabsContent value="reporting">
          <AutoReportingPanel />
        </TabsContent>

        <TabsContent value="termux">
          <TermuxGDrivePanel />
        </TabsContent>
      </Tabs>

      {/* Module Status Display */}
      <Card className="bg-black/70 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-cyan-300">Module Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {moduleStatus.map((module) => (
              <motion.div
                key={module.name}
                className="p-3 bg-black/50 border border-cyan-500/20 rounded-lg"
                whileHover={{ scale: 1.05 }}
              >
                <h4 className="text-sm font-medium text-cyan-300">{module.name}</h4>
                <p className={`text-xs mt-1 ${module.active ? 'text-green-400' : 'text-gray-400'}`}>
                  {module.active ? 'Active' : 'Inactive'}
                </p>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}