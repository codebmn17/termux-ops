import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  BarChart3, 
  PieChart, 
  ArrowUpRight,
  ArrowDownRight,
  Settings
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface EarningsData {
  period: 'daily' | 'weekly' | 'monthly';
  data: Array<{
    date: string;
    revenue: number;
    transactions: number;
    modules: Record<string, { revenue: number; transactions: number }>;
  }>;
  totals: {
    revenue: number;
    transactions: number;
    modules: Record<string, { revenue: number; transactions: number }>;
  };
}

interface EarningsDashboardProps {
  className?: string;
  compact?: boolean;
}

export function EarningsDashboard({ className = '', compact = false }: EarningsDashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  
  const { data: earningsData, isLoading } = useQuery({
    queryKey: ['/api/monetization/earnings', selectedPeriod],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: moduleSettings } = useQuery({
    queryKey: ['/api/monetization/settings'],
  });

  if (isLoading) {
    return (
      <Card className={`border-cyan-400/20 bg-black/40 backdrop-blur-sm ${className}`}>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-cyan-400/20 rounded w-1/4"></div>
            <div className="h-8 bg-cyan-400/20 rounded w-1/2"></div>
            <div className="h-20 bg-cyan-400/20 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const earnings: EarningsData = earningsData || {
    period: selectedPeriod,
    data: [],
    totals: { revenue: 0, transactions: 0, modules: {} }
  };

  const formatCurrency = (amount: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

  const calculateGrowth = () => {
    if (earnings.data.length < 2) return { value: 0, trend: 'neutral' as const };
    
    const latest = earnings.data[0]?.revenue || 0;
    const previous = earnings.data[1]?.revenue || 0;
    
    if (previous === 0) return { value: 0, trend: 'neutral' as const };
    
    const growth = ((latest - previous) / previous) * 100;
    return {
      value: Math.abs(growth),
      trend: growth > 0 ? 'up' as const : growth < 0 ? 'down' as const : 'neutral' as const
    };
  };

  const growth = calculateGrowth();

  const getTopModule = () => {
    const modules = Object.entries(earnings.totals.modules);
    if (modules.length === 0) return null;
    
    return modules.reduce((top, [name, data]) => 
      data.revenue > top.data.revenue ? { name, data } : top
    );
  };

  const topModule = getTopModule();

  if (compact) {
    return (
      <Card className={`border-cyan-400/20 bg-black/40 backdrop-blur-sm ${className}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-cyan-400/70">Total Earnings</p>
              <p className="text-2xl font-bold text-cyan-300">
                {formatCurrency(earnings.totals.revenue)}
              </p>
            </div>
            <div className="text-right">
              <div className="flex items-center text-sm">
                {growth.trend === 'up' ? (
                  <ArrowUpRight className="text-green-400 mr-1" size={16} />
                ) : growth.trend === 'down' ? (
                  <ArrowDownRight className="text-red-400 mr-1" size={16} />
                ) : null}
                <span className={`${
                  growth.trend === 'up' ? 'text-green-400' : 
                  growth.trend === 'down' ? 'text-red-400' : 'text-cyan-400/70'
                }`}>
                  {growth.value.toFixed(1)}%
                </span>
              </div>
              <p className="text-xs text-cyan-400/50">{earnings.data.length} records</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-cyan-300">Earnings Dashboard</h2>
          <p className="text-cyan-400/70">Track your passive income performance</p>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          className="border-cyan-400/50 text-cyan-300 hover:bg-cyan-400/10"
        >
          <Settings size={16} className="mr-2" />
          Configure
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="text-green-400" size={20} />
              <div>
                <p className="text-sm text-cyan-400/70">Total Revenue</p>
                <p className="text-xl font-bold text-cyan-300">
                  {formatCurrency(earnings.totals.revenue)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="text-blue-400" size={20} />
              <div>
                <p className="text-sm text-cyan-400/70">Transactions</p>
                <p className="text-xl font-bold text-cyan-300">
                  {earnings.totals.transactions.toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className={`${
                growth.trend === 'up' ? 'text-green-400' : 
                growth.trend === 'down' ? 'text-red-400' : 'text-cyan-400'
              }`} size={20} />
              <div>
                <p className="text-sm text-cyan-400/70">Growth</p>
                <p className={`text-xl font-bold ${
                  growth.trend === 'up' ? 'text-green-400' : 
                  growth.trend === 'down' ? 'text-red-400' : 'text-cyan-300'
                }`}>
                  {growth.trend !== 'neutral' ? (growth.trend === 'up' ? '+' : '-') : ''}
                  {growth.value.toFixed(1)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <PieChart className="text-purple-400" size={20} />
              <div>
                <p className="text-sm text-cyan-400/70">Top Module</p>
                <p className="text-lg font-bold text-cyan-300">
                  {topModule ? topModule.name.replace('_', ' ') : 'None'}
                </p>
                {topModule && (
                  <p className="text-xs text-cyan-400/50">
                    {formatCurrency(topModule.data.revenue)}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <Tabs value={selectedPeriod} onValueChange={(value) => setSelectedPeriod(value as any)}>
        <TabsList className="grid w-full grid-cols-3 bg-black/40 border border-cyan-400/20">
          <TabsTrigger value="daily" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
            Daily
          </TabsTrigger>
          <TabsTrigger value="weekly" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
            Weekly
          </TabsTrigger>
          <TabsTrigger value="monthly" className="data-[state=active]:bg-cyan-400/20 data-[state=active]:text-cyan-300">
            Monthly
          </TabsTrigger>
        </TabsList>

        <TabsContent value={selectedPeriod} className="space-y-4">
          <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-cyan-300">Revenue Trends</CardTitle>
              <CardDescription className="text-cyan-400/70">
                {selectedPeriod.charAt(0).toUpperCase() + selectedPeriod.slice(1)} breakdown of earnings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {earnings.data.slice(0, 10).map((item, index) => (
                  <motion.div
                    key={item.date}
                    className="flex items-center justify-between p-3 rounded border border-cyan-400/10 bg-black/20"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <div className="flex items-center space-x-3">
                      <Calendar className="text-cyan-400" size={16} />
                      <div>
                        <p className="text-cyan-300 font-medium">
                          {new Date(item.date).toLocaleDateString()}
                        </p>
                        <p className="text-cyan-400/70 text-sm">
                          {item.transactions} transactions
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-cyan-300">
                        {formatCurrency(item.revenue)}
                      </p>
                      <div className="flex space-x-2">
                        {Object.entries(item.modules).map(([module, data]) => (
                          <Badge 
                            key={module} 
                            variant="outline" 
                            className="border-cyan-400/30 text-cyan-300 text-xs"
                          >
                            {module}: {formatCurrency(data.revenue)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
                
                {earnings.data.length === 0 && (
                  <div className="text-center py-8">
                    <BarChart3 className="text-cyan-400/50 mx-auto mb-4" size={48} />
                    <p className="text-cyan-400/70">No earnings data available</p>
                    <p className="text-cyan-400/50 text-sm mt-2">
                      Enable monetization modules to start tracking earnings
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Active Modules Status */}
      {moduleSettings && (
        <Card className="border-cyan-400/20 bg-black/40 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-cyan-300">Active Modules</CardTitle>
            <CardDescription className="text-cyan-400/70">
              Currently enabled monetization methods
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {moduleSettings.filter((module: any) => module.enabled).map((module: any) => (
                <div key={module.module} className="text-center p-3 rounded border border-cyan-400/10 bg-black/20">
                  <p className="text-cyan-300 font-medium capitalize">
                    {module.module.replace('_', ' ')}
                  </p>
                  <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/30">
                    Active
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}