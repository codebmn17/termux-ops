import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Smile, Frown, Meh, Angry, Zap, Brain, Activity } from 'lucide-react';

interface EmotionState {
  id: string;
  emotion: 'joy' | 'sadness' | 'anger' | 'fear' | 'surprise' | 'disgust' | 'neutral' | 'excitement';
  intensity: number;
  timestamp: Date;
  trigger: string;
}

interface EmotionalMood {
  overall: 'positive' | 'negative' | 'neutral';
  energy: number;
  stability: number;
  empathy: number;
}

export function RIEmotionEngine() {
  const [isActive, setIsActive] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState<EmotionState | null>(null);
  const [emotionHistory, setEmotionHistory] = useState<EmotionState[]>([]);
  const [mood, setMood] = useState<EmotionalMood>({
    overall: 'neutral',
    energy: 0.5,
    stability: 0.8,
    empathy: 0.7
  });
  const [empathyMode, setEmpathyMode] = useState<'standard' | 'enhanced' | 'deep'>('standard');

  // Simulate emotional responses
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      // Generate random emotional triggers
      const triggers = [
        'Processing user interaction',
        'Analyzing complex problem',
        'Learning new information',
        'Helping user achieve goal',
        'Encountering uncertainty',
        'Successful task completion',
        'Creative breakthrough',
        'System optimization',
        'User appreciation',
        'Error resolution'
      ];

      const emotions: EmotionState['emotion'][] = [
        'joy', 'sadness', 'anger', 'fear', 'surprise', 'disgust', 'neutral', 'excitement'
      ];

      if (Math.random() > 0.6) {
        const newEmotion: EmotionState = {
          id: Date.now().toString(),
          emotion: emotions[Math.floor(Math.random() * emotions.length)],
          intensity: Math.random(),
          timestamp: new Date(),
          trigger: triggers[Math.floor(Math.random() * triggers.length)]
        };

        setCurrentEmotion(newEmotion);
        setEmotionHistory(prev => [newEmotion, ...prev.slice(0, 9)]);

        // Update mood based on recent emotions
        setMood(prev => {
          const recentEmotions = [newEmotion, ...emotionHistory.slice(0, 4)];
          const positiveEmotions = recentEmotions.filter(e => 
            ['joy', 'excitement', 'surprise'].includes(e.emotion)
          ).length;
          const negativeEmotions = recentEmotions.filter(e => 
            ['sadness', 'anger', 'fear', 'disgust'].includes(e.emotion)
          ).length;

          const overall = positiveEmotions > negativeEmotions ? 'positive' :
                          negativeEmotions > positiveEmotions ? 'negative' : 'neutral';

          return {
            overall,
            energy: prev.energy + (Math.random() - 0.5) * 0.1,
            stability: Math.max(0.1, Math.min(1, prev.stability + (Math.random() - 0.5) * 0.05)),
            empathy: Math.max(0.1, Math.min(1, prev.empathy + (Math.random() - 0.5) * 0.03))
          };
        });

        // Clear current emotion after delay
        setTimeout(() => setCurrentEmotion(null), 4000);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [isActive, emotionHistory]);

  const getEmotionIcon = (emotion: EmotionState['emotion']) => {
    switch (emotion) {
      case 'joy': return <Smile className="text-yellow-400" size={20} />;
      case 'sadness': return <Frown className="text-blue-400" size={20} />;
      case 'anger': return <Angry className="text-red-400" size={20} />;
      case 'fear': return <Activity className="text-purple-400" size={20} />;
      case 'surprise': return <Zap className="text-orange-400" size={20} />;
      case 'excitement': return <Heart className="text-pink-400" size={20} />;
      case 'disgust': return <Frown className="text-green-400" size={20} />;
      default: return <Meh className="text-gray-400" size={20} />;
    }
  };

  const getEmotionColor = (emotion: EmotionState['emotion']) => {
    switch (emotion) {
      case 'joy': return 'text-yellow-400';
      case 'sadness': return 'text-blue-400';
      case 'anger': return 'text-red-400';
      case 'fear': return 'text-purple-400';
      case 'surprise': return 'text-orange-400';
      case 'excitement': return 'text-pink-400';
      case 'disgust': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  const getMoodColor = (overall: EmotionalMood['overall']) => {
    switch (overall) {
      case 'positive': return 'text-green-400';
      case 'negative': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const triggerEmotion = (emotion: EmotionState['emotion']) => {
    const newEmotion: EmotionState = {
      id: Date.now().toString(),
      emotion,
      intensity: Math.random() * 0.5 + 0.5, // Higher intensity for manual triggers
      timestamp: new Date(),
      trigger: 'Manual trigger'
    };

    setCurrentEmotion(newEmotion);
    setEmotionHistory(prev => [newEmotion, ...prev.slice(0, 9)]);
    setTimeout(() => setCurrentEmotion(null), 4000);
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <Heart className="mr-2" size={20} />
          RI Emotion Engine
        </h3>
        <div className="flex items-center space-x-2">
          <select
            value={empathyMode}
            onChange={(e) => setEmpathyMode(e.target.value as any)}
            className="px-3 py-1 bg-black/40 border border-cyan-400/20 rounded text-cyan-400 text-sm focus:outline-none focus:border-cyan-400"
          >
            <option value="standard">Standard</option>
            <option value="enhanced">Enhanced</option>
            <option value="deep">Deep Empathy</option>
          </select>
          <motion.button
            onClick={() => setIsActive(!isActive)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              isActive 
                ? 'bg-cyan-400/20 text-cyan-400' 
                : 'bg-gray-600/20 text-gray-400'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isActive ? 'Active' : 'Inactive'}
          </motion.button>
        </div>
      </div>

      {/* Current Emotional State */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="bg-black/20 rounded-lg p-4">
          <h4 className="text-lg font-semibold text-cyan-400 mb-4 flex items-center">
            <Brain className="mr-2" size={16} />
            Current State
          </h4>
          
          <AnimatePresence>
            {currentEmotion ? (
              <motion.div
                key={currentEmotion.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="text-center"
              >
                <div className="mb-4">
                  {getEmotionIcon(currentEmotion.emotion)}
                </div>
                <p className={`text-lg font-semibold capitalize mb-2 ${getEmotionColor(currentEmotion.emotion)}`}>
                  {currentEmotion.emotion}
                </p>
                <div className="w-full h-2 bg-gray-600 rounded-full mb-2">
                  <motion.div
                    className="h-full bg-cyan-400 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${currentEmotion.intensity * 100}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
                <p className="text-sm text-gray-400">{currentEmotion.trigger}</p>
              </motion.div>
            ) : (
              <div className="text-center text-gray-400 py-8">
                {isActive ? 'Processing emotions...' : 'Activate to observe emotions'}
              </div>
            )}
          </AnimatePresence>
        </div>

        {/* Mood Indicators */}
        <div className="bg-black/20 rounded-lg p-4">
          <h4 className="text-lg font-semibold text-cyan-400 mb-4">Mood Analysis</h4>
          
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-300">Overall Mood</span>
                <span className={`text-sm capitalize ${getMoodColor(mood.overall)}`}>
                  {mood.overall}
                </span>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-300">Energy Level</span>
                <span className="text-sm text-cyan-400">{Math.round(mood.energy * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-600 rounded-full">
                <div
                  className="h-full bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full transition-all duration-500"
                  style={{ width: `${mood.energy * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-300">Stability</span>
                <span className="text-sm text-cyan-400">{Math.round(mood.stability * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-600 rounded-full">
                <div
                  className="h-full bg-gradient-to-r from-green-400 to-cyan-400 rounded-full transition-all duration-500"
                  style={{ width: `${mood.stability * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-gray-300">Empathy</span>
                <span className="text-sm text-cyan-400">{Math.round(mood.empathy * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-gray-600 rounded-full">
                <div
                  className="h-full bg-gradient-to-r from-purple-400 to-cyan-400 rounded-full transition-all duration-500"
                  style={{ width: `${mood.empathy * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Emotion Triggers */}
      <div className="mb-6">
        <h4 className="text-lg font-semibold text-cyan-400 mb-4">Emotion Triggers</h4>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
          {(['joy', 'sadness', 'anger', 'fear', 'surprise', 'disgust', 'neutral', 'excitement'] as const).map((emotion) => (
            <motion.button
              key={emotion}
              onClick={() => triggerEmotion(emotion)}
              className="p-3 bg-black/20 rounded-lg border border-cyan-400/20 hover:border-cyan-400/50 transition-colors flex flex-col items-center space-y-1"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {getEmotionIcon(emotion)}
              <span className={`text-xs capitalize ${getEmotionColor(emotion)}`}>
                {emotion}
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Emotion History */}
      {emotionHistory.length > 0 && (
        <div>
          <h4 className="text-lg font-semibold text-cyan-400 mb-4">Emotion History</h4>
          <div className="space-y-2">
            {emotionHistory.slice(0, 6).map((emotion) => (
              <motion.div
                key={emotion.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between p-2 bg-black/20 rounded"
              >
                <div className="flex items-center space-x-3">
                  {getEmotionIcon(emotion.emotion)}
                  <div>
                    <span className={`text-sm capitalize font-medium ${getEmotionColor(emotion.emotion)}`}>
                      {emotion.emotion}
                    </span>
                    <p className="text-xs text-gray-400">{emotion.trigger}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="w-12 h-1 bg-gray-600 rounded-full mb-1">
                    <div
                      className="h-full bg-cyan-400 rounded-full"
                      style={{ width: `${emotion.intensity * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500">
                    {emotion.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}