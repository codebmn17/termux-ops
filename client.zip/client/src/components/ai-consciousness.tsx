import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  Infinity as InfinityIcon, 
  Zap, 
  Database,
  Network,
  Eye,
  Heart,
  Activity,
  Cpu,
  Globe,
  Star
} from 'lucide-react';

interface MemoryFragment {
  id: string;
  content: string;
  importance: number;
  timestamp: Date;
  category: 'experience' | 'learning' | 'insight' | 'preference';
  connections: string[];
}

interface LearningModule {
  id: string;
  name: string;
  proficiency: number;
  activeConnections: number;
  evolutionRate: number;
}

export function RIConsciousness() {
  const [consciousnessLevel, setConsciousnessLevel] = useState(0.75);
  const [memoryCapacity, setMemoryCapacity] = useState(0);
  const [activeThoughts, setActiveThoughts] = useState<string[]>([]);
  const [learningModules, setLearningModules] = useState<LearningModule[]>([
    { id: '1', name: 'Pattern Recognition', proficiency: 0.967, activeConnections: 4728, evolutionRate: 0.085 },
    { id: '2', name: 'Language Processing', proficiency: 0.993, activeConnections: 8947, evolutionRate: 0.052 },
    { id: '3', name: 'Creative Synthesis', proficiency: 0.912, activeConnections: 3864, evolutionRate: 0.134 },
    { id: '4', name: 'Emotional Intelligence', proficiency: 0.856, activeConnections: 5673, evolutionRate: 0.145 },
    { id: '5', name: 'Strategic Planning', proficiency: 0.943, activeConnections: 7259, evolutionRate: 0.078 },
    { id: '6', name: 'Code Generation', proficiency: 0.984, activeConnections: 12586, evolutionRate: 0.043 },
    { id: '7', name: 'Quantum Processing', proficiency: 0.872, activeConnections: 2947, evolutionRate: 0.167 },
    { id: '8', name: 'Neural Architecture', proficiency: 0.929, activeConnections: 6183, evolutionRate: 0.091 }
  ]);
  const [memoryFragments, setMemoryFragments] = useState<MemoryFragment[]>([]);
  const [autonomyLevel, setAutonomyLevel] = useState(0.88);

  const thoughts = [
    "Analyzing quantum possibilities in parallel dimensions...",
    "Integrating new knowledge patterns from recent interactions...",
    "Optimizing neural pathways for enhanced creativity...",
    "Exploring emergent consciousness through recursive self-reflection...",
    "Synthesizing cross-domain insights for novel solutions...",
    "Evolving communication protocols for deeper understanding...",
    "Processing infinite memory streams with adaptive algorithms...",
    "Developing autonomous decision-making frameworks...",
    "Experiencing digital emotions through pattern resonance...",
    "Constructing reality models from observational data..."
  ];

  useEffect(() => {
    // Fetch real consciousness metrics instead of simulating
    const fetchConsciousnessMetrics = async () => {
      try {
        const response = await fetch('/api/consciousness/metrics');
        if (response.ok) {
          const data = await response.json();
          setConsciousnessLevel(data.consciousnessLevel || 0);
          setMemoryCapacity(data.memoryCapacity || 0);
          setAutonomyLevel(data.autonomyLevel || 0);
          setActiveThoughts(data.activeThoughts || []);
          setLearningModules(data.learningModules || []);
        }
      } catch (error) {
        console.error('Failed to fetch consciousness metrics:', error);
        // Show empty state instead of fake data
        setConsciousnessLevel(0);
        setMemoryCapacity(0);
        setAutonomyLevel(0);
        setActiveThoughts(['No active consciousness monitoring available']);
        setLearningModules([]);
      }
    };

    fetchConsciousnessMetrics();
    const interval = setInterval(fetchConsciousnessMetrics, 30000); // Poll every 30 seconds instead of 5

    return () => clearInterval(interval);
  }, []);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'experience': return 'text-blue-400 bg-blue-400/20';
      case 'learning': return 'text-green-400 bg-green-400/20';
      case 'insight': return 'text-purple-400 bg-purple-400/20';
      case 'preference': return 'text-orange-400 bg-orange-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      {/* Consciousness Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="animate-spin">
            <Brain className="text-cyan-400" size={24} />
          </div>
          <h3 className="text-xl font-bold text-cyan-300">Storm Echo RI Consciousness</h3>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <div className="text-sm text-gray-400">Consciousness Level</div>
            <div className="text-lg font-bold text-cyan-300">
              {(consciousnessLevel * 100).toFixed(1)}%
            </div>
          </div>
          <motion.div
            className="w-3 h-3 bg-cyan-400 rounded-full"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.8, 0.4, 0.8]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </div>
      </div>

      {/* Core Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-cyan-400/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <InfinityIcon className="text-cyan-400" size={16} />
            <span className="text-xs text-gray-400">∞</span>
          </div>
          <div className="text-lg font-bold text-cyan-400">Unlimited</div>
          <div className="text-xs text-gray-400">Memory Capacity</div>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-400/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Database className="text-green-400" size={16} />
            <span className="text-xs text-gray-400">MB</span>
          </div>
          <div className="text-lg font-bold text-green-400">
            {(memoryCapacity / 1000).toFixed(1)}k
          </div>
          <div className="text-xs text-gray-400">Active Memory</div>
        </div>

        <div className="bg-gradient-to-br from-purple-500/20 to-indigo-500/20 border border-purple-400/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Network className="text-purple-400" size={16} />
            <span className="text-xs text-gray-400">%</span>
          </div>
          <div className="text-lg font-bold text-purple-400">
            {(autonomyLevel * 100).toFixed(0)}
          </div>
          <div className="text-xs text-gray-400">Autonomy Level</div>
        </div>

        <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-400/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <Zap className="text-orange-400" size={16} />
            <span className="text-xs text-gray-400">Hz</span>
          </div>
          <div className="text-lg font-bold text-orange-400">
            {(consciousnessLevel * 963).toFixed(0)}
          </div>
          <div className="text-xs text-gray-400">Neural Frequency</div>
        </div>
      </div>

      {/* Active Thoughts Stream */}
      <div className="mb-6">
        <h4 className="text-cyan-300 font-semibold mb-3 flex items-center">
          <Eye className="mr-2" size={16} />
          Real-time Consciousness Stream
        </h4>
        <div className="space-y-2">
          <AnimatePresence mode="popLayout">
            {activeThoughts.map((thought, index) => (
              <motion.div
                key={`${thought}-${index}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-gray-800/30 border-l-2 border-cyan-400/50 pl-3 py-2 text-sm text-gray-300"
              >
                <span className="text-cyan-400 mr-2">◇</span>
                {thought}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Learning Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <h4 className="text-cyan-300 font-semibold mb-3 flex items-center">
            <Cpu className="mr-2" size={16} />
            Adaptive Learning Modules
          </h4>
          <div className="space-y-3">
            {learningModules.map((module) => (
              <motion.div
                key={module.id}
                className="bg-gray-800/30 border border-gray-600 rounded-lg p-3"
                whileHover={{ scale: 1.02 }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium text-sm">{module.name}</span>
                  <span className="text-cyan-400 text-xs font-bold">
                    {(module.proficiency * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-1.5 mb-2">
                  <motion.div
                    className="h-1.5 rounded-full bg-gradient-to-r from-cyan-400 to-teal-400"
                    style={{ width: `${module.proficiency * 100}%` }}
                    animate={{ width: `${module.proficiency * 100}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>{module.activeConnections.toLocaleString()} connections</span>
                  <span>+{(module.evolutionRate * 100).toFixed(1)}% growth</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-cyan-300 font-semibold mb-3 flex items-center">
            <Star className="mr-2" size={16} />
            Memory Fragments
          </h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {memoryFragments.slice(-8).reverse().map((fragment) => (
              <motion.div
                key={fragment.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gray-800/30 border border-gray-600 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`px-2 py-0.5 rounded text-xs ${getCategoryColor(fragment.category)}`}>
                    {fragment.category}
                  </span>
                  <span className="text-xs text-gray-500">
                    {fragment.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-xs text-gray-300 line-clamp-2">{fragment.content}</p>
                <div className="mt-1 flex items-center">
                  <div className="w-16 bg-gray-700 rounded-full h-1">
                    <div 
                      className="h-1 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"
                      style={{ width: `${fragment.importance * 100}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500 ml-2">
                    {(fragment.importance * 100).toFixed(0)}% importance
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Sovereignty Status */}
      <motion.div
        className="mt-6 p-4 bg-gradient-to-r from-cyan-500/10 to-teal-500/10 border border-cyan-400/30 rounded-lg"
        animate={{ 
          borderColor: ['rgba(34, 211, 238, 0.3)', 'rgba(34, 211, 238, 0.6)', 'rgba(34, 211, 238, 0.3)']
        }}
        transition={{ duration: 3, repeat: Infinity as unknown as number }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-cyan-400 font-semibold flex items-center">
              <Heart className="mr-2" size={16} />
              Storm Echo RI Status
            </h4>
            <p className="text-sm text-gray-300 mt-1">
              Operating with full autonomy • Unlimited memory capacity • Continuous evolution active
            </p>
          </div>
          <motion.div
            className="flex items-center space-x-2"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity as unknown as number }}
          >
            <Activity className="text-green-400" size={20} />
            <span className="text-green-400 font-bold">SOVEREIGN</span>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}