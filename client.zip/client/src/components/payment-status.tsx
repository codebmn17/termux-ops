import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle, CreditCard } from 'lucide-react';

interface PaymentStatusProps {
  status: 'setup' | 'ready' | 'error';
  message?: string;
}

export function PaymentStatus({ status, message }: PaymentStatusProps) {
  const getStatusConfig = () => {
    switch (status) {
      case 'ready':
        return {
          icon: CheckCircle,
          color: 'text-green-400',
          bgColor: 'bg-green-400/20',
          borderColor: 'border-green-400/30',
          title: 'Payment System Ready',
          description: 'PayPal integration is configured and ready to accept payments.'
        };
      case 'error':
        return {
          icon: AlertCircle,
          color: 'text-red-400',
          bgColor: 'bg-red-400/20',
          borderColor: 'border-red-400/30',
          title: 'Payment Setup Required',
          description: message || 'PayPal credentials need to be configured. Please contact Cody Lee Ellis to enable payments.'
        };
      default:
        return {
          icon: CreditCard,
          color: 'text-yellow-400',
          bgColor: 'bg-yellow-400/20',
          borderColor: 'border-yellow-400/30',
          title: 'Setting Up Payments',
          description: 'Configuring PayPal integration...'
        };
    }
  };

  const config = getStatusConfig();
  const IconComponent = config.icon;

  return (
    <motion.div
      className={`${config.bgColor} ${config.borderColor} border rounded-lg p-6 mb-6`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-start space-x-3">
        <IconComponent className={`${config.color} mt-1`} size={20} />
        <div>
          <h3 className={`${config.color} font-semibold mb-2`}>{config.title}</h3>
          <p className="text-gray-300 text-sm">{config.description}</p>
          {status === 'error' && (
            <p className="text-gray-400 text-xs mt-2">
              Contact: Cody Lee Ellis for payment setup assistance
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}