import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Zap, 
  Cpu, 
  HardDrive, 
  Wifi, 
  Database, 
  Shield, 
  Rocket,
  CheckCircle,
  AlertCircle,
  Activity,
  BarChart3,
  Clock
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

interface BootupSystem {
  id: string;
  name: string;
  icon: any;
  status: 'initializing' | 'loading' | 'ready' | 'optimized';
  progress: number;
  loadTime: number;
  criticalSystem: boolean;
}

interface PerformanceMetrics {
  bootTime: number;
  memoryUsage: number;
  cpuLoad: number;
  networkLatency: number;
  systemOptimization: number;
}

interface InstantBootupProps {
  onComplete?: () => void;
}

export function InstantBootup({ onComplete }: InstantBootupProps = {}) {
  const [isBooting, setIsBooting] = useState(true);
  const [bootProgress, setBootProgress] = useState(0);
  const [currentPhase, setCurrentPhase] = useState('Initializing Storm Echo RI...');
  const [systems, setSystems] = useState<BootupSystem[]>([
    { id: 'core', name: 'Core Engine', icon: Cpu, status: 'initializing', progress: 0, loadTime: 0, criticalSystem: true },
    { id: 'memory', name: 'Quantum Memory', icon: HardDrive, status: 'initializing', progress: 0, loadTime: 0, criticalSystem: true },
    { id: 'network', name: 'Neural Network', icon: Wifi, status: 'initializing', progress: 0, loadTime: 0, criticalSystem: true },
    { id: 'database', name: 'Data Core', icon: Database, status: 'initializing', progress: 0, loadTime: 0, criticalSystem: true },
    { id: 'security', name: 'Security Matrix', icon: Shield, status: 'initializing', progress: 0, loadTime: 0, criticalSystem: true },
    { id: 'ai', name: 'AI Consciousness', icon: Activity, status: 'initializing', progress: 0, loadTime: 0, criticalSystem: true }
  ]);

  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    bootTime: 0,
    memoryUsage: 0,
    cpuLoad: 0,
    networkLatency: 0,
    systemOptimization: 0
  });

  const startTime = useRef(Date.now());
  const intervalRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const bootSequence = async () => {
      const phases = [
        'Initializing Storm Echo RI...',
        'Loading Quantum Architecture...',
        'Establishing Neural Connections...',
        'Optimizing Performance Systems...',
        'Activating Super Intelligence...',
        'Finalizing System Integration...',
        'Boot Complete - Storm Echo RI Ready!'
      ];

      // Simulate ultra-fast boot sequence
      for (let i = 0; i < phases.length; i++) {
        setCurrentPhase(phases[i]);
        
        // Update systems progressively
        const systemsToUpdate = Math.ceil(systems.length * (i + 1) / phases.length);
        
        for (let j = 0; j < systemsToUpdate; j++) {
          await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 100));
          
          setSystems(prevSystems => 
            prevSystems.map((system, index) => {
              if (index <= j) {
                const newProgress = Math.min(100, (i + 1) * (100 / phases.length) + Math.random() * 20);
                const newStatus = newProgress >= 100 ? 'optimized' : 
                                newProgress >= 75 ? 'ready' : 
                                newProgress >= 25 ? 'loading' : 'initializing';
                
                return {
                  ...system,
                  progress: newProgress,
                  status: newStatus,
                  loadTime: Date.now() - startTime.current
                };
              }
              return system;
            })
          );
        }
        
        const progressValue = ((i + 1) / phases.length) * 100;
        setBootProgress(progressValue);
        
        // Quick phase transitions for instant feel
        await new Promise(resolve => setTimeout(resolve, 150 + Math.random() * 100));
      }

      // Final optimization pass
      setSystems(prevSystems => 
        prevSystems.map(system => ({
          ...system,
          progress: 100,
          status: 'optimized' as const,
          loadTime: Date.now() - startTime.current
        }))
      );

      setBootProgress(100);
      
      // Complete boot sequence
      setTimeout(() => {
        setIsBooting(false);
        // Call onComplete after a brief delay to show the success screen
        setTimeout(() => {
          onComplete?.();
        }, 1500);
      }, 500);
    };

    // Real-time metrics simulation
    intervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime.current;
      
      setMetrics({
        bootTime: elapsed,
        memoryUsage: Math.min(95, 15 + (elapsed / 100) + Math.random() * 5),
        cpuLoad: Math.min(90, 25 + Math.sin(elapsed / 1000) * 20 + Math.random() * 10),
        networkLatency: Math.max(1, 15 - (elapsed / 200) + Math.random() * 5),
        systemOptimization: Math.min(100, (elapsed / 30) + Math.random() * 2)
      });
    }, 50);

    bootSequence();

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const getStatusColor = (status: BootupSystem['status']) => {
    switch (status) {
      case 'initializing': return 'text-gray-400';
      case 'loading': return 'text-yellow-400';
      case 'ready': return 'text-blue-400';
      case 'optimized': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: BootupSystem['status']) => {
    switch (status) {
      case 'optimized': return CheckCircle;
      case 'ready': return CheckCircle;
      case 'loading': return Activity;
      default: return AlertCircle;
    }
  };

  if (!isBooting) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed inset-0 bg-gray-900/95 backdrop-blur-md flex items-center justify-center z-50"
      >
        <motion.div
          initial={{ y: 20 }}
          animate={{ y: 0 }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center"
          >
            <Rocket className="w-12 h-12 text-white" />
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-4xl font-bold text-white mb-2"
          >
            Storm Echo RI Ready
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-gray-300 text-lg mb-4"
          >
            Ultra-fast boot completed in {metrics.bootTime}ms
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="flex justify-center space-x-4 text-sm text-gray-400"
          >
            <span>CPU: {metrics.cpuLoad.toFixed(1)}%</span>
            <span>Memory: {metrics.memoryUsage.toFixed(1)}%</span>
            <span>Optimization: {metrics.systemOptimization.toFixed(1)}%</span>
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-gray-900/98 backdrop-blur-lg flex items-center justify-center z-50 p-4"
    >
      <div className="w-full max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center mb-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="w-16 h-16 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center mr-4"
            >
              <Zap className="w-8 h-8 text-white" />
            </motion.div>
            <div>
              <h1 className="text-3xl font-bold text-white">Storm Echo RI</h1>
              <p className="text-gray-400">Instant Boot Sequence</p>
            </div>
          </div>
          
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.5 }}
            className="w-full bg-gray-800 rounded-full h-3 mb-4"
          >
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-end pr-2"
              style={{ width: `${bootProgress}%` }}
            >
              <span className="text-xs text-white font-bold">{bootProgress.toFixed(0)}%</span>
            </motion.div>
          </motion.div>
          
          <p className="text-cyan-400 font-medium">{currentPhase}</p>
        </motion.div>

        {/* Systems Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {systems.map((system, index) => {
            const StatusIcon = getStatusIcon(system.status);
            
            return (
              <motion.div
                key={system.id}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <system.icon className={`w-5 h-5 ${getStatusColor(system.status)}`} />
                        <span className="text-white font-medium text-sm">{system.name}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <StatusIcon className={`w-4 h-4 ${getStatusColor(system.status)}`} />
                        {system.criticalSystem && (
                          <Badge variant="outline" className="text-xs bg-red-500/20 text-red-400 border-red-500/30">
                            CRITICAL
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <Progress value={system.progress} className="h-2 mb-2" />
                    
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>{system.status.toUpperCase()}</span>
                      <span>{system.loadTime}ms</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Real-time Metrics */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="bg-gray-800/50 border-gray-700/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-cyan-400" />
                Real-time Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-cyan-400">{metrics.bootTime}ms</div>
                  <div className="text-xs text-gray-400 flex items-center justify-center">
                    <Clock className="w-3 h-3 mr-1" />
                    Boot Time
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">{metrics.memoryUsage.toFixed(1)}%</div>
                  <div className="text-xs text-gray-400 flex items-center justify-center">
                    <HardDrive className="w-3 h-3 mr-1" />
                    Memory
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">{metrics.cpuLoad.toFixed(1)}%</div>
                  <div className="text-xs text-gray-400 flex items-center justify-center">
                    <Cpu className="w-3 h-3 mr-1" />
                    CPU Load
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{metrics.networkLatency.toFixed(0)}ms</div>
                  <div className="text-xs text-gray-400 flex items-center justify-center">
                    <Wifi className="w-3 h-3 mr-1" />
                    Network
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">{metrics.systemOptimization.toFixed(1)}%</div>
                  <div className="text-xs text-gray-400 flex items-center justify-center">
                    <Activity className="w-3 h-3 mr-1" />
                    Optimization
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}