import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { ParticleSystem } from './particle-system';
import { usePulseFeedback } from '@/hooks/use-pulse-feedback';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface EchoPulseButtonProps {
  onPulse: () => void;
}

export function EchoPulseButton({ onPulse }: EchoPulseButtonProps) {
  const [isPulsing, setIsPulsing] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const particleContainerRef = useRef<HTMLDivElement>(null);
  const { createParticleBurst } = ParticleSystem({ containerRef: particleContainerRef });
  const { isActive, currentPhase, pulseButtonPressed } = usePulseFeedback();

  // AI analysis mutation
  const analyzePulseMutation = useMutation({
    mutationFn: async (pulseData: { sequence: number[], syncMode: string }) => {
      return apiRequest('/api/pulse/analyze', 'POST', {
        ...pulseData,
        userId: 'storm-echo-user',
        frequency: '963'
      });
    },
    onSuccess: (data: any) => {
      console.log('🤖 AI Analysis:', data.analysis);
    },
    onError: (error) => {
      console.log('🤖 AI Analysis unavailable:', error);
    }
  });

  const handlePulse = async () => {
    if (isPulsing || isActive) return;

    setIsPulsing(true);
    onPulse();
    
    // Immediate vibration feedback on button press
    if ('vibrate' in navigator) {
      console.log("🎯 Echo Pulse button vibration");
      navigator.vibrate(50); // Short initial vibration
    }

    // Create particle burst effect
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      createParticleBurst(centerX, centerY);
    }

    // Trigger the pulse feedback sequence and get the sequence data
    const sequence = await pulseButtonPressed();
    
    // Send pulse data for AI analysis
    if (sequence) {
      analyzePulseMutation.mutate({
        sequence: sequence.map(p => p.duration),
        syncMode: 'pulse'
      });
    }

    // Reset after animation
    setTimeout(() => {
      setIsPulsing(false);
    }, 2000);
  };

  return (
    <>
      <div className="relative mb-8">
        <motion.button
          ref={buttonRef}
          onClick={handlePulse}
          disabled={isPulsing || isActive}
          data-echo-pulse
          className={`echo-button relative w-36 h-36 md:w-44 md:h-44 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center transition-all duration-300 ${
            isPulsing || isActive ? 'animate-pulse-glow opacity-80' : ''
          } ${
            isActive ? 'cursor-not-allowed' : 'cursor-pointer'
          }`}
          whileHover={!isActive ? { scale: 1.05 } : {}}
          whileTap={!isActive ? { scale: 0.95 } : {}}
          transition={{ duration: 0.3, ease: "easeInOut" }}
        >
          {/* Subtle AI Heartbeat Pulse */}
          <motion.div
            className="absolute inset-2 rounded-full bg-white/5"
            animate={{
              scale: [1, 1.05, 1],
              opacity: [0.1, 0.05, 0.1]
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <span className="text-black font-['Orbitron'] font-bold text-lg md:text-xl tracking-wide relative z-10">
            {isActive ? 'Pulsing...' : 'Echo Pulse'}
          </span>
        </motion.button>
        
        {/* Pulse feedback indicator */}
        {currentPhase && (
          <motion.div
            className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 text-cyan-400 text-sm font-medium text-center whitespace-nowrap"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            {currentPhase}
          </motion.div>
        )}
      </div>
      <div ref={particleContainerRef} className="fixed inset-0 pointer-events-none z-50" />
    </>
  );
}
