import { useState } from 'react';
import { motion } from 'framer-motion';
import { DollarSign, TrendingUp, Eye, EyeOff, ArrowUpRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { EarningsDashboard } from './earnings-dashboard';

interface EarningsWidgetProps {
  className?: string;
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
  compact?: boolean;
}

export function EarningsWidget({ 
  className = '', 
  position = 'top-right',
  compact = true 
}: EarningsWidgetProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const { data: earningsData } = useQuery({
    queryKey: ['/api/monetization/earnings', 'daily'],
    refetchInterval: 60000, // Refresh every minute
  });

  const { data: moduleSettings } = useQuery({
    queryKey: ['/api/monetization/settings'],
  });

  // Don't show widget if no monetization modules are enabled
  const hasActiveModules = moduleSettings?.settings?.some((module: any) => module.enabled) || false;
  
  if (!hasActiveModules && !isVisible) {
    return null;
  }

  const totalEarnings = earningsData?.totals?.revenue || 0;
  const todayEarnings = earningsData?.data?.[0]?.revenue || 0;
  const activeModules = moduleSettings?.settings?.filter((module: any) => module.enabled).length || 0;

  const formatCurrency = (amount: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

  const positionClasses = {
    'top-right': 'fixed top-4 right-4 z-50',
    'top-left': 'fixed top-4 left-4 z-50',
    'bottom-right': 'fixed bottom-4 right-4 z-50',
    'bottom-left': 'fixed bottom-4 left-4 z-50'
  };

  if (isExpanded) {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
        <motion.div
          className="w-full max-w-6xl max-h-[90vh] overflow-auto"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="border-cyan-400/20 bg-black/90 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-cyan-300">Revenue Dashboard</h2>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsExpanded(false)}
                  className="border-cyan-400/50 text-cyan-300"
                >
                  Close
                </Button>
              </div>
              <EarningsDashboard />
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div
      className={`${positionClasses[position]} ${className}`}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.05 }}
    >
      <Card className="border-cyan-400/20 bg-black/60 backdrop-blur-sm hover:bg-black/70 transition-all duration-300 cursor-pointer group">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <DollarSign className="text-green-400" size={18} />
              <span className="text-sm font-medium text-cyan-300">Earnings</span>
            </div>
            <div className="flex items-center space-x-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsVisible(!isVisible)}
                className="p-1 h-6 w-6 hover:bg-cyan-400/10"
              >
                {isVisible ? <EyeOff size={12} /> : <Eye size={12} />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(true)}
                className="p-1 h-6 w-6 hover:bg-cyan-400/10"
              >
                <ArrowUpRight size={12} />
              </Button>
            </div>
          </div>

          {isVisible ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-cyan-400/70">Total</span>
                <span className="text-lg font-bold text-cyan-300">
                  {formatCurrency(totalEarnings)}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-cyan-400/70">Today</span>
                <span className="text-sm font-semibold text-green-400">
                  +{formatCurrency(todayEarnings)}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-cyan-400/70">Active</span>
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                  {activeModules} modules
                </Badge>
              </div>

              <div className="pt-2 border-t border-cyan-400/20">
                <div className="flex items-center text-xs text-cyan-400/60">
                  <TrendingUp size={10} className="mr-1" />
                  <span>Live tracking</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-cyan-300">
                {formatCurrency(totalEarnings)}
              </span>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                Live
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}