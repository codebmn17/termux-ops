import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Monitor, Keyboard, Zap, Terminal, Activity } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

export function KeyboardDebugPanel() {
  const [testResults, setTestResults] = useState<any[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  // Get keyboard status
  const { data: keyboardStatus } = useQuery({
    queryKey: ['/api/keyboard/status'],
    refetchInterval: 2000
  });

  // Get available layouts
  const { data: layouts } = useQuery({
    queryKey: ['/api/keyboard/layouts']
  });

  const runKeyboardTests = async () => {
    setIsRunning(true);
    setTestResults([]);
    
    const tests = [
      {
        name: 'Session Creation Test',
        test: async () => {
          const response = await fetch('/api/keyboard/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ terminalType: 'dev' })
          });
          return response.json();
        }
      },
      {
        name: 'Key Processing Test (F5)',
        test: async () => {
          // First create a session
          const sessionResponse = await fetch('/api/keyboard/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ terminalType: 'dev' })
          });
          const session = await sessionResponse.json();
          
          // Test key processing
          const keyResponse = await fetch('/api/keyboard/process-key', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sessionId: session.sessionId,
              key: 'F5',
              modifiers: {}
            })
          });
          return keyResponse.json();
        }
      },
      {
        name: 'Ctrl+L Test',
        test: async () => {
          const sessionResponse = await fetch('/api/keyboard/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ terminalType: 'dev' })
          });
          const session = await sessionResponse.json();
          
          const keyResponse = await fetch('/api/keyboard/process-key', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sessionId: session.sessionId,
              key: 'l',
              modifiers: { ctrl: true }
            })
          });
          return keyResponse.json();
        }
      },
      {
        name: 'Layout Switch Test',
        test: async () => {
          const sessionResponse = await fetch('/api/keyboard/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ terminalType: 'network' })
          });
          const session = await sessionResponse.json();
          
          const switchResponse = await fetch('/api/keyboard/switch-layout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sessionId: session.sessionId,
              layoutId: 'security-ops'
            })
          });
          return switchResponse.json();
        }
      },
      {
        name: 'Session Stats Test',
        test: async () => {
          const sessionResponse = await fetch('/api/keyboard/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ terminalType: 'security' })
          });
          const session = await sessionResponse.json();
          
          const statsResponse = await fetch(`/api/keyboard/session/${session.sessionId}/stats`);
          return statsResponse.json();
        }
      }
    ];

    for (const test of tests) {
      try {
        const result = await test.test();
        setTestResults(prev => [...prev, {
          name: test.name,
          status: 'success',
          result,
          timestamp: new Date().toISOString()
        }]);
      } catch (error) {
        setTestResults(prev => [...prev, {
          name: test.name,
          status: 'error',
          error: error instanceof Error ? error.message : 'Unknown error',
          timestamp: new Date().toISOString()
        }]);
      }
    }
    
    setIsRunning(false);
  };

  return (
    <Card className="bg-black/90 backdrop-blur-lg border-cyan-500/30 p-6">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Monitor className="w-6 h-6 text-cyan-400" />
            <h2 className="text-xl font-bold text-cyan-400">Keyboard Debug Panel</h2>
          </div>
          <Button
            onClick={runKeyboardTests}
            disabled={isRunning}
            className="bg-cyan-600 hover:bg-cyan-500"
          >
            {isRunning ? (
              <>
                <Activity className="w-4 h-4 mr-2 animate-spin" />
                Running Tests...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Run Debug Tests
              </>
            )}
          </Button>
        </div>

        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
            <h3 className="text-cyan-400 font-semibold mb-2">System Status</h3>
            {keyboardStatus ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span className="text-green-400 text-sm">Initialized</span>
                </div>
                <div className="text-xs text-gray-400">
                  {keyboardStatus.totalLayouts} layouts available
                </div>
                <div className="text-xs text-gray-400">
                  {keyboardStatus.activeSessions} active sessions
                </div>
              </div>
            ) : (
              <div className="text-red-400 text-sm">Loading...</div>
            )}
          </div>

          <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
            <h3 className="text-cyan-400 font-semibold mb-2">Available Layouts</h3>
            {layouts ? (
              <div className="space-y-1">
                {layouts.slice(0, 3).map((layout: any) => (
                  <Badge
                    key={layout.id}
                    variant="outline"
                    className="text-xs border-cyan-400/30 text-cyan-400"
                  >
                    {layout.name}
                  </Badge>
                ))}
                {layouts.length > 3 && (
                  <div className="text-xs text-gray-400">
                    +{layouts.length - 3} more
                  </div>
                )}
              </div>
            ) : (
              <div className="text-red-400 text-sm">Loading...</div>
            )}
          </div>

          <div className="bg-black/50 border border-cyan-500/30 rounded-lg p-4">
            <h3 className="text-cyan-400 font-semibold mb-2">Test Results</h3>
            <div className="space-y-1">
              <div className="text-xs text-gray-400">
                {testResults.filter(r => r.status === 'success').length} passed
              </div>
              <div className="text-xs text-gray-400">
                {testResults.filter(r => r.status === 'error').length} failed
              </div>
              <div className="text-xs text-gray-400">
                {testResults.length} total tests
              </div>
            </div>
          </div>
        </div>

        {/* Test Results */}
        {testResults.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-cyan-400 font-semibold">Test Results</h3>
            <div className="max-h-64 overflow-y-auto space-y-2">
              {testResults.map((result, index) => (
                <div
                  key={index}
                  className={`p-3 rounded border ${
                    result.status === 'success'
                      ? 'bg-green-500/10 border-green-500/30'
                      : 'bg-red-500/10 border-red-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`font-medium ${
                      result.status === 'success' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {result.name}
                    </span>
                    <Badge
                      variant={result.status === 'success' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {result.status}
                    </Badge>
                  </div>
                  <div className="mt-2 text-xs text-gray-400 font-mono">
                    {result.status === 'success' ? (
                      <pre className="whitespace-pre-wrap">
                        {JSON.stringify(result.result, null, 2)}
                      </pre>
                    ) : (
                      <span className="text-red-400">{result.error}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Layout Details */}
        {layouts && (
          <div className="space-y-2">
            <h3 className="text-cyan-400 font-semibold">Layout Configuration</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {layouts.map((layout: any) => (
                <div
                  key={layout.id}
                  className="bg-black/50 border border-cyan-500/30 rounded-lg p-4"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Keyboard className="w-4 h-4 text-cyan-400" />
                    <span className="font-semibold text-cyan-400">{layout.name}</span>
                    <Badge variant="outline" className="text-xs border-cyan-400/30 text-cyan-400">
                      {layout.layout}
                    </Badge>
                  </div>
                  <div className="text-xs text-gray-400 space-y-1">
                    <div>Mappings: {Object.keys(layout.mappings || {}).length}</div>
                    <div>Shortcuts: {Object.keys(layout.shortcuts || {}).length}</div>
                    <div>Language: {layout.language}</div>
                  </div>
                  
                  {/* Show some example shortcuts */}
                  <div className="mt-2">
                    <div className="text-xs text-cyan-400 mb-1">Key Shortcuts:</div>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(layout.shortcuts || {}).slice(0, 6).map(([key, value]) => (
                        <Badge
                          key={key}
                          variant="outline"
                          className="text-xs border-gray-500/30 text-gray-400"
                          title={`${key} → ${value}`}
                        >
                          {key}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}