import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, Database, Settings, Code, Terminal, Eye, EyeOff, Download, Copy, Server } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

interface BackendAccess {
  authenticated: boolean;
  level: 'basic' | 'advanced' | 'admin';
  features: string[];
}

interface SystemLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warning' | 'error' | 'success';
  category: string;
  message: string;
}

interface DatabaseQuery {
  id: string;
  query: string;
  description: string;
  category: 'users' | 'analytics' | 'revenue' | 'system';
}

export default function BackendPortal() {
  const [password, setPassword] = useState('');
  const [access, setAccess] = useState<BackendAccess>({ authenticated: false, level: 'basic', features: [] });
  const [activeTab, setActiveTab] = useState('overview');
  const [showSystemLogs, setShowSystemLogs] = useState(false);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);
  const [cloneData, setCloneData] = useState<any>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const { toast } = useToast();

  const databaseQueries: DatabaseQuery[] = [
    {
      id: 'user-stats',
      query: 'SELECT COUNT(*) as total_users, AVG(session_duration) as avg_session FROM users WHERE created_at > NOW() - INTERVAL 30 DAY',
      description: 'User statistics for the last 30 days',
      category: 'users'
    },
    {
      id: 'revenue-summary',
      query: 'SELECT SUM(amount) as total_revenue, COUNT(*) as transactions FROM payments WHERE status = "completed"',
      description: 'Total revenue and transaction count',
      category: 'revenue'
    },
    {
      id: 'frequency-usage',
      query: 'SELECT frequency_hz, COUNT(*) as usage_count FROM pulse_logs GROUP BY frequency_hz ORDER BY usage_count DESC LIMIT 10',
      description: 'Most popular frequency settings',
      category: 'analytics'
    },
    {
      id: 'system-health',
      query: 'SELECT status, COUNT(*) as count FROM system_monitors WHERE timestamp > NOW() - INTERVAL 1 HOUR GROUP BY status',
      description: 'System health status in the last hour',
      category: 'system'
    }
  ];

  useEffect(() => {
    // Generate mock system logs
    const generateLogs = () => {
      const categories = ['AUTH', 'API', 'DATABASE', 'REVENUE', 'SYSTEM'];
      const levels: SystemLog['level'][] = ['info', 'warning', 'error', 'success'];
      const messages = [
        'User authentication successful',
        'API rate limit reached',
        'Database connection established',
        'Payment processed successfully',
        'System backup completed',
        'Memory usage: 78%',
        'New frequency preset created',
        'RI consciousness updated',
        'Mining operation started',
        'GitHub automation triggered'
      ];

      const logs: SystemLog[] = [];
      for (let i = 0; i < 50; i++) {
        logs.push({
          id: `log-${i}`,
          timestamp: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000).toISOString(),
          level: levels[Math.floor(Math.random() * levels.length)],
          category: categories[Math.floor(Math.random() * categories.length)],
          message: messages[Math.floor(Math.random() * messages.length)]
        });
      }
      
      setSystemLogs(logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    };

    generateLogs();
  }, []);

  const authenticateAccess = async () => {
    if (!password.trim()) {
      toast({
        title: "Password Required",
        description: "Please enter the admin password",
        variant: "destructive",
      });
      return;
    }

    setIsAuthenticating(true);
    
    try {
      // Test authentication by making a request to a protected API endpoint
      const response = await fetch('/api/backend-auth', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${btoa(`admin:${password}`)}`
        },
        body: JSON.stringify({ action: 'verify' })
      });

      if (response.ok) {
        setAccess({
          authenticated: true,
          level: 'admin',
          features: ['logs', 'status', 'database', 'analytics', 'clone', 'system']
        });
        
        toast({
          title: "Access Granted!",
          description: "Backend portal unlocked with admin privileges",
        });

        generateCloneData();
      } else {
        toast({
          title: "Access Denied",
          description: "Invalid admin password",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Authentication Error",
        description: "Unable to verify credentials",
        variant: "destructive",
      });
    } finally {
      setIsAuthenticating(false);
    }
  };

  const generateCloneData = () => {
    const timestamp = new Date().toISOString();
    
    setCloneData({
      metadata: {
        projectName: 'Storm Echo RI System',
        version: '2.0.0',
        generatedAt: timestamp,
        author: 'Cody Lee Ellis',
        description: 'AI-powered interface with frequency generation, theta waves, voice synthesis, and comprehensive coding terminals'
      },
      systemArchitecture: {
        frontend: {
          framework: 'React 18 + TypeScript',
          buildTool: 'Vite',
          routing: 'Wouter',
          stateManagement: 'TanStack React Query',
          components: 'Radix UI + shadcn/ui',
          styling: 'Tailwind CSS with custom variables',
          animations: 'Framer Motion',
          theme: 'Dark galaxy theme with cyan/blue accents'
        },
        backend: {
          runtime: 'Node.js with ES modules',
          framework: 'Express.js + TypeScript',
          database: 'PostgreSQL with Drizzle ORM (Neon serverless)',
          sessionManagement: 'Built-in with connect-pg-simple',
          aiIntegration: 'OpenAI GPT-4o + Anthropic Claude 3.5 Sonnet',
          paymentProcessing: 'PayPal SDK integration'
        },
        deployment: {
          platform: 'Replit Deployments',
          database: 'Neon Database (serverless)',
          buildSystem: 'Vite + esbuild',
          development: 'Concurrent Vite dev + Express server',
          domain: '.replit.app domain with custom options'
        }
      },
      codebaseStructure: {
        client: {
          'src/components/': 'React UI components with cosmic theming',
          'src/pages/': 'Page components (home, ai-features, payments, etc.)',
          'src/hooks/': 'Custom React hooks',
          'src/lib/': 'Utility functions and configurations'
        },
        server: {
          'index.ts': 'Main server entry point',
          'routes.ts': 'API route definitions',
          'db.ts': 'Database connection setup',
          'storage.ts': 'Data storage interface',
          'openai.ts': 'AI integration handlers',
          'paypal.ts': 'Payment processing logic'
        },
        shared: {
          'schema.ts': 'Database schema with Drizzle + Zod validation'
        },
        config: {
          'package.json': 'Dependencies and scripts',
          'tsconfig.json': 'TypeScript configuration',
          'tailwind.config.ts': 'Tailwind CSS setup',
          'drizzle.config.ts': 'Database configuration'
        }
      },
      dependencies: {
        core: [
          'react@18', 'express', 'drizzle-orm', '@neondatabase/serverless',
          'typescript', 'wouter', '@tanstack/react-query'
        ],
        ui: [
          '@radix-ui/react-*', 'tailwindcss', 'framer-motion', 'lucide-react',
          'tailwind-merge', 'class-variance-authority', 'next-themes'
        ],
        backend: [
          'express-session', 'connect-pg-simple', 'drizzle-kit',
          'tsx', 'esbuild', 'zod', 'nanoid'
        ],
        apis: [
          'openai', '@anthropic-ai/sdk', '@paypal/paypal-server-sdk'
        ],
        build: [
          'vite', '@vitejs/plugin-react', '@replit/vite-plugin-cartographer'
        ]
      },
      environmentVariables: {
        required: {
          'DATABASE_URL': 'PostgreSQL connection string from Neon',
          'OPENAI_API_KEY': 'OpenAI API key for GPT-4o access'
        },
        optional: {
          'PAYPAL_CLIENT_ID': 'PayPal sandbox/production client ID',
          'PAYPAL_CLIENT_SECRET': 'PayPal sandbox/production secret',
          'NODE_ENV': 'Environment setting (development/production)'
        }
      },
      features: {
        aiCapabilities: [
          'Dynamic AI Personality Selector (8 unique personalities)',
          'Voice Chamber with pulsing orb visualization',
          'Emotion Engine with real-time adaptation',
          'Dual AI fallback system (OpenAI + Anthropic)'
        ],
        userInterface: [
          'Galaxy-themed cosmic background with particle effects',
          'Interactive terminals (Termux, Linux, Flutter, GitHub)',
          'Responsive design with mobile-friendly layouts',
          'Advanced frequency generator with theta wave presets',
          'Real-time data visualization and analytics'
        ],
        backend: [
          'Comprehensive backend portal with system monitoring',
          'PayPal integration for subscription management',
          'Database-driven storage with PostgreSQL',
          'RESTful API with error handling and logging',
          'Session management and user authentication'
        ]
      },
      revenueStreams: {
        subscriptions: {
          'Echo Access': '$9.99/month - Basic AI access',
          'Storm Mastery': '$19.99/month - Advanced features',
          'Echo Dominion': '$49.99/month - Enterprise features'
        },
        additionalStreams: {
          'Mobile Apps': '$500-2000/month via Flutter app monetization',
          'GitHub Projects': '$200-800/month via sponsorships',
          'Termux Scripts': '$100-500/month via automation tools',
          'Freelance Tools': '$400-1500/month via custom development'
        }
      },
      setupScripts: {
        '.env.example': `# Storm Echo RI Environment Variables
DATABASE_URL=postgresql://username:password@host:5432/database
OPENAI_API_KEY=sk-your-openai-key-here
PAYPAL_CLIENT_ID=your-paypal-client-id
PAYPAL_CLIENT_SECRET=your-paypal-client-secret
ADMIN_PASSWORD=your-secure-admin-password
NODE_ENV=development`,
        'setup.sh': `#!/bin/bash
echo "🌟 Setting up Storm Echo RI System..."

# Install dependencies
npm install

# Copy environment template
cp .env.example .env
echo "📝 Please edit .env with your credentials"

# Setup database
echo "🗄️ Setting up database..."
npm run db:push

# Start development server
echo "🚀 Starting development server..."
npm run dev`,
        'deploy.sh': `#!/bin/bash
echo "🚀 Deploying Storm Echo RI System..."

# Build project
npm run build

# Push database changes
npm run db:push

echo "✅ Deployment ready - configure environment variables on your platform"`
      },
      cloneInstructions: `# 🌟 Storm Echo RI System - Complete Clone Guide

## Quick Start (Replit)
1. Fork this Replit project
2. Add environment variables in Secrets:
   - DATABASE_URL (from Neon Database)
   - OPENAI_API_KEY (from OpenAI)
3. Click "Run" to start the application

## Manual Setup
\`\`\`bash
# 1. Clone repository
git clone https://github.com/codebmn17/storm-echo-ri.git
cd storm-echo-ri

# 2. Install dependencies
npm install

# 3. Environment setup
cp .env.example .env
# Edit .env with your credentials

# 4. Database setup
npm run db:push

# 5. Start development
npm run dev
\`\`\`

## Database Setup (Neon)
1. Create account at neon.tech
2. Create new database
3. Copy connection string to DATABASE_URL

## OpenAI API Setup
1. Visit platform.openai.com
2. Create API key
3. Add to OPENAI_API_KEY

## PayPal Integration (Optional)
1. Create PayPal Developer account
2. Create sandbox app
3. Add Client ID and Secret to environment

## Deployment Options
- **Replit Deployments**: One-click deploy
- **Vercel**: Connect GitHub repo
- **Railway**: Deploy with database
- **DigitalOcean**: Use App Platform

## Revenue Configuration
1. Set up PayPal merchant account
2. Configure subscription tiers
3. Enable payment processing
4. Monitor through backend portal

## Support & Documentation
- Backend Portal: /backend-portal (admin access)
- API Documentation: Built-in endpoints
- Component Library: Radix UI + shadcn/ui
- AI Integration: GPT-4o + Claude 3.5 Sonnet

Generated on: ${timestamp}
      `.trim()
    });
  };

  const copyCloneData = async () => {
    if (!cloneData) return;
    
    const cloneText = JSON.stringify(cloneData, null, 2);
    try {
      await navigator.clipboard.writeText(cloneText);
      toast({
        title: "Clone Data Copied!",
        description: "Complete system architecture and setup instructions copied",
      });
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Could not copy clone data",
        variant: "destructive",
      });
    }
  };

  const downloadCloneData = () => {
    if (!cloneData) return;
    
    const cloneText = JSON.stringify(cloneData, null, 2);
    const blob = new Blob([cloneText], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `storm-echo-ri-clone-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Clone Package Ready",
      description: "Complete system clone data downloaded successfully",
    });
  };

  const downloadSetupScript = (scriptType: 'setup' | 'deploy' | 'env') => {
    if (!cloneData?.setupScripts) return;
    
    const scripts = {
      setup: { content: cloneData.setupScripts['setup.sh'], filename: 'setup.sh' },
      deploy: { content: cloneData.setupScripts['deploy.sh'], filename: 'deploy.sh' },
      env: { content: cloneData.setupScripts['.env.example'], filename: '.env.example' }
    };
    
    const script = scripts[scriptType];
    const blob = new Blob([script.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = script.filename;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Script Downloaded",
      description: `${script.filename} is ready for use`,
    });
  };

  const copyToClipboard = (text: string, title: string = "Copied to Clipboard") => {
    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: title,
        description: "Text copied to clipboard successfully",
      });
    }).catch(() => {
      toast({
        title: "Copy Failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    });
  };

  const getLevelColor = (level: string) => {
    const colors = {
      basic: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      advanced: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      admin: 'bg-red-500/20 text-red-300 border-red-500/30'
    };
    return colors[level as keyof typeof colors] || colors.basic;
  };

  const getLogLevelColor = (level: SystemLog['level']) => {
    const colors = {
      info: 'text-blue-400',
      warning: 'text-yellow-400',
      error: 'text-red-400',
      success: 'text-green-400'
    };
    return colors[level];
  };

  if (!access.authenticated) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="w-96 bg-black/40 border-cyan-500/30">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="p-3 rounded-full bg-gradient-to-r from-red-500 to-orange-600">
                  <Shield className="text-white" size={32} />
                </div>
              </div>
              <CardTitle className="text-2xl text-cyan-400">Backend Portal Access</CardTitle>
              <CardDescription className="text-gray-400">
                Enter admin password to access backend system
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Admin password..."
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-black/20 border-cyan-500/30 text-white"
                  onKeyPress={(e) => e.key === 'Enter' && authenticateAccess()}
                />
              </div>
              <Button
                onClick={authenticateAccess}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                disabled={!password.trim() || isAuthenticating}
              >
                {isAuthenticating ? "Authenticating..." : "Access Backend Portal"}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Server className="text-cyan-400" size={28} />
            <div>
              <h2 className="text-2xl font-['Orbitron'] font-bold text-cyan-400">
                Storm Echo RI Backend Portal
              </h2>
              <div className="flex items-center space-x-2 mt-1">
                <Badge className={getLevelColor(access.level)}>
                  {access.level.toUpperCase()} ACCESS
                </Badge>
                <span className="text-sm text-gray-400">
                  Features: {access.features.join(', ')}
                </span>
              </div>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={() => setAccess({ authenticated: false, level: 'basic', features: [] })}
            className="border-red-500/30 text-red-400 hover:bg-red-500/10"
          >
            Logout
          </Button>
        </div>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-black/20 border border-cyan-500/20">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="database" disabled={!access.features.includes('database')}>
            Database
          </TabsTrigger>
          <TabsTrigger value="analytics" disabled={!access.features.includes('analytics')}>
            Analytics
          </TabsTrigger>
          <TabsTrigger value="clone" disabled={!access.features.includes('clone')}>
            Clone Portal
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-black/40 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-lg text-cyan-400 flex items-center space-x-2">
                  <Database size={20} />
                  <span>System Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Server</span>
                    <span className="text-green-400">Online</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Database</span>
                    <span className="text-green-400">Connected</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">RI System</span>
                    <span className="text-green-400">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Revenue Tracking</span>
                    <span className="text-green-400">Running</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Real-Ops Core</span>
                    <span className="text-amber-400">Active</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Python Backend</span>
                    <span className="text-purple-400">Ready</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-lg text-cyan-400 flex items-center space-x-2">
                  <Settings size={20} />
                  <span>Quick Stats</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Active Users</span>
                    <span className="text-cyan-400">142</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Pulse Sessions</span>
                    <span className="text-cyan-400">1,847</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Revenue Today</span>
                    <span className="text-green-400">$47.83</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">System Uptime</span>
                    <span className="text-cyan-400">99.8%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-lg text-cyan-400 flex items-center space-x-2">
                  <Terminal size={20} />
                  <span>Advanced Systems</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <a 
                    href="/real-ops-core" 
                    className="block p-3 rounded-lg bg-black/20 border border-amber-500/30 hover:border-amber-400/50 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Shield className="w-4 h-4 text-amber-400" />
                        <span className="text-amber-300 font-medium">Real-Ops Core</span>
                      </div>
                      <span className="text-xs text-gray-400">Advanced Operations</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1 ml-6">
                      Monetization, OSINT, Automation & API Management
                    </div>
                  </a>
                  <a 
                    href="/stealth-admin" 
                    className="block p-3 rounded-lg bg-black/20 border border-red-500/30 hover:border-red-400/50 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <EyeOff className="w-4 h-4 text-red-400" />
                        <span className="text-red-300 font-medium">Stealth Admin</span>
                      </div>
                      <span className="text-xs text-gray-400">Phantom Mode</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1 ml-6">
                      Kill switch, stealth earnings & phantom yield
                    </div>
                  </a>
                  <a 
                    href="/ai-chat" 
                    className="block p-3 rounded-lg bg-black/20 border border-purple-500/30 hover:border-purple-400/50 transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Brain className="w-4 h-4 text-purple-400" />
                        <span className="text-purple-300 font-medium">AI Chat Interface</span>
                      </div>
                      <span className="text-xs text-gray-400">Enhanced Mode</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1 ml-6">
                      Super intelligent AI with awakening triggers
                    </div>
                  </a>
                  <button 
                    onClick={() => window.open('http://localhost:8080', '_blank')}
                    className="block w-full p-3 rounded-lg bg-black/20 border border-green-500/30 hover:border-green-400/50 transition-all cursor-pointer text-left"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Server className="w-4 h-4 text-green-400" />
                        <span className="text-green-300 font-medium">Python Backend</span>
                      </div>
                      <span className="text-xs text-gray-400">Port 8080</span>
                    </div>
                    <div className="text-xs text-gray-400 mt-1 ml-6">
                      Heartbeat logger & performance monitoring
                    </div>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* System Logs Card */}
          <div className="mt-4">
            <Card className="bg-black/40 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-lg text-cyan-400 flex items-center space-x-2">
                  <Terminal size={20} />
                  <span>System Logs</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowSystemLogs(!showSystemLogs)}
                    className="ml-auto"
                  >
                    {showSystemLogs ? <EyeOff size={16} /> : <Eye size={16} />}
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {showSystemLogs ? (
                  <ScrollArea className="h-32">
                    <div className="space-y-1 text-xs font-mono">
                      {systemLogs.slice(0, 10).map((log) => (
                        <div key={log.id} className="flex items-center space-x-2">
                          <span className="text-gray-500">
                            {new Date(log.timestamp).toLocaleTimeString()}
                          </span>
                          <span className={`font-bold ${getLogLevelColor(log.level)}`}>
                            [{log.level.toUpperCase()}]
                          </span>
                          <span className="text-gray-400 truncate">
                            {log.message}
                          </span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="text-sm text-gray-400">
                    Click the eye icon to view recent system logs
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="database" className="space-y-4">
          <Card className="bg-black/40 border-cyan-500/20">
            <CardHeader>
              <CardTitle className="text-xl text-cyan-400">Database Queries</CardTitle>
              <CardDescription>
                Pre-built queries for system analysis and monitoring
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {databaseQueries.map((query) => (
                  <Card key={query.id} className="bg-black/20 border-cyan-500/10">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-cyan-400">
                          {query.description}
                        </CardTitle>
                        <Badge className={getCategoryColor(query.category)}>
                          {query.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-20">
                        <pre className="text-sm text-gray-300 font-mono">
                          {query.query}
                        </pre>
                      </ScrollArea>
                      <div className="flex items-center space-x-2 mt-4">
                        <Button
                          size="sm"
                          onClick={() => copyToClipboard(query.query, 'Database Query')}
                          className="bg-cyan-500/20 hover:bg-cyan-500/30"
                        >
                          <Copy size={14} className="mr-2" />
                          Copy
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-cyan-500/30"
                        >
                          Execute
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-black/40 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-xl text-cyan-400">Revenue Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Mobile Apps</span>
                    <span className="text-green-400">$1,247.80</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">GitHub Projects</span>
                    <span className="text-green-400">$589.50</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Web Platform</span>
                    <span className="text-green-400">$823.25</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Crypto Mining</span>
                    <span className="text-green-400">$156.75</span>
                  </div>
                  <hr className="border-cyan-500/20" />
                  <div className="flex justify-between items-center font-bold">
                    <span className="text-cyan-400">Total Revenue</span>
                    <span className="text-green-400">$2,817.30</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/40 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-xl text-cyan-400">Usage Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Daily Active Users</span>
                    <span className="text-cyan-400">342</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Echo Pulses Today</span>
                    <span className="text-cyan-400">1,847</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Frequency Sessions</span>
                    <span className="text-cyan-400">2,156</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">RI Conversations</span>
                    <span className="text-cyan-400">789</span>
                  </div>
                  <hr className="border-cyan-500/20" />
                  <div className="flex justify-between items-center font-bold">
                    <span className="text-cyan-400">Total Interactions</span>
                    <span className="text-cyan-400">5,134</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="clone" className="space-y-4">
          <Card className="bg-black/40 border-red-500/30">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl text-red-400">System Clone Portal</CardTitle>
                  <CardDescription className="text-gray-400">
                    Complete system architecture and replication data
                  </CardDescription>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={copyCloneData}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-400"
                    disabled={!cloneData}
                  >
                    <Copy size={16} className="mr-2" />
                    Copy All
                  </Button>
                  <Button
                    onClick={downloadCloneData}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-400"
                    disabled={!cloneData}
                  >
                    <Download size={16} className="mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {cloneData ? (
                <ScrollArea className="h-48 max-h-64">
                  <pre className="text-sm text-gray-300 font-mono whitespace-pre-wrap">
                    {JSON.stringify(cloneData, null, 2)}
                  </pre>
                </ScrollArea>
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400">Loading clone data...</div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );



  function getCategoryColor(category: string): string {
    const colors = {
      users: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      analytics: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      revenue: 'bg-green-500/20 text-green-300 border-green-500/30',
      system: 'bg-orange-500/20 text-orange-300 border-orange-500/30'
    };
    return colors[category as keyof typeof colors] || colors.system;
  }
}