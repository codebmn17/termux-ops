import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Command, Brain, Bot, Terminal, Mic, Book, Shield, DollarSign, Package, Home, MessageSquare, Users, Activity, Cpu, Database, BarChart3, TrendingUp, Settings } from 'lucide-react';
import { useLocation } from 'wouter';

interface QuickAccessItem {
  id: string;
  label: string;
  icon: any;
  shortcut: string;
  path: string;
  color: string;
}

export function QuickAccessMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [, navigate] = useLocation();

  const quickAccessItems: QuickAccessItem[] = [
    { id: 'home', label: 'Storm Echo Home', icon: Home, shortcut: 'H', path: '/', color: 'text-cyan-400' },
    { id: 'ai', label: 'AI Features', icon: Brain, shortcut: 'A', path: '/ai-features', color: 'text-pink-400' },
    { id: 'terminal', label: 'Maximum Terminals', icon: Terminal, shortcut: 'T', path: '/coding-terminals', color: 'text-emerald-400' },
    { id: 'voice', label: 'Voice Chamber', icon: Mic, shortcut: 'V', path: '/voice-chamber', color: 'text-violet-400' },
    { id: 'library', label: 'Quantum Library', icon: Book, shortcut: 'L', path: '/library', color: 'text-blue-400' },
    { id: 'consciousness', label: 'Consciousness Cloning', icon: Activity, shortcut: 'C', path: '/consciousness-cloning', color: 'text-purple-400' },
    { id: 'processor', label: 'Processor Core', icon: Cpu, shortcut: 'O', path: '/processor-core', color: 'text-yellow-400' },
    { id: 'companion', label: 'AI Companion', icon: Users, shortcut: 'M', path: '/ai-companion', color: 'text-pink-400' },
    { id: 'backend', label: 'Backend Portal', icon: Database, shortcut: 'B', path: '/backend-portal', color: 'text-indigo-400' },
    { id: 'analytics', label: 'Analytics Dashboard', icon: BarChart3, shortcut: 'N', path: '/analytics', color: 'text-orange-400' },
    { id: 'startup', label: 'Startup Accelerator', icon: TrendingUp, shortcut: 'Q', path: '/startup-accelerator', color: 'text-green-400' },
    { id: 'income', label: 'Passive Income', icon: DollarSign, shortcut: 'I', path: '/passive-income', color: 'text-green-400' },
    { id: 'payments', label: 'Storm Plans', icon: DollarSign, shortcut: 'P', path: '/payments', color: 'text-emerald-400' },
    { id: 'storage', label: 'Storage', icon: Package, shortcut: 'S', path: '/storage', color: 'text-orange-400' },
    { id: 'codex', label: 'Echo Codex', icon: Book, shortcut: 'E', path: '/codex', color: 'text-amber-400' },
    { id: 'chat', label: 'Storm Echo Chat', icon: MessageSquare, shortcut: 'R', path: '/chat', color: 'text-blue-400' },
    { id: 'control', label: 'Control Center', icon: Settings, shortcut: 'G', path: '#control-center', color: 'text-purple-400' }
  ];

  const filteredItems = quickAccessItems.filter(item =>
    item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleItemClick = (item: QuickAccessItem) => {
    if (item.id === 'control') {
      // Toggle Control Center
      const event = new CustomEvent('toggle-control-center');
      window.dispatchEvent(event);
    } else {
      navigate(item.path);
    }
    setIsOpen(false);
    setSearchQuery('');
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + K to open quick access
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(true);
      }

      // Escape to close
      if (e.key === 'Escape') {
        setIsOpen(false);
        setSearchQuery('');
      }

      // Direct shortcuts when menu is open
      if (isOpen && !e.ctrlKey && !e.metaKey) {
        const item = quickAccessItems.find(i => 
          i.shortcut.toLowerCase() === e.key.toLowerCase()
        );
        if (item) {
          handleItemClick(item);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, navigate]);

  return (
    <>
      {/* Quick Access Button - Properly positioned */}
      <motion.button
        onClick={() => setIsOpen(true)}
        className="fixed top-4 right-4 z-30 p-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg shadow-lg hover:shadow-xl transition-all"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        title="Quick Access (Ctrl+K)"
      >
        <Command size={18} className="text-white" />
      </motion.button>

      {/* Quick Access Modal */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-35"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setIsOpen(false);
                setSearchQuery('');
              }}
            />

            {/* Menu - Properly positioned within viewport */}
            <motion.div
              className="fixed top-16 right-4 left-4 sm:left-auto sm:w-80 z-40 max-w-[calc(100vw-2rem)] sm:max-w-none"
              initial={{ scale: 0.9, opacity: 0, y: -20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: -20 }}
              transition={{ type: 'spring', duration: 0.3 }}
            >
              <div className="bg-gray-900 border border-cyan-500/30 rounded-xl shadow-2xl overflow-hidden mx-auto max-w-md">
                {/* Search Input */}
                <div className="p-4 border-b border-gray-800">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search or press shortcut key..."
                    className="w-full px-4 py-2 bg-gray-800 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    autoFocus
                  />
                </div>

                {/* Quick Access Items */}
                <div className="max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
                  {filteredItems.map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <motion.button
                        key={item.id}
                        onClick={() => handleItemClick(item)}
                        className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800 transition-colors"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <div className="flex items-center space-x-3">
                          <Icon size={20} className={item.color} />
                          <span className="text-white">{item.label}</span>
                        </div>
                        <span className="text-xs text-gray-500 bg-gray-800 px-2 py-1 rounded">
                          {item.shortcut}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>

                {/* Footer */}
                <div className="p-3 border-t border-gray-800 text-center text-xs text-gray-500">
                  Press <kbd className="px-2 py-1 bg-gray-800 rounded">Esc</kbd> to close
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}