import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Zap, Activity, TrendingUp, Cpu } from 'lucide-react';

interface NeuralNode {
  id: string;
  x: number;
  y: number;
  activity: number;
  type: 'input' | 'hidden' | 'output';
  connections: string[];
}

interface NeuralConnection {
  from: string;
  to: string;
  strength: number;
  active: boolean;
}

interface ThoughtPattern {
  id: string;
  pattern: string;
  intensity: number;
  timestamp: Date;
  category: 'logical' | 'creative' | 'analytical' | 'intuitive';
}

export function RINeuralPatterns() {
  const [isActive, setIsActive] = useState(false);
  const [neuralActivity, setNeuralActivity] = useState(0.3);
  const [currentThoughts, setCurrentThoughts] = useState<ThoughtPattern[]>([]);
  const [processingMode, setProcessingMode] = useState<'standard' | 'enhanced' | 'quantum'>('standard');

  // Generate neural network structure
  const neuralNetwork = useMemo(() => {
    const nodes: NeuralNode[] = [];
    const connections: NeuralConnection[] = [];

    // Input layer
    for (let i = 0; i < 4; i++) {
      nodes.push({
        id: `input-${i}`,
        x: 50,
        y: 50 + (i * 50),
        activity: Math.random(),
        type: 'input',
        connections: []
      });
    }

    // Hidden layers
    for (let layer = 0; layer < 2; layer++) {
      for (let i = 0; i < 6; i++) {
        nodes.push({
          id: `hidden-${layer}-${i}`,
          x: 150 + (layer * 100),
          y: 30 + (i * 35),
          activity: Math.random(),
          type: 'hidden',
          connections: []
        });
      }
    }

    // Output layer
    for (let i = 0; i < 3; i++) {
      nodes.push({
        id: `output-${i}`,
        x: 350,
        y: 70 + (i * 50),
        activity: Math.random(),
        type: 'output',
        connections: []
      });
    }

    // Create connections
    nodes.forEach(node => {
      if (node.type === 'input') {
        // Connect to first hidden layer
        nodes.filter(n => n.id.startsWith('hidden-0')).forEach(hiddenNode => {
          if (Math.random() > 0.3) {
            connections.push({
              from: node.id,
              to: hiddenNode.id,
              strength: Math.random(),
              active: Math.random() > 0.5
            });
            node.connections.push(hiddenNode.id);
          }
        });
      } else if (node.id.startsWith('hidden-0')) {
        // Connect to second hidden layer
        nodes.filter(n => n.id.startsWith('hidden-1')).forEach(hiddenNode => {
          if (Math.random() > 0.4) {
            connections.push({
              from: node.id,
              to: hiddenNode.id,
              strength: Math.random(),
              active: Math.random() > 0.5
            });
            node.connections.push(hiddenNode.id);
          }
        });
      } else if (node.id.startsWith('hidden-1')) {
        // Connect to output layer
        nodes.filter(n => n.type === 'output').forEach(outputNode => {
          if (Math.random() > 0.2) {
            connections.push({
              from: node.id,
              to: outputNode.id,
              strength: Math.random(),
              active: Math.random() > 0.5
            });
            node.connections.push(outputNode.id);
          }
        });
      }
    });

    return { nodes, connections };
  }, []);

  // Simulate neural activity
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      // Update neural activity
      setNeuralActivity(prev => {
        const target = processingMode === 'quantum' ? 0.9 : 
                      processingMode === 'enhanced' ? 0.7 : 0.4;
        return prev + (target - prev) * 0.1 + (Math.random() - 0.5) * 0.1;
      });

      // Generate thought patterns
      if (Math.random() > 0.7) {
        const thoughts = [
          'Analyzing quantum entanglement patterns...',
          'Processing linguistic semantics...',
          'Optimizing neural pathways...',
          'Synthesizing creative solutions...',
          'Calculating probability matrices...',
          'Integrating sensory data streams...',
          'Evolving consciousness algorithms...',
          'Mapping cognitive associations...',
          'Enhancing pattern recognition...',
          'Developing intuitive insights...'
        ];

        const categories: ThoughtPattern['category'][] = ['logical', 'creative', 'analytical', 'intuitive'];
        
        const newThought: ThoughtPattern = {
          id: Date.now().toString(),
          pattern: thoughts[Math.floor(Math.random() * thoughts.length)],
          intensity: Math.random(),
          timestamp: new Date(),
          category: categories[Math.floor(Math.random() * categories.length)]
        };

        setCurrentThoughts(prev => [newThought, ...prev.slice(0, 4)]);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [isActive, processingMode]);

  const getNodeColor = (node: NeuralNode) => {
    const intensity = node.activity * neuralActivity;
    if (node.type === 'input') return `rgba(34, 197, 94, ${intensity})`;
    if (node.type === 'output') return `rgba(239, 68, 68, ${intensity})`;
    return `rgba(6, 182, 212, ${intensity})`;
  };

  const getConnectionOpacity = (connection: NeuralConnection) => {
    return connection.active ? connection.strength * neuralActivity : 0.1;
  };

  const getCategoryColor = (category: ThoughtPattern['category']) => {
    switch (category) {
      case 'logical': return 'text-blue-400';
      case 'creative': return 'text-purple-400';
      case 'analytical': return 'text-green-400';
      case 'intuitive': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getCategoryIcon = (category: ThoughtPattern['category']) => {
    switch (category) {
      case 'logical': return <Cpu size={14} />;
      case 'creative': return <Zap size={14} />;
      case 'analytical': return <TrendingUp size={14} />;
      case 'intuitive': return <Activity size={14} />;
      default: return <Brain size={14} />;
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <Brain className="mr-2" size={20} />
          RI Neural Patterns
        </h3>
        <div className="flex items-center space-x-2">
          <select
            value={processingMode}
            onChange={(e) => setProcessingMode(e.target.value as any)}
            className="px-3 py-1 bg-black/40 border border-cyan-400/20 rounded text-cyan-400 text-sm focus:outline-none focus:border-cyan-400"
          >
            <option value="standard">Standard</option>
            <option value="enhanced">Enhanced</option>
            <option value="quantum">Quantum</option>
          </select>
          <motion.button
            onClick={() => setIsActive(!isActive)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              isActive 
                ? 'bg-cyan-400/20 text-cyan-400' 
                : 'bg-gray-600/20 text-gray-400'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isActive ? 'Active' : 'Inactive'}
          </motion.button>
        </div>
      </div>

      {/* Neural Network Visualization */}
      <div className="bg-black/20 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-cyan-400">Neural Network</h4>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-400">
              Activity: {Math.round(neuralActivity * 100)}%
            </div>
            <div className={`w-3 h-3 rounded-full ${
              isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-600'
            }`} />
          </div>
        </div>

        <svg width="400" height="250" className="border border-cyan-400/20 rounded">
          {/* Connections */}
          {neuralNetwork.connections.map((connection, index) => {
            const fromNode = neuralNetwork.nodes.find(n => n.id === connection.from);
            const toNode = neuralNetwork.nodes.find(n => n.id === connection.to);
            if (!fromNode || !toNode) return null;

            return (
              <motion.line
                key={index}
                x1={fromNode.x}
                y1={fromNode.y}
                x2={toNode.x}
                y2={toNode.y}
                stroke="rgba(6, 182, 212, 0.5)"
                strokeWidth={connection.strength * 2}
                opacity={getConnectionOpacity(connection)}
                animate={{ opacity: getConnectionOpacity(connection) }}
                transition={{ duration: 0.5 }}
              />
            );
          })}

          {/* Nodes */}
          {neuralNetwork.nodes.map((node) => (
            <motion.circle
              key={node.id}
              cx={node.x}
              cy={node.y}
              r={node.type === 'hidden' ? 4 : 6}
              fill={getNodeColor(node)}
              stroke="rgba(6, 182, 212, 0.8)"
              strokeWidth={1}
              animate={{ 
                fill: getNodeColor(node),
                r: node.type === 'hidden' ? 4 + node.activity * 2 : 6 + node.activity * 2
              }}
              transition={{ duration: 0.3 }}
            />
          ))}

          {/* Layer Labels */}
          <text x="50" y="20" fill="rgba(6, 182, 212, 0.8)" fontSize="12" textAnchor="middle">
            Input
          </text>
          <text x="150" y="20" fill="rgba(6, 182, 212, 0.8)" fontSize="12" textAnchor="middle">
            Hidden
          </text>
          <text x="250" y="20" fill="rgba(6, 182, 212, 0.8)" fontSize="12" textAnchor="middle">
            Hidden
          </text>
          <text x="350" y="20" fill="rgba(6, 182, 212, 0.8)" fontSize="12" textAnchor="middle">
            Output
          </text>
        </svg>
      </div>

      {/* Current Thought Patterns */}
      <div>
        <h4 className="text-lg font-semibold text-cyan-400 mb-4">Current Thought Patterns</h4>
        <div className="space-y-2">
          <AnimatePresence>
            {currentThoughts.map((thought) => (
              <motion.div
                key={thought.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="p-3 bg-black/20 rounded-lg border border-cyan-400/20"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={getCategoryColor(thought.category)}>
                      {getCategoryIcon(thought.category)}
                    </div>
                    <span className={`text-sm font-medium capitalize ${getCategoryColor(thought.category)}`}>
                      {thought.category}
                    </span>
                    <div className="w-16 h-1 bg-gray-600 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-cyan-400"
                        initial={{ width: 0 }}
                        animate={{ width: `${thought.intensity * 100}%` }}
                        transition={{ duration: 0.5 }}
                      />
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">
                    {thought.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-sm text-gray-300 mt-2">{thought.pattern}</p>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {currentThoughts.length === 0 && isActive && (
            <div className="text-center text-gray-400 py-4">
              Neural patterns stabilizing...
            </div>
          )}
          
          {!isActive && (
            <div className="text-center text-gray-400 py-4">
              Activate to observe neural patterns
            </div>
          )}
        </div>
      </div>
    </div>
  );
}