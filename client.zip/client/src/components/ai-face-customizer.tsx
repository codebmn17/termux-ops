import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Palette, Eye, Smile, Zap, RotateCcw, Save } from 'lucide-react';

interface FaceFeatures {
  eyeColor: string;
  eyeShape: 'round' | 'almond' | 'angular';
  mouthShape: 'neutral' | 'smile' | 'serious';
  faceColor: string;
  glowIntensity: number;
  animationSpeed: number;
}

export function RIFaceCustomizer() {
  const [features, setFeatures] = useState<FaceFeatures>({
    eyeColor: '#00ffff',
    eyeShape: 'round',
    mouthShape: 'neutral',
    faceColor: '#4fc3f7',
    glowIntensity: 0.8,
    animationSpeed: 1.0
  });

  const [isAnimating, setIsAnimating] = useState(false);
  const [colorCycling, setColorCycling] = useState(false);

  const eyeColors = ['#00ffff', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57'];
  const faceColors = ['#4fc3f7', '#81c784', '#ffb74d', '#f06292', '#9575cd', '#64b5f6'];

  useEffect(() => {
    if (colorCycling) {
      const interval = setInterval(() => {
        const randomEyeColor = eyeColors[Math.floor(Math.random() * eyeColors.length)];
        const randomFaceColor = faceColors[Math.floor(Math.random() * faceColors.length)];
        setFeatures(prev => ({
          ...prev,
          eyeColor: randomEyeColor,
          faceColor: randomFaceColor
        }));
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [colorCycling]);

  const updateFeature = (key: keyof FaceFeatures, value: any) => {
    // Ensure animationSpeed is never zero or negative
    if (key === 'animationSpeed') {
      value = Math.max(0.1, value);
    }
    setFeatures(prev => ({ ...prev, [key]: value }));
  };

  const resetToDefault = () => {
    setFeatures({
      eyeColor: '#00ffff',
      eyeShape: 'round',
      mouthShape: 'neutral',
      faceColor: '#4fc3f7',
      glowIntensity: 0.8,
      animationSpeed: 1.0
    });
    setColorCycling(false);
  };

  const getEyePath = (shape: string) => {
    switch (shape) {
      case 'almond':
        return 'M15,25 Q25,20 35,25 Q25,30 15,25';
      case 'angular':
        return 'M15,25 L25,20 L35,25 L25,30 Z';
      default:
        return 'M15,25 Q25,20 35,25 Q25,30 15,25';
    }
  };

  const getMouthPath = (shape: string) => {
    switch (shape) {
      case 'smile':
        return 'M20,40 Q25,45 30,40';
      case 'serious':
        return 'M20,40 L30,40';
      default:
        return 'M20,42 Q25,40 30,42';
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-300 flex items-center">
          <Palette className="mr-2" size={20} />
          RI Face Customizer
        </h3>
        <div className="flex space-x-2">
          <motion.button
            onClick={() => setColorCycling(!colorCycling)}
            className={`px-3 py-1 rounded text-xs font-medium transition-all ${
              colorCycling 
                ? 'bg-cyan-600 text-white' 
                : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {colorCycling ? 'Stop Cycling' : 'Color Cycle'}
          </motion.button>
          <motion.button
            onClick={resetToDefault}
            className="px-3 py-1 rounded bg-red-600 hover:bg-red-700 text-white text-xs font-medium transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <RotateCcw size={12} className="inline mr-1" />
            Reset
          </motion.button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Face Preview */}
        <div className="flex items-center justify-center">
          <motion.div
            className="relative"
            animate={{ 
              scale: isAnimating ? [1, 1.02, 1] : 1,
              rotate: isAnimating ? [0, 1, -1, 0] : 0
            }}
            transition={{ 
              duration: Math.max(0.5, 3 / Math.max(0.5, features.animationSpeed)), 
              repeat: isAnimating ? Infinity : 0,
              ease: "easeInOut"
            }}
          >
            <svg width="120" height="120" viewBox="0 0 50 50">
              {/* Face Glow */}
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation={3 * features.glowIntensity} result="coloredBlur"/>
                  <feMerge> 
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              
              {/* Face */}
              <circle 
                cx="25" 
                cy="25" 
                r="20" 
                fill={features.faceColor}
                filter="url(#glow)"
                opacity="0.8"
              />
              
              {/* Eyes */}
              <motion.path
                d={getEyePath(features.eyeShape)}
                fill={features.eyeColor}
                animate={{ opacity: [1, 0.3, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.path
                d={getEyePath(features.eyeShape).replace(/15/g, '30').replace(/35/g, '50')}
                fill={features.eyeColor}
                animate={{ opacity: [1, 0.3, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.1 }}
              />
              
              {/* Mouth */}
              <path
                d={getMouthPath(features.mouthShape)}
                stroke={features.eyeColor}
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
              />
              
              {/* Neural Network Lines */}
              <motion.g
                animate={{ opacity: [0.3, 0.8, 0.3] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <line x1="10" y1="15" x2="15" y2="20" stroke={features.eyeColor} strokeWidth="0.5" opacity="0.6"/>
                <line x1="40" y1="15" x2="35" y2="20" stroke={features.eyeColor} strokeWidth="0.5" opacity="0.6"/>
                <line x1="25" y1="5" x2="25" y2="15" stroke={features.eyeColor} strokeWidth="0.5" opacity="0.6"/>
              </motion.g>
            </svg>
          </motion.div>
        </div>

        {/* Customization Controls */}
        <div className="space-y-4">
          {/* Eye Color */}
          <div>
            <label className="block text-cyan-400 text-sm font-medium mb-2 flex items-center">
              <Eye size={14} className="mr-1" />
              Eye Color
            </label>
            <div className="flex space-x-2 mb-2">
              {eyeColors.map((color) => (
                <motion.button
                  key={color}
                  onClick={() => updateFeature('eyeColor', color)}
                  className={`w-6 h-6 rounded-full border-2 ${
                    features.eyeColor === color ? 'border-white' : 'border-gray-600'
                  }`}
                  style={{ backgroundColor: color }}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                />
              ))}
            </div>
            <input
              type="color"
              value={features.eyeColor}
              onChange={(e) => updateFeature('eyeColor', e.target.value)}
              className="w-full h-8 rounded border border-gray-600 bg-gray-800"
            />
          </div>

          {/* Face Color */}
          <div>
            <label className="block text-cyan-400 text-sm font-medium mb-2">Face Color</label>
            <div className="flex space-x-2 mb-2">
              {faceColors.map((color) => (
                <motion.button
                  key={color}
                  onClick={() => updateFeature('faceColor', color)}
                  className={`w-6 h-6 rounded-full border-2 ${
                    features.faceColor === color ? 'border-white' : 'border-gray-600'
                  }`}
                  style={{ backgroundColor: color }}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                />
              ))}
            </div>
          </div>

          {/* Eye Shape */}
          <div>
            <label className="block text-cyan-400 text-sm font-medium mb-2">Eye Shape</label>
            <div className="flex space-x-2">
              {['round', 'almond', 'angular'].map((shape) => (
                <motion.button
                  key={shape}
                  onClick={() => updateFeature('eyeShape', shape)}
                  className={`px-3 py-1 rounded text-xs ${
                    features.eyeShape === shape
                      ? 'bg-cyan-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {shape}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Mouth Shape */}
          <div>
            <label className="block text-cyan-400 text-sm font-medium mb-2 flex items-center">
              <Smile size={14} className="mr-1" />
              Expression
            </label>
            <div className="flex space-x-2">
              {['neutral', 'smile', 'serious'].map((mood) => (
                <motion.button
                  key={mood}
                  onClick={() => updateFeature('mouthShape', mood)}
                  className={`px-3 py-1 rounded text-xs ${
                    features.mouthShape === mood
                      ? 'bg-cyan-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {mood}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Animation Controls */}
          <div>
            <label className="block text-cyan-400 text-sm font-medium mb-2 flex items-center">
              <Zap size={14} className="mr-1" />
              Animation Speed
            </label>
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.1"
              value={features.animationSpeed}
              onChange={(e) => updateFeature('animationSpeed', Math.max(0.1, parseFloat(e.target.value)))}
              className="w-full"
            />
            <div className="text-xs text-gray-400 mt-1">{features.animationSpeed.toFixed(1)}x</div>
          </div>

          {/* Glow Intensity */}
          <div>
            <label className="block text-cyan-400 text-sm font-medium mb-2">Glow Intensity</label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={features.glowIntensity}
              onChange={(e) => updateFeature('glowIntensity', parseFloat(e.target.value))}
              className="w-full"
            />
            <div className="text-xs text-gray-400 mt-1">{Math.round(features.glowIntensity * 100)}%</div>
          </div>

          <motion.button
            className="w-full bg-gradient-to-r from-cyan-600 to-teal-600 text-white py-2 px-4 rounded-lg font-medium hover:from-cyan-700 hover:to-teal-700 transition-all duration-300 flex items-center justify-center"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Save size={16} className="mr-2" />
            Save AI Appearance
          </motion.button>
        </div>
      </div>
    </div>
  );
}