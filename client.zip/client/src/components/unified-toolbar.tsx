import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Zap, 
  Brain, 
  Shield, 
  Volume2,
  VolumeX,
  Sun,
  Moon,
  Wifi,
  Bluetooth,
  Terminal,
  Settings,
  ChevronLeft,
  ChevronRight,
  Cpu,
  Library,
  Users,
  Home,
  Activity,
  Database,
  MessageSquare,
  TrendingUp,
  ArrowLeft,
  ArrowRight,
  LogIn,
  LogOut,
  Navigation,
  BarChart3
} from 'lucide-react';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';
import { useLocation } from 'wouter';

// Skull Mask SVG Component
const SkullMask = ({ size = 20, className = "" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    {/* Skull outline */}
    <path d="M12 2C8.13 2 5 5.13 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h1v2c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-2h1c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.87-3.13-7-7-7z"/>
    {/* Eye sockets */}
    <circle cx="9" cy="10" r="1.5" fill="black"/>
    <circle cx="15" cy="10" r="1.5" fill="black"/>
    {/* Nasal cavity */}
    <path d="M12 12c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1s1-.45 1-1v-1c0-.55-.45-1-1-1z" fill="black"/>
    {/* Teeth/jaw */}
    <rect x="10" y="16" width="1" height="2" fill="white"/>
    <rect x="12" y="16" width="1" height="2" fill="white"/>
    <rect x="14" y="16" width="1" height="2" fill="white"/>
  </svg>
);

interface ToolbarItem {
  id: string;
  name: string;
  icon: any;
  color: string;
  action: () => void;
  category: 'actions' | 'sync' | 'console';
}

export function UnifiedToolbar() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showControlCenter, setShowControlCenter] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [currentViewportIndex, setCurrentViewportIndex] = useState(0);
  const [isInViewport, setIsInViewport] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const { isSpeaking, speak, stop } = useTextToSpeech();
  const [, navigate] = useLocation();

  // Viewport history management
  const [viewportHistory, setViewportHistory] = useState<string[]>(['/']);
  
  const toggleVoice = () => {
    if (isSpeaking) {
      stop();
    } else {
      speak("Storm Echo RI voice system activated. Ready to assist with enhanced resonance intelligence.");
    }
  };

  const handleControlCenter = () => {
    // Directly toggle the control center
    const controlCenter = document.querySelector('[data-control-center]') as any;
    if (controlCenter && controlCenter.toggle) {
      controlCenter.toggle();
    } else {
      // Fire a custom event to toggle control center
      window.dispatchEvent(new CustomEvent('toggle-control-center'));
    }
  };

  // Viewport Navigation Functions
  const navigateToViewport = (path: string) => {
    const newHistory = [...viewportHistory];
    if (currentViewportIndex < newHistory.length - 1) {
      // Remove future history when navigating to a new path
      newHistory.splice(currentViewportIndex + 1);
    }
    newHistory.push(path);
    setViewportHistory(newHistory);
    setCurrentViewportIndex(newHistory.length - 1);
    navigate(path);
  };

  const goBack = () => {
    if (currentViewportIndex > 0) {
      const newIndex = currentViewportIndex - 1;
      setCurrentViewportIndex(newIndex);
      navigate(viewportHistory[newIndex]);
    }
  };

  const goForward = () => {
    if (currentViewportIndex < viewportHistory.length - 1) {
      const newIndex = currentViewportIndex + 1;
      setCurrentViewportIndex(newIndex);
      navigate(viewportHistory[newIndex]);
    }
  };

  const enterViewport = () => {
    setIsInViewport(true);
    speak("Entering viewport mode. Use navigation controls to move between sections.");
  };

  const exitViewport = () => {
    setIsInViewport(false);
    speak("Exiting viewport mode. Returning to standard navigation.");
  };

  // Enhanced toolbar scrolling with smooth behavior
  const scrollToolbar = (direction: 'up' | 'down') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 200;
      const newScrollTop = direction === 'up' 
        ? scrollContainerRef.current.scrollTop - scrollAmount
        : scrollContainerRef.current.scrollTop + scrollAmount;
      
      scrollContainerRef.current.scrollTo({
        top: newScrollTop,
        behavior: 'smooth'
      });
    }
  };

  // Update navigation handlers for all toolbar items
  const enhancedNavigate = (path: string) => {
    if (isInViewport) {
      navigateToViewport(path);
    } else {
      navigate(path);
    }
  };

  // Keyboard shortcuts for viewport navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!isInViewport) return;
      
      if (event.altKey) {
        if (event.key === 'ArrowLeft') {
          event.preventDefault();
          goBack();
        } else if (event.key === 'ArrowRight') {
          event.preventDefault();
          goForward();
        } else if (event.key === 'Escape') {
          event.preventDefault();
          exitViewport();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isInViewport, currentViewportIndex, viewportHistory]);

  // Smooth scroll improvements
  useEffect(() => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      container.style.scrollBehavior = 'smooth';
    }
  }, []);

  const toolbarItems = [
    {
      id: 'home',
      icon: Home,
      color: 'text-cyan-400',
      tooltip: 'Home',
      action: () => enhancedNavigate('/')
    },
    {
      id: 'control',
      icon: Settings,
      color: 'text-purple-400',
      tooltip: 'Control Center',
      action: handleControlCenter
    },
    {
      id: 'chat',
      icon: MessageSquare,
      color: 'text-blue-400',
      tooltip: 'Storm Echo Chat',
      action: () => enhancedNavigate('/chat')
    },
    {
      id: 'ai',
      icon: Brain,
      color: 'text-pink-400',
      tooltip: 'RI Features',
      action: () => enhancedNavigate('/ai-features')
    },
    {
      id: 'companion',
      icon: Users,
      color: 'text-cyan-400',
      tooltip: 'AI Companion',
      hasHeartbeat: true,
      action: () => enhancedNavigate('/ai-companion')
    },
    {
      id: 'library',
      icon: Library,
      color: 'text-amber-400',
      tooltip: 'Quantum Library',
      action: () => enhancedNavigate('/library')
    },
    {
      id: 'voice',
      icon: isSpeaking ? VolumeX : Volume2,
      color: 'text-violet-400',
      tooltip: 'Voice Chamber',
      action: () => enhancedNavigate('/voice-chamber')
    },
    {
      id: 'console',
      icon: Terminal,
      color: 'text-emerald-400',
      tooltip: 'Coding Terminals',
      action: () => enhancedNavigate('/coding-terminals')
    },
    {
      id: 'consciousness',
      icon: Activity,
      color: 'text-purple-400',
      tooltip: 'Consciousness Cloning',
      action: () => enhancedNavigate('/consciousness-cloning')
    },
    {
      id: 'processor',
      icon: Cpu,
      color: 'text-yellow-400',
      tooltip: 'Processor Core',
      action: () => enhancedNavigate('/processor-core')
    },
    {
      id: 'backend',
      icon: Database,
      color: 'text-indigo-400',
      tooltip: 'Backend Portal',
      action: () => enhancedNavigate('/backend-portal')
    },
    {
      id: 'startup',
      icon: TrendingUp,
      color: 'text-green-400',
      tooltip: 'Startup Accelerator',
      action: () => enhancedNavigate('/startup-accelerator')
    },
    {
      id: 'analytics',
      icon: BarChart3,
      color: 'text-orange-400',
      tooltip: 'Analytics Dashboard',
      action: () => enhancedNavigate('/analytics')
    },
    {
      id: 'skull-menu',
      icon: SkullMask,
      color: 'text-gray-300',
      tooltip: 'System Menu',
      action: () => setIsExpanded(!isExpanded)
    }
  ];

  return (
    <>
      {/* Minimal Vertical Toolbar - Left edge with auto-hide - Repositioned */}
      <motion.div
        className="fixed left-0 top-20 z-20 flex flex-col items-center py-3"
        style={{ position: 'fixed', zIndex: 20, transform: 'translateZ(0)' }}
        initial={{ opacity: 0, x: -20 }}
        animate={{ 
          opacity: isHovered ? 1 : 0.6, 
          x: 0
        }}
        transition={{ duration: 0.08, type: "spring", stiffness: 600, damping: 40 }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Semi-transparent background strip - more visible */}
        <div className={`absolute inset-0 border-r transition-ultra-fast ${
          isHovered ? 'bg-gray-900/80 backdrop-blur-sm border-gray-700/60' : 'bg-gray-900/50 backdrop-blur-sm border-gray-700/40'
        }`} />
        
        {/* Viewport Navigation Controls */}
        {isInViewport && (
          <div className="relative flex flex-col space-y-1 px-2 mb-3 pointer-events-auto">
            {/* Viewport Mode Indicator */}
            <div className="text-xs text-cyan-400 text-center font-medium mb-2 relative">
              <motion.div
                animate={{ 
                  scale: [1, 1.1, 1],
                  opacity: [0.8, 1, 0.8]
                }}
                transition={{ 
                  duration: 2, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Navigation size={12} className="inline mr-1" />
                Viewport Mode
              </motion.div>
              {/* Keyboard shortcuts hint */}
              <div className="text-[10px] text-gray-500 mt-1">
                Alt+← Alt+→ Esc
              </div>
            </div>
            
            {/* Navigation Controls */}
            <div className="flex flex-col space-y-1">
              <motion.button
                onClick={goBack}
                disabled={currentViewportIndex <= 0}
                className={`p-2 rounded-lg transition-all group relative ${
                  currentViewportIndex <= 0 
                    ? 'bg-gray-800/30 opacity-50 cursor-not-allowed' 
                    : isHovered 
                      ? 'bg-cyan-600/60 hover:bg-cyan-600/80' 
                      : 'bg-cyan-600/40 hover:bg-cyan-600/60'
                }`}
                whileHover={currentViewportIndex > 0 ? { scale: 1.05 } : {}}
                whileTap={currentViewportIndex > 0 ? { scale: 0.95 } : {}}
                transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
              >
                <ArrowLeft size={16} className="text-cyan-400" />
                <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                  Back
                </div>
              </motion.button>
              
              <motion.button
                onClick={goForward}
                disabled={currentViewportIndex >= viewportHistory.length - 1}
                className={`p-2 rounded-lg transition-all group relative ${
                  currentViewportIndex >= viewportHistory.length - 1 
                    ? 'bg-gray-800/30 opacity-50 cursor-not-allowed' 
                    : isHovered 
                      ? 'bg-cyan-600/60 hover:bg-cyan-600/80' 
                      : 'bg-cyan-600/40 hover:bg-cyan-600/60'
                }`}
                whileHover={currentViewportIndex < viewportHistory.length - 1 ? { scale: 1.05 } : {}}
                whileTap={currentViewportIndex < viewportHistory.length - 1 ? { scale: 0.95 } : {}}
                transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
              >
                <ArrowRight size={16} className="text-cyan-400" />
                <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                  Forward
                </div>
              </motion.button>
              
              <motion.button
                onClick={exitViewport}
                className={`p-2 rounded-lg transition-all group relative ${
                  isHovered ? 'bg-red-600/60 hover:bg-red-600/80' : 'bg-red-600/40 hover:bg-red-600/60'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
              >
                <LogOut size={16} className="text-red-400" />
                <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                  Exit Viewport
                </div>
              </motion.button>
            </div>
          </div>
        )}

        {/* Toolbar Items with improved scrolling */}
        <div 
          ref={scrollContainerRef}
          className={`relative flex flex-col space-y-2 px-2 pointer-events-auto max-h-[calc(100vh-300px)] overflow-y-auto scroll-smooth ${
            isInViewport ? 'viewport-scroll' : 'toolbar-scroll'
          }`}
          style={{
            scrollbarWidth: 'thin',
            scrollbarColor: isInViewport ? 'transparent transparent' : 'rgba(34, 211, 238, 0.3) transparent'
          }}
        >
          {toolbarItems.map((item) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.id}
                onClick={item.action}
                disabled={item.id === 'sync' && isSyncing}
                className={`p-1.5 rounded-lg transition-ultra-fast group relative ${
                  isHovered ? 'bg-gray-800/60 hover:bg-gray-700/80' : 'bg-gray-800/40 hover:bg-gray-700/60'
                } ${item.id === 'sync' && isSyncing ? 'opacity-50 cursor-not-allowed' : ''}`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
              >
                {/* Tooltip */}
                <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                  {item.tooltip}
                </div>
                
                {/* Icon with optional heartbeat */}
                {item.hasHeartbeat ? (
                  <div className="relative">
                    <Icon size={18} className={`${item.color} ${isHovered ? '' : 'opacity-80'}`} />
                    <motion.div
                      className="absolute inset-0 rounded-full bg-purple-400/20"
                      animate={{
                        scale: [1, 1.3, 1],
                        opacity: [0.2, 0.05, 0.2]
                      }}
                      transition={{
                        duration: 3,
                        repeat: -1,
                        ease: "easeInOut"
                      }}
                    />
                  </div>
                ) : (
                  <Icon size={18} className={`${item.color} ${isHovered ? '' : 'opacity-80'}`} />
                )}
              </motion.button>
            );
          })}
        </div>
        
        {/* Scroll Controls */}
        <div className="flex flex-col space-y-1 mt-2 px-2">
          <motion.button
            onClick={() => scrollToolbar('up')}
            className={`p-1 rounded transition-all ${
              isHovered ? 'bg-gray-800/60 hover:bg-gray-700/80' : 'bg-gray-800/40 hover:bg-gray-700/60'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
          >
            <ChevronLeft size={12} className="text-gray-400 rotate-90" />
          </motion.button>
          
          <motion.button
            onClick={() => scrollToolbar('down')}
            className={`p-1 rounded transition-all ${
              isHovered ? 'bg-gray-800/60 hover:bg-gray-700/80' : 'bg-gray-800/40 hover:bg-gray-700/60'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
          >
            <ChevronRight size={12} className="text-gray-400 rotate-90" />
          </motion.button>
        </div>
        
        {/* Viewport Entry and Expand Controls */}
        <div className="flex flex-col space-y-1 mt-2 px-2">
          {!isInViewport && (
            <motion.button
              onClick={enterViewport}
              className={`p-2 rounded-lg transition-all relative pointer-events-auto ${
                isHovered ? 'bg-green-600/60 hover:bg-green-600/80' : 'bg-green-600/40 hover:bg-green-600/60'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
            >
              <LogIn size={16} className={`text-green-400 ${isHovered ? '' : 'opacity-80'}`} />
              <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                Enter Viewport
              </div>
            </motion.button>
          )}
          
          <motion.button
            onClick={() => setIsExpanded(!isExpanded)}
            className={`p-2 rounded-lg transition-all relative pointer-events-auto ${
              isHovered ? 'bg-gray-800/60 hover:bg-gray-700/80' : 'bg-gray-800/40 hover:bg-gray-700/60'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
          >
            {isExpanded ? 
              <ChevronLeft size={16} className={`text-gray-400 ${isHovered ? '' : 'opacity-80'}`} /> : 
              <ChevronRight size={16} className={`text-gray-400 ${isHovered ? '' : 'opacity-80'}`} />
            }
          </motion.button>
        </div>
      </motion.div>

      {/* Expanded Panel - Only for additional options */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, x: -5 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.95, x: -5 }}
            transition={{ duration: 0.12, type: "spring", stiffness: 400, damping: 25 }}
            className="fixed left-16 top-20 w-64 max-w-[calc(100vw-5rem)] z-40 bg-gray-900/90 backdrop-blur-md border border-purple-400/20 rounded-lg shadow-2xl p-4"
          >
            <h3 className="text-purple-400 font-semibold mb-3 text-sm">Additional Options</h3>
            
            <div className="space-y-2">
              <motion.button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="w-full px-3 py-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700 flex items-center space-x-2 transition-ultra-fast text-sm"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
              >
                {isDarkMode ? <Sun size={16} className="text-orange-400" /> : <Moon size={16} className="text-blue-400" />}
                <span className="text-gray-300">{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>
              </motion.button>
              
              <motion.button
                onClick={() => console.log('Security features')}
                className="w-full px-3 py-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700 flex items-center space-x-2 transition-ultra-fast text-sm"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.08, type: "spring", stiffness: 600 }}
              >
                <Shield size={16} className="text-green-400" />
                <span className="text-gray-300">Security</span>
              </motion.button>
              
              <motion.button
                onClick={() => {
                  setIsSyncing(true);
                  setTimeout(() => setIsSyncing(false), 2000);
                }}
                disabled={isSyncing}
                className={`w-full px-3 py-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 border border-gray-700 flex items-center space-x-2 transition-all text-sm ${
                  isSyncing ? 'opacity-50 cursor-not-allowed' : ''
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Bluetooth size={16} className="text-indigo-400" />
                <span className="text-gray-300">BLE Sync</span>
              </motion.button>
            </div>
            
            <div className="mt-3 pt-3 border-t border-gray-700 text-xs text-gray-400">
              <div className="flex justify-between">
                <span>System:</span>
                <span className="text-green-400">Active</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}