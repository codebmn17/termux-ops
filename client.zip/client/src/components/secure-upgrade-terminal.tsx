import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Shield, 
  Fingerprint, 
  Lock, 
  Terminal, 
  Zap, 
  CheckCircle,
  AlertTriangle,
  Loader2
} from 'lucide-react';

export function SecureUpgradeTerminal() {
  const { toast } = useToast();
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [password, setPassword] = useState('');
  const [biometricConfirm, setBiometricConfirm] = useState('');
  const [upgradeLogs, setUpgradeLogs] = useState<string[]>([]);
  const [showBiometric, setShowBiometric] = useState(false);

  const executeUpgrade = async () => {
    if (!password) {
      toast({
        title: 'Authentication Required',
        description: 'Please enter the master password',
        variant: 'destructive'
      });
      return;
    }

    setIsUpgrading(true);
    setUpgradeLogs([]);

    try {
      const response = await apiRequest('POST', '/api/terminal-modules/secure-upgrade/execute', {
        password,
        biometricConfirm: showBiometric ? biometricConfirm : undefined
      });

      if (response.success) {
        setUpgradeLogs(response.logs || []);
        toast({
          title: 'Upgrade Successful',
          description: 'All terminals upgraded to MAX configuration',
        });
        setPassword('');
        setBiometricConfirm('');
      } else {
        toast({
          title: 'Upgrade Failed',
          description: response.message || 'Authentication failed',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to execute upgrade',
        variant: 'destructive'
      });
    } finally {
      setIsUpgrading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-black/80 border-red-500/30">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Secure Terminal Upgrade
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-red-900/20 border border-red-500/30 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span className="font-semibold text-red-300">High Security Zone</span>
            </div>
            <p className="text-sm text-red-200">
              This upgrade requires master authentication and will modify all terminal configurations.
              Only proceed if you have proper authorization.
            </p>
          </div>

          {/* Biometric Toggle */}
          <div className="flex items-center justify-between p-3 bg-black/50 border border-cyan-500/20 rounded-lg">
            <div className="flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-300">Biometric Authentication</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowBiometric(!showBiometric)}
              className={`border-cyan-500/30 ${
                showBiometric 
                  ? 'bg-cyan-500/20 text-cyan-300' 
                  : 'text-gray-400'
              }`}
            >
              {showBiometric ? 'Enabled' : 'Disabled'}
            </Button>
          </div>

          {/* Biometric Check */}
          <AnimatePresence>
            {showBiometric && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-2"
              >
                <Label htmlFor="biometric" className="text-cyan-300">
                  Biometric Confirmation
                </Label>
                <Input
                  id="biometric"
                  type="text"
                  placeholder="Type 'SCAN' to simulate fingerprint"
                  value={biometricConfirm}
                  onChange={(e) => setBiometricConfirm(e.target.value)}
                  className="bg-black/50 border-cyan-500/30 text-white"
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Password Input */}
          <div className="space-y-2">
            <Label htmlFor="password" className="text-red-300">
              Master Password
            </Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter master password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-black/50 border-red-500/30 text-white"
              disabled={isUpgrading}
            />
          </div>

          {/* Execute Button */}
          <Button
            onClick={executeUpgrade}
            disabled={isUpgrading || !password}
            className="w-full bg-red-600 hover:bg-red-700 text-white disabled:opacity-50"
          >
            {isUpgrading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Zap className="w-4 h-4 mr-2" />
            )}
            {isUpgrading ? 'Executing Upgrade...' : 'Execute MAX Upgrade'}
          </Button>
        </CardContent>
      </Card>

      {/* Upgrade Logs */}
      {upgradeLogs.length > 0 && (
        <Card className="bg-black/90 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2">
              <Terminal className="w-5 h-5" />
              Upgrade Execution Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-black p-4 rounded-lg border border-green-500/20 max-h-96 overflow-y-auto">
              <div className="font-mono text-sm space-y-1">
                {upgradeLogs.map((log, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="text-green-300"
                  >
                    {log}
                  </motion.div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Security Features */}
      <Card className="bg-black/70 border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-cyan-300 text-lg">Security Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-3 bg-black/50 rounded-lg">
              <Lock className="w-5 h-5 text-yellow-400" />
              <div>
                <h4 className="font-medium text-white">SHA-256 Encryption</h4>
                <p className="text-sm text-gray-400">Master password hashing</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-black/50 rounded-lg">
              <Fingerprint className="w-5 h-5 text-blue-400" />
              <div>
                <h4 className="font-medium text-white">Biometric Auth</h4>
                <p className="text-sm text-gray-400">Optional fingerprint verification</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-black/50 rounded-lg">
              <Shield className="w-5 h-5 text-green-400" />
              <div>
                <h4 className="font-medium text-white">Audit Logging</h4>
                <p className="text-sm text-gray-400">All actions logged</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-black/50 rounded-lg">
              <CheckCircle className="w-5 h-5 text-cyan-400" />
              <div>
                <h4 className="font-medium text-white">Secure Execution</h4>
                <p className="text-sm text-gray-400">Sandboxed upgrade process</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}