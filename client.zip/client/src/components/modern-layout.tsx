import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ModernLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  headerActions?: React.ReactNode;
  className?: string;
}

export function ModernLayout({ 
  children, 
  title, 
  subtitle, 
  headerActions, 
  className = '' 
}: ModernLayoutProps) {
  return (
    <div className={`min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 ${className}`}>
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(34,211,238,0.1),transparent_70%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_24%,rgba(255,255,255,0.05)_25%,rgba(255,255,255,0.05)_26%,transparent_27%,transparent_74%,rgba(255,255,255,0.05)_75%,rgba(255,255,255,0.05)_76%,transparent_77%),linear-gradient(transparent_24%,rgba(255,255,255,0.05)_25%,rgba(255,255,255,0.05)_26%,transparent_27%,transparent_74%,rgba(255,255,255,0.05)_75%,rgba(255,255,255,0.05)_76%,transparent_77%)]" style={{ backgroundSize: '50px 50px' }} />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {(title || subtitle || headerActions) && (
          <motion.header
            className="p-6 border-b border-gray-800/50 backdrop-blur-sm"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center justify-between">
              <div>
                {title && (
                  <h1 className="text-3xl font-bold text-white glow-text-enhanced text-cyan-400">
                    {title}
                  </h1>
                )}
                {subtitle && (
                  <p className="text-gray-400 mt-1">{subtitle}</p>
                )}
              </div>
              {headerActions && (
                <div className="flex items-center space-x-3">
                  {headerActions}
                </div>
              )}
            </div>
          </motion.header>
        )}

        <main className="p-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
}

interface ModernGridProps {
  children: React.ReactNode;
  columns?: 1 | 2 | 3 | 4 | 6;
  gap?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function ModernGrid({ 
  children, 
  columns = 3, 
  gap = 'md', 
  className = '' 
}: ModernGridProps) {
  const gridCols = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 md:grid-cols-2',
    3: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4',
    6: 'grid-cols-2 md:grid-cols-3 lg:grid-cols-6'
  };

  const gaps = {
    sm: 'gap-4',
    md: 'gap-6',
    lg: 'gap-8'
  };

  return (
    <div className={`grid ${gridCols[columns]} ${gaps[gap]} ${className}`}>
      {children}
    </div>
  );
}

interface ModernCardProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
  variant?: 'default' | 'elevated' | 'glass';
  className?: string;
}

export function ModernCard({ 
  children, 
  title, 
  subtitle, 
  icon, 
  actions, 
  variant = 'default', 
  className = '' 
}: ModernCardProps) {
  const variants = {
    default: 'card-enhanced',
    elevated: 'card-enhanced shadow-2xl transform hover:scale-[1.02]',
    glass: 'bg-white/5 backdrop-blur-md border border-white/10 rounded-xl'
  };

  return (
    <motion.div
      className={`${variants[variant]} transition-ultra-fast ${className}`}
      whileHover={{ y: variant === 'elevated' ? -4 : -2 }}
      transition={{ duration: 0.1 }}
    >
      <Card className="bg-transparent border-transparent">
        {(title || subtitle || icon || actions) && (
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {icon && (
                  <div className="p-2 rounded-lg bg-gradient-to-r from-cyan-600/20 to-blue-600/20 border border-cyan-500/30">
                    {icon}
                  </div>
                )}
                <div>
                  {title && (
                    <CardTitle className="text-white font-semibold">{title}</CardTitle>
                  )}
                  {subtitle && (
                    <p className="text-gray-400 text-sm mt-1">{subtitle}</p>
                  )}
                </div>
              </div>
              {actions && (
                <div className="flex items-center space-x-2">
                  {actions}
                </div>
              )}
            </div>
          </CardHeader>
        )}
        
        <CardContent className="pt-0">
          {children}
        </CardContent>
      </Card>
    </motion.div>
  );
}

interface ModernSidebarProps {
  children: React.ReactNode;
  width?: 'sm' | 'md' | 'lg';
  position?: 'left' | 'right';
  className?: string;
}

export function ModernSidebar({ 
  children, 
  width = 'md', 
  position = 'left', 
  className = '' 
}: ModernSidebarProps) {
  const widths = {
    sm: 'w-64',
    md: 'w-80',
    lg: 'w-96'
  };

  const positions = {
    left: 'left-0',
    right: 'right-0'
  };

  return (
    <motion.div
      className={`fixed top-0 ${positions[position]} h-full ${widths[width]} card-enhanced z-50 ${className}`}
      initial={{ x: position === 'left' ? -320 : 320 }}
      animate={{ x: 0 }}
      exit={{ x: position === 'left' ? -320 : 320 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
    >
      <div className="h-full overflow-y-auto scrollbar-enhanced p-6">
        {children}
      </div>
    </motion.div>
  );
}

interface ModernNavProps {
  items: Array<{
    label: string;
    href?: string;
    onClick?: () => void;
    icon?: React.ReactNode;
    active?: boolean;
  }>;
  orientation?: 'horizontal' | 'vertical';
  className?: string;
}

export function ModernNav({ items, orientation = 'horizontal', className = '' }: ModernNavProps) {
  const orientationClass = orientation === 'horizontal' 
    ? 'flex flex-row space-x-2' 
    : 'flex flex-col space-y-2';

  return (
    <nav className={`${orientationClass} ${className}`}>
      {items.map((item, index) => (
        <motion.div
          key={index}
          className={`
            px-4 py-2 rounded-lg cursor-pointer transition-ultra-fast
            ${item.active 
              ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white' 
              : 'bg-gray-800/40 text-gray-300 hover:bg-gray-700/60 hover:text-white'
            }
          `}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={item.onClick}
        >
          <div className="flex items-center space-x-2">
            {item.icon && <span className="w-4 h-4">{item.icon}</span>}
            <span className="font-medium">{item.label}</span>
          </div>
        </motion.div>
      ))}
    </nav>
  );
}