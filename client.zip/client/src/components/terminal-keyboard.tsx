import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Keyboard, 
  Command, 
  Terminal, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  CornerDownLeft,
  Delete,
  Space,
  RotateCw,
  Home,
  Settings,
  Zap,
  Monitor,
  Code,
  Network,
  Shield,
  FileText,
  User,
  Sparkles,
  ChevronUp,
  ChevronDown
} from 'lucide-react';

interface TerminalKeyboardProps {
  onKeyPress: (key: string, modifiers?: { ctrl?: boolean; alt?: boolean; shift?: boolean }) => void;
  sessionType: string;
  isVisible: boolean;
  onToggle: () => void;
}

interface KeyConfig {
  key: string;
  label: string;
  icon?: React.ReactNode;
  className?: string;
  modifiers?: { ctrl?: boolean; alt?: boolean; shift?: boolean };
  width?: 'normal' | 'wide' | 'wider' | 'widest';
}

const FUNCTION_KEYS: KeyConfig[] = [
  { key: 'F1', label: 'F1', className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'F2', label: 'F2', className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'F3', label: 'F3', className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'F4', label: 'F4', className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'F5', label: 'F5', className: 'text-green-400 border-green-400/30' },
  { key: 'F6', label: 'F6', className: 'text-green-400 border-green-400/30' },
  { key: 'F7', label: 'F7', className: 'text-green-400 border-green-400/30' },
  { key: 'F8', label: 'F8', className: 'text-green-400 border-green-400/30' },
  { key: 'F9', label: 'F9', className: 'text-yellow-400 border-yellow-400/30' },
  { key: 'F10', label: 'F10', className: 'text-yellow-400 border-yellow-400/30' },
  { key: 'F11', label: 'F11', className: 'text-red-400 border-red-400/30' },
  { key: 'F12', label: 'F12', className: 'text-red-400 border-red-400/30' }
];

const NUMBER_ROW: KeyConfig[] = [
  { key: '`', label: '`' },
  { key: '1', label: '1' },
  { key: '2', label: '2' },
  { key: '3', label: '3' },
  { key: '4', label: '4' },
  { key: '5', label: '5' },
  { key: '6', label: '6' },
  { key: '7', label: '7' },
  { key: '8', label: '8' },
  { key: '9', label: '9' },
  { key: '0', label: '0' },
  { key: '-', label: '-' },
  { key: '=', label: '=' },
  { key: 'Backspace', label: '⌫', width: 'wide', className: 'text-red-400 border-red-400/30' }
];

const QWERTY_ROW1: KeyConfig[] = [
  { key: 'Tab', label: '⇥', width: 'wide', className: 'text-blue-400 border-blue-400/30' },
  { key: 'q', label: 'Q' },
  { key: 'w', label: 'W' },
  { key: 'e', label: 'E' },
  { key: 'r', label: 'R' },
  { key: 't', label: 'T' },
  { key: 'y', label: 'Y' },
  { key: 'u', label: 'U' },
  { key: 'i', label: 'I' },
  { key: 'o', label: 'O' },
  { key: 'p', label: 'P' },
  { key: '[', label: '[' },
  { key: ']', label: ']' },
  { key: '\\', label: '\\', width: 'wide' }
];

const QWERTY_ROW2: KeyConfig[] = [
  { key: 'CapsLock', label: 'Caps', width: 'wider', className: 'text-orange-400 border-orange-400/30' },
  { key: 'a', label: 'A' },
  { key: 's', label: 'S' },
  { key: 'd', label: 'D' },
  { key: 'f', label: 'F' },
  { key: 'g', label: 'G' },
  { key: 'h', label: 'H' },
  { key: 'j', label: 'J' },
  { key: 'k', label: 'K' },
  { key: 'l', label: 'L' },
  { key: ';', label: ';' },
  { key: "'", label: "'" },
  { key: 'Enter', label: '↵', width: 'wider', className: 'text-green-400 border-green-400/30', icon: <CornerDownLeft className="w-4 h-4" /> }
];

const QWERTY_ROW3: KeyConfig[] = [
  { key: 'Shift', label: 'Shift', width: 'widest', className: 'text-purple-400 border-purple-400/30', icon: <ChevronUp className="w-4 h-4" /> },
  { key: 'z', label: 'Z' },
  { key: 'x', label: 'X' },
  { key: 'c', label: 'C' },
  { key: 'v', label: 'V' },
  { key: 'b', label: 'B' },
  { key: 'n', label: 'N' },
  { key: 'm', label: 'M' },
  { key: ',', label: ',' },
  { key: '.', label: '.' },
  { key: '/', label: '/' },
  { key: 'Shift', label: 'Shift', width: 'widest', className: 'text-purple-400 border-purple-400/30', icon: <ChevronUp className="w-4 h-4" /> }
];

const BOTTOM_ROW: KeyConfig[] = [
  { key: 'Ctrl', label: 'Ctrl', width: 'wide', className: 'text-red-400 border-red-400/30' },
  { key: 'Alt', label: 'Alt', width: 'normal', className: 'text-yellow-400 border-yellow-400/30' },
  { key: ' ', label: 'Space', width: 'widest', className: 'text-gray-300 border-gray-500/30', icon: <Space className="w-4 h-4" /> },
  { key: 'Alt', label: 'Alt', width: 'normal', className: 'text-yellow-400 border-yellow-400/30' },
  { key: 'Ctrl', label: 'Ctrl', width: 'wide', className: 'text-red-400 border-red-400/30' }
];

const ARROW_KEYS: KeyConfig[] = [
  { key: 'ArrowUp', label: '↑', icon: <ArrowUp className="w-4 h-4" />, className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'ArrowDown', label: '↓', icon: <ArrowDown className="w-4 h-4" />, className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'ArrowLeft', label: '←', icon: <ArrowLeft className="w-4 h-4" />, className: 'text-cyan-400 border-cyan-400/30' },
  { key: 'ArrowRight', label: '→', icon: <ArrowRight className="w-4 h-4" />, className: 'text-cyan-400 border-cyan-400/30' }
];

const NAVIGATION_KEYS: KeyConfig[] = [
  { key: 'Home', label: 'Home', icon: <Home className="w-3 h-3" />, className: 'text-blue-400 border-blue-400/30' },
  { key: 'End', label: 'End', icon: <Settings className="w-3 h-3" />, className: 'text-blue-400 border-blue-400/30' },
  { key: 'PageUp', label: 'PgUp', icon: <ChevronUp className="w-3 h-3" />, className: 'text-green-400 border-green-400/30' },
  { key: 'PageDown', label: 'PgDn', icon: <ChevronDown className="w-3 h-3" />, className: 'text-green-400 border-green-400/30' },
  { key: 'Insert', label: 'Ins', className: 'text-yellow-400 border-yellow-400/30' },
  { key: 'Delete', label: 'Del', icon: <Delete className="w-3 h-3" />, className: 'text-red-400 border-red-400/30' }
];

// Session-specific command shortcuts
const SESSION_SHORTCUTS: Record<string, KeyConfig[]> = {
  dev: [
    { key: 'git status', label: 'Git Status', className: 'text-orange-400 border-orange-400/30', icon: <Code className="w-3 h-3" /> },
    { key: 'npm start', label: 'Start Dev', className: 'text-green-400 border-green-400/30', icon: <Zap className="w-3 h-3" /> },
    { key: 'npm test', label: 'Run Tests', className: 'text-blue-400 border-blue-400/30', icon: <Monitor className="w-3 h-3" /> },
    { key: 'code .', label: 'VS Code', className: 'text-purple-400 border-purple-400/30', icon: <Code className="w-3 h-3" /> },
    { key: 'docker ps', label: 'Docker PS', className: 'text-cyan-400 border-cyan-400/30', icon: <Monitor className="w-3 h-3" /> },
    { key: 'yarn build', label: 'Build', className: 'text-yellow-400 border-yellow-400/30', icon: <Settings className="w-3 h-3" /> }
  ],
  network: [
    { key: 'ping google.com', label: 'Ping Test', className: 'text-green-400 border-green-400/30', icon: <Network className="w-3 h-3" /> },
    { key: 'netstat -tuln', label: 'Netstat', className: 'text-blue-400 border-blue-400/30', icon: <Network className="w-3 h-3" /> },
    { key: 'nmap -sn 192.168.1.0/24', label: 'Network Scan', className: 'text-cyan-400 border-cyan-400/30', icon: <Network className="w-3 h-3" /> },
    { key: 'iftop', label: 'IFTop', className: 'text-purple-400 border-purple-400/30', icon: <Network className="w-3 h-3" /> },
    { key: 'ss -tuln', label: 'Socket Stats', className: 'text-orange-400 border-orange-400/30', icon: <Network className="w-3 h-3" /> },
    { key: 'curl -I', label: 'HTTP Head', className: 'text-yellow-400 border-yellow-400/30', icon: <Network className="w-3 h-3" /> }
  ],
  mining: [
    { key: 'stormecho-miner start', label: 'Start Miner', className: 'text-green-400 border-green-400/30', icon: <Zap className="w-3 h-3" /> },
    { key: 'stormecho-miner stop', label: 'Stop Miner', className: 'text-red-400 border-red-400/30', icon: <Zap className="w-3 h-3" /> },
    { key: 'stormecho-miner status', label: 'Miner Status', className: 'text-blue-400 border-blue-400/30', icon: <Monitor className="w-3 h-3" /> },
    { key: 'htop', label: 'System Monitor', className: 'text-cyan-400 border-cyan-400/30', icon: <Monitor className="w-3 h-3" /> },
    { key: 'nvidia-smi', label: 'GPU Status', className: 'text-orange-400 border-orange-400/30', icon: <Monitor className="w-3 h-3" /> },
    { key: 'stormecho-autofund --execute', label: 'Auto Fund', className: 'text-purple-400 border-purple-400/30', icon: <Zap className="w-3 h-3" /> }
  ],
  security: [
    { key: 'sudo ufw status', label: 'Firewall', className: 'text-red-400 border-red-400/30', icon: <Shield className="w-3 h-3" /> },
    { key: 'fail2ban-client status', label: 'Fail2Ban', className: 'text-orange-400 border-orange-400/30', icon: <Shield className="w-3 h-3" /> },
    { key: 'last', label: 'Last Logins', className: 'text-yellow-400 border-yellow-400/30', icon: <Shield className="w-3 h-3" /> },
    { key: 'ps aux | grep suspicious', label: 'Process Scan', className: 'text-cyan-400 border-cyan-400/30', icon: <Shield className="w-3 h-3" /> },
    { key: 'chkrootkit', label: 'Rootkit Check', className: 'text-purple-400 border-purple-400/30', icon: <Shield className="w-3 h-3" /> },
    { key: 'lynis audit system', label: 'Security Audit', className: 'text-blue-400 border-blue-400/30', icon: <Shield className="w-3 h-3" /> }
  ],
  logs: [
    { key: 'tail -f /var/log/syslog', label: 'Syslog', className: 'text-blue-400 border-blue-400/30', icon: <FileText className="w-3 h-3" /> },
    { key: 'journalctl -f', label: 'Journal', className: 'text-green-400 border-green-400/30', icon: <FileText className="w-3 h-3" /> },
    { key: 'grep -i error /var/log/*.log', label: 'Find Errors', className: 'text-red-400 border-red-400/30', icon: <FileText className="w-3 h-3" /> },
    { key: 'dmesg | tail', label: 'Kernel Logs', className: 'text-yellow-400 border-yellow-400/30', icon: <FileText className="w-3 h-3" /> },
    { key: 'less /var/log/auth.log', label: 'Auth Logs', className: 'text-purple-400 border-purple-400/30', icon: <FileText className="w-3 h-3" /> },
    { key: 'zcat /var/log/*.gz', label: 'Archived Logs', className: 'text-cyan-400 border-cyan-400/30', icon: <FileText className="w-3 h-3" /> }
  ],
  personal: [
    { key: 'cd ~', label: 'Home Dir', className: 'text-green-400 border-green-400/30', icon: <User className="w-3 h-3" /> },
    { key: 'ls -la', label: 'List All', className: 'text-blue-400 border-blue-400/30', icon: <User className="w-3 h-3" /> },
    { key: 'nano ~/.bashrc', label: 'Edit Bashrc', className: 'text-yellow-400 border-yellow-400/30', icon: <User className="w-3 h-3" /> },
    { key: 'history | grep', label: 'Search History', className: 'text-cyan-400 border-cyan-400/30', icon: <User className="w-3 h-3" /> },
    { key: 'alias', label: 'Show Aliases', className: 'text-purple-400 border-purple-400/30', icon: <User className="w-3 h-3" /> },
    { key: 'crontab -l', label: 'Cron Jobs', className: 'text-orange-400 border-orange-400/30', icon: <User className="w-3 h-3" /> }
  ],
  wildcard: [
    { key: 'sudo apt update', label: 'Update Repos', className: 'text-green-400 border-green-400/30', icon: <Sparkles className="w-3 h-3" /> },
    { key: 'df -h', label: 'Disk Space', className: 'text-blue-400 border-blue-400/30', icon: <Sparkles className="w-3 h-3" /> },
    { key: 'free -h', label: 'Memory', className: 'text-yellow-400 border-yellow-400/30', icon: <Sparkles className="w-3 h-3" /> },
    { key: 'top', label: 'Process Monitor', className: 'text-cyan-400 border-cyan-400/30', icon: <Sparkles className="w-3 h-3" /> },
    { key: 'tmux new -s main', label: 'New Tmux', className: 'text-purple-400 border-purple-400/30', icon: <Sparkles className="w-3 h-3" /> },
    { key: 'screen -S main', label: 'New Screen', className: 'text-orange-400 border-orange-400/30', icon: <Sparkles className="w-3 h-3" /> }
  ]
};

export function TerminalKeyboard({ onKeyPress, sessionType, isVisible, onToggle }: TerminalKeyboardProps) {
  const [shiftPressed, setShiftPressed] = useState(false);
  const [ctrlPressed, setCtrlPressed] = useState(false);
  const [altPressed, setAltPressed] = useState(false);
  const [activeTab, setActiveTab] = useState('main');

  const getKeyWidth = (width?: string) => {
    switch (width) {
      case 'wide': return 'w-16';
      case 'wider': return 'w-20';
      case 'widest': return 'w-32';
      default: return 'w-12';
    }
  };

  const handleKeyPress = (keyConfig: KeyConfig) => {
    const modifiers = {
      ctrl: ctrlPressed || keyConfig.modifiers?.ctrl,
      alt: altPressed || keyConfig.modifiers?.alt,
      shift: shiftPressed || keyConfig.modifiers?.shift
    };

    onKeyPress(keyConfig.key, modifiers);

    // Handle modifier toggles
    if (keyConfig.key === 'Shift') {
      setShiftPressed(!shiftPressed);
    } else if (keyConfig.key === 'Ctrl') {
      setCtrlPressed(!ctrlPressed);
    } else if (keyConfig.key === 'Alt') {
      setAltPressed(!altPressed);
    } else {
      // Reset modifiers after regular key press
      setShiftPressed(false);
      setCtrlPressed(false);
      setAltPressed(false);
    }
  };

  const handleCommandPress = (command: string) => {
    onKeyPress(command + '\n');
  };

  const renderKey = (keyConfig: KeyConfig, index: number) => {
    const isModifierActive = 
      (keyConfig.key === 'Shift' && shiftPressed) ||
      (keyConfig.key === 'Ctrl' && ctrlPressed) ||
      (keyConfig.key === 'Alt' && altPressed);

    return (
      <motion.div
        key={`${keyConfig.key}-${index}`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleKeyPress(keyConfig)}
          className={`
            ${getKeyWidth(keyConfig.width)} h-10 p-1 text-xs font-mono
            ${keyConfig.className || 'text-gray-300 border-gray-500/30'}
            ${isModifierActive ? 'bg-cyan-500/20 border-cyan-400' : 'bg-black/50'}
            hover:bg-cyan-500/10 transition-all duration-200
          `}
        >
          <div className="flex flex-col items-center justify-center gap-0.5">
            {keyConfig.icon}
            <span className="leading-none">{keyConfig.label}</span>
          </div>
        </Button>
      </motion.div>
    );
  };

  const sessionShortcuts = SESSION_SHORTCUTS[sessionType] || [];

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={onToggle}
          size="sm"
          className="bg-cyan-600 hover:bg-cyan-500 text-white"
        >
          <Keyboard className="w-4 h-4 mr-2" />
          Show Keyboard
        </Button>
      </div>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 50 }}
        className="fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-lg border-t border-cyan-500/30"
      >
        <Card className="bg-transparent border-0 rounded-none">
          <div className="p-4">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Keyboard className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg font-semibold text-cyan-400">
                  Production Terminal Keyboard - {sessionType.toUpperCase()}
                </h3>
                <Badge variant="outline" className="border-cyan-400/30 text-cyan-400">
                  Linux Integration
                </Badge>
              </div>
              <Button
                onClick={onToggle}
                size="sm"
                variant="ghost"
                className="text-gray-400 hover:text-white"
              >
                ✕
              </Button>
            </div>

            {/* Modifier Status */}
            <div className="flex items-center gap-2 mb-4">
              <span className="text-sm text-gray-400">Modifiers:</span>
              {ctrlPressed && <Badge className="bg-red-500/20 text-red-400 border-red-400/30">Ctrl</Badge>}
              {altPressed && <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-400/30">Alt</Badge>}
              {shiftPressed && <Badge className="bg-purple-500/20 text-purple-400 border-purple-400/30">Shift</Badge>}
              {!ctrlPressed && !altPressed && !shiftPressed && (
                <Badge variant="outline" className="border-gray-500/30 text-gray-500">None</Badge>
              )}
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-3 bg-black/50 border border-cyan-500/30 mb-4">
                <TabsTrigger value="main">Main Keyboard</TabsTrigger>
                <TabsTrigger value="shortcuts">Session Commands</TabsTrigger>
                <TabsTrigger value="navigation">Navigation</TabsTrigger>
              </TabsList>

              <TabsContent value="main" className="space-y-2">
                {/* Function Keys */}
                <div className="flex gap-1 justify-center">
                  {FUNCTION_KEYS.map((key, index) => renderKey(key, index))}
                </div>

                {/* Number Row */}
                <div className="flex gap-1 justify-center">
                  {NUMBER_ROW.map((key, index) => renderKey(key, index))}
                </div>

                {/* QWERTY Rows */}
                <div className="flex gap-1 justify-center">
                  {QWERTY_ROW1.map((key, index) => renderKey(key, index))}
                </div>

                <div className="flex gap-1 justify-center">
                  {QWERTY_ROW2.map((key, index) => renderKey(key, index))}
                </div>

                <div className="flex gap-1 justify-center">
                  {QWERTY_ROW3.map((key, index) => renderKey(key, index))}
                </div>

                {/* Bottom Row */}
                <div className="flex gap-1 justify-center">
                  {BOTTOM_ROW.map((key, index) => renderKey(key, index))}
                </div>
              </TabsContent>

              <TabsContent value="shortcuts" className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
                  {sessionShortcuts.map((shortcut, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCommandPress(shortcut.key)}
                        className={`
                          w-full h-16 p-2 text-xs
                          ${shortcut.className || 'text-gray-300 border-gray-500/30'}
                          bg-black/50 hover:bg-cyan-500/10 transition-all duration-200
                        `}
                      >
                        <div className="flex flex-col items-center justify-center gap-1">
                          {shortcut.icon}
                          <span className="leading-tight text-center">{shortcut.label}</span>
                        </div>
                      </Button>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="navigation" className="space-y-4">
                {/* Arrow Keys */}
                <div className="flex flex-col items-center gap-2">
                  <div className="flex gap-1">
                    {renderKey(ARROW_KEYS[0], 0)} {/* Up */}
                  </div>
                  <div className="flex gap-1">
                    {renderKey(ARROW_KEYS[2], 2)} {/* Left */}
                    {renderKey(ARROW_KEYS[1], 1)} {/* Down */}
                    {renderKey(ARROW_KEYS[3], 3)} {/* Right */}
                  </div>
                </div>

                {/* Navigation Keys */}
                <div className="grid grid-cols-3 md:grid-cols-6 gap-2 justify-center">
                  {NAVIGATION_KEYS.map((key, index) => renderKey(key, index))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}