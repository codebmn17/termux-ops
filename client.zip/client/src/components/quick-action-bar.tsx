import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Zap, 
  Brain, 
  Globe, 
  Shield, 
  Sparkles,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Maximize,
  X,
  Eye
} from 'lucide-react';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';

// Custom Anonymous Mask SVG Component
const AnonymousMask = ({ size = 24, className = "" }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    className={className}
  >
    {/* Mask outline */}
    <path
      d="M12 2C8 2 5 4.5 5 8v6c0 3.5 3 6 7 6s7-2.5 7-6V8c0-3.5-3-6-7-6z"
      stroke="currentColor"
      strokeWidth="1.5"
      fill="none"
    />
    
    {/* Eyes */}
    <ellipse cx="9" cy="9" rx="1.5" ry="2" fill="currentColor" />
    <ellipse cx="15" cy="9" rx="1.5" ry="2" fill="currentColor" />
    
    {/* Signature Anonymous smile */}
    <path
      d="M8 15c1 2 3 2 4 2s3 0 4-2"
      stroke="currentColor"
      strokeWidth="1.5"
      fill="none"
      strokeLinecap="round"
    />
    
    {/* Mustache */}
    <path
      d="M7 12c1-0.5 2-0.5 3 0c1 0.5 2 0.5 3 0c1-0.5 2-0.5 3 0"
      stroke="currentColor"
      strokeWidth="1.2"
      fill="none"
      strokeLinecap="round"
    />
    
    {/* Goatee */}
    <path
      d="M11 17v2c0 0.5 0.5 1 1 1s1-0.5 1-1v-2"
      stroke="currentColor"
      strokeWidth="1.2"
      fill="none"
      strokeLinecap="round"
    />
  </svg>
);

interface QuickAction {
  id: string;
  name: string;
  icon: any;
  color: string;
  action: () => void;
}

export function QuickActionBar() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const { isSpeaking, speak, stop } = useTextToSpeech();
  
  const toggleVoice = () => {
    if (isSpeaking) {
      stop();
    } else {
      speak("Storm Echo RI voice system activated. Ready to assist with enhanced resonance intelligence.");
    }
  };

  const quickActions: QuickAction[] = [
    {
      id: 'pulse',
      name: 'Echo Pulse',
      icon: Zap,
      color: 'from-cyan-500 to-blue-500',
      action: () => {
        // Trigger echo pulse
        const button = document.querySelector('[data-echo-pulse]') as HTMLButtonElement;
        if (button) button.click();
      }
    },
    {
      id: 'ai-boost',
      name: 'RI Boost',
      icon: Brain,
      color: 'from-purple-500 to-pink-500',
      action: () => {
        // Navigate to AI features
        window.location.href = '/ai-features';
      }
    },
    {
      id: 'voice',
      name: isSpeaking ? 'Mute Voice' : 'Enable Voice',
      icon: isSpeaking ? VolumeX : Volume2,
      color: 'from-violet-500 to-indigo-500',
      action: toggleVoice
    },
    {
      id: 'shield',
      name: 'Security',
      icon: Shield,
      color: 'from-green-500 to-emerald-500',
      action: () => {
        // Toggle security mode and update document title for privacy
        const isSecure = document.body.classList.toggle('security-mode');
        if (isSecure) {
          document.title = '🔒 Storm Echo RI - Secure Mode';
          console.log('🛡️ Security mode activated - Enhanced privacy enabled');
          // Add subtle visual indicator
          document.body.style.filter = 'hue-rotate(15deg)';
        } else {
          document.title = 'Storm Echo RI - AI Ecosystem';
          console.log('🔓 Security mode deactivated');
          document.body.style.filter = '';
        }
      }
    },
    {
      id: 'theme',
      name: isDarkMode ? 'Light Mode' : 'Dark Mode',
      icon: isDarkMode ? Sun : Moon,
      color: 'from-orange-500 to-yellow-500',
      action: () => setIsDarkMode(!isDarkMode)
    }
  ];

  return (
    <>
      {/* Quick Action Toggle - Moved to top-right */}
      <motion.button
        onClick={() => setIsExpanded(!isExpanded)}
        className="fixed top-20 right-6 z-40 p-3 bg-gradient-to-r from-purple-500/80 to-pink-600/80 backdrop-blur-sm rounded-full shadow-lg hover:shadow-purple-500/50 transition-all"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        {/* Subtle AI Heartbeat Pulse */}
        <motion.div
          className="absolute inset-0 rounded-full bg-purple-400/20"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.1, 0.3]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        {isExpanded ? (
          <X className="text-white relative z-10" size={24} />
        ) : (
          <AnonymousMask size={24} className="text-white relative z-10" />
        )}
      </motion.button>

      {/* Quick Actions Panel */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, x: 20, y: -20 }}
            animate={{ opacity: 1, scale: 1, x: 0, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, x: 20, y: -20 }}
            className="fixed top-32 right-6 z-40 bg-gray-900/95 backdrop-blur-md border border-purple-400/20 rounded-lg shadow-2xl p-4"
          >
            <h3 className="text-purple-400 font-semibold mb-3 flex items-center">
              <AnonymousMask size={16} className="mr-2 text-purple-400" />
              Quick Actions
            </h3>
            
            <div className="space-y-2">
              {quickActions.map((action) => {
                const Icon = action.icon;
                return (
                  <motion.button
                    key={action.id}
                    onClick={action.action}
                    className={`w-48 px-4 py-2 rounded-lg bg-gradient-to-r ${action.color} text-white font-medium flex items-center space-x-2 hover:shadow-lg transition-all`}
                    whileHover={{ scale: 1.05, x: 5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Icon size={18} />
                    <span className="text-sm">{action.name}</span>
                  </motion.button>
                );
              })}
            </div>

            <div className="mt-4 pt-3 border-t border-gray-700">
              <button
                onClick={() => window.location.href = '/'}
                className="w-full px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-gray-300 text-sm transition-colors flex items-center justify-center space-x-2"
              >
                <Maximize size={16} />
                <span>Full Dashboard</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}