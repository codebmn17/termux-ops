import { motion } from 'framer-motion';
import { AlertCircle, Brain, CreditCard, Volume2, VolumeX, Mic } from 'lucide-react';

interface RIStatusProps {
  status: 'ready' | 'quota_exceeded' | 'error' | 'loading';
  message?: string;
  voiceEnabled?: boolean;
  isSpeaking?: boolean;
  onToggleVoice?: () => void;
}

export function RIStatus({ status, message, voiceEnabled = false, isSpeaking = false, onToggleVoice }: RIStatusProps) {
  const getStatusConfig = () => {
    switch (status) {
      case 'ready':
        return {
          icon: Brain,
          color: 'text-cyan-400',
          bgColor: 'bg-cyan-400/20',
          borderColor: 'border-cyan-400/30',
          title: 'Storm Echo RI Ready',
          description: voiceEnabled ? 
            'Voice synthesis active. RI is ready to speak and respond.' :
            'ChatGPT-4o integration active. Click voice icon to enable speech.'
        };
      case 'quota_exceeded':
        return {
          icon: CreditCard,
          color: 'text-yellow-400',
          bgColor: 'bg-yellow-400/20',
          borderColor: 'border-yellow-400/30',
          title: 'API Quota Exceeded',
          description: 'Your OpenAI API quota has been reached. Add billing to your OpenAI account to continue using RI features.'
        };
      case 'error':
        return {
          icon: AlertCircle,
          color: 'text-red-400',
          bgColor: 'bg-red-400/20',
          borderColor: 'border-red-400/30',
          title: 'RI Connection Error',
          description: message || 'Unable to connect to OpenAI services. Please check your API key configuration.'
        };
      default:
        return {
          icon: Brain,
          color: 'text-cyan-400',
          bgColor: 'bg-cyan-400/20',
          borderColor: 'border-cyan-400/30',
          title: 'Initializing RI System',
          description: 'Connecting to Storm Echo RI...'
        };
    }
  };

  const config = getStatusConfig();
  const IconComponent = config.icon;

  return (
    <motion.div
      className={`${config.bgColor} ${config.borderColor} border rounded-lg p-4 mb-4`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-1">
          <IconComponent className={`${config.color} mt-1`} size={18} />
          <div className="flex-1">
            <h4 className={`${config.color} font-semibold text-sm mb-1`}>{config.title}</h4>
            <p className="text-gray-300 text-xs leading-relaxed">{config.description}</p>
            {status === 'quota_exceeded' && (
              <p className="text-gray-400 text-xs mt-2">
                Visit <span className="text-cyan-400">platform.openai.com/account/billing</span> to add credits
              </p>
            )}
          </div>
        </div>
        
        {/* Voice Controls */}
        {status === 'ready' && onToggleVoice && (
          <div className="flex items-center space-x-2">
            {/* Voice Pulsing Indicator */}
            {isSpeaking && (
              <motion.div
                className="w-3 h-3 bg-cyan-400 rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.7, 1, 0.7]
                }}
                transition={{
                  duration: 0.8,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            )}
            
            {/* Voice Toggle Button */}
            <motion.button
              onClick={onToggleVoice}
              className={`p-2 rounded-lg transition-all ${
                voiceEnabled 
                  ? 'bg-cyan-400/20 text-cyan-400 hover:bg-cyan-400/30' 
                  : 'bg-gray-600/20 text-gray-400 hover:bg-gray-600/30'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              title={voiceEnabled ? "Disable Voice" : "Enable Voice"}
            >
              {voiceEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </motion.button>
          </div>
        )}
      </div>
    </motion.div>
  );
}