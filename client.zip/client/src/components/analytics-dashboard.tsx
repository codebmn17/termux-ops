import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, DollarSign, Users, Eye, CreditCard, Activity, Target, Zap, RefreshCw } from 'lucide-react';

interface DashboardData {
  summary: {
    totalRevenue: string;
    totalTransactions: number;
    totalPageViews: number;
    totalNewUsers: number;
    averageConversionRate: string;
    dateRange: { start: string; end: string };
  };
  charts: {
    dailyRevenue: Array<{ date: string; revenue: number; transactions: number }>;
    dailyPageViews: Array<{ date: string; pageViews: number; newUsers: number }>;
    topRevenueDays: Array<{ date: string; revenue: number }>;
  };
  recentActivity: {
    transactions: Array<{
      id: number;
      amount: number;
      currency: string;
      productType: string;
      customerEmail: string;
      createdAt: string;
    }>;
  };
}

interface RealtimeData {
  today: {
    revenue: number;
    transactions: number;
    pageViews: number;
    newUsers: number;
  };
  recentActivity: Array<{
    type: string;
    timestamp: string;
    data: any;
  }>;
  pendingTransactions: number;
}

export function AnalyticsDashboard() {
  const [dateRange, setDateRange] = useState('30d');
  const [isRealtime, setIsRealtime] = useState(false);

  // Optimized dashboard data fetch with stale time
  const { data: dashboardData, isLoading: dashboardLoading, refetch: refetchDashboard, isFetching } = useQuery<DashboardData>({
    queryKey: ['analytics-dashboard', dateRange],
    queryFn: async () => {
      const response = await fetch(`/api/analytics/dashboard?days=${dateRange}`);
      if (!response.ok) throw new Error('Failed to fetch dashboard data');
      return response.json();
    },
    staleTime: 30000, // Data considered fresh for 30 seconds
    gcTime: 300000, // Keep in cache for 5 minutes
  });

  // Optimized real-time data with conditional fetching
  const { data: realtimeData, isLoading: realtimeLoading } = useQuery<RealtimeData>({
    queryKey: ['analytics-realtime'],
    queryFn: async () => {
      const response = await fetch('/api/analytics/realtime');
      if (!response.ok) throw new Error('Failed to fetch real-time data');
      return response.json();
    },
    refetchInterval: isRealtime ? 10000 : false, // Increased to 10 seconds for better performance
    enabled: isRealtime, // Only fetch when realtime is enabled
    staleTime: 5000,
  });

  // Optimized page view tracking - fire and forget
  useEffect(() => {
    // Use fire-and-forget approach to avoid blocking render
    fetch('/api/analytics/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        eventType: 'page_view',
        eventData: { page: 'analytics-dashboard' },
        sessionId: `session_${Date.now()}`
      })
    }).catch(() => {}); // Ignore errors to avoid console spam
  }, []);

  // Memoized formatters for better performance
  const formatCurrency = useCallback((amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    }).format(amount);
  }, []);

  const formatDate = useCallback((dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  }, []);

  // Memoized calculations to prevent unnecessary re-renders
  const metricsData = useMemo(() => {
    if (!dashboardData) return [];
    
    return [
      {
        title: 'Total Revenue',
        value: formatCurrency(parseFloat(dashboardData.summary.totalRevenue || '0')),
        icon: DollarSign,
        color: 'text-green-400',
        bgColor: 'bg-green-500/20',
        trend: '+12.5%'
      },
      {
        title: 'Transactions',
        value: dashboardData.summary.totalTransactions?.toLocaleString() || '0',
        icon: CreditCard,
        color: 'text-blue-400',
        bgColor: 'bg-blue-500/20',
        trend: '+8.2%'
      },
      {
        title: 'Page Views',
        value: dashboardData.summary.totalPageViews?.toLocaleString() || '0',
        icon: Eye,
        color: 'text-purple-400',
        bgColor: 'bg-purple-500/20',
        trend: '+15.3%'
      },
      {
        title: 'New Users',
        value: dashboardData.summary.totalNewUsers?.toLocaleString() || '0',
        icon: Users,
        color: 'text-cyan-400',
        bgColor: 'bg-cyan-500/20',
        trend: '+5.7%'
      }
    ];
  }, [dashboardData, formatCurrency]);

  // Optimized loading state with skeleton UI
  if (dashboardLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 p-6 overflow-hidden">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header skeleton */}
          <div className="flex justify-between items-center">
            <div className="space-y-2">
              <div className="h-8 w-64 bg-gray-700 rounded animate-pulse"></div>
              <div className="h-4 w-48 bg-gray-800 rounded animate-pulse"></div>
            </div>
            <div className="flex space-x-4">
              <div className="h-10 w-20 bg-gray-700 rounded animate-pulse"></div>
              <div className="h-10 w-32 bg-gray-700 rounded animate-pulse"></div>
            </div>
          </div>
          
          {/* Metrics skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-800/60 rounded-xl animate-pulse"></div>
            ))}
          </div>
          
          {/* Charts skeleton */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-96 bg-gray-800/60 rounded-xl animate-pulse"></div>
            <div className="h-96 bg-gray-800/60 rounded-xl animate-pulse"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 p-4 sm:p-6 overflow-x-hidden">
      <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Analytics Dashboard</h1>
            <p className="text-gray-400">Real-time insights and revenue tracking</p>
          </div>

          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            {/* Real-time toggle with loading indicator */}
            <motion.button
              onClick={() => setIsRealtime(!isRealtime)}
              className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center ${
                isRealtime 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              disabled={isFetching}
            >
              {realtimeLoading ? (
                <RefreshCw size={16} className="inline mr-2 animate-spin" />
              ) : (
                <Activity size={16} className="inline mr-2" />
              )}
              {isRealtime ? 'Live' : 'Static'}
            </motion.button>

            {/* Date range selector */}
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-gray-800 text-white px-4 py-2 rounded-lg border border-gray-600 focus:border-cyan-500 focus:outline-none"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
            </select>
          </div>
        </motion.div>

        {/* Key Metrics Cards - Optimized with memoized data */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {metricsData.map((metric, index) => (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }} // Reduced delay for faster animation
              className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-4 sm:p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${metric.bgColor}`}>
                  <metric.icon size={24} className={metric.color} />
                </div>
                <div className="flex items-center text-green-400 text-sm">
                  <TrendingUp size={16} className="mr-1" />
                  {metric.trend}
                </div>
              </div>
              <h3 className="text-gray-400 text-sm font-medium">{metric.title}</h3>
              <p className="text-2xl font-bold text-white mt-1">{metric.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Real-time Today's Stats */}
        {isRealtime && realtimeData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-6"
          >
            <h2 className="text-xl font-bold text-white mb-4 flex items-center">
              <Zap size={20} className="mr-2 text-yellow-400" />
              Today's Real-Time Stats
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-400">{formatCurrency(realtimeData.today.revenue)}</p>
                <p className="text-gray-400 text-sm">Revenue Today</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-400">{realtimeData.today.transactions}</p>
                <p className="text-gray-400 text-sm">Transactions</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-400">{realtimeData.today.pageViews}</p>
                <p className="text-gray-400 text-sm">Page Views</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-cyan-400">{realtimeData.today.newUsers}</p>
                <p className="text-gray-400 text-sm">New Users</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Charts Grid - Optimized with lazy loading */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
          {/* Revenue Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-4 sm:p-6 overflow-hidden"
          >
            <h2 className="text-lg sm:text-xl font-bold text-white mb-4">Daily Revenue</h2>
            <div className="w-full chart-container gpu-accelerated" style={{ height: '280px', minHeight: '280px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart 
                  data={dashboardData?.charts.dailyRevenue || []}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#9CA3AF"
                    tickFormatter={formatDate}
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                    fontSize={12}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      fontSize: '14px'
                    }}
                    formatter={(value: any) => [formatCurrency(value), 'Revenue']}
                    labelFormatter={formatDate}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#06b6d4" 
                    fill="url(#revenueGradient)"
                    strokeWidth={2}
                    animationDuration={300}
                  />
                  <defs>
                    <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Page Views Chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-4 sm:p-6 overflow-hidden"
          >
            <h2 className="text-lg sm:text-xl font-bold text-white mb-4">Daily Page Views</h2>
            <div className="w-full chart-container gpu-accelerated" style={{ height: '280px', minHeight: '280px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart 
                  data={dashboardData?.charts.dailyPageViews || []}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#9CA3AF"
                    tickFormatter={formatDate}
                    fontSize={12}
                  />
                  <YAxis 
                    stroke="#9CA3AF" 
                    fontSize={12}
                    tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      fontSize: '14px'
                    }}
                    labelFormatter={formatDate}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="pageViews" 
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 4, fill: '#8b5cf6' }}
                    animationDuration={300}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="newUsers" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={false}
                    activeDot={{ r: 3, fill: '#10b981' }}
                    animationDuration={300}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Recent Transactions - Optimized with virtual scrolling simulation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-4 sm:p-6"
        >
          <h2 className="text-lg sm:text-xl font-bold text-white mb-4">Recent Transactions</h2>
          <div className="overflow-x-auto smooth-scroll scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800">
            <table className="w-full text-left min-w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="pb-3 text-gray-400 font-medium text-sm whitespace-nowrap">Amount</th>
                  <th className="pb-3 text-gray-400 font-medium text-sm whitespace-nowrap">Product</th>
                  <th className="pb-3 text-gray-400 font-medium text-sm whitespace-nowrap hidden sm:table-cell">Customer</th>
                  <th className="pb-3 text-gray-400 font-medium text-sm whitespace-nowrap">Date</th>
                </tr>
              </thead>
              <tbody>
                {dashboardData?.recentActivity.transactions?.slice(0, 8).map((transaction) => (
                  <tr key={transaction.id} className="border-b border-gray-700/50 hover:bg-gray-700/20">
                    <td className="py-2 text-green-400 font-semibold text-sm">
                      {formatCurrency(transaction.amount)}
                    </td>
                    <td className="py-2 text-white text-sm truncate max-w-32">
                      {transaction.productType || 'N/A'}
                    </td>
                    <td className="py-2 text-gray-300 text-sm truncate max-w-48 hidden sm:table-cell">
                      {transaction.customerEmail || 'Anonymous'}
                    </td>
                    <td className="py-2 text-gray-400 text-sm whitespace-nowrap">
                      {new Date(transaction.createdAt).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric' 
                      })}
                    </td>
                  </tr>
                )) || (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-gray-400 text-sm">
                      No transactions available. Connect PayPal to start tracking revenue.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Conversion Rate */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">Conversion Analytics</h2>
            <div className="flex items-center text-cyan-400">
              <Target size={20} className="mr-2" />
              <span className="text-2xl font-bold">
                {dashboardData?.summary.averageConversionRate || '0.00'}%
              </span>
            </div>
          </div>
          <p className="text-gray-400">
            Average conversion rate from page views to completed transactions
          </p>
        </motion.div>
      </div>
    </div>
  );
}