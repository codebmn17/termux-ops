import { useState, useEffect } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CloudIcon, SmartphoneIcon, SyncIcon, SettingsIcon, DownloadIcon, UploadIcon } from 'lucide-react';

interface SyncStatus {
  enabled: boolean;
  configured: boolean;
  lastSync?: string;
  nextSync?: string;
  syncPaths: string[];
}

interface SyncConfig {
  enabled: boolean;
  syncInterval: number;
  syncPaths: string[];
}

export default function TermuxGDrivePanel() {
  const [status, setStatus] = useState<SyncStatus | null>(null);
  const [config, setConfig] = useState<SyncConfig>({
    enabled: false,
    syncInterval: 30,
    syncPaths: []
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadStatus();
  }, []);

  const loadStatus = async () => {
    try {
      const data = await apiRequest('GET', '/api/termux/gdrive/status');
      setStatus(data);
      setConfig({
        enabled: data.enabled,
        syncInterval: 30, // Default from status
        syncPaths: data.syncPaths
      });
    } catch (error) {
      console.error('Failed to load status:', error);
    }
  };

  const setupGoogleDrive = async () => {
    setIsLoading(true);
    try {
      const result = await apiRequest('POST', '/api/termux/gdrive/setup');
      
      if (result.success) {
        toast({
          title: 'Setup Successful',
          description: result.message
        });
        await loadStatus();
      } else {
        toast({
          title: 'Setup Failed',
          description: result.message,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to setup Google Drive',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const syncToGoogleDrive = async () => {
    setIsLoading(true);
    try {
      const result = await apiRequest('POST', '/api/termux/gdrive/sync-upload');
      
      if (result.success) {
        toast({
          title: 'Upload Successful',
          description: `${result.message}. Synced: ${result.syncedFiles?.join(', ') || 'No files'}`
        });
        await loadStatus();
      } else {
        toast({
          title: 'Upload Failed',
          description: result.message,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to sync to Google Drive',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const syncFromGoogleDrive = async () => {
    setIsLoading(true);
    try {
      const result = await apiRequest('POST', '/api/termux/gdrive/sync-download');
      
      if (result.success) {
        toast({
          title: 'Download Successful',
          description: `${result.message}. Downloaded: ${result.downloadedFiles?.join(', ') || 'No files'}`
        });
        await loadStatus();
      } else {
        toast({
          title: 'Download Failed',
          description: result.message,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to sync from Google Drive',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateConfig = async () => {
    setIsLoading(true);
    try {
      const result = await apiRequest('POST', '/api/termux/gdrive/config', config);
      
      if (result.success) {
        toast({
          title: 'Configuration Updated',
          description: result.message
        });
        await loadStatus();
      } else {
        toast({
          title: 'Configuration Failed',
          description: result.message,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update configuration',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const testConnection = async () => {
    setIsLoading(true);
    try {
      const result = await apiRequest('POST', '/api/termux/gdrive/test-connection');
      
      if (result.success) {
        toast({
          title: 'Connection Test Successful',
          description: result.message
        });
      } else {
        const remoteInfo = result.remotes?.length ? `Available remotes: ${result.remotes.join(', ')}` : 'No remotes configured';
        const detailInfo = result.details ? `\nDetails: ${result.details}` : '';
        
        toast({
          title: 'Connection Test Failed',
          description: `${result.message}\n${remoteInfo}${detailInfo}`,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to test Google Drive connection',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createTermuxScript = async () => {
    setIsLoading(true);
    try {
      const result = await apiRequest('POST', '/api/termux/gdrive/create-script');
      
      if (result.success) {
        toast({
          title: 'Script Created',
          description: `Termux sync script created at: ${result.scriptPath}`
        });
      } else {
        toast({
          title: 'Script Creation Failed',
          description: result.message,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create Termux script',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-cyan-500/20 rounded-lg">
          <CloudIcon className="w-6 h-6 text-cyan-300" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-cyan-300">Termux Google Drive Sync</h2>
          <p className="text-gray-400 text-sm">Mobile file synchronization and cloud backup</p>
        </div>
      </div>

      <Tabs defaultValue="status" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="status">Status</TabsTrigger>
          <TabsTrigger value="sync">Sync</TabsTrigger>
          <TabsTrigger value="config">Config</TabsTrigger>
          <TabsTrigger value="termux">Termux</TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="space-y-4">
          <Card className="bg-black/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300 flex items-center space-x-2">
                <SyncIcon className="w-5 h-5" />
                <span>Sync Status</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {status ? (
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-cyan-300">Configuration</Label>
                    <Badge variant={status.configured ? "default" : "destructive"}>
                      {status.configured ? "Configured" : "Not Configured"}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-cyan-300">Auto-Sync</Label>
                    <Badge variant={status.enabled ? "default" : "secondary"}>
                      {status.enabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-cyan-300">Last Sync</Label>
                    <p className="text-sm text-gray-400">
                      {status.lastSync ? new Date(status.lastSync).toLocaleString() : 'Never'}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-cyan-300">Next Sync</Label>
                    <p className="text-sm text-gray-400">
                      {status.nextSync ? new Date(status.nextSync).toLocaleString() : 'N/A'}
                    </p>
                  </div>

                  <div className="col-span-2 space-y-2">
                    <Label className="text-cyan-300">Sync Paths ({status.syncPaths.length})</Label>
                    <div className="flex flex-wrap gap-1">
                      {status.syncPaths.map((path, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {path}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-gray-400">Loading status...</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-black/50 border-cyan-500/30">
              <CardHeader>
                <CardTitle className="text-cyan-300 flex items-center space-x-2">
                  <UploadIcon className="w-5 h-5" />
                  <span>Upload to Google Drive</span>
                </CardTitle>
                <CardDescription>
                  Sync local StormEcho files to Google Drive
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={syncToGoogleDrive}
                  disabled={isLoading || !status?.configured}
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                >
                  {isLoading ? 'Syncing...' : 'Upload Files'}
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-black/50 border-cyan-500/30">
              <CardHeader>
                <CardTitle className="text-cyan-300 flex items-center space-x-2">
                  <DownloadIcon className="w-5 h-5" />
                  <span>Download from Google Drive</span>
                </CardTitle>
                <CardDescription>
                  Download StormEcho files from Google Drive
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={syncFromGoogleDrive}
                  disabled={isLoading || !status?.configured}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {isLoading ? 'Downloading...' : 'Download Files'}
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300">Google Drive Setup</CardTitle>
              <CardDescription>
                Configure rclone and Google Drive authentication
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button
                  onClick={setupGoogleDrive}
                  disabled={isLoading}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  {isLoading ? 'Setting up...' : 'Setup Google Drive'}
                </Button>
                <Button
                  onClick={testConnection}
                  disabled={isLoading}
                  variant="outline"
                  className="w-full border-green-500/30 text-green-300 hover:bg-green-500/10"
                >
                  {isLoading ? 'Testing...' : 'Test Connection'}
                </Button>
              </div>
              <p className="text-xs text-gray-400 mt-2">
                Requires rclone installation and Google Drive authentication
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="config" className="space-y-4">
          <Card className="bg-black/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300 flex items-center space-x-2">
                <SettingsIcon className="w-5 h-5" />
                <span>Sync Configuration</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.enabled}
                  onCheckedChange={(checked) => setConfig(prev => ({ ...prev, enabled: checked }))}
                />
                <Label className="text-cyan-300">Enable Auto-Sync</Label>
              </div>

              <div className="space-y-2">
                <Label className="text-cyan-300">Sync Interval (minutes)</Label>
                <Input
                  type="number"
                  value={config.syncInterval}
                  onChange={(e) => setConfig(prev => ({ ...prev, syncInterval: parseInt(e.target.value) || 30 }))}
                  className="bg-black/50 border-cyan-500/30"
                  min="5"
                  max="1440"
                />
                <p className="text-xs text-gray-400">
                  How often to automatically sync files (5-1440 minutes)
                </p>
              </div>

              <Button
                onClick={updateConfig}
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? 'Updating...' : 'Update Configuration'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="termux" className="space-y-4">
          <Card className="bg-black/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-300 flex items-center space-x-2">
                <SmartphoneIcon className="w-5 h-5" />
                <span>Termux Integration</span>
              </CardTitle>
              <CardDescription>
                Mobile synchronization for Termux environment
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={createTermuxScript}
                disabled={isLoading}
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                {isLoading ? 'Creating...' : 'Create Termux Sync Script'}
              </Button>

              <div className="bg-gray-900/50 p-4 rounded-lg">
                <h4 className="text-cyan-300 font-semibold mb-2">Termux Setup Instructions:</h4>
                <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                  <li>Install Termux from F-Droid or Google Play</li>
                  <li>Run: <code className="bg-black/50 px-1 rounded">pkg install rclone</code></li>
                  <li>Configure Google Drive: <code className="bg-black/50 px-1 rounded">rclone config</code></li>
                  <li>Download sync script from StormEcho</li>
                  <li>Run script: <code className="bg-black/50 px-1 rounded">bash termux-gdrive-sync.sh</code></li>
                </ol>
              </div>

              <div className="bg-blue-900/20 p-4 rounded-lg border border-blue-500/30">
                <h4 className="text-blue-300 font-semibold mb-2">Sync Locations:</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li><strong>Upload to:</strong> gdrive:StormEcho_Mobile_Sync</li>
                  <li><strong>Download to:</strong> /storage/emulated/0/StormEcho_Download</li>
                  <li><strong>Local files:</strong> /storage/emulated/0/StormEcho/</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}