import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Activity, 
  Zap, 
  Shield, 
  Globe, 
  Database,
  Cpu,
  BarChart,
  Settings,
  X,
  Maximize2,
  Minimize2
} from 'lucide-react';

interface SystemMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  icon: any; // Lucide icon component
  color: string;
}

export function ControlCenter() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [activeTab, setActiveTab] = useState('system');
  
  // Allow external trigger
  useEffect(() => {
    const handleControlCenterToggle = () => {
      setIsOpen(prev => !prev);
    };
    
    window.addEventListener('toggle-control-center', handleControlCenterToggle);
    
    return () => {
      window.removeEventListener('toggle-control-center', handleControlCenterToggle);
    };
  }, []);
  
  const [metrics, setMetrics] = useState<SystemMetric[]>([
    {
      id: '1',
      name: 'RI Processing',
      value: 92.5,
      unit: '%',
      trend: 'up',
      icon: Cpu,
      color: 'text-cyan-400'
    },
    {
      id: '2',
      name: 'Active Users',
      value: 342,
      unit: '',
      trend: 'up',
      icon: Activity,
      color: 'text-green-400'
    },
    {
      id: '3',
      name: 'Energy Output',
      value: 1847,
      unit: 'THz',
      trend: 'stable',
      icon: Zap,
      color: 'text-yellow-400'
    },
    {
      id: '4',
      name: 'Security Status',
      value: 100,
      unit: '%',
      trend: 'stable',
      icon: Shield,
      color: 'text-purple-400'
    }
  ]);

  // Simulate real-time metric updates
  useEffect(() => {
    if (!isOpen) return;
    
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(metric => ({
        ...metric,
        value: metric.id === '2' ? metric.value : 
               metric.value + (Math.random() - 0.5) * 5,
        trend: Math.random() > 0.7 ? 
          (Math.random() > 0.5 ? 'up' : 'down') : 
          metric.trend
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, [isOpen]);

  const tabs = [
    { id: 'system', label: 'System', icon: Activity },
    { id: 'network', label: 'Network', icon: Globe },
    { id: 'database', label: 'Database', icon: Database },
    { id: 'analytics', label: 'Analytics', icon: BarChart }
  ];

  return (
    <>
      {/* Control Center Toggle Button */}
      <motion.button
        onClick={() => setIsOpen(true)}
        data-control-center-toggle
        className="fixed top-6 left-6 z-40 p-3 bg-gradient-to-r from-purple-500 to-violet-600 rounded-full shadow-lg hover:shadow-purple-500/50 transition-all hidden"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Settings className="text-white" size={24} />
      </motion.button>

      {/* Control Center Panel */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-30"
              onClick={() => setIsOpen(false)}
            />

            {/* Panel */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={`fixed z-35 bg-gray-900/95 backdrop-blur-md border border-purple-400/20 rounded-lg shadow-2xl transition-all ${
                isMaximized 
                  ? 'inset-2 sm:inset-4 max-w-[calc(100vw-1rem)] max-h-[calc(100vh-1rem)]' 
                  : 'top-20 left-4 right-4 sm:right-auto sm:left-6 sm:w-80 md:w-96 max-h-[70vh] sm:max-h-[600px] max-w-[calc(100vw-2rem)]'
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-purple-400/20">
                <h3 className="text-lg font-bold text-purple-400 flex items-center">
                  <Activity className="mr-2" size={20} />
                  Storm Control Center
                </h3>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setIsMaximized(!isMaximized)}
                    className="p-1.5 hover:bg-gray-800 rounded transition-colors"
                  >
                    {isMaximized ? (
                      <Minimize2 className="text-gray-400" size={16} />
                    ) : (
                      <Maximize2 className="text-gray-400" size={16} />
                    )}
                  </button>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-1.5 hover:bg-gray-800 rounded transition-colors"
                  >
                    <X className="text-gray-400" size={16} />
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-gray-700 overflow-x-auto">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex-1 px-2 sm:px-4 py-2 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap ${
                      activeTab === tab.id
                        ? 'text-purple-400 border-b-2 border-purple-400'
                        : 'text-gray-400 hover:text-gray-300'
                    }`}
                  >
                    <tab.icon size={14} className="inline mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">{tab.label}</span>
                    <span className="sm:hidden">{tab.label.slice(0, 3)}</span>
                  </button>
                ))}
              </div>

              {/* Content */}
              <div className="p-3 sm:p-4 overflow-y-auto" style={{ maxHeight: isMaximized ? 'calc(100vh - 200px)' : '50vh' }}>
                {activeTab === 'system' && (
                  <div className="space-y-4">
                    {/* System Metrics */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {metrics.map(metric => {
                        const Icon = metric.icon;
                        return (
                          <motion.div
                            key={metric.id}
                            className="bg-gray-800/50 border border-gray-700 rounded-lg p-3"
                            whileHover={{ scale: 1.02 }}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <Icon className={metric.color} size={20} />
                              <span className={`text-xs ${
                                metric.trend === 'up' ? 'text-green-400' : 
                                metric.trend === 'down' ? 'text-red-400' : 
                                'text-gray-400'
                              }`}>
                                {metric.trend === 'up' ? '↑' : 
                                 metric.trend === 'down' ? '↓' : '→'}
                              </span>
                            </div>
                            <div className={`text-xl font-bold ${metric.color}`}>
                              {metric.value.toFixed(metric.unit === '%' ? 1 : 0)}{metric.unit}
                            </div>
                            <div className="text-xs text-gray-400">{metric.name}</div>
                          </motion.div>
                        );
                      })}
                    </div>

                    {/* Quick Actions */}
                    <div className="mt-4">
                      <h4 className="text-purple-400 font-semibold mb-3 text-sm">Quick Actions</h4>
                      <div className="space-y-2">
                        <button className="w-full px-3 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/30 rounded-lg text-purple-400 text-xs sm:text-sm transition-colors">
                          Run System Diagnostics
                        </button>
                        <button className="w-full px-3 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/30 rounded-lg text-purple-400 text-xs sm:text-sm transition-colors">
                          Optimize Performance
                        </button>
                        <button className="w-full px-3 py-2 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/30 rounded-lg text-purple-400 text-xs sm:text-sm transition-colors">
                          Clear Cache
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'network' && (
                  <div className="text-gray-400">
                    <h4 className="text-cyan-400 font-semibold mb-3">Network Status</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between py-2 border-b border-gray-700">
                        <span>Connection Status</span>
                        <span className="text-green-400">Connected</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-700">
                        <span>Latency</span>
                        <span className="text-cyan-400">12ms</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-700">
                        <span>Bandwidth</span>
                        <span className="text-cyan-400">1.2 GB/s</span>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'database' && (
                  <div className="text-gray-400">
                    <h4 className="text-cyan-400 font-semibold mb-3">Database Health</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between py-2 border-b border-gray-700">
                        <span>Status</span>
                        <span className="text-green-400">Operational</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-700">
                        <span>Size</span>
                        <span className="text-cyan-400">2.3 GB</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-700">
                        <span>Queries/sec</span>
                        <span className="text-cyan-400">1,247</span>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'analytics' && (
                  <div className="text-gray-400">
                    <h4 className="text-cyan-400 font-semibold mb-3">Performance Analytics</h4>
                    <div className="h-48 bg-gray-800/50 rounded-lg flex items-center justify-center">
                      <span className="text-gray-500">Analytics Chart</span>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}