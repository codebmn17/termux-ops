import { useEffect, useRef } from 'react';
import cosmicNebula from '@assets/Screenshot_20250803_110914_Brave_1754241799298.png';

export function GalaxyBackground() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Create ambient particles continuously
    const createAmbientParticles = () => {
      const particle = document.createElement('div');
      particle.className = 'particle animate-particle-float';
      particle.style.left = Math.random() * window.innerWidth + 'px';
      particle.style.top = window.innerHeight + 'px';
      particle.style.animationDuration = (3 + Math.random() * 2) + 's';
      particle.style.opacity = '0.3';
      
      container.appendChild(particle);
      
      // Remove particle after animation
      setTimeout(() => {
        if (particle.parentNode) {
          particle.parentNode.removeChild(particle);
        }
      }, 5000);
    };

    const intervalId = setInterval(createAmbientParticles, 2000);

    // Handle window resize
    const handleResize = () => {
      const particles = container.querySelectorAll('.particle');
      particles.forEach(particle => {
        const element = particle as HTMLElement;
        if (parseInt(element.style.left) > window.innerWidth) {
          element.style.left = Math.random() * window.innerWidth + 'px';
        }
      });
    };

    window.addEventListener('resize', handleResize);

    return () => {
      clearInterval(intervalId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="min-h-screen w-full fixed inset-0">
      {/* Cosmic nebula background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: `url(${cosmicNebula})`,
          filter: 'brightness(0.7) contrast(1.2)'
        }}
      />
      
      {/* Overlay gradient for better text visibility */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/50" />
      
      {/* Animated particles */}
      <div ref={containerRef} className="absolute inset-0 pointer-events-none" />
    </div>
  );
}
