import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Mail, 
  Send, 
  Settings, 
  Clock, 
  Shield, 
  CheckCircle,
  AlertTriangle,
  Calendar,
  TestTube
} from 'lucide-react';

interface ReportingStatus {
  isActive: boolean;
  schedules: {
    daily: string;
    weekly: string;
  };
  emailStatus: {
    enabled: boolean;
    configured: boolean;
    from: string;
    to: string;
  };
  recentReports: Array<{
    timestamp: string;
    type: string;
    success: boolean;
    recipient: string;
  }>;
  totalReports: number;
}

export function AutoReportingPanel() {
  const { toast } = useToast();
  const [status, setStatus] = useState<ReportingStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [emailConfig, setEmailConfig] = useState({
    from: '',
    to: '',
    password: ''
  });
  const [scheduleConfig, setScheduleConfig] = useState({
    daily: '0 9 * * *',
    weekly: '0 9 * * 1'
  });

  useEffect(() => {
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await apiRequest('GET', '/api/terminal-modules/auto-reporting/status');
      if (response.success) {
        setStatus(response.status);
        setEmailConfig({
          from: response.status.emailStatus.from,
          to: response.status.emailStatus.to,
          password: ''
        });
        setScheduleConfig(response.status.schedules);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch reporting status',
        variant: 'destructive'
      });
    }
  };

  const sendImmediateReport = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/terminal-modules/auto-reporting/send-report');
      
      if (response.success) {
        toast({
          title: 'Report Sent',
          description: 'Performance report sent successfully'
        });
        fetchStatus();
      } else {
        toast({
          title: 'Send Failed',
          description: response.message || 'Failed to send report',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send report',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const testEmailConnection = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/email-test');
      
      if (response.success) {
        toast({
          title: 'Test Successful',
          description: 'Performance report sent successfully! Check your inbox.'
        });
      } else {
        toast({
          title: 'Test Failed',
          description: `Failed to send test email${response.configured ? '' : ' - EMAIL_PASSWORD not configured'}`,
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to test email connection',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateEmailConfig = async () => {
    try {
      const response = await apiRequest('POST', '/api/email-notifications/config', emailConfig);
      
      if (response.success) {
        toast({
          title: 'Configuration Updated',
          description: 'Email settings saved successfully'
        });
        fetchStatus();
      } else {
        toast({
          title: 'Update Failed',
          description: 'Failed to update email configuration',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update email configuration',
        variant: 'destructive'
      });
    }
  };

  const updateSchedule = async () => {
    try {
      const response = await apiRequest('POST', '/api/terminal-modules/auto-reporting/schedule', scheduleConfig);
      
      if (response.success) {
        toast({
          title: 'Schedule Updated',
          description: 'Report schedule updated successfully'
        });
        fetchStatus();
      } else {
        toast({
          title: 'Update Failed',
          description: 'Failed to update schedule',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update schedule',
        variant: 'destructive'
      });
    }
  };

  const sendSecurityAlert = async () => {
    try {
      const response = await apiRequest('POST', '/api/terminal-modules/auto-reporting/security-alert', {
        alertType: 'Test Security Alert',
        details: 'This is a test security alert from the StormEcho system.',
        severity: 'medium'
      });
      
      if (response.success) {
        toast({
          title: 'Security Alert Sent',
          description: 'Test security alert sent successfully'
        });
      } else {
        toast({
          title: 'Alert Failed',
          description: 'Failed to send security alert',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send security alert',
        variant: 'destructive'
      });
    }
  };

  if (!status) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin w-8 h-8 border-4 border-cyan-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Overview */}
      <Card className="bg-black/80 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-cyan-400 flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Auto-Reporting Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-black/50 rounded-lg">
              <div className={`text-2xl font-bold ${status.isActive ? 'text-green-400' : 'text-red-400'}`}>
                {status.isActive ? '✅' : '❌'}
              </div>
              <p className="text-sm text-gray-300">System Status</p>
            </div>
            
            <div className="text-center p-3 bg-black/50 rounded-lg">
              <div className={`text-2xl font-bold ${status.emailStatus.enabled ? 'text-green-400' : 'text-yellow-400'}`}>
                {status.emailStatus.enabled ? '📧' : '⚠️'}
              </div>
              <p className="text-sm text-gray-300">Email Service</p>
            </div>
            
            <div className="text-center p-3 bg-black/50 rounded-lg">
              <div className="text-2xl font-bold text-cyan-400">{status.totalReports}</div>
              <p className="text-sm text-gray-300">Total Reports</p>
            </div>
            
            <div className="text-center p-3 bg-black/50 rounded-lg">
              <div className="text-2xl font-bold text-purple-400">
                {status.recentReports.filter(r => r.success).length}/{status.recentReports.length}
              </div>
              <p className="text-sm text-gray-300">Success Rate</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="bg-black/80 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center gap-2">
            <Send className="w-5 h-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button
              onClick={sendImmediateReport}
              disabled={isLoading}
              className="bg-cyan-600 hover:bg-cyan-700"
            >
              <Send className="w-4 h-4 mr-2" />
              Send Report
            </Button>
            
            <Button
              onClick={testEmailConnection}
              disabled={isLoading}
              variant="outline"
              className="border-yellow-500/30 hover:bg-yellow-500/10"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Test Email
            </Button>
            
            <Button
              onClick={sendSecurityAlert}
              disabled={isLoading}
              variant="outline"
              className="border-orange-500/30 hover:bg-orange-500/10"
            >
              <Shield className="w-4 h-4 mr-2" />
              Test Alert
            </Button>
            
            <Button
              onClick={fetchStatus}
              variant="outline"
              className="border-cyan-500/30 hover:bg-cyan-500/10"
            >
              <Settings className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Email Configuration */}
      <Card className="bg-black/80 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Email Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="from-email" className="text-cyan-300">From Email</Label>
              <Input
                id="from-email"
                type="email"
                value={emailConfig.from}
                onChange={(e) => setEmailConfig(prev => ({ ...prev, from: e.target.value }))}
                className="bg-black/50 border-cyan-500/30"
                placeholder="stormecho.reports@gmail.com"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="to-email" className="text-cyan-300">To Email</Label>
              <Input
                id="to-email"
                type="email"
                value={emailConfig.to}
                onChange={(e) => setEmailConfig(prev => ({ ...prev, to: e.target.value }))}
                className="bg-black/50 border-cyan-500/30"
                placeholder="your-email@gmail.com"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email-password" className="text-cyan-300">Gmail App Password</Label>
            <Input
              id="email-password"
              type="password"
              value={emailConfig.password}
              onChange={(e) => setEmailConfig(prev => ({ ...prev, password: e.target.value }))}
              className="bg-black/50 border-cyan-500/30"
              placeholder="Gmail app password (add to secrets)"
            />
            <div className="text-xs text-gray-400 space-y-1">
              <p>Add EMAIL_PASSWORD to Replit Secrets for security</p>
              <p className="text-cyan-300">Setup Guide:</p>
              <p>1. Enable 2FA in Google Account → Security</p>
              <p>2. Generate App Password for "Mail"</p>
              <p>3. Add 16-character password to Replit Secrets</p>
              <p>4. Restart application to activate</p>
            </div>
          </div>
          
          <Button onClick={updateEmailConfig} className="bg-blue-600 hover:bg-blue-700">
            <Settings className="w-4 h-4 mr-2" />
            Update Configuration
          </Button>
        </CardContent>
      </Card>

      {/* Schedule Configuration */}
      <Card className="bg-black/80 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Report Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="daily-schedule" className="text-cyan-300">Daily Reports (Cron)</Label>
              <Input
                id="daily-schedule"
                value={scheduleConfig.daily}
                onChange={(e) => setScheduleConfig(prev => ({ ...prev, daily: e.target.value }))}
                className="bg-black/50 border-cyan-500/30"
                placeholder="0 9 * * *"
              />
              <p className="text-xs text-gray-400">Current: 9 AM daily</p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="weekly-schedule" className="text-cyan-300">Weekly Reports (Cron)</Label>
              <Input
                id="weekly-schedule"
                value={scheduleConfig.weekly}
                onChange={(e) => setScheduleConfig(prev => ({ ...prev, weekly: e.target.value }))}
                className="bg-black/50 border-cyan-500/30"
                placeholder="0 9 * * 1"
              />
              <p className="text-xs text-gray-400">Current: 9 AM Mondays</p>
            </div>
          </div>
          
          <Button onClick={updateSchedule} className="bg-purple-600 hover:bg-purple-700">
            <Calendar className="w-4 h-4 mr-2" />
            Update Schedule
          </Button>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      {status.recentReports.length > 0 && (
        <Card className="bg-black/80 border-gray-500/30">
          <CardHeader>
            <CardTitle className="text-gray-300 flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Recent Reports
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {status.recentReports.map((report, index) => (
                <motion.div
                  key={index}
                  className="flex items-center justify-between p-3 bg-black/50 rounded-lg"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="flex items-center gap-3">
                    {report.success ? (
                      <CheckCircle className="w-4 h-4 text-green-400" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-red-400" />
                    )}
                    <span className="text-white font-medium">{report.type}</span>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-gray-300">
                      {new Date(report.timestamp).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(report.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}