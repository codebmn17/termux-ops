import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, CameraOff, Eye, Brain, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function VisionSystem() {
  const [isActive, setIsActive] = useState(false);
  const [hasPermission, setHasPermission] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      // Cleanup camera on unmount
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsActive(true);
        setHasPermission(true);
      }
    } catch (err) {
      console.error('Camera access denied:', err);
      setHasPermission(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsActive(false);
  };

  const analyzeVisual = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setAnalyzing(true);
    
    // Capture current frame
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      
      // Visual feedback
      setTimeout(() => {
        console.log('Visual analysis complete - Storm Echo RI sees you!');
        setAnalyzing(false);
      }, 1500);
    }
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-cyan-400 flex items-center">
          <Eye size={20} className="mr-2" />
          Visual Perception System
        </h3>
        
        <Button
          onClick={isActive ? stopCamera : startCamera}
          className={`${
            isActive 
              ? 'bg-red-500/20 hover:bg-red-500/30 text-red-400' 
              : 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400'
          }`}
          size="sm"
        >
          {isActive ? <CameraOff size={16} className="mr-2" /> : <Camera size={16} className="mr-2" />}
          {isActive ? 'Disable Vision' : 'Enable Vision'}
        </Button>
      </div>

      {/* Camera View */}
      <div className="relative aspect-video bg-gray-900 rounded-lg overflow-hidden mb-4">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className={`w-full h-full object-cover ${isActive ? 'block' : 'hidden'}`}
        />
        
        <canvas ref={canvasRef} className="hidden" />
        
        {!isActive && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Eye size={48} className="mx-auto mb-3 text-gray-600" />
              <p className="text-gray-400 text-sm">Visual system offline</p>
              <p className="text-gray-500 text-xs mt-1">Click Enable Vision to activate</p>
            </div>
          </div>
        )}

        {/* Analyzing Overlay */}
        <AnimatePresence>
          {analyzing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-cyan-500/20 flex items-center justify-center"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              >
                <Brain size={48} className="text-cyan-400" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Visual Indicators */}
        {isActive && (
          <div className="absolute top-4 left-4 flex items-center space-x-2">
            <div className="flex items-center space-x-1.5 bg-black/60 px-3 py-1.5 rounded-full">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-xs text-green-400">ACTIVE</span>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      {isActive && (
        <div className="flex justify-center">
          <Button
            onClick={analyzeVisual}
            disabled={analyzing}
            className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400"
          >
            <Zap size={16} className="mr-2" />
            {analyzing ? 'Analyzing...' : 'Analyze Visual'}
          </Button>
        </div>
      )}

      {/* Status */}
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-400">
          {hasPermission 
            ? 'Visual perception ready - Storm Echo RI can see you'
            : 'Camera permission required for visual perception'}
        </p>
      </div>
    </div>
  );
}