import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PulseLog {
  id: number;
  timestamp: string;
  message: string;
  type: 'info' | 'pulse' | 'complete';
}

export function PulseConsole() {
  const [logs, setLogs] = useState<PulseLog[]>([]);

  useEffect(() => {
    // Override console.log to capture pulse feedback logs
    const originalLog = console.log;
    console.log = (...args) => {
      const message = args.join(' ');
      
      // Only capture messages with specific pulse indicators
      if (message.includes('⚡') || message.includes('🌀') || message.includes('✅') || message.includes('🔘') || message.includes('🌌')) {
        const log: PulseLog = {
          id: Date.now() + Math.random(),
          timestamp: new Date().toLocaleTimeString(),
          message: message,
          type: message.includes('⚡') ? 'info' : 
                 message.includes('🌀') ? 'pulse' : 
                 message.includes('✅') ? 'complete' : 'info'
        };
        
        setLogs(prev => [...prev.slice(-4), log]); // Keep only last 5 logs
      }
      
      originalLog(...args); // Call original console.log
    };

    return () => {
      console.log = originalLog; // Restore original console.log
    };
  }, []);

  if (logs.length === 0) return null;

  return (
    <motion.div
      className="fixed bottom-4 right-4 left-4 sm:left-auto sm:w-80 max-h-48 bg-black/80 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-4 overflow-hidden max-w-[calc(100vw-2rem)]"
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-cyan-400 text-sm font-medium">Pulse Console</h3>
        <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
      </div>
      
      <div className="space-y-1 text-xs overflow-y-auto max-h-32">
        <AnimatePresence>
          {logs.map((log) => (
            <motion.div
              key={log.id}
              className={`p-2 rounded border-l-2 ${
                log.type === 'info' ? 'border-cyan-400 bg-cyan-400/5' :
                log.type === 'pulse' ? 'border-blue-400 bg-blue-400/5' :
                'border-green-400 bg-green-400/5'
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center justify-between">
                <span className="text-white font-mono">{log.message}</span>
                <span className="text-gray-400 text-xs">{log.timestamp}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}