import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, DollarSign, Calendar, Target } from 'lucide-react';

interface IncomeData {
  id: string;
  source: string;
  amount: number;
  date: string;
  category: string;
}

export function IncomeTracker() {
  const [totalIncome, setTotalIncome] = useState(0);
  const [monthlyGrowth, setMonthlyGrowth] = useState(0);

  // Real income data from API
  const [recentIncomes, setRecentIncomes] = useState<IncomeData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchRealIncomeData = async () => {
      setIsLoading(true);
      try {
        // Fetch actual income data from API endpoints
        const response = await fetch('/api/income-data');
        if (response.ok) {
          const data = await response.json();
          setRecentIncomes(data.recentIncomes || []);
          const total = data.recentIncomes?.reduce((sum: number, income: IncomeData) => sum + income.amount, 0) || 0;
          setTotalIncome(total);
          setMonthlyGrowth(data.monthlyGrowth || 0);
        } else {
          // If no real data available, show empty state
          setRecentIncomes([]);
          setTotalIncome(0);
          setMonthlyGrowth(0);
        }
      } catch (error) {
        console.error('Failed to fetch income data:', error);
        setRecentIncomes([]);
        setTotalIncome(0);
        setMonthlyGrowth(0);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRealIncomeData();
  }, []);

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <TrendingUp className="mr-2" size={20} />
          Income Tracker
        </h3>
        <div className="text-right">
          <div className="text-2xl font-bold text-green-400">${totalIncome}</div>
          <div className="text-xs text-gray-400">Last 7 days</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-green-400/10 border border-green-400/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <DollarSign className="text-green-400" size={16} />
            <span className="text-green-400 text-xs font-semibold">+{monthlyGrowth}%</span>
          </div>
          <div className="text-green-400 font-bold mt-2">${totalIncome * 4.3}</div>
          <div className="text-xs text-gray-400">Monthly Projection</div>
        </div>

        <div className="bg-blue-400/10 border border-blue-400/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <Calendar className="text-blue-400" size={16} />
            <span className="text-blue-400 text-xs font-semibold">{recentIncomes.length}</span>
          </div>
          <div className="text-blue-400 font-bold mt-2">Active</div>
          <div className="text-xs text-gray-400">Income Streams</div>
        </div>

        <div className="bg-purple-400/10 border border-purple-400/20 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <Target className="text-purple-400" size={16} />
            <span className="text-purple-400 text-xs font-semibold">73%</span>
          </div>
          <div className="text-purple-400 font-bold mt-2">$5,000</div>
          <div className="text-xs text-gray-400">Monthly Goal</div>
        </div>
      </div>

      <div className="space-y-3">
        <h4 className="text-cyan-400 font-semibold text-sm">Recent Transactions</h4>
        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-cyan-400 mx-auto"></div>
            <p className="text-gray-400 text-sm mt-2">Loading transactions...</p>
          </div>
        ) : recentIncomes.length > 0 ? (
          recentIncomes.map((income, index) => (
            <motion.div
              key={income.id}
              className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <div>
                <div className="text-white font-medium text-sm">{income.source}</div>
                <div className="text-gray-400 text-xs">{income.date}</div>
              </div>
              <div className="text-green-400 font-bold">+${income.amount}</div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-8">
            <DollarSign className="mx-auto text-gray-500 mb-2" size={24} />
            <p className="text-gray-400 text-sm">No transactions yet</p>
            <p className="text-gray-500 text-xs mt-1">Connect payment providers to track real income</p>
          </div>
        )}
      </div>
    </div>
  );
}