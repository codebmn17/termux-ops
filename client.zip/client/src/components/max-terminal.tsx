import { useEffect, useRef, useState } from 'react';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { WebLinksAddon } from 'xterm-addon-web-links';
import { SerializeAddon } from 'xterm-addon-serialize';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TerminalKeyboard } from '@/components/terminal-keyboard';
import { Link } from 'wouter';
import { masterLoop } from '@/lib/master-loop';
import { 
  Terminal as TerminalIcon, 
  Code2, 
  Network, 
  Activity, 
  Shield, 
  FileText, 
  User, 
  Sparkles,
  Play,
  RotateCw,
  Download,
  Search,
  Settings,
  Keyboard,
  Monitor,
  Cpu,
  Zap
} from 'lucide-react';
import 'xterm/css/xterm.css';

interface TerminalSession {
  id: string;
  name: string;
  icon: React.ReactNode;
  terminal?: Terminal;
  fitAddon?: FitAddon;
  ws?: WebSocket;
}

const HOT_COMMANDS = [
  { id: 'miner-start', label: 'Launch Miner', command: 'stormecho-miner start\n', icon: <Activity className="w-4 h-4" /> },
  { id: 'auto-fund', label: 'Auto Fund', command: 'stormecho-autofund --execute\n', icon: <Download className="w-4 h-4" /> },
  { id: 'sys-update', label: 'System Update', command: 'sudo apt update && sudo apt upgrade -y\n', icon: <RotateCw className="w-4 h-4" /> },
  { id: 'scan-net', label: 'Network Scan', command: 'nmap -sn 192.168.1.0/24\n', icon: <Search className="w-4 h-4" /> },
  { id: 'pulse-check', label: 'Performance', command: 'stormecho-performance --status\n', icon: <Activity className="w-4 h-4" /> },
  { id: 'git-status', label: 'Git Status', command: 'git status\n', icon: <Code2 className="w-4 h-4" /> },
];

export function MaxTerminal() {
  useEffect(() => {
    // Initialize MasterLoop AI integration on component mount
    masterLoop.initialize().then(() => {
      console.log('🔥 MasterLoop AI integration activated');
    });
    
    return () => {
      // Cleanup MasterLoop on unmount
      masterLoop.destroy();
    };
  }, []);

  const [sessions] = useState<TerminalSession[]>([
    { id: 'dev', name: 'Dev / Code', icon: <Code2 className="w-4 h-4" /> },
    { id: 'network', name: 'Networking', icon: <Network className="w-4 h-4" /> },
    { id: 'mining', name: 'Mining / Auto', icon: <Activity className="w-4 h-4" /> },
    { id: 'security', name: 'Security', icon: <Shield className="w-4 h-4" /> },
    { id: 'logs', name: 'Logs', icon: <FileText className="w-4 h-4" /> },
    { id: 'personal', name: 'Personal', icon: <User className="w-4 h-4" /> },
    { id: 'wildcard', name: 'Wildcard', icon: <Sparkles className="w-4 h-4" /> },
  ]);
  const [activeSession, setActiveSession] = useState('dev');
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const terminalRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});
  const terminalsInitialized = useRef<Set<string>>(new Set());
  const terminalInstances = useRef<{ [key: string]: Terminal }>({});

  useEffect(() => {
    // Initialize terminal for active session
    if (!terminalsInitialized.current.has(activeSession)) {
      initializeTerminal(activeSession);
    }
  }, [activeSession, sessions]);

  const initializeTerminal = (sessionId: string) => {
    const session = sessions.find(s => s.id === sessionId);
    if (!session || !terminalRefs.current[sessionId]) return;

    const terminal = new Terminal({
      cursorBlink: true,
      theme: {
        background: '#000000',
        foreground: '#00ffea',
        cursor: '#00ffea',
        cursorAccent: '#000000',
        selectionBackground: '#00ffea33',
        black: '#000000',
        red: '#ff0066',
        green: '#00ff88',
        yellow: '#ffee00',
        blue: '#0088ff',
        magenta: '#ff00ff',
        cyan: '#00ffea',
        white: '#ffffff',
        brightBlack: '#666666',
        brightRed: '#ff3388',
        brightGreen: '#00ffaa',
        brightYellow: '#ffff00',
        brightBlue: '#00aaff',
        brightMagenta: '#ff66ff',
        brightCyan: '#00ffff',
        brightWhite: '#ffffff',
      },
      fontFamily: '"Cascadia Code", "Courier New", monospace',
      fontSize: 14,
      lineHeight: 1.2,
      letterSpacing: 0,
      allowProposedApi: true,
      allowTransparency: true,
      drawBoldTextInBrightColors: true,
    });

    const fitAddon = new FitAddon();
    const webLinksAddon = new WebLinksAddon();
    const serializeAddon = new SerializeAddon();

    terminal.loadAddon(fitAddon);
    terminal.loadAddon(webLinksAddon);
    terminal.loadAddon(serializeAddon);

    terminal.open(terminalRefs.current[sessionId]!);
    fitAddon.fit();

    // Restore previous session from localStorage
    const savedSession = localStorage.getItem(`terminal_session_${sessionId}`);
    if (savedSession) {
      terminal.write(savedSession);
    }

    // Welcome message
    if (!savedSession) {
      terminal.writeln(`\x1b[1;36m🌌 StormEcho Max Terminal - ${session.name}\x1b[0m`);
      terminal.writeln(`\x1b[1;32m✅ Session initialized with advanced capabilities\x1b[0m`);
      terminal.writeln(`\x1b[1;33m📋 Hot commands available in the menu above\x1b[0m`);
      terminal.writeln('');
    }

    // Connect to backend WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/api/terminal/${sessionId}`);

    ws.onopen = () => {
      terminal.writeln(`\x1b[1;32m✓ Connected to backend\x1b[0m`);
      terminal.write('\r\n$ ');
    };

    ws.onmessage = (event) => {
      terminal.write(event.data);
    };

    ws.onerror = (error) => {
      terminal.writeln(`\x1b[1;31m✗ Connection error: ${error}\x1b[0m`);
    };

    ws.onclose = () => {
      terminal.writeln(`\x1b[1;33m⚠ Connection closed\x1b[0m`);
    };

    // Handle terminal input
    terminal.onData((data) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
      
      // Save session data
      const currentSession = serializeAddon.serialize();
      localStorage.setItem(`terminal_session_${sessionId}`, currentSession);
    });

    // Handle resize
    const handleResize = () => {
      fitAddon.fit();
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'resize',
          cols: terminal.cols,
          rows: terminal.rows
        }));
      }
    };

    window.addEventListener('resize', handleResize);

    // Store references
    session.terminal = terminal;
    session.fitAddon = fitAddon;
    session.ws = ws;
    terminalsInitialized.current.add(sessionId);
    
    // Update MasterLoop activity
    masterLoop.updateSessionActivity(sessionId);
  };

  const executeCommand = (command: string) => {
    const session = sessions.find(s => s.id === activeSession);
    if (session?.terminal && session?.ws?.readyState === WebSocket.OPEN) {
      session.ws.send(command);
      // Update MasterLoop activity when command is executed
      masterLoop.updateSessionActivity(activeSession);
    }
  };

  const clearTerminal = () => {
    const session = sessions.find(s => s.id === activeSession);
    if (session?.terminal) {
      session.terminal.clear();
      localStorage.removeItem(`terminal_session_${activeSession}`);
    }
  };

  const handleKeyboardInput = (key: string, modifiers?: { ctrl?: boolean; alt?: boolean; shift?: boolean }) => {
    const session = sessions.find(s => s.id === activeSession);
    if (!session?.terminal) return;

    // Handle special keys and modifiers
    if (modifiers?.ctrl && key.length === 1) {
      // Ctrl+key combinations
      const ctrlCode = key.toLowerCase().charCodeAt(0) - 96;
      session.terminal.write(String.fromCharCode(ctrlCode));
    } else if (modifiers?.alt && key.length === 1) {
      // Alt+key combinations
      session.terminal.write(`\x1b${key}`);
    } else if (key.startsWith('Arrow')) {
      // Arrow keys
      const arrowMap: Record<string, string> = {
        'ArrowUp': '\x1b[A',
        'ArrowDown': '\x1b[B',
        'ArrowRight': '\x1b[C',
        'ArrowLeft': '\x1b[D'
      };
      session.terminal.write(arrowMap[key] || key);
    } else if (key.startsWith('F')) {
      // Function keys
      const functionMap: Record<string, string> = {
        'F1': '\x1bOP', 'F2': '\x1bOQ', 'F3': '\x1bOR', 'F4': '\x1bOS',
        'F5': '\x1b[15~', 'F6': '\x1b[17~', 'F7': '\x1b[18~', 'F8': '\x1b[19~',
        'F9': '\x1b[20~', 'F10': '\x1b[21~', 'F11': '\x1b[23~', 'F12': '\x1b[24~'
      };
      session.terminal.write(functionMap[key] || key);
    } else if (key === 'Enter') {
      session.terminal.write('\r\n');
    } else if (key === 'Tab') {
      session.terminal.write('\t');
    } else if (key === 'Backspace') {
      session.terminal.write('\b');
    } else if (key === 'Delete') {
      session.terminal.write('\x1b[3~');
    } else if (key === 'Home') {
      session.terminal.write('\x1b[H');
    } else if (key === 'End') {
      session.terminal.write('\x1b[F');
    } else if (key === 'PageUp') {
      session.terminal.write('\x1b[5~');
    } else if (key === 'PageDown') {
      session.terminal.write('\x1b[6~');
    } else if (key === 'Insert') {
      session.terminal.write('\x1b[2~');
    } else if (key === ' ') {
      session.terminal.write(' ');
    } else if (key.includes('\n')) {
      // Command execution
      if (session.ws?.readyState === WebSocket.OPEN) {
        session.ws.send(key);
      }
    } else {
      // Regular character input
      session.terminal.write(key);
    }

    // Store terminal instance for keyboard access
    terminalInstances.current[activeSession] = session.terminal;
  };

  return (
    <Card className="bg-black/90 backdrop-blur-lg border-cyan-500/30 p-4 w-full max-w-full">
      <div className="space-y-4">
        {/* Header with Hot Commands */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-cyan-500/30 pb-4 gap-4 sm:gap-2">
          <div className="flex items-center gap-2">
            <TerminalIcon className="w-6 h-6 text-cyan-400" />
            <h2 className="text-lg sm:text-xl font-bold text-cyan-400">Max Terminal System</h2>
          </div>
          
          <div className="flex items-center gap-2 flex-wrap">
            {/* Keyboard Toggle */}
            <Button
              onClick={() => setKeyboardVisible(!keyboardVisible)}
              size="sm"
              variant="outline"
              className={`border-cyan-500/30 hover:bg-cyan-500/10 ${keyboardVisible ? 'bg-cyan-500/20' : ''}`}
            >
              <Keyboard className="w-4 h-4 mr-2" />
              {keyboardVisible ? 'Hide' : 'Show'} Keyboard
            </Button>
            {/* Hot Commands */}
            <div className="flex flex-wrap gap-1">
              {HOT_COMMANDS.map((cmd) => (
                <Button
                  key={cmd.id}
                  variant="outline"
                  size="sm"
                  onClick={() => executeCommand(cmd.command)}
                  className="border-cyan-500/30 hover:bg-cyan-500/10 hover:border-cyan-400 text-xs shrink-0"
                  title={cmd.label}
                >
                  {cmd.icon}
                  <span className="ml-1 hidden xl:inline">{cmd.label}</span>
                </Button>
              ))}
            </div>
            
            {/* Terminal Controls */}
            <Button
              variant="outline"
              size="sm"
              onClick={clearTerminal}
              className="border-red-500/30 hover:bg-red-500/10 hover:border-red-400"
              title="Clear Terminal"
            >
              <RotateCw className="w-4 h-4" />
            </Button>
            
            <Link href="/terminal-settings">
              <Button
                variant="outline"
                size="sm"
                className="border-cyan-500/30 hover:bg-cyan-500/10 hover:border-cyan-400"
                title="Settings"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Terminal Tabs */}
        <Tabs value={activeSession} onValueChange={setActiveSession} className="w-full">
          <TabsList className="grid grid-cols-7 bg-black/50 border border-cyan-500/30 overflow-x-auto">
            {sessions.map((session) => (
              <TabsTrigger
                key={session.id}
                value={session.id}
                className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400 text-xs"
              >
                <div className="flex items-center gap-1">
                  {session.icon}
                  <span className="hidden md:inline">{session.name}</span>
                </div>
              </TabsTrigger>
            ))}
          </TabsList>

          {sessions.map((session) => (
            <TabsContent
              key={session.id}
              value={session.id}
              className="mt-4"
            >
              <div
                ref={(el) => terminalRefs.current[session.id] = el}
                className="h-[400px] sm:h-[450px] lg:h-[500px] bg-black rounded border border-cyan-500/30 overflow-hidden"
              />
            </TabsContent>
          ))}
        </Tabs>

        {/* Status Bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-cyan-400/70 border-t border-cyan-500/30 pt-2 gap-2 sm:gap-0">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              Connected
            </span>
            <span>Session: {activeSession}</span>
            <span>Multi-Session Enabled</span>
          </div>
          <div className="flex items-center gap-4">
            <span>Persistent History: ON</span>
            <span>Secure Mode: ACTIVE</span>
          </div>
        </div>

        {/* Terminal Keyboard Component */}
        <TerminalKeyboard
          onKeyPress={handleKeyboardInput}
          sessionType={activeSession}
          isVisible={keyboardVisible}
          onToggle={() => setKeyboardVisible(!keyboardVisible)}
        />
      </div>
    </Card>
  );
}