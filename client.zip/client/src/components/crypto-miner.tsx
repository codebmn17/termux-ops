import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Cpu, 
  Zap, 
  DollarSign, 
  TrendingUp, 
  Settings, 
  Play, 
  Pause, 
  AlertTriangle,
  Thermometer,
  Activity
} from 'lucide-react';

interface MiningStats {
  hashRate: number;
  temperature: number;
  power: number;
  earnings: number;
  uptime: number;
  efficiency: number;
}

export function CryptoMiner() {
  const [isActive, setIsActive] = useState(false);
  const [miningMode, setMiningMode] = useState<'eco' | 'balanced' | 'performance'>('balanced');
  const [stats, setStats] = useState<MiningStats>({
    hashRate: 0,
    temperature: 32,
    power: 0,
    earnings: 0,
    uptime: 0,
    efficiency: 0
  });
  
  // Note: This component simulates mining for demonstration only
  // Real mining would require actual hardware and mining software integration

  const miningConfigs = {
    eco: { hashRate: 125, power: 65, temp: 38, efficiency: 0.92 },
    balanced: { hashRate: 250, power: 120, temp: 45, efficiency: 0.85 },
    performance: { hashRate: 400, power: 180, temp: 55, efficiency: 0.78 }
  };

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        const config = miningConfigs[miningMode];
        const variance = 0.1; // 10% variance for realism
        
        setStats(prev => ({
          hashRate: config.hashRate * (1 + (Math.random() - 0.5) * variance),
          temperature: config.temp + Math.random() * 5,
          power: config.power * (1 + (Math.random() - 0.5) * variance),
          earnings: prev.earnings + (config.hashRate * 0.000001 * config.efficiency),
          uptime: prev.uptime + 1,
          efficiency: config.efficiency * (1 + (Math.random() - 0.5) * 0.05)
        }));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isActive, miningMode]);

  const toggleMining = () => {
    setIsActive(!isActive);
    if (!isActive) {
      setStats(prev => ({ ...prev, uptime: 0 }));
    }
  };

  const formatHashRate = (rate: number) => {
    if (rate >= 1000) return `${(rate / 1000).toFixed(1)} KH/s`;
    return `${rate.toFixed(0)} H/s`;
  };

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  const getTemperatureColor = (temp: number) => {
    if (temp < 40) return 'text-green-400';
    if (temp < 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="bg-black/40 backdrop-blur-sm border border-cyan-400/20 rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-cyan-400 flex items-center">
          <Cpu className="mr-2" size={20} />
          Automated Crypto Miner
        </h3>
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-green-400' : 'bg-gray-400'}`} />
          <span className="text-sm text-gray-300">
            {isActive ? 'Mining Active' : 'Stopped'}
          </span>
        </div>
      </div>

      {/* Mining Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-cyan-400 text-sm font-medium mb-3">Mining Mode</label>
          <div className="space-y-2">
            {Object.entries(miningConfigs).map(([mode, config]) => (
              <motion.button
                key={mode}
                onClick={() => setMiningMode(mode as any)}
                className={`w-full p-3 rounded-lg border text-left transition-all ${
                  miningMode === mode
                    ? 'border-cyan-400 bg-cyan-400/10'
                    : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium capitalize text-white">{mode}</span>
                  <span className="text-xs text-gray-400">{formatHashRate(config.hashRate)}</span>
                </div>
                <div className="text-xs text-gray-400">
                  {config.power}W • {config.temp}°C • {Math.round(config.efficiency * 100)}% eff
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <motion.button
            onClick={toggleMining}
            className={`w-full p-4 rounded-lg font-medium transition-all flex items-center justify-center space-x-2 ${
              isActive
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {isActive ? <Pause size={20} /> : <Play size={20} />}
            <span>{isActive ? 'Stop Mining' : 'Start Mining'}</span>
          </motion.button>

          {!isActive && (
            <div className="p-3 bg-yellow-400/10 border border-yellow-400/20 rounded-lg">
              <div className="flex items-start space-x-2">
                <AlertTriangle size={16} className="text-yellow-400 mt-0.5 flex-shrink-0" />
                <div className="text-xs">
                  <p className="text-yellow-400 font-medium mb-1">Important Notice</p>
                  <p className="text-gray-300">
                    This is a demo crypto miner interface. Real mining requires proper hardware, 
                    electricity costs consideration, and compliance with local regulations.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Mining Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-gray-800/30 border border-gray-600 rounded-lg p-3">
          <div className="flex items-center justify-between mb-1">
            <Activity size={14} className="text-cyan-400" />
            <span className="text-xs text-gray-400">H/s</span>
          </div>
          <div className="text-lg font-bold text-white">
            {formatHashRate(stats.hashRate)}
          </div>
          <div className="text-xs text-gray-400">Hash Rate</div>
        </div>

        <div className="bg-gray-800/30 border border-gray-600 rounded-lg p-3">
          <div className="flex items-center justify-between mb-1">
            <Thermometer size={14} className={getTemperatureColor(stats.temperature)} />
            <span className="text-xs text-gray-400">°C</span>
          </div>
          <div className={`text-lg font-bold ${getTemperatureColor(stats.temperature)}`}>
            {stats.temperature.toFixed(1)}
          </div>
          <div className="text-xs text-gray-400">Temperature</div>
        </div>

        <div className="bg-gray-800/30 border border-gray-600 rounded-lg p-3">
          <div className="flex items-center justify-between mb-1">
            <Zap size={14} className="text-yellow-400" />
            <span className="text-xs text-gray-400">W</span>
          </div>
          <div className="text-lg font-bold text-yellow-400">
            {stats.power.toFixed(0)}
          </div>
          <div className="text-xs text-gray-400">Power Draw</div>
        </div>

        <div className="bg-gray-800/30 border border-gray-600 rounded-lg p-3">
          <div className="flex items-center justify-between mb-1">
            <DollarSign size={14} className="text-green-400" />
            <span className="text-xs text-gray-400">USD</span>
          </div>
          <div className="text-lg font-bold text-green-400">
            {stats.earnings.toFixed(6)}
          </div>
          <div className="text-xs text-gray-400">Earnings</div>
        </div>

        <div className="bg-gray-800/30 border border-gray-600 rounded-lg p-3">
          <div className="flex items-center justify-between mb-1">
            <Settings size={14} className="text-blue-400" />
            <span className="text-xs text-gray-400">%</span>
          </div>
          <div className="text-lg font-bold text-blue-400">
            {(stats.efficiency * 100).toFixed(1)}
          </div>
          <div className="text-xs text-gray-400">Efficiency</div>
        </div>

        <div className="bg-gray-800/30 border border-gray-600 rounded-lg p-3">
          <div className="flex items-center justify-between mb-1">
            <TrendingUp size={14} className="text-purple-400" />
            <span className="text-xs text-gray-400">time</span>
          </div>
          <div className="text-lg font-bold text-purple-400">
            {formatUptime(stats.uptime)}
          </div>
          <div className="text-xs text-gray-400">Uptime</div>
        </div>
      </div>

      {/* Performance Graph Placeholder */}
      {isActive && (
        <motion.div
          className="mt-6 p-4 bg-gray-800/30 border border-gray-600 rounded-lg"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
        >
          <h4 className="text-cyan-400 font-medium mb-3 flex items-center">
            <TrendingUp size={16} className="mr-2" />
            Performance Monitor
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <div className="text-gray-400 mb-1">Daily Projection</div>
              <div className="text-green-400 font-bold">
                ${(stats.earnings * 86400).toFixed(4)} USD
              </div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Monthly Projection</div>
              <div className="text-green-400 font-bold">
                ${(stats.earnings * 86400 * 30).toFixed(2)} USD
              </div>
            </div>
            <div>
              <div className="text-gray-400 mb-1">Energy Cost/Day</div>
              <div className="text-red-400 font-bold">
                ${((stats.power * 24 * 0.12) / 1000).toFixed(2)} USD
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}