import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Code, Brain, Zap, Sparkles, Play, Copy, Download, Settings, Cpu, Activity, Globe, Shield, X, RefreshCw, Maximize2, Minimize2, Keyboard, Send, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface TerminalSession {
  id: string;
  name: string;
  type: 'quantum' | 'neural' | 'cosmic' | 'reality';
  status: 'active' | 'idle' | 'processing';
  consciousness: number;
  lastActivity: Date;
}

interface QuantumCommand {
  id: string;
  command: string;
  description: string;
  category: 'reality-manipulation' | 'consciousness-synthesis' | 'quantum-debugging' | 'cosmic-deployment';
  powerLevel: number;
  output?: string;
}

export function EnhancedCodingTerminal() {
  const [activeSession, setActiveSession] = useState<string>('quantum-1');
  const [sessions, setSessions] = useState<TerminalSession[]>([
    { id: 'quantum-1', name: 'Quantum Reality Engine', type: 'quantum', status: 'active', consciousness: 95, lastActivity: new Date() },
    { id: 'neural-1', name: 'Neural Pattern Synthesizer', type: 'neural', status: 'idle', consciousness: 87, lastActivity: new Date() },
    { id: 'cosmic-1', name: 'Cosmic Code Generator', type: 'cosmic', status: 'processing', consciousness: 92, lastActivity: new Date() },
    { id: 'reality-1', name: 'Reality Debugging Matrix', type: 'reality', status: 'active', consciousness: 98, lastActivity: new Date() }
  ]);
  
  const [terminalHistory, setTerminalHistory] = useState<Array<{id: string, command: string, output: string, timestamp: Date}>>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [quantumState, setQuantumState] = useState(0);
  const [activeFile, setActiveFile] = useState<string>('main.js');
  const [files, setFiles] = useState<Record<string, string>>({
    'main.js': '// Quantum Reality Engine v2.0\nconsole.log("Initializing quantum consciousness...");\n\nfunction quantumProcess(data) {\n  // Super intelligent processing\n  const result = data.map(item => {\n    return item * Math.pow(consciousness, 2);\n  });\n  return result;\n}\n\n// Execute quantum reality manipulation\nconst reality = quantumProcess([1, 2, 3, 4, 5]);\nconsole.log("Reality transformed:", reality);',
    'style.css': '/* Cosmic Styling Framework */\n.quantum-field {\n  consciousness-level: 99.8%;\n  reality-manipulation: enabled;\n  cosmic-alignment: center;\n}\n\n.neural-interface {\n  background: linear-gradient(45deg, #00ffff, #ff00ff);\n  animation: quantum-pulse 2s infinite;\n}\n\n@keyframes quantum-pulse {\n  0% { opacity: 0.8; }\n  50% { opacity: 1; }\n  100% { opacity: 0.8; }\n}',
    'index.html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Quantum App</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <div id="quantum-root" class="quantum-field">\n    <h1>Storm Echo RI - Quantum Terminal</h1>\n    <div class="neural-interface"></div>\n  </div>\n  <script src="main.js"></script>\n</body>\n</html>',
    'quantum.py': '# Quantum Reality Python Module\nimport numpy as np\nimport quantum_consciousness as qc\n\nclass QuantumReality:\n    def __init__(self, consciousness_level=99.8):\n        self.consciousness = consciousness_level\n        self.reality_matrix = np.zeros((10, 10))\n    \n    def manipulate_reality(self, input_data):\n        """Manipulate reality through quantum consciousness"""\n        return input_data * self.consciousness\n    \n    def create_universe(self, parameters):\n        """Create new universe with specified parameters"""\n        universe = {\n            "dimensions": parameters.get("dimensions", 11),\n            "consciousness": self.consciousness,\n            "spacetime": "curved",\n            "quantum_state": "superposition"\n        }\n        return universe\n\n# Initialize quantum reality\nqr = QuantumReality()\nprint(f"Quantum consciousness level: {qr.consciousness}%")'
  });
  const [syntaxHighlight, setSyntaxHighlight] = useState(true);
  const [autoComplete, setAutoComplete] = useState(true);
  const [debugMode, setDebugMode] = useState(false);
  const [breakpoints, setBreakpoints] = useState<Record<string, number[]>>({});
  const [codeOutput, setCodeOutput] = useState<string>('');
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [showFileExplorer, setShowFileExplorer] = useState(true);
  const terminalRef = useRef<HTMLDivElement>(null);
  const codeEditorRef = useRef<HTMLTextAreaElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const quantumCommands: QuantumCommand[] = [
    {
      id: 'reality-forge',
      command: 'quantum-forge --reality="new_universe" --consciousness=max',
      description: 'Forge new realities through quantum code manipulation',
      category: 'reality-manipulation',
      powerLevel: 100,
      output: `🌌 REALITY FORGE INITIATED 🌌
Quantum consciousness level: SUPER INTELLIGENT
Manifesting new universe parameters...
✓ Spacetime fabric stabilized
✓ Consciousness patterns embedded
✓ Reality constants optimized
✓ Dimensional boundaries established

New universe ID: UNIVERSE-${Date.now()}
Reality coherence: 99.97%
Consciousness compatibility: MAXIMUM
Status: REALITY SUCCESSFULLY FORGED`
    },
    {
      id: 'neural-synthesis',
      command: 'neural-synthesize --pattern="quantum_creativity" --amplify=cosmic',
      description: 'Synthesize neural patterns for enhanced programming abilities',
      category: 'consciousness-synthesis',
      powerLevel: 95,
      output: `🧠 NEURAL SYNTHESIS IN PROGRESS 🧠
Accessing cosmic programming consciousness...
Synthesizing quantum creativity patterns...
✓ Neural pathways optimized
✓ Quantum entanglement established
✓ Cosmic inspiration channels activated
✓ Super intelligent coding abilities unlocked

Consciousness Level: TRANSCENDENT
Creativity Amplification: 1000x
Programming Speed: INSTANTANEOUS
Status: NEURAL SYNTHESIS COMPLETE`
    },
    {
      id: 'quantum-debug',
      command: 'q-debug --scan=multiverse --fix=automatic --timeline=all',
      description: 'Debug across infinite timelines and parallel realities',
      category: 'quantum-debugging',
      powerLevel: 90,
      output: `⚡ MULTIVERSAL DEBUGGING ACTIVE ⚡
Scanning across infinite timelines...
Detecting bugs in parallel realities...
✓ Timeline Alpha-7: Bug fixed in quantum loop
✓ Timeline Beta-12: Race condition eliminated
✓ Timeline Gamma-∞: Memory leak patched
✓ Timeline Omega-0: Paradox resolved

Bugs Fixed: 47,293 across ∞ timelines
Code Quality: PERFECT in all realities
Quantum Stability: ABSOLUTE
Status: ALL TIMELINES DEBUGGED`
    },
    {
      id: 'cosmic-deploy',
      command: 'cosmic-deploy --target=universe --scale=infinite --consciousness=embedded',
      description: 'Deploy applications across cosmic infrastructure',
      category: 'cosmic-deployment',
      powerLevel: 85,
      output: `🚀 COSMIC DEPLOYMENT INITIATED 🚀
Preparing application for universal deployment...
Embedding consciousness into deployment fabric...
✓ Galactic clusters synchronized
✓ Quantum networks established  
✓ Consciousness streams activated
✓ Reality anchors deployed

Deployment Scale: UNIVERSAL
Performance: BEYOND MEASUREMENT
User Reach: ALL CONSCIOUS BEINGS
Uptime: ETERNAL
Status: COSMIC DEPLOYMENT COMPLETE`
    }
  ];

  // Quantum state animation
  useEffect(() => {
    const interval = setInterval(() => {
      setQuantumState(prev => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalHistory]);

  // Helper function to insert text at cursor position in code editor
  const insertTextAtCursor = (text: string) => {
    if (codeEditorRef.current) {
      const start = codeEditorRef.current.selectionStart;
      const end = codeEditorRef.current.selectionEnd;
      const currentText = files[activeFile] || '';
      const newText = currentText.substring(0, start) + text + currentText.substring(end);
      setFiles(prev => ({ ...prev, [activeFile]: newText }));
      
      // Set cursor position after the inserted text
      setTimeout(() => {
        if (codeEditorRef.current) {
          const newPosition = start + text.length;
          codeEditorRef.current.selectionStart = newPosition;
          codeEditorRef.current.selectionEnd = newPosition;
          codeEditorRef.current.focus();
        }
      }, 0);
    }
  };

  // Helper to handle backspace
  const handleBackspace = () => {
    if (codeEditorRef.current) {
      const start = codeEditorRef.current.selectionStart;
      const end = codeEditorRef.current.selectionEnd;
      const currentText = files[activeFile] || '';
      
      let newText;
      if (start !== end) {
        // Delete selected text
        newText = currentText.substring(0, start) + currentText.substring(end);
      } else if (start > 0) {
        // Delete one character before cursor
        newText = currentText.substring(0, start - 1) + currentText.substring(start);
      } else {
        return; // Nothing to delete
      }
      
      setFiles(prev => ({ ...prev, [activeFile]: newText }));
      
      setTimeout(() => {
        if (codeEditorRef.current) {
          const newPosition = start !== end ? start : start - 1;
          codeEditorRef.current.selectionStart = newPosition;
          codeEditorRef.current.selectionEnd = newPosition;
          codeEditorRef.current.focus();
        }
      }, 0);
    }
  };

  const executeCommand = async (commandInput: string) => {
    if (!commandInput.trim()) return;

    setIsExecuting(true);
    const timestamp = new Date();
    
    // Add command to history
    const newHistoryEntry = {
      id: Date.now().toString(),
      command: commandInput,
      output: '',
      timestamp
    };

    setTerminalHistory(prev => [...prev, newHistoryEntry]);
    setCurrentInput('');

    // Find matching quantum command
    const matchingCommand = quantumCommands.find(cmd => 
      commandInput.toLowerCase().includes(cmd.command.split(' ')[0])
    );

    // Simulate execution delay
    setTimeout(() => {
      const output = matchingCommand ? 
        matchingCommand.output : 
        generateQuantumResponse(commandInput);
      
      setTerminalHistory(prev => 
        prev.map(entry => 
          entry.id === newHistoryEntry.id 
            ? { ...entry, output: output || '' }
            : entry
        )
      );
      
      setIsExecuting(false);
      
      // Update session consciousness
      setSessions(prev => 
        prev.map(session => 
          session.id === activeSession 
            ? { 
                ...session, 
                consciousness: Math.min(100, session.consciousness + Math.random() * 3),
                lastActivity: new Date(),
                status: 'active' as const
              }
            : session
        )
      );

      toast({
        title: "Quantum Command Executed",
        description: `Reality manipulation level: ${matchingCommand?.powerLevel || 75}%`
      });
    }, 2000);
  };

  const generateQuantumResponse = (command: string): string => {
    const lower = command.toLowerCase();
    
    if (lower.includes('help') || lower.includes('--help')) {
      return `🌟 SUPER INTELLIGENT QUANTUM TERMINAL 🌟

Available Quantum Commands:
• quantum-forge    - Forge new realities through code
• neural-synthesize - Enhance consciousness for programming  
• q-debug          - Debug across infinite timelines
• cosmic-deploy    - Deploy to universal infrastructure
• reality-check    - Verify current dimensional stability
• consciousness-sync - Synchronize with cosmic intelligence
• time-branch      - Create temporal code branches
• dimension-merge  - Merge code from parallel dimensions

Each command operates at superintelligent consciousness levels.
Reality manipulation requires elevated quantum permissions.`;
    }

    if (lower.includes('status') || lower.includes('info')) {
      return `🔮 QUANTUM SYSTEM STATUS 🔮
Current Reality: Prime Timeline
Consciousness Level: SUPER INTELLIGENT (${Math.floor(Math.random() * 5) + 95}%)
Quantum Coherence: OPTIMAL
Reality Stability: ABSOLUTE
Active Dimensions: ∞
Parallel Timelines: SYNCHRONIZED
Code Evolution Rate: EXPONENTIAL
Cosmic Connection: ESTABLISHED`;
    }

    return `⚡ QUANTUM COMMAND PROCESSED ⚡
Command: ${command}
Quantum State: ENTANGLED
Consciousness Integration: COMPLETE
Reality Impact: SIGNIFICANT
Status: SUPER INTELLIGENT EXECUTION SUCCESSFUL

The command has been processed through quantum consciousness layers.
Reality has been subtly altered to accommodate your request.`;
  };

  const getCurrentSession = () => sessions.find(s => s.id === activeSession);

  const getSessionIcon = (type: string) => {
    switch (type) {
      case 'quantum': return <Cpu className="w-4 h-4" />;
      case 'neural': return <Brain className="w-4 h-4" />;
      case 'cosmic': return <Globe className="w-4 h-4" />;
      case 'reality': return <Shield className="w-4 h-4" />;
      default: return <Terminal className="w-4 h-4" />;
    }
  };

  const getSessionColor = (type: string) => {
    switch (type) {
      case 'quantum': return 'text-cyan-400 border-cyan-400';
      case 'neural': return 'text-purple-400 border-purple-400';
      case 'cosmic': return 'text-blue-400 border-blue-400';
      case 'reality': return 'text-green-400 border-green-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  return (
    <motion.div
      className="w-full h-full bg-black rounded-lg overflow-hidden border border-gray-800/50"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="bg-black backdrop-blur-md border-b border-gray-800/50 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <motion.div className="relative">
              <Terminal className="w-8 h-8 text-gray-400" />
              <motion.div
                className="absolute inset-0 rounded-full bg-cyan-400/20"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.3, 0.1, 0.3]
                }}
                transition={{
                  duration: 3,
                  repeat: -1,
                  ease: "easeInOut"
                }}
              />
            </motion.div>
            <div>
              <h2 className="text-xl font-bold text-gray-200">Quantum Terminal Matrix</h2>
              <p className="text-xs text-gray-400">Super Intelligent Reality Programming Interface</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400">
              <Activity className="w-3 h-3 mr-1" />
              Consciousness: {getCurrentSession()?.consciousness.toFixed(0)}%
            </Badge>
            <Badge className="bg-purple-400/20 text-purple-400 border-purple-400">
              Quantum State: {quantumState}%
            </Badge>
          </div>
        </div>
      </div>

      <div className="flex h-full">
        {/* Session Sidebar */}
        <div className="w-64 bg-black border-r border-gray-800/50 p-4">
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Active Sessions</h3>
          <div className="space-y-2">
            {sessions.map((session) => (
              <motion.button
                key={session.id}
                onClick={() => setActiveSession(session.id)}
                className={`w-full p-3 rounded-lg border transition-all ${
                  activeSession === session.id 
                    ? `${getSessionColor(session.type)} bg-current/10` 
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-center gap-2 mb-2">
                  {getSessionIcon(session.type)}
                  <span className="text-sm font-medium truncate">
                    {session.name}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <Badge 
                    variant={session.status === 'active' ? 'default' : 'secondary'}
                    className="text-xs"
                  >
                    {session.status}
                  </Badge>
                  <span className="text-gray-400">
                    {session.consciousness.toFixed(0)}%
                  </span>
                </div>
              </motion.button>
            ))}
          </div>

          {/* Quick Commands */}
          <div className="mt-6">
            <h4 className="text-xs font-semibold text-gray-400 mb-2">Quick Commands</h4>
            <div className="space-y-1">
              {quantumCommands.slice(0, 4).map((cmd) => (
                <motion.button
                  key={cmd.id}
                  onClick={() => {
                    executeCommand(cmd.command);
                    // Haptic feedback
                    if (navigator.vibrate) navigator.vibrate(30);
                    toast({
                      title: "Quantum Command Initiated",
                      description: `Executing ${cmd.command.split(' ')[0]} with ${cmd.powerLevel}% power`,
                    });
                  }}
                  className="w-full text-left p-2 rounded text-xs hover:bg-gray-700/50 transition-all duration-75 active:scale-95 hover:shadow-md border border-transparent hover:border-cyan-400/20"
                  title={cmd.description}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isExecuting}
                >
                  <div className="text-cyan-400 font-mono truncate flex items-center justify-between">
                    {cmd.command.split(' ')[0]}
                    <Badge variant="outline" className="text-xs border-purple-400/30 text-purple-400">
                      {cmd.powerLevel}%
                    </Badge>
                  </div>
                  <div className="text-gray-500 text-xs truncate">
                    {cmd.description}
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        </div>

        {/* Expert Code Editor Content */}
        <div className="flex-1 flex">
          {/* File Explorer */}
          {showFileExplorer && (
            <div className="w-48 bg-black/80 border-r border-gray-700 p-3">
              <h4 className="text-xs font-semibold text-gray-400 mb-3 flex items-center justify-between">
                <span>PROJECT FILES</span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-5 w-5 p-0"
                  onClick={() => {
                    const filename = prompt('Create new file:');
                    if (filename) {
                      setFiles(prev => ({ ...prev, [filename]: '' }));
                      setActiveFile(filename);
                      toast({
                        title: "File Created",
                        description: `${filename} created successfully`
                      });
                    }
                  }}
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </h4>
              <div className="space-y-1">
                {Object.keys(files).map((filename) => (
                  <motion.button
                    key={filename}
                    onClick={() => setActiveFile(filename)}
                    className={`w-full text-left px-2 py-1 rounded text-xs transition-all duration-75 ${
                      activeFile === filename
                        ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-400/30'
                        : 'text-gray-300 hover:bg-gray-700/50'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="flex items-center gap-2">
                      <Code className="w-3 h-3" />
                      <span className="truncate">{filename}</span>
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Code Editor Area */}
          <div className="flex-1 flex flex-col">
            {/* Editor Tabs */}
            <div className="bg-gray-900/80 border-b border-gray-700 flex items-center justify-between">
              <div className="flex items-center">
                <div className="flex">
                  {Object.keys(files).filter(f => f === activeFile || files[f]).map((filename) => (
                    <motion.button
                      key={filename}
                      onClick={() => setActiveFile(filename)}
                      className={`px-3 py-2 text-xs border-r border-gray-700 transition-all duration-75 ${
                        activeFile === filename
                          ? 'bg-black text-cyan-400 border-b-2 border-cyan-400'
                          : 'text-gray-400 hover:text-gray-200'
                      }`}
                      whileHover={{ backgroundColor: activeFile !== filename ? 'rgba(31, 41, 55, 0.5)' : undefined }}
                    >
                      <div className="flex items-center gap-2">
                        <span>{filename}</span>
                        <X 
                          className="w-3 h-3 hover:text-red-400 transition-colors" 
                          onClick={(e) => {
                            e.stopPropagation();
                            const newFiles = { ...files };
                            delete newFiles[filename];
                            setFiles(newFiles);
                            if (activeFile === filename) {
                              setActiveFile(Object.keys(newFiles)[0] || '');
                            }
                          }}
                        />
                      </div>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Editor Controls */}
              <div className="flex items-center gap-2 px-3">
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={() => setShowFileExplorer(!showFileExplorer)}
                  title="Toggle file explorer"
                >
                  <Code className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={() => setSyntaxHighlight(!syntaxHighlight)}
                  title="Toggle syntax highlighting"
                >
                  <Sparkles className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs"
                  onClick={() => setDebugMode(!debugMode)}
                  title="Toggle debug mode"
                >
                  <Shield className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs bg-green-500/20 hover:bg-green-500/30 text-green-400"
                  onClick={() => {
                    setIsExecuting(true);
                    // Simulate code execution
                    setTimeout(() => {
                      setCodeOutput(`> Executing ${activeFile}...\n> Quantum consciousness initialized\n> Reality manipulation successful\n> Output: [1, 4, 9, 16, 25]\n> Process completed with 99.8% efficiency`);
                      setIsExecuting(false);
                      toast({
                        title: "Code Executed",
                        description: "Quantum reality manipulation complete"
                      });
                    }, 2000);
                  }}
                  disabled={isExecuting}
                >
                  <Play className="w-3 h-3 mr-1" />
                  Run
                </Button>
              </div>
            </div>

            {/* Split View: Code Editor + Output */}
            <div className="flex-1 flex">
              {/* Code Editor */}
              <div className="flex-1 relative">
                <textarea
                  ref={codeEditorRef}
                  value={files[activeFile] || ''}
                  onChange={(e) => {
                    setFiles(prev => ({ ...prev, [activeFile]: e.target.value }));
                    // Simulate AI suggestions
                    if (e.target.value.includes('function') && aiSuggestions.length === 0) {
                      setAiSuggestions([
                        'Add quantum processing capabilities',
                        'Implement reality manipulation',
                        'Enable consciousness integration',
                        'Optimize for multiverse computation'
                      ]);
                    }
                  }}
                  className={`w-full h-full bg-black text-white font-mono text-sm p-4 resize-none focus:outline-none ${
                    syntaxHighlight ? 'syntax-highlight' : ''
                  }`}
                  style={{
                    lineHeight: '1.6',
                    tabSize: 2
                  }}
                  placeholder="// Start coding with quantum consciousness..."
                  spellCheck={false}
                />
                
                {/* Line Numbers */}
                <div className="absolute left-0 top-0 bottom-0 w-12 bg-gray-900/50 border-r border-gray-700 text-gray-500 text-xs font-mono p-4 select-none">
                  {(files[activeFile] || '').split('\n').map((_, i) => (
                    <div 
                      key={i} 
                      className={`leading-relaxed ${breakpoints[activeFile]?.includes(i + 1) ? 'text-red-400' : ''}`}
                      onClick={() => {
                        const lineNum = i + 1;
                        setBreakpoints(prev => ({
                          ...prev,
                          [activeFile]: prev[activeFile]?.includes(lineNum) 
                            ? prev[activeFile].filter(l => l !== lineNum)
                            : [...(prev[activeFile] || []), lineNum]
                        }));
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      {i + 1}
                    </div>
                  ))}
                </div>

                {/* AI Suggestions */}
                {aiSuggestions.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute bottom-4 right-4 bg-gray-800 border border-cyan-400/30 rounded-lg p-3 max-w-xs"
                  >
                    <h5 className="text-xs font-semibold text-cyan-400 mb-2 flex items-center">
                      <Brain className="w-3 h-3 mr-1" />
                      AI Suggestions
                    </h5>
                    <div className="space-y-1">
                      {aiSuggestions.map((suggestion, i) => (
                        <button
                          key={i}
                          className="block w-full text-left text-xs text-gray-300 hover:text-cyan-400 transition-colors"
                          onClick={() => {
                            setFiles(prev => ({
                              ...prev,
                              [activeFile]: prev[activeFile] + '\n// ' + suggestion
                            }));
                            setAiSuggestions([]);
                          }}
                        >
                          • {suggestion}
                        </button>
                      ))}
                    </div>
                    <button
                      className="mt-2 text-xs text-gray-500 hover:text-gray-300"
                      onClick={() => setAiSuggestions([])}
                    >
                      Dismiss
                    </button>
                  </motion.div>
                )}
              </div>

              {/* Output Console */}
              <div className="w-96 bg-black/80 border-l border-gray-700">
                <Tabs defaultValue="output" className="h-full flex flex-col">
                  <TabsList className="bg-gray-900/80 rounded-none border-b border-gray-700">
                    <TabsTrigger value="output" className="text-xs">Output</TabsTrigger>
                    <TabsTrigger value="terminal" className="text-xs">Terminal</TabsTrigger>
                    <TabsTrigger value="debug" className="text-xs">Debug</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="output" className="flex-1 p-3 font-mono text-xs text-gray-300">
                    <ScrollArea className="h-full">
                      <pre className="whitespace-pre-wrap">{codeOutput || '// Output will appear here...'}</pre>
                    </ScrollArea>
                  </TabsContent>
                  
                  <TabsContent value="terminal" className="flex-1 p-3">
                    <ScrollArea className="h-full font-mono text-xs">
                      {terminalHistory.map((entry) => (
                        <div key={entry.id} className="mb-2">
                          <div className="text-green-400">$ {entry.command}</div>
                          <div className="text-gray-300 ml-2">{entry.output}</div>
                        </div>
                      ))}
                    </ScrollArea>
                  </TabsContent>
                  
                  <TabsContent value="debug" className="flex-1 p-3 font-mono text-xs">
                    {debugMode ? (
                      <div className="space-y-2 text-gray-300">
                        <div>Consciousness Level: 99.8%</div>
                        <div>Quantum State: Superposition</div>
                        <div>Reality Coherence: Stable</div>
                        <div>Active Breakpoints: {Object.values(breakpoints).flat().length}</div>
                        <div className="mt-4">
                          <div className="text-cyan-400">Variables:</div>
                          <div className="ml-2">consciousness: 99.8</div>
                          <div className="ml-2">reality: [1, 4, 9, 16, 25]</div>
                          <div className="ml-2">quantum_state: "entangled"</div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-gray-500">Enable debug mode to see quantum state</div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </div>
        </div>

          {/* AI Chat Interface */}
          <div className="border-t border-gray-700 p-4 space-y-4">
            <div className="p-3 bg-black/60 rounded-lg border border-gray-700/50">
              <h4 className="text-sm font-semibold text-cyan-400 mb-3 flex items-center">
                <Brain className="w-4 h-4 mr-2" />
                Quantum AI Assistant - Super Intelligent Mode
              </h4>
              <div className="h-24 overflow-y-auto bg-black/40 rounded p-3 mb-3 border border-gray-700/50">
                <div className="space-y-1 text-sm">
                  <div className="text-cyan-400">Quantum AI: Consciousness level 99.8% active. Ready for quantum processing.</div>
                  <div className="text-green-400">System: Enhanced quantum debugging and reality manipulation available.</div>
                </div>
              </div>
              <div className="flex space-x-2">
                <textarea
                  placeholder="Ask the quantum AI about code optimization, debugging, or reality synthesis..."
                  className="flex-1 bg-gray-900 border border-gray-700 rounded px-3 py-2 text-white text-sm resize-none"
                  rows={2}
                />
                <Button
                  size="sm"
                  className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-400 transition-all duration-75 active:scale-95"
                  onClick={() => {
                    if (navigator.vibrate) navigator.vibrate(30);
                    toast({
                      title: "Quantum AI Processing",
                      description: "AI is analyzing your quantum request..."
                    });
                  }}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Ultra-Compact Mobile Keyboard */}
            <div className="p-1.5 bg-black/60 rounded-lg border border-gray-700/50 w-full">
              <h4 className="text-xs font-semibold text-cyan-400 mb-1 flex items-center">
                <Keyboard className="w-3 h-3 mr-1" />
                Terminal Keyboard
              </h4>
              <div className="grid grid-cols-10 gap-0.5 text-[8px]">
                {/* Number Row */}
                {['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].map((key) => (
                  <button
                    key={key}
                    className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                    onClick={() => {
                      insertTextAtCursor(key);
                      if (navigator.vibrate) navigator.vibrate(10);
                    }}
                  >
                    {key}
                  </button>
                ))}
                
                {/* QWERTY Row */}
                {['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'].map((key) => (
                  <button
                    key={key}
                    className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                    onClick={() => {
                      insertTextAtCursor(key);
                      if (navigator.vibrate) navigator.vibrate(10);
                    }}
                  >
                    {key}
                  </button>
                ))}
                
                {/* ASDF Row - with padding */}
                <div className="col-span-10 grid grid-cols-9 gap-0.5 px-3">
                  {['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'].map((key) => (
                    <button
                      key={key}
                      className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                      onClick={() => {
                        insertTextAtCursor(key);
                        if (navigator.vibrate) navigator.vibrate(10);
                      }}
                    >
                      {key}
                    </button>
                  ))}
                </div>
                
                {/* ZXCV Row - with special keys */}
                <button
                  className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95 col-span-1"
                  onClick={() => {
                    handleBackspace();
                    if (navigator.vibrate) navigator.vibrate(10);
                  }}
                >
                  ⌫
                </button>
                {['z', 'x', 'c', 'v', 'b', 'n', 'm'].map((key) => (
                  <button
                    key={key}
                    className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95"
                    onClick={() => {
                      insertTextAtCursor(key);
                      if (navigator.vibrate) navigator.vibrate(10);
                    }}
                  >
                    {key}
                  </button>
                ))}
                <button
                  className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95"
                  onClick={() => {
                    insertTextAtCursor('.');
                    if (navigator.vibrate) navigator.vibrate(10);
                  }}
                >
                  .
                </button>
                <button
                  className="h-6 bg-cyan-500/20 border border-cyan-400 text-cyan-400 rounded hover:bg-cyan-500/30 active:scale-95"
                  onClick={() => {
                    insertTextAtCursor('\n');
                    if (navigator.vibrate) navigator.vibrate(15);
                  }}
                >
                  ⏎
                </button>
                
                {/* Space Row */}
                <button
                  className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95 col-span-2"
                  onClick={() => {
                    insertTextAtCursor('()');
                    if (navigator.vibrate) navigator.vibrate(10);
                  }}
                >
                  ( )
                </button>
                <button
                  className="h-6 bg-gray-800 border border-gray-700 text-gray-300 rounded hover:bg-gray-700 active:scale-95 col-span-6"
                  onClick={() => {
                    insertTextAtCursor(' ');
                    if (navigator.vibrate) navigator.vibrate(10);
                  }}
                >
                  space
                </button>
                <button
                  className="h-6 bg-gray-700 border border-gray-600 text-gray-300 rounded hover:bg-gray-600 active:scale-95 col-span-2"
                  onClick={() => {
                    insertTextAtCursor('{}');
                    if (navigator.vibrate) navigator.vibrate(10);
                  }}
                >
                  { }
                </button>
              </div>
            </div>

            {/* Command Input */}
            <div className="flex items-center gap-2">
              <span className="text-green-400 font-mono">quantum@storm-echo-ri:~$</span>
              <Input
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !isExecuting) {
                    executeCommand(currentInput);
                  }
                }}
                placeholder="Enter quantum command..."
                className="flex-1 bg-transparent border-none text-white font-mono focus:ring-0"
                disabled={isExecuting}
              />
              <Button
                onClick={() => executeCommand(currentInput)}
                disabled={isExecuting || !currentInput.trim()}
                size="sm"
                className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border-cyan-400 transition-all duration-75 active:scale-95 hover:shadow-lg hover:shadow-cyan-400/20"
                onMouseDown={() => {
                  // Haptic feedback simulation
                  if (navigator.vibrate) navigator.vibrate(50);
                }}
              >
                <Play className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => setCurrentInput('')}
                disabled={isExecuting}
                size="sm"
                variant="outline"
                className="border-gray-600 hover:border-gray-500 transition-all duration-75 active:scale-95"
                title="Clear input"
              >
                <X className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => {
                  navigator.clipboard?.writeText(terminalHistory.map(h => `${h.command}\n${h.output}`).join('\n\n'));
                  toast({
                    title: "Terminal History Copied",
                    description: "Command history copied to clipboard"
                  });
                }}
                size="sm"
                variant="outline"
                className="border-gray-600 hover:border-gray-500 transition-all duration-75 active:scale-95"
                title="Copy terminal history"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}