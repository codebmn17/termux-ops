import { useState, useEffect, lazy } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Codex from "@/pages/codex";
import Chat from "@/pages/chat";
import Payments from "@/pages/payments";
import PassiveIncome from "@/pages/passive-income";
import AIFeatures from "@/pages/ai-features";
import CodingTerminals from "@/pages/coding-terminals";
import BackendPortal from "@/pages/backend-portal";
import MaxTerminalPage from "@/pages/max-terminal-page";
import VoiceChamber from "@/pages/voice-chamber";
import Storage from "@/pages/storage";
import AICompanionPage from "@/pages/ai-companion";
import NotFound from "@/pages/not-found";
import Library from "@/pages/library";
import AICloningPage from "@/pages/ai-cloning";
import AIAutomationPage from "@/pages/ai-automation";
import ConsciousnessCloning from "@/pages/consciousness-cloning";
import ProcessorCore from "@/pages/processor-core";
import DonatePage from "@/pages/donate";
import ShopPage from "@/pages/shop";
import StormConsole from "@/pages/storm-console";
import { ControlCenter } from "@/components/control-center";
import { HolographicDisplay } from "@/components/holographic-display";
import { StartupAccelerator as StartupAcceleratorComponent } from "@/components/startup-accelerator";
import { InstantBootup } from "@/components/instant-bootup";
import { QuickAccessMenu } from "@/components/quick-access-menu";



function Router() {
  return (
    <div className="min-h-screen bg-background text-foreground transition-fast">
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/codex" component={Codex} />
        <Route path="/chat" component={Chat} />
        <Route path="/payments" component={Payments} />
        <Route path="/passive-income" component={PassiveIncome} />
        <Route path="/ai-features" component={AIFeatures} />
        <Route path="/coding-terminals" component={CodingTerminals} />
        <Route path="/terminal" component={CodingTerminals} />
        <Route path="/backend-portal" component={BackendPortal} />
        <Route path="/max-terminal" component={MaxTerminalPage} />
        <Route path="/voice-chamber" component={VoiceChamber} />
        <Route path="/storage" component={Storage} />
        <Route path="/ai-companion" component={AICompanionPage} />
        <Route path="/library" component={Library} />
        <Route path="/ai-cloning" component={AICloningPage} />
        <Route path="/ai-automation" component={AIAutomationPage} />
        <Route path="/consciousness-cloning" component={ConsciousnessCloning} />
        <Route path="/processor-core" component={ProcessorCore} />
        <Route path="/analytics" component={lazy(() => import('./pages/analytics'))} />
        <Route path="/startup-accelerator" component={lazy(() => import('./pages/startup-accelerator'))} />
        <Route path="/network-manager" component={lazy(() => import('./pages/network-manager'))} />
        <Route path="/donate" component={DonatePage} />
        <Route path="/shop" component={ShopPage} />
        <Route path="/storm-console" component={StormConsole} />
        <Route path="/monetization-admin" component={lazy(() => import('./pages/monetization-admin'))} />
        <Route path="/ai-chat" component={lazy(() => import('./pages/ai-chat'))} />
        <Route path="/stealth-admin" component={lazy(() => import('./pages/stealth-admin'))} />
        <Route path="/real-ops-core" component={lazy(() => import('./pages/real-ops-core'))} />
        <Route path="/terminal-settings" component={lazy(() => import('./pages/terminal-settings'))} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  const [showInstantBoot, setShowInstantBoot] = useState(false); // Disabled for now to show main app
  
  const [showStartup, setShowStartup] = useState(false);

  const handleInstantBootComplete = () => {
    setShowInstantBoot(false);
    sessionStorage.setItem('hasShownInstantBoot', 'true');
  };

  const handleStartupComplete = () => {
    setShowStartup(false);
    sessionStorage.setItem('hasShownStartup', 'true');
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {showInstantBoot && (
          <InstantBootup onComplete={handleInstantBootComplete} />
        )}
        {showStartup && (
          <StartupAcceleratorComponent onComplete={handleStartupComplete} />
        )}
        {!showStartup && (
          <>
            <Toaster />
            <Router />
            <ControlCenter />

            <QuickAccessMenu />

          </>
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
